% ============================================================================
% CONSTRAINT STORY: ai_governance_legitimacy__technocratic_optimization_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_ai_governance_legitimacy__technocratic_optimization_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    constraint_indexing:directionality_override/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: ai_governance_legitimacy__technocratic_optimization_reading
 *   human_readable: AI Governance Legitimacy via Technocratic Optimization
 *   domain: theological_ethics/technology_governance/political_theology
 *
 * SUMMARY:
 *   This reading instantiates AI governance legitimacy as grounded in
 *   technocratic optimization: aggregate welfare, efficiency, and innovation
 *   are the primary goods, with dignity and solidarity principles treated as
 *   secondary constraints to be balanced against feasibility and growth.
 *   Authority rests with technical expertise and demonstrated performance.
 *   The encyclical's principles are acknowledged as aspirational values but
 *   subordinated to optimization imperatives. The constraint is CLAIMED as
 *   mountain (a foundational feature of governance rationality) but declares
 *   beneficiaries and victims, triggering FSM evaluation. The claim-metric
 *   divergence is deliberate: the reading asserts technocratic optimization
 *   is the natural authority basis while the metrics document moderate
 *   extraction and rising enforcement intensity.
 *
 * KEY AGENTS:
 *   - tech_firms: Agenda-setters (institutional/arbitrage) — define optimization metrics and operationalize governance
 *   - investors: Beneficiaries (powerful/mobile) — capture returns from efficiency-maximized deployment
 *   - high_skill_workers: Beneficiaries (moderate/mobile) — earn premiums under technocratic authority
 *   - early_adopters: Beneficiaries (moderate/constrained) — access productivity gains from rapid deployment
 *   - displaced_workers: Payers (powerless/trapped) — lose employment to automation justified by aggregate metrics
 *   - digitally_excluded_communities: Payers (powerless/trapped) — designed out of systems optimized for connected majorities
 *   - algorithmically_profiled_populations: Payers (powerless/identity_locked) — systematically disadvantaged by majority-optimized models
 *   - magisterial_interpreters: Excluded (institutional/analytical) — assert dignity constraints but lack authority in technocratic frameworks
 *   - democratic_governance_advocates: Excluded (organized/constrained) — contest technocratic legitimacy claim
 *   - academic_ethicists: Observers (analytical/analytical) — document optimization-dignity tensions
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(ai_governance_legitimacy__technocratic_optimization_reading, 0.35).
domain_priors:suppression_score(ai_governance_legitimacy__technocratic_optimization_reading, 0.42).
domain_priors:theater_ratio(ai_governance_legitimacy__technocratic_optimization_reading, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, extractiveness, 0.35).
narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 0.42).
narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, resistance, 0.54).

% --- Constraint claim ---
narrative_ontology:constraint_claim(ai_governance_legitimacy__technocratic_optimization_reading, mountain).
narrative_ontology:human_readable(ai_governance_legitimacy__technocratic_optimization_reading, "AI Governance Legitimacy via Technocratic Optimization").
narrative_ontology:topic_domain(ai_governance_legitimacy__technocratic_optimization_reading, "theological_ethics/technology_governance/political_theology").

domain_priors:requires_active_enforcement(ai_governance_legitimacy__technocratic_optimization_reading).
domain_priors:emerges_naturally(ai_governance_legitimacy__technocratic_optimization_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(ai_governance_legitimacy__technocratic_optimization_reading, '9e9a8148-2df4-405c-a8fd-e686cd67d65e').
narrative_ontology:cs_kernel_codification('9e9a8148-2df4-405c-a8fd-e686cd67d65e', distributed).
narrative_ontology:cs_authority_grounding('9e9a8148-2df4-405c-a8fd-e686cd67d65e', expertise).
narrative_ontology:cs_interpretation_layer_present('9e9a8148-2df4-405c-a8fd-e686cd67d65e').
narrative_ontology:cs_reading_relation('9e9a8148-2df4-405c-a8fd-e686cd67d65e', ai_governance_legitimacy__magisterial_subsidiarity_reading, coexists_with).
narrative_ontology:cs_reading_relation('9e9a8148-2df4-405c-a8fd-e686cd67d65e', ai_governance_legitimacy__democratic_pluralist_reading, coexists_with).
narrative_ontology:cs_reading_relation('9e9a8148-2df4-405c-a8fd-e686cd67d65e', ai_governance_legitimacy__market_libertarian_reading, influences).
narrative_ontology:cs_axiom('9e9a8148-2df4-405c-a8fd-e686cd67d65e', foundational, aggregate_welfare_primary).
narrative_ontology:cs_axiom_status(aggregate_welfare_primary, holdable).
narrative_ontology:cs_axiom_grounding('9e9a8148-2df4-405c-a8fd-e686cd67d65e', aggregate_welfare_primary, instrumental).
narrative_ontology:cs_axiom('9e9a8148-2df4-405c-a8fd-e686cd67d65e', foundational, expertise_grounds_authority).
narrative_ontology:cs_axiom_status(expertise_grounds_authority, holdable).
narrative_ontology:cs_axiom_grounding('9e9a8148-2df4-405c-a8fd-e686cd67d65e', expertise_grounds_authority, conventional).
narrative_ontology:cs_axiom('9e9a8148-2df4-405c-a8fd-e686cd67d65e', secondary, dignity_as_constraint_not_target).
narrative_ontology:cs_axiom_status(dignity_as_constraint_not_target, holdable).
narrative_ontology:cs_axiom_grounding('9e9a8148-2df4-405c-a8fd-e686cd67d65e', dignity_as_constraint_not_target, instrumental).
narrative_ontology:cs_reference_frame('9e9a8148-2df4-405c-a8fd-e686cd67d65e', optimization_rationality_paradigm).
narrative_ontology:cs_drift_state('9e9a8148-2df4-405c-a8fd-e686cd67d65e', post_encyclical_era, gap(authority_erosion, minor, false)).
narrative_ontology:cs_created_at('9e9a8148-2df4-405c-a8fd-e686cd67d65e', '2026-06-11T14:32:00Z').
narrative_ontology:cs_kernel_id(ai_governance_legitimacy__technocratic_optimization_reading, ai_governance_legitimacy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__technocratic_optimization_reading, tech_firms).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__technocratic_optimization_reading, investors).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__technocratic_optimization_reading, high_skill_workers).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__technocratic_optimization_reading, early_adopters).
narrative_ontology:constraint_victim(ai_governance_legitimacy__technocratic_optimization_reading, displaced_workers).
narrative_ontology:constraint_victim(ai_governance_legitimacy__technocratic_optimization_reading, digitally_excluded_communities).
narrative_ontology:constraint_victim(ai_governance_legitimacy__technocratic_optimization_reading, algorithmically_profiled_populations).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Define AI development priorities, set performance benchmarks, and operationalize governance frameworks. They frame legitimacy as optimization efficiency and translate ethical principles into engineering constraints. Exit options include jurisdictional arbitrage and private standard-setting.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, tech_firms, agenda_setter,
    institutional, generational, arbitrage, global).

% Capture returns from AI innovation scaled under efficiency-maximizing governance. They fund projects that demonstrate technical performance and growth potential, treating ethical constraints as risk factors to be priced rather than categorical limits.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, investors, beneficiary,
    powerful, biographical, mobile, global).

% Earn wage premiums in AI development roles. Their expertise is valued under technocratic authority structures. They can exit to competing firms or adjacent sectors, giving them negotiating leverage within the optimization framework.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, high_skill_workers, beneficiary,
    moderate, biographical, mobile, global).

% Access productivity gains and service improvements from rapidly deployed AI systems. They bear some risk from immature technology but gain first-mover advantages. Exit requires forgoing efficiency gains that become infrastructure.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, early_adopters, beneficiary,
    moderate, biographical, constrained, regional).

% Lose employment to automation justified by aggregate welfare maximization. Retraining programs are secondary to deployment speed. Their displacement is treated as a transitional cost rather than a constraint on the optimization function itself.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, displaced_workers, payer,
    powerless, biographical, trapped, national).

% Lack infrastructure access required to benefit from AI systems optimized for connected populations. Their exclusion is acknowledged as a distribution problem to be addressed after core optimization, not as a constraint on system design.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, digitally_excluded_communities, payer,
    powerless, generational, trapped, regional).

% Subject to classification and prediction systems optimized for aggregate accuracy rather than individual fairness. Their demographic characteristics make them systematically disadvantaged by models trained on majority patterns. Exit is blocked by ubiquitous deployment.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, algorithmically_profiled_populations, payer,
    powerless, biographical, identity_locked, national).

% Assert that dignity and solidarity should constrain rather than follow from optimization. They lack implementation authority in technocratic frameworks where expertise means technical performance, not moral philosophy.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, magisterial_interpreters, excluded,
    institutional, civilizational, analytical, global).

% Argue for participatory governance and consent mechanisms. They contest the technocratic legitimacy claim but face collective action problems when competing against concentrated technical authority and capital.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, democratic_governance_advocates, excluded,
    organized, generational, constrained, national).

% Document tensions between optimization imperatives and dignity-based principles. They analyze how efficiency framing shapes governance outcomes but lack direct authority over deployment decisions.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, academic_ethicists, observer,
    analytical, biographical, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Aligns AI development around measurable performance metrics: accuracy, efficiency, deployment speed, aggregate welfare proxies. Solves the collective action problem of defining success criteria when multiple stakeholders have competing values.
% TRANSFER_FUNCTION: Moves decision authority from democratic or magisterial bodies to technical experts and capital holders. Moves productivity gains from labor to capital and high-skill workers. Moves algorithmic risk from populations with exit options to those without.
% ABSENT_VOICES: Displaced workers whose livelihoods are optimization targets, not optimization agents. Digitally excluded communities designed out of systems optimized for connected majorities. Populations profiled by opaque algorithms who cannot contest classifications. These seats lack the technical expertise that grounds authority in this framework.
% DISAPPEARANCE_RATIONALE: If this legitimacy frame vanished, AI governance would reorganize around alternative authority sources: magisterial principles, democratic deliberation, or market libertarianism. Development priorities would shift from efficiency maximization to dignity protection or decentralization. The distribution of AI gains and risks would change dramatically.
% FOUNDING_PROBLEM: How to coordinate rapid AI development when stakeholders disagree about values. Early AI governance faced fragmentation: incompatible principles, competing oversight claims, deadlock between efficiency and equity. The optimization frame resolved this by establishing technical performance as the neutral coordination point.
% FOUNDING_PROBLEM_CORROBORATION: Tech firms and optimization advocates attest the coordination problem remains live and only technical expertise can manage AI complexity. Magisterial interpreters, democratic advocates, and displaced worker organizations attest the founding problem is supplanted: the current deadlock is between optimization imperatives and dignity principles, not between incompatible technical approaches. The latter reading is corroborated by legislative hearings, civil society testimony, and academic ethics research documenting systematic subordination of vulnerable populations to efficiency metrics.
narrative_ontology:disappearance_verdict(ai_governance_legitimacy__technocratic_optimization_reading, world_rearranges).
narrative_ontology:founding_problem_status(ai_governance_legitimacy__technocratic_optimization_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(ai_governance_legitimacy__technocratic_optimization_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(ai_governance_legitimacy__technocratic_optimization_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(ai_governance_legitimacy__technocratic_optimization_reading_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, ExtMetricName, E),
    domain_priors:suppression_score(ai_governance_legitimacy__technocratic_optimization_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(ai_governance_legitimacy__technocratic_optimization_reading),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(ai_governance_legitimacy__technocratic_optimization_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is moderate (0.35 at interval end, rising from 0.22 at founding) because efficiency maximization systematically transfers gains to capital and high-skill labor while displacing lower-skill workers and excluding digitally disconnected populations. The transfer is framed as optimization rather than extraction, but the structural outcome is asymmetric: beneficiaries have exit options and authority, victims are trapped and excluded from decision-making. Suppression rises (0.28 → 0.42) as technocratic frameworks harden into infrastructure: regulatory capture gives technical experts veto power, algorithmic deployment becomes ubiquitous, and alternative governance frames are marginalized as infeasible. Theater is moderate-low (0.28) because ethics boards and impact assessments perform real work but are structurally subordinate to optimization imperatives — they constrain rather than guide. Resistance is substantial (0.54) from displaced workers, excluded communities, and dignity-principle advocates who contest the optimization framing itself. Accessibility collapse is moderate (0.48) because alternative governance frames remain conceptually available even as implementation authority consolidates.
 *
 * PERSPECTIVAL GAP:
 *   From the agenda-setter seat (tech firms), this constraint is genuine coordination around performance metrics that enable rapid innovation. From the powerless payer seats (displaced workers, excluded communities, profiled populations), the same structure operates as imposed optimization that systematically subordinates their interests to aggregate efficiency. The engine computes this divergence from the structural data: beneficiaries with exit and authority experience rope-like coordination; victims without exit or voice experience extraction justified by optimization rhetoric.
 *
 * DIRECTIONALITY LOGIC:
 *   Tech firms are structural beneficiaries with agenda-setting authority (d near beneficiary end). Investors and high-skill workers benefit from optimization-driven gains (d beneficiary-side). Early adopters sit near symmetric: genuine coordination benefit, some risk exposure. Displaced workers, excluded communities, and profiled populations are targets (d near target end): they bear costs framed as transitional or secondary to aggregate welfare, with no exit and no authority. Magisterial interpreters and democratic advocates are excluded rather than coordinated — their principles are treated as constraints on optimization, not sources of legitimacy.
 *
 * MANDATROPHY ANALYSIS:
 *   The optimization frame presents itself as coordination (aligning development around measurable success criteria) but operates with substantial asymmetric extraction (gains to capital and expertise, costs to displaced and excluded populations). This is the tangled_rope signature: genuine coordination function (solving fragmentation via performance metrics) bundled with extraction (authority concentrated among those who benefit, systematic exclusion of those who pay). The mandatrophy question is whether the coordination function requires the current distribution of authority and costs, or whether alternative governance frames (magisterial, democratic) could coordinate AI development while distributing gains and authority differently.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    natural_vs_constructed_optimization,
    'Is technocratic optimization a natural feature of rational governance (mountain claim), or a constructed arrangement that benefits technical experts and capital holders (rope or tangled_rope)?',
    'Historical comparison of AI governance outcomes under alternative legitimacy frames (democratic, magisterial, market). If optimization imperatives emerge convergently across frames, the mountain claim is supported. If outcomes systematically vary with authority structure, the constraint is constructed.',
    'If natural, the beneficiary/victim asymmetry is an unavoidable feature of efficient coordination. If constructed, the asymmetry is a choice embedded in authority allocation, and alternative frames are feasible.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(natural_vs_constructed_optimization, empirical, 'Whether optimization as legitimacy basis is foundational or serves beneficiary interests').

omega_variable(
    coordination_extraction_separability,
    'Can the coordination function (aligning development around performance metrics) be separated from the extraction structure (gains to capital/expertise, costs to displaced/excluded)?',
    'Policy experiments with alternative governance: worker representation on AI ethics boards, democratic oversight of deployment decisions, magisterial accountability frameworks. If coordination holds while distribution shifts, the functions are separable.',
    'If separable, current extraction is contingent on authority concentration rather than inherent to coordination. If inseparable, the asymmetry is the price of solving fragmentation.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(coordination_extraction_separability, conceptual, 'Whether optimization coordination requires current beneficiary structure').

omega_variable(
    dignity_as_constraint_vs_target,
    'Is dignity properly treated as a constraint on optimization (this reading) or as the optimization target itself (magisterial reading)?',
    'Philosophical analysis of dignity''s conceptual role: is it a side-constraint (protections that optimization must respect) or a maximand (the good that optimization should pursue)? Empirical test: do dignity violations systematically correlate with optimization success or failure?',
    'If dignity is a constraint, technocratic optimization is the appropriate frame and dignity principles set feasibility bounds. If dignity is the target, technocratic optimization subordinates the wrong variable and alternative frames are normatively superior.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(dignity_as_constraint_vs_target, preference, 'Normative ordering between efficiency and dignity in governance legitimacy').

omega_variable(
    expertise_authority_scope,
    'Does technical expertise ground authority over all AI governance decisions, or only over technical implementation within democratically or magisterially set bounds?',
    'Jurisdictional analysis: which governance questions are technical (expertise grounds authority) and which are normative (democratic or magisterial authority primary)? Cross-cultural comparison of where different traditions draw this boundary.',
    'If expertise grounds comprehensive authority, technocratic optimization is the legitimate frame for all AI decisions. If expertise is bounded, optimization must be subordinated to democratic or magisterial principles for normative questions.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(expertise_authority_scope, conceptual, 'Scope of technical expertise as authority basis').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(ai_governance_legitimacy__technocratic_optimization_reading, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(ai_g_tr_t0, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 0, 0.15).
narrative_ontology:measurement(ai_g_tr_t5, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 5, 0.18).
narrative_ontology:measurement(ai_g_tr_t10, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 10, 0.21).
narrative_ontology:measurement(ai_g_tr_t15, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 15, 0.24).
narrative_ontology:measurement(ai_g_tr_t20, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 20, 0.26).
narrative_ontology:measurement(ai_g_tr_t25, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 25, 0.28).

% Extraction over time
narrative_ontology:measurement(ai_g_be_t0, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 0, 0.22).
narrative_ontology:measurement(ai_g_be_t5, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 5, 0.26).
narrative_ontology:measurement(ai_g_be_t10, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 10, 0.29).
narrative_ontology:measurement(ai_g_be_t15, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 15, 0.32).
narrative_ontology:measurement(ai_g_be_t20, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 20, 0.34).
narrative_ontology:measurement(ai_g_be_t25, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 25, 0.35).

% Suppression requirement over time
narrative_ontology:measurement(ai_g_su_t0, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 0, 0.28).
narrative_ontology:measurement(ai_g_su_t5, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 5, 0.32).
narrative_ontology:measurement(ai_g_su_t10, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 10, 0.36).
narrative_ontology:measurement(ai_g_su_t15, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 15, 0.39).
narrative_ontology:measurement(ai_g_su_t20, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 20, 0.41).
narrative_ontology:measurement(ai_g_su_t25, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 25, 0.42).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(ai_governance_legitimacy__technocratic_optimization_reading, enforcement_mechanism).
narrative_ontology:affects_constraint(ai_governance_legitimacy__technocratic_optimization_reading, ai_governance_legitimacy__magisterial_subsidiarity_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__technocratic_optimization_reading, ai_governance_legitimacy__democratic_pluralist_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__technocratic_optimization_reading, ai_governance_legitimacy__market_libertarian_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the ai_governance_legitimacy kernel. The kernel decomposes into four readings with different authority sources (technical expertise, Magisterium, democratic publics, market mechanisms) and different beneficiary/victim structures. The technocratic reading has moderate extraction (0.35) concentrated on displaced workers and excluded communities; the magisterial reading has lower extraction via subsidiarity and solidarity constraints; the democratic reading distributes authority through consent mechanisms; the market reading has the lowest suppression but highest accessibility collapse via exit as sole protection. Each reading is a structurally distinct constraint with its own ε, linked via network.affects_constraints.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

constraint_indexing:directionality_override(ai_governance_legitimacy__technocratic_optimization_reading, institutional, 0.15).

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
