% ============================================================================
% CONSTRAINT STORY: woman_category__intersex_accommodation_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-01-15
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_woman_category__intersex_accommodation_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: woman_category__intersex_accommodation_reading
 *   human_readable: Woman Category: Intersex Accommodation Reading
 *   domain: political_philosophy/law/social_policy/bioethics
 *
 * SUMMARY:
 *   This constraint is ONE READING of the contested 'woman category' kernel.
 *   It grounds category membership in biological sex understood as a spectrum
 *   rather than a binary, including intersex variations that are
 *   female-typical or ambiguous within the woman category rather than forcing
 *   binary assignment. The reading claims to emerge from biological reality
 *   (mountain framing) but extraction concentrates in elite sports where
 *   boundary cases create high-stakes eligibility disputes and require
 *   invasive testing. The constraint coordinates most institutional sex
 *   segregation with low extraction (intersex people are a small population),
 *   but the sports boundary cases generate substantial per-person costs. KEY
 *   AGENTS (by structural relationship): - intersex_people: Primary
 *   beneficiaries (powerless/identity_locked) — gain recognition and
 *   categorical inclusion - intersex_athletes_with_ambiguous_biology: Primary
 *   targets (powerless/identity_locked) — bear concentrated eligibility costs
 *   in elite sports - policy_administrators_binary_systems: Secondary payers
 *   (institutional/constrained) — bear administrative complexity costs -
 *   bioethics_researchers: Analytical observers (institutional/analytical) —
 *   study categorical justice implications - binary_enforcement_advocates,
 *   identity_primacy_advocates: Excluded voices (organized/mobile) —
 *   challenge foundational premises from opposed directions
 *
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(woman_category__intersex_accommodation_reading, 0.42).
domain_priors:suppression_score(woman_category__intersex_accommodation_reading, 0.38).
domain_priors:theater_ratio(woman_category__intersex_accommodation_reading, 0.22).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, extractiveness, 0.42).
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, suppression_requirement, 0.38).
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, theater_ratio, 0.22).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, accessibility_collapse, 0.72).
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, resistance, 0.48).

% --- Constraint claim ---
narrative_ontology:constraint_claim(woman_category__intersex_accommodation_reading, mountain).
narrative_ontology:human_readable(woman_category__intersex_accommodation_reading, "Woman Category: Intersex Accommodation Reading").
narrative_ontology:topic_domain(woman_category__intersex_accommodation_reading, "political_philosophy/law/social_policy/bioethics").

domain_priors:requires_active_enforcement(woman_category__intersex_accommodation_reading).
domain_priors:emerges_naturally(woman_category__intersex_accommodation_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(woman_category__intersex_accommodation_reading, 'a7910c3a-b12d-4033-a741-5f792577a3f8').
narrative_ontology:cs_kernel_codification('a7910c3a-b12d-4033-a741-5f792577a3f8', distributed).
narrative_ontology:cs_authority_grounding('a7910c3a-b12d-4033-a741-5f792577a3f8', distributed).
narrative_ontology:cs_reading_relation('a7910c3a-b12d-4033-a741-5f792577a3f8', woman_category__sex_biology_reading, influences).
narrative_ontology:cs_reading_relation('a7910c3a-b12d-4033-a741-5f792577a3f8', woman_category__gender_identity_reading, coexists_with).
narrative_ontology:cs_axiom('a7910c3a-b12d-4033-a741-5f792577a3f8', foundational, biological_sex_is_spectrum_not_binary).
narrative_ontology:cs_axiom_status(biological_sex_is_spectrum_not_binary, holdable).
narrative_ontology:cs_axiom_grounding('a7910c3a-b12d-4033-a741-5f792577a3f8', biological_sex_is_spectrum_not_binary, empirically_contingent).
narrative_ontology:cs_axiom('a7910c3a-b12d-4033-a741-5f792577a3f8', foundational, intersex_variations_warrant_categorical_inclusion).
narrative_ontology:cs_axiom_status(intersex_variations_warrant_categorical_inclusion, holdable).
narrative_ontology:cs_axiom_grounding('a7910c3a-b12d-4033-a741-5f792577a3f8', intersex_variations_warrant_categorical_inclusion, deontological).
narrative_ontology:cs_reference_frame('a7910c3a-b12d-4033-a741-5f792577a3f8', pre_high_profile_sports_cases).
narrative_ontology:cs_drift_state('a7910c3a-b12d-4033-a741-5f792577a3f8', post_semenya_cas_ruling_era, gap(practice_drift, substantial, true)).
narrative_ontology:cs_created_at('a7910c3a-b12d-4033-a741-5f792577a3f8', '').
narrative_ontology:cs_kernel_id(woman_category__intersex_accommodation_reading, woman_category).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(woman_category__intersex_accommodation_reading, intersex_people).
narrative_ontology:constraint_beneficiary(woman_category__intersex_accommodation_reading, female_typical_biology_athletes).
narrative_ontology:constraint_beneficiary(woman_category__intersex_accommodation_reading, medical_research_community).
narrative_ontology:constraint_victim(woman_category__intersex_accommodation_reading, intersex_athletes_with_ambiguous_biology).
narrative_ontology:constraint_victim(woman_category__intersex_accommodation_reading, policy_administrators_binary_systems).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% People with intersex variations that do not fit binary male/female categories. This reading acknowledges their biological reality and includes them in the woman category where their biology is female-typical or ambiguous rather than forcing them into a male category or excluding them entirely. They cannot exit their biological reality; the constraint shapes whether they are legally and socially recognized.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, intersex_people, beneficiary,
    powerless, biographical, identity_locked, global).

% Athletes with typical XX female biology competing in women's sports categories. This reading preserves women's sport categories by acknowledging that some intersex variations do not confer male-typical advantages, while creating boundary cases where advantage must be assessed rather than assumed from binary assignment.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, female_typical_biology_athletes, beneficiary,
    moderate, biographical, constrained, global).

% Medical and biological researchers studying sex development and variation. This reading aligns legal/social categories with biological complexity they observe, enabling more accurate research design and medical care for intersex conditions rather than forcing data into binary categories.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, medical_research_community, beneficiary,
    institutional, generational, mobile, global).

% Athletes with intersex variations that place them in boundary cases for competition eligibility (Caster Semenya case). While the reading acknowledges their biology as real, they bear concentrated costs in elite sports: invasive testing, eligibility disputes, hormonal suppression requirements, or categorical exclusion. The small population size means individual cases become high-visibility disputes. Exit is identity-locked: they cannot change their biology, and leaving sport means abandoning career investments.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, intersex_athletes_with_ambiguous_biology, payer,
    powerless, biographical, identity_locked, global).

% Government agencies and sports governing bodies administering sex-segregated programs built on binary categories. This reading requires them to develop complex eligibility criteria, case-by-case assessment protocols, and hormonal testing regimes for boundary cases. Their administrative costs are higher than under strict binary enforcement; they face litigation from multiple directions regardless of how boundaries are drawn.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, policy_administrators_binary_systems, payer,
    institutional, immediate, constrained, national).

% Social and political movements advocating for strict binary sex categories in law and policy. This reading treats their position as empirically incomplete rather than normatively authoritative; they argue biological complexity is being weaponized to undermine women's sex-based rights and that intersex variations are rare edge cases that should not reshape categorical boundaries.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, binary_enforcement_advocates, excluded,
    organized, generational, mobile, national).

% Movements advocating for gender identity as the sole basis for category membership. This reading treats biological factors as constraining category membership in some contexts; they argue that any biological criteria reinscribe oppressive medical gatekeeping and that self-identification should be the universal standard.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, identity_primacy_advocates, excluded,
    organized, generational, mobile, global).

% Academic researchers studying categorical justice, bodily autonomy, and the ethics of classification systems. They analyze how different readings distribute costs and recognition across intersex people, binary-sex people, and transgender people, and examine which empirical claims about biological variation are well-supported versus contested.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, bioethics_researchers, observer,
    institutional, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Coordinates sex-segregated institutional arrangements (sports, prisons, shelters, medical research cohorts) by providing a categorical boundary that acknowledges biological complexity while maintaining distinction from male-typical biology. Solves the real problem that strict binary enforcement misclassifies people whose biology does not fit either binary category cleanly.
% TRANSFER_FUNCTION: Transfers recognition and legal inclusion to intersex people with female-typical or ambiguous biology, while transferring administrative complexity and case-assessment costs to institutions. In elite sports specifically, transfers eligibility uncertainty and testing burdens to intersex athletes in boundary cases.
% ABSENT_VOICES: Binary enforcement advocates and identity primacy advocates are structurally excluded from authoritative standing in this reading: the former because it treats binary categories as empirically incomplete, the latter because it treats biological factors as sometimes determinative. Both groups would challenge the reading's foundational premise if they had seats at the definitional table.
% DISAPPEARANCE_RATIONALE: If this reading vanished overnight, intersex people would face forced binary assignment (likely to male category for many with ambiguous biology), women's sports would revert to either strict binary exclusion or identity-based inclusion with different boundary problems, medical research would lose granularity in sex-based analysis, and litigation over categorical boundaries would shift to different grounds. The institutional arrangements built on sex categories would reorganize around one of the sibling readings.
% FOUNDING_PROBLEM: Binary male/female categories empirically misclassify people with intersex variations, forcing them into categories that do not match their biology and creating unjust exclusions or misrecognitions. The problem became acute in international sport with high-profile cases of athletes with intersex conditions being disqualified or required to undergo hormonal suppression despite having female-typical or ambiguous biology.
% FOUNDING_PROBLEM_CORROBORATION: Medical and biological research communities document that intersex variations occur in approximately 1.7% of live births and that these variations create a spectrum rather than a strict binary (corroboration from outside beneficiaries: peer-reviewed endocrinology and genetics research, clinical case studies). Sports medicine researchers document that not all intersex variations confer male-typical athletic advantages (independent empirical work). Intersex advocacy organizations and affected individuals provide first-person testimony of harms from forced binary classification (affected parties, but corroborated by independent medical ethics analysis).
narrative_ontology:disappearance_verdict(woman_category__intersex_accommodation_reading, world_rearranges).
narrative_ontology:founding_problem_status(woman_category__intersex_accommodation_reading, live).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(woman_category__intersex_accommodation_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(woman_category__intersex_accommodation_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(woman_category__intersex_accommodation_reading_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, ExtMetricName, E),
    domain_priors:suppression_score(woman_category__intersex_accommodation_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(woman_category__intersex_accommodation_reading),
    narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(woman_category__intersex_accommodation_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is moderate (0.42) because most policy domains accommodate intersex variations at low cost given small population size, but elite sports create concentrated per-person extraction through testing regimes and eligibility disputes. Suppression is moderate-low (0.38) because the constraint requires active enforcement of boundary criteria but faces resistance from both binary-enforcement and identity-primacy movements. Theater ratio is low (0.22) because most administrative complexity is genuine coordination cost rather than performative, though some sports testing protocols are more invasive than necessary for advantage assessment. Accessibility collapse is moderate-high (0.72) because biological reality constrains alternatives significantly but boundary-drawing choices remain contested. Resistance is moderate (0.48) because the reading faces opposition from both directions: binary advocates resisting spectrum acknowledgment and identity advocates resisting biological criteria.
 *   
 *   The measurement series shows modest extraction accumulation over time as sports governing bodies developed more elaborate testing and suppression protocols, and as high-profile cases increased administrative theater around boundary enforcement. The shared time grid ensures every metric is authored at each examined point.
 *
 * PERSPECTIVAL GAP:
 *   Seats should compute differently based on domain context. In most policy domains (ID documents, medical care, legal recognition), intersex people experience this as coordination with low extraction — recognition of biological reality. In elite sports specifically, intersex athletes with ambiguous biology experience the same reading as high-extraction despite the recognition benefit, because boundary assessment requires invasive testing and hormonal suppression. Policy administrators experience it as increased coordination cost across all domains. The engine computes these domain-specific seat divergences from the power/exit/scope positioning and the directed extraction toward specific victim groups.
 *
 * DIRECTIONALITY LOGIC:
 *   Intersex people are structural beneficiaries (gain recognition, inclusion, medical alignment) with powerless/identity_locked positioning — directionality near beneficiary end, low effective extraction. Intersex athletes in boundary cases are targets (bear testing, suppression, exclusion costs) with same positioning but concentrated extraction in sports context — directionality toward target end despite benefiting from recognition in other domains. Policy administrators are institutional payers (bear complexity costs) with constrained exit — moderate directionality. Medical researchers are institutional beneficiaries (gain categorical alignment with observed biology) with mobile exit — directionality near beneficiary end. Binary and identity advocates are excluded rather than coordinated.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint demonstrates mandatrophy tension: its mandate (coordinate sex-segregated institutions by acknowledging biological complexity) remains live, but its operation extracts substantially from intersex athletes in boundary cases through testing regimes that exceed genuine advantage-assessment needs. The theater ratio and extraction accumulation over time suggest drift from pure coordination toward institutionalized gatekeeping. However, extraction remains domain-specific rather than universal, and the small population size means aggregate extraction is lower than per-person concentration suggests. The claim/metric divergence (mountain claim, moderate extraction metrics) captures this tension: the reading asserts grounding in biological fact while its enforcement instantiates extractive boundary maintenance.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    mountain_vs_constructed_boundary,
    'Is the acknowledgment of biological sex as a spectrum a discovery of natural fact (mountain), or is the specific way this reading draws categorical boundaries around ''woman'' a constructed choice among multiple empirically-compatible framings?',
    'Comparison of this reading''s categorical boundaries with alternative spectrum-acknowledging frameworks that draw lines differently (e.g., advantage-based sport categories, multi-category legal recognition, eliminated sex categories in some domains). If multiple boundary-drawing schemes are compatible with the same biological evidence, the reading is constructed rather than discovered.',
    'If constructed, the constraint is a policy choice that benefits intersex people with female-typical biology at the expense of clearer bright-line rules, rather than a natural law. If mountain, disagreement with the reading is empirical error rather than legitimate value contestation. Classification would shift from mountain toward rope or tangled_rope if construction is established.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(mountain_vs_constructed_boundary, conceptual, 'Natural fact vs. constructed categorical boundary').

omega_variable(
    advantage_assessment_vs_categorical_inclusion,
    'In elite sports contexts, is the high extraction from intersex athletes in boundary cases an unavoidable cost of fairly assessing competitive advantage, or is it excess suppression serving categorical-purity goals beyond advantage assessment?',
    'Empirical analysis of which intersex variations confer male-typical advantages, comparison of testing protocols to genuine advantage-detection needs, examination of whether eligibility criteria track advantage or categorical assignment. If protocols are more invasive or exclusionary than advantage assessment requires, extraction is excessive.',
    'Determines whether sports-domain extraction is coordination cost (genuine advantage assessment) or extractive overhead (categorical gatekeeping). High excess extraction would shift classification toward snare for the sports subdomain while leaving other domains as rope.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(advantage_assessment_vs_categorical_inclusion, empirical, 'Necessary advantage assessment vs. excess categorical suppression in sports').

omega_variable(
    spectrum_endpoint_ambiguity,
    'Where does this reading place the boundary between ''female-typical/ambiguous biology included in woman category'' and ''male-typical biology excluded''? Is the boundary drawn at clear biological markers or does it remain contested?',
    'Examination of case law, sports governing body eligibility criteria, and medical diagnostic protocols to identify what specific markers (hormone levels, chromosome patterns, anatomical features, developmental history) are treated as determinative versus indeterminate. Mapping of intersex variations to categorical assignments under this reading.',
    'An ambiguous or shifting boundary increases extraction for people near the boundary (more testing, more uncertainty, more case-by-case discretion) and indicates the reading is under-specified. A clear biological boundary would support the mountain claim; a contested boundary would indicate constructed line-drawing.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(spectrum_endpoint_ambiguity, empirical, 'Boundary specification for spectrum categories').

omega_variable(
    committer_frame_coexistence,
    'Do the three readings (sex_biology, intersex_accommodation, gender_identity) coexist as simultaneously held positions by different parties, or does adopting one reading logically foreclose the others within a single institutional framework?',
    'Analysis of jurisdictions and institutions: can a single legal system or sports body hold multiple readings simultaneously for different purposes, or does committing to one reading require displacing the others? Examination of whether readings make incompatible empirical claims or merely different normative prioritizations.',
    'If readings coexist, each is a legitimate framing choice and contestation is about values/policy rather than truth. If readings foreclose each other, one is correct and the others are error, shifting the constraint toward higher-stakes truth claims and potentially higher suppression of alternative views.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(committer_frame_coexistence, conceptual, 'Coexistence vs. foreclosure of sibling readings').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(woman_category__intersex_accommodation_reading, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(woma_tr_t0, woman_category__intersex_accommodation_reading, theater_ratio, 0, 0.12).
narrative_ontology:measurement(woma_tr_t5, woman_category__intersex_accommodation_reading, theater_ratio, 5, 0.15).
narrative_ontology:measurement(woma_tr_t10, woman_category__intersex_accommodation_reading, theater_ratio, 10, 0.17).
narrative_ontology:measurement(woma_tr_t15, woman_category__intersex_accommodation_reading, theater_ratio, 15, 0.19).
narrative_ontology:measurement(woma_tr_t20, woman_category__intersex_accommodation_reading, theater_ratio, 20, 0.21).
narrative_ontology:measurement(woma_tr_t25, woman_category__intersex_accommodation_reading, theater_ratio, 25, 0.22).

% Extraction over time
narrative_ontology:measurement(woma_be_t0, woman_category__intersex_accommodation_reading, base_extractiveness, 0, 0.28).
narrative_ontology:measurement(woma_be_t5, woman_category__intersex_accommodation_reading, base_extractiveness, 5, 0.32).
narrative_ontology:measurement(woma_be_t10, woman_category__intersex_accommodation_reading, base_extractiveness, 10, 0.36).
narrative_ontology:measurement(woma_be_t15, woman_category__intersex_accommodation_reading, base_extractiveness, 15, 0.39).
narrative_ontology:measurement(woma_be_t20, woman_category__intersex_accommodation_reading, base_extractiveness, 20, 0.41).
narrative_ontology:measurement(woma_be_t25, woman_category__intersex_accommodation_reading, base_extractiveness, 25, 0.42).

% Suppression requirement over time
narrative_ontology:measurement(woma_su_t0, woman_category__intersex_accommodation_reading, suppression_requirement, 0, 0.25).
narrative_ontology:measurement(woma_su_t5, woman_category__intersex_accommodation_reading, suppression_requirement, 5, 0.28).
narrative_ontology:measurement(woma_su_t10, woman_category__intersex_accommodation_reading, suppression_requirement, 10, 0.31).
narrative_ontology:measurement(woma_su_t15, woman_category__intersex_accommodation_reading, suppression_requirement, 15, 0.34).
narrative_ontology:measurement(woma_su_t20, woman_category__intersex_accommodation_reading, suppression_requirement, 20, 0.36).
narrative_ontology:measurement(woma_su_t25, woman_category__intersex_accommodation_reading, suppression_requirement, 25, 0.38).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(woman_category__intersex_accommodation_reading, identity_coordination).
narrative_ontology:boltzmann_floor_override(woman_category__intersex_accommodation_reading, 0.1).
narrative_ontology:affects_constraint(woman_category__intersex_accommodation_reading, woman_category__sex_biology_reading).
narrative_ontology:affects_constraint(woman_category__intersex_accommodation_reading, woman_category__gender_identity_reading).

% DUAL FORMULATION NOTE:
% This constraint is part of a three-member family decomposing the contested 'woman category' kernel. Each reading assigns different ε values due to different victim sets and extraction patterns. sex_biology_reading has lowest ε in most domains (binary categories are administratively simple) but high ε for intersex people forced into mismatched categories. gender_identity_reading has low ε for transgender people (no biological gatekeeping) but contested ε for female-typical biology people in sports/safety contexts. This reading (intersex_accommodation) has low ε in most domains (small affected population) but high per-person ε in elite sports boundary cases. The readings are linked because institutional adoption of one reading creates pressure on adjacent institutions and generates boundary disputes with institutions using different readings.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
