% ============================================================================
% CONSTRAINT STORY: westphalia_sovereignty__graded_sovereignty
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-12
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_westphalia_sovereignty__graded_sovereignty, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: westphalia_sovereignty__graded_sovereignty
 *   human_readable: Graded Sovereignty: Capacity-Indexed Intervention Legitimacy
 *   domain: international_law/political_theory
 *
 * SUMMARY:
 *   The graded sovereignty reading treats state authority as a measurable
 *   capacity distributed on a spectrum, with intervention legitimacy indexed
 *   to quantified deficits. Emerged in 1990s as response to failed-state
 *   crises and humanitarian catastrophes that neither absolute sovereignty
 *   nor unconstrained intervention could handle. Claims to be descriptive
 *   recognition of state capacity variation but operates as prescriptive
 *   framework that allocates intervention authority to capacity-evaluating
 *   institutions. Claimed as mountain (natural/foundational feature emerging
 *   from state system realities) while generating identifiable beneficiaries
 *   who profit from administering the grading apparatus.
 *
 * KEY AGENTS:
 *   - capacity_evaluation_authorities: Agenda-setters (institutional/arbitrage) — define metrics that determine sovereignty status
 *   - intervention_authorized_states: Beneficiaries (institutional/arbitrage) — gain legitimacy for territorial overrides
 *   - international_development_institutions: Beneficiaries/Agenda-setters (institutional/mobile) — extract operational mandate from permanent client base
 *   - weak_capacity_states: Payers (organized/trapped) — subordinated sovereignty based on external assessments
 *   - post_colonial_nations: Payers (organized/identity_locked) — re-tiered under metrics calibrated to Western forms
 *   - non_state_populations_in_intervention_zones: Excluded (powerless/trapped) — subjects of framework with no voice in it
 *   - international_law_scholars: Observers (analytical/analytical) — document gap between humanitarian rhetoric and distributional effects
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(westphalia_sovereignty__graded_sovereignty, 0.68).
domain_priors:suppression_score(westphalia_sovereignty__graded_sovereignty, 0.71).
domain_priors:theater_ratio(westphalia_sovereignty__graded_sovereignty, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, extractiveness, 0.68).
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, suppression_requirement, 0.71).
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, accessibility_collapse, 0.58).
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, resistance, 0.67).

% --- Constraint claim ---
narrative_ontology:constraint_claim(westphalia_sovereignty__graded_sovereignty, mountain).
narrative_ontology:human_readable(westphalia_sovereignty__graded_sovereignty, "Graded Sovereignty: Capacity-Indexed Intervention Legitimacy").
narrative_ontology:topic_domain(westphalia_sovereignty__graded_sovereignty, "international_law/political_theory").

domain_priors:requires_active_enforcement(westphalia_sovereignty__graded_sovereignty).
domain_priors:emerges_naturally(westphalia_sovereignty__graded_sovereignty).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(westphalia_sovereignty__graded_sovereignty, '5d7145de-a32f-467b-8944-61da8ae068aa').
narrative_ontology:cs_kernel_codification('5d7145de-a32f-467b-8944-61da8ae068aa', distributed).
narrative_ontology:cs_authority_grounding('5d7145de-a32f-467b-8944-61da8ae068aa', distributed).
narrative_ontology:cs_reading_relation('5d7145de-a32f-467b-8944-61da8ae068aa', westphalia_sovereignty__absolute_non_intervention, coexists_with).
narrative_ontology:cs_reading_relation('5d7145de-a32f-467b-8944-61da8ae068aa', westphalia_sovereignty__conditional_responsibility, influences).
narrative_ontology:cs_axiom('5d7145de-a32f-467b-8944-61da8ae068aa', foundational, sovereignty_as_measurable_capacity).
narrative_ontology:cs_axiom_status(sovereignty_as_measurable_capacity, holdable).
narrative_ontology:cs_axiom_grounding('5d7145de-a32f-467b-8944-61da8ae068aa', sovereignty_as_measurable_capacity, empirically_contingent).
narrative_ontology:cs_axiom('5d7145de-a32f-467b-8944-61da8ae068aa', foundational, intervention_legitimacy_indexed_to_deficits).
narrative_ontology:cs_axiom_status(intervention_legitimacy_indexed_to_deficits, holdable).
narrative_ontology:cs_axiom_grounding('5d7145de-a32f-467b-8944-61da8ae068aa', intervention_legitimacy_indexed_to_deficits, instrumental).
narrative_ontology:cs_axiom('5d7145de-a32f-467b-8944-61da8ae068aa', secondary, capacity_metrics_culturally_neutral).
narrative_ontology:cs_axiom_status(capacity_metrics_culturally_neutral, holdable).
narrative_ontology:cs_axiom_grounding('5d7145de-a32f-467b-8944-61da8ae068aa', capacity_metrics_culturally_neutral, empirically_contingent).
narrative_ontology:cs_reference_frame('5d7145de-a32f-467b-8944-61da8ae068aa', post_cold_war_humanitarian_crisis_response).
narrative_ontology:cs_drift_state('5d7145de-a32f-467b-8944-61da8ae068aa', contemporary_selectivity_era, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('5d7145de-a32f-467b-8944-61da8ae068aa', '').
narrative_ontology:cs_kernel_id(westphalia_sovereignty__graded_sovereignty, westphalia_sovereignty).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, capacity_evaluation_authorities).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, intervention_authorized_states).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, international_development_institutions).
narrative_ontology:constraint_victim(westphalia_sovereignty__graded_sovereignty, weak_capacity_states).
narrative_ontology:constraint_victim(westphalia_sovereignty__graded_sovereignty, post_colonial_nations).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__graded_sovereignty, developmental_hierarchy_doctrine).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__graded_sovereignty, responsibility_to_protect_framework).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% International organizations and academic institutions that develop and operationalize sovereignty capacity metrics—state fragility indices, governance indicators, institutional capacity assessments. They define the measurement framework that determines which states are classified as having capacity deficits warranting intervention. Control the technical apparatus that translates political judgments into quantified thresholds.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, capacity_evaluation_authorities, agenda_setter,
    institutional, generational, arbitrage, global).

% Powerful states that consistently score high on capacity metrics and gain legitimacy to conduct interventions in low-capacity states. The graded framework provides doctrinal cover for actions that would be clearly illegitimate under absolute sovereignty: their capacity scores authorize them to override weaker states' territorial claims when metrics indicate deficits. Collect strategic influence and resource access through legitimized intervention.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, intervention_authorized_states, beneficiary,
    institutional, generational, arbitrage, global).

% Organizations whose mandates and funding flows are justified by capacity-building missions in deficit states. The graded sovereignty framework creates permanent clients: states classified as low-capacity require ongoing technical assistance, conditionality regimes, and institutional reform programs. Their operational model depends on a stable population of states whose sovereignty is recognized as deficient.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, international_development_institutions, beneficiary,
    institutional, generational, mobile, global).
narrative_ontology:stakeholder_secondary_role(westphalia_sovereignty__graded_sovereignty, international_development_institutions, agenda_setter).

% States classified by capacity metrics as having governance deficits, failed institutions, or fragile authority structures. Experience their sovereignty as conditional and revocable: must accept external oversight, submit to capacity assessments, comply with intervention missions framed as assistance. Cannot exit the graded framework without first achieving capacity scores set by external authorities. Their territorial claims are systematically subordinated to judgments made elsewhere about their institutional adequacy.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, weak_capacity_states, payer,
    organized, generational, trapped, national).

% States that achieved formal independence under Westphalian equality doctrine but find their sovereignty re-tiered under capacity frameworks. The metrics used to assess capacity are calibrated to Western institutional forms; traditional or non-Western governance structures systematically score as deficits. Identity-locked because rejecting the capacity framework means rejecting the international legal vocabulary through which their statehood claims are recognized at all. Pay through subordinated status and paternalistic oversight dressed as partnership.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, post_colonial_nations, payer,
    organized, generational, identity_locked, national).

% Populations living in states designated as having capacity deficits. Are subjects of intervention but not parties to the framework that authorizes it. Their welfare is cited as justification for overriding their state's sovereignty, but they have no voice in capacity assessments or intervention design. Experience sovereignty debates as decisions made about them by distant authorities claiming to act on their behalf.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, non_state_populations_in_intervention_zones, excluded,
    powerless, biographical, trapped, local).

% Analyze whether graded sovereignty represents evolutionary adaptation of Westphalian system to modern realities or re-inscription of colonial hierarchies in technical language. Track how capacity metrics correlate with geopolitical alignments and resource extraction patterns. Document gap between framework's humanitarian rhetoric and its distributional effects.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, international_law_scholars, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides international system with graduated response mechanism for state failure scenarios: distinguishes between states that should be left alone and those requiring external involvement. Offers alternative to binary sovereignty model that could not handle failed-state and mass-atrocity situations.
% TRANSFER_FUNCTION: Moves decision authority over territorial integrity from weak-capacity states to capacity-evaluation authorities and intervention-authorized states. Transfers legitimacy to override sovereignty claims from universal principle to metric-indexed judgment. Moves resources and strategic access from deficit states to intervening states and development institutions through legitimized entry.
% ABSENT_VOICES: Non-state populations whose welfare justifies intervention have no seat in capacity framework design. Alternative governance traditions that don't map to Western institutional metrics are structurally excluded from evaluation apparatus. States that reject the graded framework entirely cannot participate in international system without accepting its terms.
% DISAPPEARANCE_RATIONALE: If graded sovereignty framework vanished, intervention legitimacy would revert to cruder force-based or ideology-based justifications without capacity-metric cover. Development institutions would lose technical rationale for conditional lending and oversight. Failed states would face either absolute inviolability or unconstrained intervention with no middle ground. The international legal vocabulary for discussing state authority would reorganize around different principles.
% FOUNDING_PROBLEM: Post-Cold War international system faced failed states, humanitarian catastrophes, and governance collapse situations where neither absolute sovereignty nor unconstrained intervention provided workable framework. Rwanda genocide and Somalia collapse demonstrated that categorical non-intervention produced mass death while ad-hoc intervention lacked legitimacy structure.
% FOUNDING_PROBLEM_CORROBORATION: Intervention-authorized states and development institutions attest the problem remains live, citing ongoing state fragility and humanitarian crises requiring graduated response. Post-colonial scholars and weak-capacity states attest the founding problem has been instrumentalized: capacity metrics now serve great-power prerogatives rather than humanitarian need, and the framework's selectivity reveals political rather than technical application. International legal scholars from outside beneficiary institutions document that intervention patterns correlate more with strategic interest than with capacity deficits.
narrative_ontology:disappearance_verdict(westphalia_sovereignty__graded_sovereignty, world_rearranges).
narrative_ontology:founding_problem_status(westphalia_sovereignty__graded_sovereignty, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(westphalia_sovereignty__graded_sovereignty, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(westphalia_sovereignty__graded_sovereignty, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(westphalia_sovereignty__graded_sovereignty_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(westphalia_sovereignty__graded_sovereignty, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, ExtMetricName, E),
    domain_priors:suppression_score(westphalia_sovereignty__graded_sovereignty, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(westphalia_sovereignty__graded_sovereignty),
    narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(westphalia_sovereignty__graded_sovereignty_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is substantial (0.68) because capacity metrics transfer sovereignty authority from assessed states to assessing institutions, with metric design controlled by beneficiaries. Suppression is high (0.71) because weak-capacity states cannot exit the framework without losing international legal standing entirely; rejection means losing access to recognition vocabulary. Theater is moderate (0.42): capacity-building missions produce real technical assistance but growing share of activity maintains the grading apparatus itself rather than addressing underlying conditions. The measurement series shows extraction and suppression intensifying over the 30-year interval as framework became institutionalized and metric proliferation increased oversight density. Resistance is high (0.67) from post-colonial scholars and subordinated states who contest framework as colonial hierarchy in technical dress. Accessibility collapse is moderate (0.58): alternative sovereignty principles exist in theory but accessing international system requires accepting graded framework's terms.
 *
 * PERSPECTIVAL GAP:
 *   From capacity-evaluation authorities' seat, graded sovereignty is technical recognition of real variation in state institutional capacity requiring calibrated international response. From weak-capacity states' seat, same structure operates as extraction mechanism that converts post-colonial sovereignty into conditional status requiring permanent external oversight. From intervention-authorized states' seat, framework provides legitimate authority for strategic engagement; from subordinated states' seat, it provides doctrinal cover for violations they cannot resist. Engine computes these divergent type classifications from the structural asymmetries in power, exit, and benefit/cost distribution.
 *
 * DIRECTIONALITY LOGIC:
 *   Capacity-evaluation authorities are primary beneficiaries with arbitrage-grade exit (control the metric apparatus, can shift focus between regions and clients). Intervention-authorized states benefit structurally (gain legitimacy for actions that would be clearly illegitimate under absolute sovereignty) with arbitrage exit (can choose which deficit states to engage). Development institutions are dual-positioned (set metrics AND collect operational mandates) with mobile exit (can pivot between capacity-building and other missions). Weak-capacity states are trapped targets (cannot exit framework without losing sovereignty claims entirely). Post-colonial nations are identity-locked targets (must use the vocabulary that subordinates them to make statehood claims at all). Excluded populations are powerless targets with no exit. Scholars are analytical observers.
 *
 * MANDATROPHY ANALYSIS:
 *   Founding problem—failed states and mass atrocities requiring response between absolute inviolability and unconstrained intervention—was real and remains partially live. But framework's evolution shows mandate expansion: capacity metrics now assess institutional forms, governance models, development indicators far beyond humanitarian crisis prevention. Theater ratio rising as metric proliferation and assessment infrastructure become self-perpetuating regardless of crisis presence. Classification prevents mislabeling as pure extraction (coordination function exists) while documenting how extraction layers onto genuine humanitarian response (victims are real, metrics are gamed, selectivity reveals strategic rather than technical application).
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    mountain_vs_constructed_hierarchy,
    'Is graded sovereignty a natural feature emerging from observable state capacity variation, or a constructed hierarchy that benefits capacity-evaluating institutions?',
    'Analyze correlation between capacity scores and (a) humanitarian outcomes vs (b) geopolitical alignments and resource access. If scores track strategic interest more than institutional quality, framework is constructed extraction. If capacity metrics predict intervention better than crisis severity, grading serves beneficiary interests.',
    'If natural feature, mountain classification holds and intervention framework is legitimate recognition of reality. If constructed hierarchy, reclassify as tangled_rope (coordination overlay on extraction) or snare (pure extraction using humanitarian cover).',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(mountain_vs_constructed_hierarchy, empirical, 'Whether capacity grading reflects state system reality or institutionalizes post-colonial subordination').

omega_variable(
    metric_calibration_bias,
    'Do capacity metrics measure universal institutional adequacy or encode particular governance models as definitional standard?',
    'Test whether non-Western institutional forms systematically score as deficits even when producing comparable outcomes. Compare capacity scores for states with different governance traditions but similar crisis prevention records. If Western institutional forms are baked into metrics as normative standard, framework is extractive imposition.',
    'If metrics are culturally neutral technical measures, supports mountain claim. If metrics encode Western institutional forms as universal standard, reveals framework as mechanism for subordinating alternative governance traditions and supports reclassification as extraction.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(metric_calibration_bias, conceptual, 'Whether capacity assessment framework is technically neutral or culturally loaded').

omega_variable(
    humanitarian_vs_strategic_selectivity,
    'Does intervention pattern follow capacity deficits or great-power strategic interest?',
    'Compare intervention frequency and intensity across states with similar capacity scores but different strategic value. If intervention correlates more with resource access, geopolitical alignment, or great-power interest than with humanitarian need, framework is cover for strategic action.',
    'If intervention follows capacity metrics regardless of strategic interest, supports coordination function. If intervention is highly selective and tracks strategic value, reveals framework as extractive legitimation apparatus and supports snare reclassification.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(humanitarian_vs_strategic_selectivity, empirical, 'Whether graded sovereignty framework guides humanitarian response or legitimizes strategic intervention').

omega_variable(
    permanence_of_deficit_classification,
    'Can states genuinely graduate out of capacity-deficit status, or does framework create permanent subordination?',
    'Track states'' capacity scores over time and examine whether institutional improvements translate to sovereignty restoration or whether new deficit categories emerge to maintain subordinated status. If metric thresholds rise as states improve, framework is extraction mechanism not development pathway.',
    'If graduation is achievable, supports scaffold-like transitional function. If deficit classification is sticky regardless of improvement, reveals framework as permanent hierarchy and supports piton or snare classification (extraction maintained theatrically as capacity-building).',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(permanence_of_deficit_classification, empirical, 'Whether capacity-deficit classification is transitional or permanent subordination').

omega_variable(
    committer_frame_absolute_vs_graded,
    'Does the graded reading logically foreclose the absolute non-intervention reading within any single international legal framework?',
    'Examine whether states or institutions can coherently hold both readings simultaneously. If graded framework''s capacity thresholds directly contradict absolute inviolability such that no framework could contain both, relation is forecloses. If they coexist as competing positions held by different states, relation is coexists_with.',
    'Determines whether readings form mutually exclusive ontological claims (forecloses) or competing political positions (coexists_with). Affects how cross-reading contamination propagates through kernel family.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(committer_frame_absolute_vs_graded, conceptual, 'Whether graded and absolute sovereignty readings can be held in single framework or are logically exclusive').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(westphalia_sovereignty__graded_sovereignty, 0, 30).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(west_tr_t0, westphalia_sovereignty__graded_sovereignty, theater_ratio, 0, 0.25).
narrative_ontology:measurement(west_tr_t6, westphalia_sovereignty__graded_sovereignty, theater_ratio, 6, 0.29).
narrative_ontology:measurement(west_tr_t12, westphalia_sovereignty__graded_sovereignty, theater_ratio, 12, 0.33).
narrative_ontology:measurement(west_tr_t18, westphalia_sovereignty__graded_sovereignty, theater_ratio, 18, 0.37).
narrative_ontology:measurement(west_tr_t24, westphalia_sovereignty__graded_sovereignty, theater_ratio, 24, 0.4).
narrative_ontology:measurement(west_tr_t30, westphalia_sovereignty__graded_sovereignty, theater_ratio, 30, 0.42).

% Extraction over time
narrative_ontology:measurement(west_be_t0, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 0, 0.48).
narrative_ontology:measurement(west_be_t6, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 6, 0.53).
narrative_ontology:measurement(west_be_t12, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 12, 0.58).
narrative_ontology:measurement(west_be_t18, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 18, 0.62).
narrative_ontology:measurement(west_be_t24, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 24, 0.65).
narrative_ontology:measurement(west_be_t30, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 30, 0.68).

% Suppression requirement over time
narrative_ontology:measurement(west_su_t0, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 0, 0.55).
narrative_ontology:measurement(west_su_t6, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 6, 0.59).
narrative_ontology:measurement(west_su_t12, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 12, 0.63).
narrative_ontology:measurement(west_su_t18, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 18, 0.67).
narrative_ontology:measurement(west_su_t24, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 24, 0.69).
narrative_ontology:measurement(west_su_t30, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 30, 0.71).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(westphalia_sovereignty__graded_sovereignty, enforcement_mechanism).
narrative_ontology:affects_constraint(westphalia_sovereignty__graded_sovereignty, westphalia_sovereignty__absolute_non_intervention).
narrative_ontology:affects_constraint(westphalia_sovereignty__graded_sovereignty, westphalia_sovereignty__conditional_responsibility).

% DUAL FORMULATION NOTE:
% Westphalia sovereignty kernel decomposes into three readings: absolute (categorical inviolability), conditional (threshold-based forfeiture), and graded (scalar capacity). Each reading instantiates different constraint with different victim sets and extraction patterns. Graded reading creates permanent evaluation apparatus not present in absolute or conditional readings. All three readings compete in contemporary international law with different state coalitions supporting each.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
