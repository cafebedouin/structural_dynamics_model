% ============================================================================
% CONSTRAINT STORY: waitangi_sovereignty_allocation__rangatiratanga_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_waitangi_sovereignty_allocation__rangatiratanga_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: waitangi_sovereignty_allocation__rangatiratanga_reading
 *   human_readable: Waitangi Sovereignty Allocation (Rangatiratanga Reading)
 *   domain: constitutional_law/indigenous_rights/post_colonial_governance
 *
 * SUMMARY:
 *   The Treaty of Waitangi was signed in 1840 in both English and Māori
 *   versions with critical semantic divergence. The English Article I ceded
 *   'all rights and powers of sovereignty' to the Crown; the Māori Article I
 *   ceded 'te kāwanatanga katoa' (governorship/governance) while Article II
 *   explicitly guaranteed 'te tino rangatiratanga' (full chiefly
 *   authority/sovereignty) over lands, villages, and taonga. This reading
 *   takes the Māori text as authoritative and holds that Māori signatories
 *   understood they were granting the Crown governance over settlers while
 *   retaining sovereignty over their own territories and people. The
 *   constraint operates as a constitutional allocation of authority that was
 *   structurally determined by what each party could legitimately offer:
 *   Māori could not cede what they had not been conquered for, and would not
 *   have signed a sovereignty-ceding document; the Crown needed
 *   administrative authority over settlers but did not need sovereignty over
 *   Māori to achieve that. This reading is claimed as mountain (a structural
 *   necessity arising from the Treaty's actual terms and the parties'
 *   positions at signing) but has identifiable beneficiaries and contested
 *   application, triggering FSM evaluation.
 *
 * KEY AGENTS:
 *   - maori_iwi_hapu: Primary beneficiary (organized/identity_locked) — hold inherent authority under Article II
 *   - crown_institutions: Primary payer (institutional/constrained) — limited to kāwanatanga, must negotiate as co-equals
 *   - indigenous_rights_advocates: Secondary beneficiary (organized/mobile) — advance reading as post-colonial model
 *   - settler_descendants: Dual-positioned (organized/constrained) — subject to governance but benefit from stability
 *   - constitutional_scholars: Analytical observer — document textual and historical evidence for readings
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(waitangi_sovereignty_allocation__rangatiratanga_reading, 0.12).
domain_priors:suppression_score(waitangi_sovereignty_allocation__rangatiratanga_reading, 0.08).
domain_priors:theater_ratio(waitangi_sovereignty_allocation__rangatiratanga_reading, 0.05).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, extractiveness, 0.12).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 0.08).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 0.05).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, accessibility_collapse, 0.92).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, resistance, 0.03).

% --- Constraint claim ---
narrative_ontology:constraint_claim(waitangi_sovereignty_allocation__rangatiratanga_reading, mountain).
narrative_ontology:human_readable(waitangi_sovereignty_allocation__rangatiratanga_reading, "Waitangi Sovereignty Allocation (Rangatiratanga Reading)").
narrative_ontology:topic_domain(waitangi_sovereignty_allocation__rangatiratanga_reading, "constitutional_law/indigenous_rights/post_colonial_governance").

domain_priors:emerges_naturally(waitangi_sovereignty_allocation__rangatiratanga_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(waitangi_sovereignty_allocation__rangatiratanga_reading, 'd271d36c-6cc7-4ba0-845e-ecaa2278f457').
narrative_ontology:cs_kernel_codification('d271d36c-6cc7-4ba0-845e-ecaa2278f457', fixed_text).
narrative_ontology:cs_authority_grounding('d271d36c-6cc7-4ba0-845e-ecaa2278f457', lineage).
narrative_ontology:cs_interpretation_layer_present('d271d36c-6cc7-4ba0-845e-ecaa2278f457').
narrative_ontology:cs_reading_relation('d271d36c-6cc7-4ba0-845e-ecaa2278f457', waitangi_sovereignty_allocation__crown_sovereignty_reading, forecloses).
narrative_ontology:cs_reading_relation('d271d36c-6cc7-4ba0-845e-ecaa2278f457', waitangi_sovereignty_allocation__partnership_reading, influences).
narrative_ontology:cs_axiom('d271d36c-6cc7-4ba0-845e-ecaa2278f457', foundational, maori_text_authoritative).
narrative_ontology:cs_axiom_status(maori_text_authoritative, holdable).
narrative_ontology:cs_axiom_grounding('d271d36c-6cc7-4ba0-845e-ecaa2278f457', maori_text_authoritative, conventional).
narrative_ontology:cs_axiom('d271d36c-6cc7-4ba0-845e-ecaa2278f457', foundational, rangatiratanga_retained_not_ceded).
narrative_ontology:cs_axiom_status(rangatiratanga_retained_not_ceded, holdable).
narrative_ontology:cs_axiom_grounding('d271d36c-6cc7-4ba0-845e-ecaa2278f457', rangatiratanga_retained_not_ceded, conventional).
narrative_ontology:cs_axiom('d271d36c-6cc7-4ba0-845e-ecaa2278f457', secondary, kawanatanga_limited_to_settlers).
narrative_ontology:cs_axiom_status(kawanatanga_limited_to_settlers, holdable).
narrative_ontology:cs_axiom_grounding('d271d36c-6cc7-4ba0-845e-ecaa2278f457', kawanatanga_limited_to_settlers, conventional).
narrative_ontology:cs_reference_frame('d271d36c-6cc7-4ba0-845e-ecaa2278f457', te_tiriti_maori_text_1840).
narrative_ontology:cs_drift_state('d271d36c-6cc7-4ba0-845e-ecaa2278f457', contemporary_tribunal_era, gap(authority_erosion, substantial, true)).
narrative_ontology:cs_created_at('d271d36c-6cc7-4ba0-845e-ecaa2278f457', '').
narrative_ontology:cs_kernel_id(waitangi_sovereignty_allocation__rangatiratanga_reading, waitangi_sovereignty_allocation).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__rangatiratanga_reading, maori_iwi_hapu).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__rangatiratanga_reading, indigenous_rights_advocates).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__rangatiratanga_reading, crown_institutions).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__rangatiratanga_reading, settler_descendants).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__rangatiratanga_reading, settler_descendants).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__rangatiratanga_reading, indigenous_self_determination_principle).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__rangatiratanga_reading, textual_primacy_doctrine).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Hold tino rangatiratanga (full authority) over ancestral lands, resources, and taonga under the Māori text of Article II. Their authority is inherent and pre-existing, not granted by the Treaty but recognized by it. Exit is identity-locked: rangatiratanga is constitutive of being tangata whenua; renouncing it means renouncing collective identity and connection to whenua.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, maori_iwi_hapu, beneficiary,
    organized, generational, identity_locked, national).

% Operate under kāwanatanga (governorship), which the Māori text limits to authority over settlers and administrative coordination, not sovereignty over Māori or their territories. Must negotiate with iwi and hapū as co-equals rather than subjects. Their claim to Westminster supremacy is contested by the Māori text's explicit retention of rangatiratanga.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, crown_institutions, payer,
    institutional, generational, constrained, national).

% Advance the rangatiratanga reading as a model for post-colonial constitutional settlement: recognition of indigenous authority as inherent rather than delegated. They benefit from the reading's coherence with international indigenous rights frameworks and use it as precedent in other jurisdictions.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, indigenous_rights_advocates, beneficiary,
    organized, generational, mobile, global).

% Subject to kāwanatanga for governance purposes but not to Māori authority if not on Māori-held lands. Their property rights and civic arrangements depend on Crown institutions that, under this reading, lack sovereignty over the territorial base. They benefit from stable governance but pay through constrained political supremacy.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, settler_descendants, payer,
    organized, biographical, constrained, national).
narrative_ontology:stakeholder_secondary_role(waitangi_sovereignty_allocation__rangatiratanga_reading, settler_descendants, beneficiary).

% Analyze the textual and historical evidence for competing sovereignty readings. They document that the Māori text explicitly reserved tino rangatiratanga while ceding only kāwanatanga, a distinction the English text collapsed into unitary sovereignty. They trace how the rangatiratanga reading aligns with what Māori signatories understood they were entering.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, constitutional_scholars, observer,
    analytical, generational, analytical, national).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes a clear allocation of authority between indigenous peoples and Crown institutions: Māori retain full authority over their territories and taonga, Crown governs settlers and coordinates between jurisdictions. Solves the coordination problem of dual authority without requiring either party to surrender what it cannot legitimately cede.
% TRANSFER_FUNCTION: Moves constitutional supremacy claims from Crown institutions back to iwi and hapū for matters within their rohe. Reallocates resource governance authority from centralized Crown control to distributed iwi/hapū authority. Transfers legitimacy for co-governance structures from contested political concession to treaty-mandated requirement.
% ABSENT_VOICES: Crown sovereignty advocates and those who benefit from Westminster parliamentary supremacy are structurally present but read the Treaty differently; they are in the conversation but contest this reading. The excluded voice is the broader Māori population who were not signatories but whose authority is here represented by rangatira who signed.
% DISAPPEARANCE_RATIONALE: If this reading disappeared, the constitutional settlement would revert to the Crown sovereignty reading: parliamentary supremacy would be unchallenged, co-governance would become political concession rather than legal obligation, resource claims would be litigated under Crown property law rather than negotiated as between co-equals, and the distinction between kāwanatanga and rangatiratanga would collapse into unitary state sovereignty.
% FOUNDING_PROBLEM: How to establish Crown governance over settlers in Aotearoa without extinguishing Māori authority over their own lands and people. The Treaty needed to enable British administration of the settler population while recognizing that Māori had not been conquered and had not ceded sovereignty.
% FOUNDING_PROBLEM_CORROBORATION: Constitutional scholars from outside the immediate beneficiary groups attest the founding problem remains live: New Zealand operates under contested constitutional foundations where the Treaty's dual-text structure creates ongoing jurisdictional disputes. The Waitangi Tribunal, established 1975, is institutional evidence that the sovereignty allocation question was never resolved, only deferred.
narrative_ontology:disappearance_verdict(waitangi_sovereignty_allocation__rangatiratanga_reading, world_rearranges).
narrative_ontology:founding_problem_status(waitangi_sovereignty_allocation__rangatiratanga_reading, live).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(waitangi_sovereignty_allocation__rangatiratanga_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(waitangi_sovereignty_allocation__rangatiratanga_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(waitangi_sovereignty_allocation__rangatiratanga_reading_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, ExtMetricName, E),
    domain_priors:suppression_score(waitangi_sovereignty_allocation__rangatiratanga_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(waitangi_sovereignty_allocation__rangatiratanga_reading),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(waitangi_sovereignty_allocation__rangatiratanga_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is low (0.12) because this reading, if operationalized, reallocates authority rather than extracting rents; it constrains Crown institutions' supremacy claims but does so via treaty interpretation rather than imposed cost. Suppression is very low (0.08) because the reading does not require active enforcement against resistance—it is maintained by textual evidence and the logic of what Māori signatories could have understood they were entering. Theater is near-zero (0.05): the coordination function (dual authority allocation) is real and the reading is not performatively maintained. Accessibility collapse is very high (0.92): once the semantic evidence is examined (tino rangatiratanga vs. sovereignty, kāwanatanga vs. complete governance), alternative readings require either ignoring the Māori text or claiming Māori signatories misunderstood their own language. Resistance is very low (0.03): the reading is contested but not actively resisted by physical force—the resistance is institutional and legal, not coercive. The measurements show modest drift over 186 years: extractiveness rises slightly as the reading's implications for resource claims become clearer; theater and suppression remain stable and low, indicating the constraint's persistence does not depend on performative maintenance or coercive enforcement.
 *
 * PERSPECTIVAL GAP:
 *   From the Māori iwi and hapū seat, this reading is the plain meaning of the text they signed and the only allocation consistent with what they understood they were entering: they did not cede sovereignty, they granted governance over settlers. From the Crown institutions seat, the reading constrains parliamentary supremacy and creates jurisdictional complexity that must be actively negotiated rather than legislatively resolved. The engine should compute this as Mountain from the iwi/hapū seat (authority is inherent, not extracted) and as Tangled Rope or Scaffold from the Crown seat (coordination function exists but is layered with structural constraint on supremacy). The gap arises not from different information but from different structural positions: one party's inherent authority is another party's constrained jurisdiction.
 *
 * DIRECTIONALITY LOGIC:
 *   Māori iwi and hapū are structural beneficiaries: the reading recognizes their inherent authority and requires Crown institutions to negotiate rather than command. Their d is near the beneficiary end (~0.1), modulated by identity_locked exit (they cannot exit their relationship to whenua without ceasing to be tangata whenua). Crown institutions are the primary payers: the reading constrains their sovereignty claims and reallocates constitutional authority. Their d is moderate (~0.4)—constrained but not trapped, as they retain kāwanatanga and can adapt institutional structures. Indigenous rights advocates benefit incidentally (d ~0.15, mobile exit) by having a coherent post-colonial model. Settler descendants are near-symmetric (d ~0.5): they benefit from stable governance but pay through Crown institutions' constrained supremacy. The structural asymmetry (iwi/hapū benefit, Crown pays) drives the per-seat divergence the engine will compute.
 *
 * MANDATROPHY ANALYSIS:
 *   The Mandatrophy lens prevents conflating Crown resistance to this reading with evidence that the reading is extractive rather than structural. Crown institutions resist not because the constraint extracts rents but because it reallocates authority they claimed via the English text. The low extractiveness, low suppression, and near-zero theater indicate this is not a Snare dressed as coordination—it is a genuine allocation of authority that constrains one party's supremacy claims. The coordination function (dual authority without mutual surrender) is real; the 'cost' to Crown institutions is relinquishing a sovereignty claim the Māori text never granted. Mandatrophy resolution confirms this is not mislabeled pure extraction.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    textual_primacy_ambiguity,
    'When two Treaty texts conflict on sovereignty allocation, which text is authoritative—the one the Crown drafted (English) or the one Māori signatories signed (Māori)?',
    'Principles of treaty interpretation in international law (contra proferentem: ambiguity construed against drafter; signatories'' understanding governs) and evidence of what Māori signatories were told the Treaty said. Historical scholarship on rangatira speeches and missionary translations provides empirical grounding.',
    'If Māori text is authoritative, rangatiratanga was retained and Crown sovereignty claims rest on English-text assertions Māori did not sign. If English text is authoritative despite not being what Māori signed, parliamentary supremacy is established but the Treaty''s legitimacy as consent-document collapses. The classification hinges on which interpretive principle governs.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(textual_primacy_ambiguity, conceptual, 'Which Treaty text governs when they conflict on sovereignty.').

omega_variable(
    kawanatanga_rangatiratanga_boundary,
    'What is the operational boundary between kāwanatanga (governance/governorship over settlers) and tino rangatiratanga (full chiefly authority over Māori lands and taonga)?',
    'Co-governance negotiations, Waitangi Tribunal jurisprudence, and iwi-Crown settlements that instantiate the boundary in practice. Empirical observation of which decisions require Crown-iwi negotiation vs. unilateral Crown action.',
    'A narrow kāwanatanga boundary (Crown authority limited to settler administration) leaves most resource and jurisdictional questions under iwi authority. A broad kāwanatanga boundary (Crown authority extends to anything affecting settlers, which is nearly everything in a mixed jurisdiction) collapses rangatiratanga into consultation rights rather than authority. The extractiveness of the constraint depends on where this boundary is drawn in practice.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(kawanatanga_rangatiratanga_boundary, empirical, 'Where kāwanatanga ends and rangatiratanga begins in operational terms.').

omega_variable(
    naturality_vs_strategic_framing,
    'Is this reading a natural-law interpretation (the only allocation consistent with what the Treaty''s Māori text actually says) or a strategic framing by beneficiaries (iwi and indigenous rights advocates) to advance political claims?',
    'Comparative constitutional scholarship, historical evidence of what Māori signatories understood, and examination of whether non-beneficiary scholars reach the same textual interpretation. If scholars with no stake in Māori authority claims independently conclude the Māori text reserved rangatiratanga, the reading is structurally grounded. If only beneficiaries and advocates advance it, it may be constructed for extraction.',
    'If natural-law interpretation, the constraint is Mountain (authority allocation determined by treaty terms) and Crown resistance is institutional denial of structural reality. If strategic framing, the constraint is Tangled Rope or Snare (coordination story layered over beneficiary rent-seeking). The FSM signature will evaluate this via beneficiary presence + omega documentation.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(naturality_vs_strategic_framing, conceptual, 'Whether reading is treaty-determined or beneficiary-constructed.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(waitangi_sovereignty_allocation__rangatiratanga_reading, 1840, 2026).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(wait_tr_t1840, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 1840, 0.02).
narrative_ontology:measurement_basis(wait_tr_t1840, observed).
narrative_ontology:measurement(wait_tr_t1870, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 1870, 0.03).
narrative_ontology:measurement_basis(wait_tr_t1870, observed).
narrative_ontology:measurement(wait_tr_t1900, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 1900, 0.04).
narrative_ontology:measurement_basis(wait_tr_t1900, observed).
narrative_ontology:measurement(wait_tr_t1950, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 1950, 0.05).
narrative_ontology:measurement_basis(wait_tr_t1950, observed).
narrative_ontology:measurement(wait_tr_t1990, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 1990, 0.04).
narrative_ontology:measurement_basis(wait_tr_t1990, observed).
narrative_ontology:measurement(wait_tr_t2026, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 2026, 0.05).
narrative_ontology:measurement_basis(wait_tr_t2026, observed).

% Extraction over time
narrative_ontology:measurement(wait_be_t1840, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 1840, 0.05).
narrative_ontology:measurement_basis(wait_be_t1840, observed).
narrative_ontology:measurement(wait_be_t1870, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 1870, 0.08).
narrative_ontology:measurement_basis(wait_be_t1870, observed).
narrative_ontology:measurement(wait_be_t1900, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 1900, 0.09).
narrative_ontology:measurement_basis(wait_be_t1900, observed).
narrative_ontology:measurement(wait_be_t1950, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 1950, 0.11).
narrative_ontology:measurement_basis(wait_be_t1950, observed).
narrative_ontology:measurement(wait_be_t1990, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 1990, 0.1).
narrative_ontology:measurement_basis(wait_be_t1990, observed).
narrative_ontology:measurement(wait_be_t2026, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 2026, 0.12).
narrative_ontology:measurement_basis(wait_be_t2026, observed).

% Suppression requirement over time
narrative_ontology:measurement(wait_su_t1840, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 1840, 0.05).
narrative_ontology:measurement_basis(wait_su_t1840, observed).
narrative_ontology:measurement(wait_su_t1870, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 1870, 0.06).
narrative_ontology:measurement_basis(wait_su_t1870, observed).
narrative_ontology:measurement(wait_su_t1900, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 1900, 0.07).
narrative_ontology:measurement_basis(wait_su_t1900, observed).
narrative_ontology:measurement(wait_su_t1950, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 1950, 0.09).
narrative_ontology:measurement_basis(wait_su_t1950, observed).
narrative_ontology:measurement(wait_su_t1990, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 1990, 0.07).
narrative_ontology:measurement_basis(wait_su_t1990, observed).
narrative_ontology:measurement(wait_su_t2026, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 2026, 0.08).
narrative_ontology:measurement_basis(wait_su_t2026, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__rangatiratanga_reading, waitangi_sovereignty_allocation__crown_sovereignty_reading).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__rangatiratanga_reading, waitangi_sovereignty_allocation__partnership_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the waitangi_sovereignty_allocation kernel. The rangatiratanga_reading takes the Māori text as authoritative and treats tino rangatiratanga as retained sovereignty, yielding low extractiveness (authority reallocation, not rent extraction) and high accessibility collapse (once textual evidence is examined, alternatives require ignoring the Māori text). The crown_sovereignty_reading takes the English text as authoritative and treats Article I as ceding complete sovereignty, yielding high extractiveness from Māori perspective and moderate suppression (Westminster supremacy must be defended against Treaty claims). The partnership_reading treats the textual conflict as irresolvable and instantiates an ongoing negotiated relationship, yielding moderate extractiveness and moderate coordination. These are not observer perspectives on one constraint—they are structurally distinct constitutional arrangements with different beneficiary/victim sets and different ε values.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
