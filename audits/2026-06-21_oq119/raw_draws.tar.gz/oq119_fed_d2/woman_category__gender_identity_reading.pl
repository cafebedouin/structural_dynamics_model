% ============================================================================
% CONSTRAINT STORY: woman_category__gender_identity_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-01-15
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_woman_category__gender_identity_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: woman_category__gender_identity_reading
 *   human_readable: Woman Category Membership via Gender Identity
 *   domain: political_philosophy/law/social_policy/bioethics
 *
 * SUMMARY:
 *   This constraint instantiates the gender identity reading of
 *   woman-category membership: 'woman' means anyone who identifies as a
 *   woman, with self-identification as sufficient criterion regardless of
 *   biological sex, medical transition status, or any external verification.
 *   The constraint is CLAIMED as mountain (a natural, foundational feature of
 *   reality about what gender categories are) while the metrics describe
 *   substantially extractive, actively enforced operation. The divergence is
 *   deliberate and measured by the engine—the claim represents the
 *   framework's self-presentation as discovering rather than constructing
 *   category boundaries, while the metrics capture its actual enforcement
 *   dynamics.
 *
 * KEY AGENTS:
 *   - transgender_women: Primary beneficiaries (organized/identity_locked) — gain categorical recognition and access rights
 *   - gender_identity_advocacy_organizations: Agenda-setters (institutional/mobile) — shaped definitional framework, receive grants and consulting contracts
 *   - institutional_diversity_officers: Agenda-setters and beneficiaries (institutional/constrained) — administer and enforce, derive institutional authority from implementation
 *   - sex_based_protection_advocates: Payers (organized/constrained) — lose ability to maintain sex-based boundaries, face institutional sanction
 *   - sex_segregated_space_administrators: Payers (institutional/trapped) — bear redesignation costs and legal liability under competing rights frameworks
 *   - female_athletes_competitive_class: Payers (moderate/constrained) — bear competitive displacement costs
 *   - medical_transition_gatekeepers: Excluded (institutional/constrained) — clinical assessment bypassed under pure self-identification
 *   - legal_philosophers_categorical_analysis: Observers (analytical/analytical) — assess structural coherence of self-identification as categorical criterion
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(woman_category__gender_identity_reading, 0.68).
domain_priors:suppression_score(woman_category__gender_identity_reading, 0.72).
domain_priors:theater_ratio(woman_category__gender_identity_reading, 0.41).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, extractiveness, 0.68).
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, suppression_requirement, 0.72).
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, theater_ratio, 0.41).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, resistance, 0.79).

% --- Constraint claim ---
narrative_ontology:constraint_claim(woman_category__gender_identity_reading, mountain).
narrative_ontology:human_readable(woman_category__gender_identity_reading, "Woman Category Membership via Gender Identity").
narrative_ontology:topic_domain(woman_category__gender_identity_reading, "political_philosophy/law/social_policy/bioethics").

domain_priors:requires_active_enforcement(woman_category__gender_identity_reading).
domain_priors:emerges_naturally(woman_category__gender_identity_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(woman_category__gender_identity_reading, '358c7fc0-e7ba-4792-9cf8-59294bec7f78').
narrative_ontology:cs_kernel_codification('358c7fc0-e7ba-4792-9cf8-59294bec7f78', distributed).
narrative_ontology:cs_authority_grounding('358c7fc0-e7ba-4792-9cf8-59294bec7f78', distributed).
narrative_ontology:cs_reading_relation('358c7fc0-e7ba-4792-9cf8-59294bec7f78', woman_category__sex_biology_reading, coexists_with).
narrative_ontology:cs_reading_relation('358c7fc0-e7ba-4792-9cf8-59294bec7f78', woman_category__intersex_accommodation_reading, coexists_with).
narrative_ontology:cs_axiom('358c7fc0-e7ba-4792-9cf8-59294bec7f78', foundational, gender_identity_primacy_over_biology).
narrative_ontology:cs_axiom_status(gender_identity_primacy_over_biology, holdable).
narrative_ontology:cs_axiom_grounding('358c7fc0-e7ba-4792-9cf8-59294bec7f78', gender_identity_primacy_over_biology, deontological).
narrative_ontology:cs_axiom('358c7fc0-e7ba-4792-9cf8-59294bec7f78', foundational, self_identification_sufficiency).
narrative_ontology:cs_axiom_status(self_identification_sufficiency, holdable).
narrative_ontology:cs_axiom_grounding('358c7fc0-e7ba-4792-9cf8-59294bec7f78', self_identification_sufficiency, conventional).
narrative_ontology:cs_reference_frame('358c7fc0-e7ba-4792-9cf8-59294bec7f78', transgender_recognition_accommodation_framework).
narrative_ontology:cs_drift_state('358c7fc0-e7ba-4792-9cf8-59294bec7f78', contemporary_categorical_override_era, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('358c7fc0-e7ba-4792-9cf8-59294bec7f78', '').
narrative_ontology:cs_kernel_id(woman_category__gender_identity_reading, woman_category).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(woman_category__gender_identity_reading, transgender_women).
narrative_ontology:constraint_beneficiary(woman_category__gender_identity_reading, gender_identity_advocacy_organizations).
narrative_ontology:constraint_beneficiary(woman_category__gender_identity_reading, institutional_diversity_officers).
narrative_ontology:constraint_victim(woman_category__gender_identity_reading, sex_based_protection_advocates).
narrative_ontology:constraint_victim(woman_category__gender_identity_reading, sex_segregated_space_administrators).
narrative_ontology:constraint_victim(woman_category__gender_identity_reading, female_athletes_competitive_class).
narrative_ontology:constraint_vindicates(woman_category__gender_identity_reading, gender_identity_primacy_doctrine).
narrative_ontology:constraint_vindicates(woman_category__gender_identity_reading, self_identification_sufficiency_principle).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Gain legal recognition, identity document revision rights, and access to sex-segregated spaces and competitive categories under this constraint. Their gender identity is the sole criterion for category membership. Exit would mean denial of identity recognition and exclusion from spaces aligned with their gender. The constraint's operation validates their categorical membership as women.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, transgender_women, beneficiary,
    organized, biographical, identity_locked, national).

% Develop model legislation, training materials, and institutional policies implementing gender identity as the determinative criterion. Receive foundation grants and institutional consulting contracts tied to this framework's adoption. Shape legal definitions through legislative testimony and litigation strategy. Could pivot advocacy focus but have built institutional capacity around this specific formulation.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, gender_identity_advocacy_organizations, agenda_setter,
    institutional, generational, mobile, national).

% Administer and enforce gender identity policies in universities, corporations, and government agencies. Their institutional authority and professional legitimacy depend on implementing this framework as organizational policy. Enforce compliance through training requirements, facility redesignation, and disciplinary processes for those who resist the definitional shift.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, institutional_diversity_officers, agenda_setter,
    institutional, biographical, constrained, local).
narrative_ontology:stakeholder_secondary_role(woman_category__gender_identity_reading, institutional_diversity_officers, beneficiary).

% Lose the ability to maintain sex-segregated spaces, sports categories, and legal protections premised on female biology under this constraint. Their framework treats biological sex as the relevant category for addressing sex-based oppression and violence; this constraint reclassifies that position as discriminatory. Face institutional sanction, deplatforming, and legal liability risk for maintaining sex-based boundaries.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, sex_based_protection_advocates, payer,
    organized, generational, constrained, national).

% Must redesignate facilities, revise access policies, and absorb legal liability under competing access-rights frameworks. Bear enforcement costs: monitoring compliance, managing conflicts between users with opposing rights claims, defending against lawsuits from either side. Cannot exit without abandoning sex-segregated provision entirely or facing civil rights violations.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, sex_segregated_space_administrators, payer,
    institutional, biographical, trapped, local).

% Compete in categories that include athletes with male-typical physiology under gender identity criteria. Bear competitive displacement costs where physiological advantage exists. Their advocacy for biology-based categories is reclassified as discriminatory under this constraint. Exit means abandoning competitive sport or accepting categorical inclusion they view as unfair.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, female_athletes_competitive_class, payer,
    moderate, biographical, constrained, national).

% Clinical assessment and diagnostic criteria for gender dysphoria become irrelevant under pure self-identification frameworks. Their gatekeeping function is bypassed: if identity alone determines category membership, medical transition becomes elective rather than diagnostic. Would argue for retained clinical assessment but are structurally excluded from definitional authority under this reading.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, medical_transition_gatekeepers, excluded,
    institutional, biographical, constrained, national).

% Analyze whether self-identification can serve as a stable categorical criterion across legal domains with different stakes. Examine the collision between access rights and exclusion rights, the weight assigned to subjective versus objective criteria, and whether the constraint's enforcement pattern reveals it as constructed policy rather than natural category. Take no position on gender identity validity but assess the structural coherence of the definitional framework.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, legal_philosophers_categorical_analysis, observer,
    analytical, generational, analytical, universal).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides legal and social recognition criteria for gender category membership, enabling identity document revision, facility access, and participation in sex-segregated domains. Solves the administrative problem of how institutions classify people when biological sex and gender identity diverge.
% TRANSFER_FUNCTION: Transfers categorical access rights and legal protections from a sex-biology framework to a gender-identity framework. Moves institutional authority over category definitions from medical/biological gatekeepers to self-identifying individuals and the advocacy organizations that shaped the policy.
% ABSENT_VOICES: Medical transition gatekeepers whose clinical assessment role is bypassed; sex-based protection advocates who view biological sex as the relevant category for addressing sex-based harm but are excluded from definitional authority and face institutional sanction for maintaining sex-based boundaries.
% DISAPPEARANCE_RATIONALE: If this definitional framework vanished overnight, institutions would revert to contested multi-criterion systems, sports governing bodies would reinstate biology-based eligibility rules, sex-segregated space access would return to anatomical or legal-sex criteria, identity document policies would require medical evidence of transition, and the entire legal architecture built on gender identity as sole criterion would require reconstruction.
% FOUNDING_PROBLEM: Transgender individuals faced legal non-recognition, identity document misalignment, exclusion from spaces matching their gender identity, and lack of institutional accommodation for gender identity distinct from assigned sex at birth.
% FOUNDING_PROBLEM_CORROBORATION: Gender identity advocacy organizations and transgender rights legal groups attest the founding problem persists and this framework is necessary for recognition. Sex-based protection advocates and sports fairness organizations attest the founding problem was substantially addressed through earlier multi-criterion accommodations and that this constraint has shifted from recognition to categorical override, with legal philosophers noting the framework now operates beyond accommodation into definitional authority. Independent legal analysis from civil liberties organizations outside either advocacy coalition documents the shift from transition-contingent recognition to self-identification sufficiency.
narrative_ontology:disappearance_verdict(woman_category__gender_identity_reading, world_rearranges).
narrative_ontology:founding_problem_status(woman_category__gender_identity_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(woman_category__gender_identity_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(woman_category__gender_identity_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(woman_category__gender_identity_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(woman_category__gender_identity_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(woman_category__gender_identity_reading, ExtMetricName, E),
    domain_priors:suppression_score(woman_category__gender_identity_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(woman_category__gender_identity_reading),
    narrative_ontology:constraint_metric(woman_category__gender_identity_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(woman_category__gender_identity_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(woman_category__gender_identity_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is substantial (0.68) because the constraint transfers categorical authority and access rights from biology-based frameworks to self-identification frameworks, creating identifiable winners and losers. The transfer is not Pareto-improving: sex-based protection advocates and female athletes in competitive categories bear real costs (loss of sex-based boundaries, competitive displacement) that are not offset by their gains. Suppression is high (0.72) because maintaining the constraint requires active enforcement against resistance: deplatforming sex-based advocates, sanctioning institutions that maintain biology-based criteria, legal penalties for 'discrimination' against self-identified category membership. Theater ratio is moderate (0.41): genuine recognition and accommodation functions coexist with increasing performative compliance (mandatory pronouns, training requirements, enforcement theater). Resistance is very high (0.79): the constraint faces sustained opposition from sex-based protection advocates, sports fairness organizations, and segments of feminist theory that view sex rather than gender identity as the relevant category. Accessibility collapse is moderate-low (0.48): alternative frameworks (biology-based, multi-criterion, intersex-accommodation) remain intellectually and legally viable, even where institutionally suppressed. The measurement trajectory shows all three metrics rising over the interval as the framework expanded from identity document accommodation to categorical override across all sex-segregated domains.
 *
 * PERSPECTIVAL GAP:
 *   The beneficiary seats experience this constraint as recognition and accommodation—validation of identity and correction of historical exclusion. The payer seats experience the same structure as categorical override and rights collision—loss of sex-based protections and competitive fairness, with suppression of objections reclassified as discrimination. The agenda-setter seats experience it as policy implementation and institutional authority. The excluded seats experience it as bypassed gatekeeping. The constraint's self-presentation as natural discovery of what gender categories fundamentally are (the mountain claim) diverges sharply from its enforcement pattern, which requires active suppression of competing frameworks and generates sustained resistance—signatures of constructed rather than discovered boundaries. The engine computes these seat-level classifications from the structural data; the authored mountain claim represents the framework's own self-understanding, not an adjudication of its ontological status.
 *
 * DIRECTIONALITY LOGIC:
 *   Transgender women are structural beneficiaries with identity-locked exit: the constraint validates their categorical membership as women and provides access to spaces and categories they cannot access under biology-based frameworks. Exit would mean denial of gender identity recognition. Gender identity advocacy organizations are agenda-setters who shaped the policy and derive institutional resources from its implementation; they have mobile exit (could shift advocacy focus) but built capacity around this framework. Institutional diversity officers are dual-positioned: they administer the framework (agenda-setters) and derive professional authority from its implementation (beneficiaries), with constrained exit (their institutional roles depend on this policy architecture). Sex-based protection advocates, space administrators, and female athletes are payers with constrained or trapped exit: they bear the costs of categorical redefinition (loss of sex-based boundaries, enforcement costs, competitive displacement) and face institutional sanction for resistance. Medical gatekeepers are excluded: their clinical assessment function is structurally bypassed under pure self-identification. The analytical observer seat sees the full structure without categorical commitment.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint exhibits mandatrophy signatures in its trajectory from accommodation to categorical override. Early interval: identity document revision and transition-contingent recognition solved genuine coordination problems (legal name/gender marker alignment, administrative clarity for transitioned individuals) with modest extraction. Middle interval: expansion from transition-contingent to self-identification-sufficient criteria, from identity documents to facility access and competitive categories, with rising extraction as the framework encountered domains where sex-biology and gender-identity criteria produce different outcomes and competing rights claims. Late interval: enforcement increasingly focused on suppressing resistance rather than solving coordination problems, with theater ratio rising as compliance becomes performative (mandatory training, pronoun policies, deplatforming dissent). The founding problem (legal non-recognition of transgender individuals) was substantially addressed by earlier multi-criterion accommodations; the constraint's persistence and expansion beyond that founding problem into categorical override across all domains is what generates the extractive pattern. Mandatrophy analysis reveals the constraint as coordination-extraction hybrid that has shifted over time toward the extraction pole, even as its self-presentation (the mountain claim) remains unchanged.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    natural_vs_constructed_category,
    'Is gender identity a natural, discovered feature of human ontology (the mountain claim), or a constructed definitional framework with identifiable beneficiaries?',
    'The enforcement pattern itself is diagnostic: natural categories do not require active suppression of alternatives, do not generate sustained resistance, and do not show rising theater ratios over time. If the constraint''s metrics continue to show high suppression, high resistance, and rising theater while the mountain claim persists, that divergence is evidence of constructed rather than natural boundaries.',
    'If natural, the constraint is a genuine mountain and resistance is confusion or bigotry; if constructed, it is a tangled rope or snare (coordination for some, extraction from others) and resistance is substantive disagreement over categorical authority. Classification type flips entirely.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(natural_vs_constructed_category, conceptual, 'Whether the constraint discovers or constructs categorical boundaries').

omega_variable(
    self_identification_sufficiency_boundary,
    'In which domains can self-identification serve as a sufficient categorical criterion without generating rights collisions or institutional dysfunction?',
    'Domain-by-domain empirical tracking: identity documents (low-stakes, low-collision), medical treatment (medium-stakes, clinical evidence relevant), sports eligibility (high-stakes, physiological advantage), sex-segregated spaces (high-stakes, exclusion-rights conflict). If ε and resistance vary systematically by domain stakes, the constraint is domain-dependent rather than universal.',
    'If self-identification sufficiency is domain-dependent, the mountain claim (universal categorical truth) fails and the framework requires domain-specific criteria. If it holds across all domains, the current collision costs are transitional rather than structural.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(self_identification_sufficiency_boundary, empirical, 'Whether self-identification criterion is domain-universal or stakes-dependent').

omega_variable(
    sibling_reading_foreclosure_vs_coexistence,
    'Do the gender_identity_reading and sex_biology_reading foreclose each other within a single legal framework, or can they coexist with domain-specific application?',
    'Legal systems that adopt hybrid criteria (self-identification for identity documents, biology-based for sports, multi-criterion for spaces) without logical contradiction demonstrate coexistence. Systems that require universal application of one criterion across all domains demonstrate foreclosure.',
    'If foreclosure is real, one reading must eventually dominate and suppress the other entirely. If coexistence is viable, the current conflict is over domain boundaries and stakes-weighting rather than categorical truth.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(sibling_reading_foreclosure_vs_coexistence, conceptual, 'Whether sibling readings logically foreclose or can coexist with domain partitioning').

omega_variable(
    beneficiary_capture_vs_universal_accommodation,
    'Does the constraint''s expansion from identity document recognition to categorical override across all domains serve universal accommodation (rising tide lifts all boats) or beneficiary capture (transfers authority and access from one group to another)?',
    'Track whether the constraint''s enforcement produces Pareto improvements (everyone better off or no one worse off) or creates identifiable losers. If sex-based protection advocates, female athletes, and space administrators bear uncompensated costs that do not diminish over time, beneficiary capture rather than universal accommodation is indicated.',
    'If universal accommodation, the resistance is transitional and will diminish as understanding spreads. If beneficiary capture, the resistance is structural and persistent because the constraint reallocates categorical authority and rights rather than solving a pure coordination problem.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(beneficiary_capture_vs_universal_accommodation, empirical, 'Whether enforcement pattern is Pareto-improving or redistributive').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(woman_category__gender_identity_reading, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(woma_tr_t0, woman_category__gender_identity_reading, theater_ratio, 0, 0.18).
narrative_ontology:measurement_basis(woma_tr_t0, observed).
narrative_ontology:measurement(woma_tr_t5, woman_category__gender_identity_reading, theater_ratio, 5, 0.23).
narrative_ontology:measurement_basis(woma_tr_t5, observed).
narrative_ontology:measurement(woma_tr_t10, woman_category__gender_identity_reading, theater_ratio, 10, 0.29).
narrative_ontology:measurement_basis(woma_tr_t10, observed).
narrative_ontology:measurement(woma_tr_t15, woman_category__gender_identity_reading, theater_ratio, 15, 0.34).
narrative_ontology:measurement_basis(woma_tr_t15, observed).
narrative_ontology:measurement(woma_tr_t20, woman_category__gender_identity_reading, theater_ratio, 20, 0.38).
narrative_ontology:measurement_basis(woma_tr_t20, observed).
narrative_ontology:measurement(woma_tr_t25, woman_category__gender_identity_reading, theater_ratio, 25, 0.41).
narrative_ontology:measurement_basis(woma_tr_t25, observed).

% Extraction over time
narrative_ontology:measurement(woma_be_t0, woman_category__gender_identity_reading, base_extractiveness, 0, 0.38).
narrative_ontology:measurement_basis(woma_be_t0, observed).
narrative_ontology:measurement(woma_be_t5, woman_category__gender_identity_reading, base_extractiveness, 5, 0.47).
narrative_ontology:measurement_basis(woma_be_t5, observed).
narrative_ontology:measurement(woma_be_t10, woman_category__gender_identity_reading, base_extractiveness, 10, 0.54).
narrative_ontology:measurement_basis(woma_be_t10, observed).
narrative_ontology:measurement(woma_be_t15, woman_category__gender_identity_reading, base_extractiveness, 15, 0.61).
narrative_ontology:measurement_basis(woma_be_t15, observed).
narrative_ontology:measurement(woma_be_t20, woman_category__gender_identity_reading, base_extractiveness, 20, 0.66).
narrative_ontology:measurement_basis(woma_be_t20, observed).
narrative_ontology:measurement(woma_be_t25, woman_category__gender_identity_reading, base_extractiveness, 25, 0.68).
narrative_ontology:measurement_basis(woma_be_t25, observed).

% Suppression requirement over time
narrative_ontology:measurement(woma_su_t0, woman_category__gender_identity_reading, suppression_requirement, 0, 0.42).
narrative_ontology:measurement_basis(woma_su_t0, observed).
narrative_ontology:measurement(woma_su_t5, woman_category__gender_identity_reading, suppression_requirement, 5, 0.51).
narrative_ontology:measurement_basis(woma_su_t5, observed).
narrative_ontology:measurement(woma_su_t10, woman_category__gender_identity_reading, suppression_requirement, 10, 0.59).
narrative_ontology:measurement_basis(woma_su_t10, observed).
narrative_ontology:measurement(woma_su_t15, woman_category__gender_identity_reading, suppression_requirement, 15, 0.66).
narrative_ontology:measurement_basis(woma_su_t15, observed).
narrative_ontology:measurement(woma_su_t20, woman_category__gender_identity_reading, suppression_requirement, 20, 0.7).
narrative_ontology:measurement_basis(woma_su_t20, observed).
narrative_ontology:measurement(woma_su_t25, woman_category__gender_identity_reading, suppression_requirement, 25, 0.72).
narrative_ontology:measurement_basis(woma_su_t25, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(woman_category__gender_identity_reading, identity_coordination).
narrative_ontology:affects_constraint(woman_category__gender_identity_reading, woman_category__sex_biology_reading).
narrative_ontology:affects_constraint(woman_category__gender_identity_reading, woman_category__intersex_accommodation_reading).

% DUAL FORMULATION NOTE:
% This constraint is one of three readings of the woman_category kernel. The gender_identity_reading (this story) makes self-identification the sole sufficient criterion. The sex_biology_reading makes chromosomal/reproductive biology determinative. The intersex_accommodation_reading treats biological sex as a non-binary spectrum. Each reading has different victim sets, different ε values across policy domains, and different enforcement costs. The ε divergence across readings and domains is why they must be modeled as separate constraints rather than as observables of a single constraint—ε is constraint-invariant, not observer-invariant. The three readings are linked via network.affects_constraints because each reading's policy implementation creates institutional pressure on the others (jurisdictional conflicts, litigation strategy, facility access disputes).

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
