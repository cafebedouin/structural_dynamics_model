% ============================================================================
% CONSTRAINT STORY: waitangi_sovereignty_allocation__crown_sovereignty_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_waitangi_sovereignty_allocation__crown_sovereignty_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: waitangi_sovereignty_allocation__crown_sovereignty_reading
 *   human_readable: Treaty of Waitangi Crown Sovereignty Reading - Complete Sovereignty Cession
 *   domain: constitutional_law/indigenous_rights/post_colonial_governance
 *
 * SUMMARY:
 *   The Crown sovereignty reading of the Treaty of Waitangi treats the
 *   English text Article I as effecting complete sovereignty cession from
 *   Māori chiefs to the British Crown, establishing Westminster parliamentary
 *   supremacy as the foundational constitutional principle. This reading
 *   asserts itself as the natural legal order - an inevitable consequence of
 *   treaty signature and colonial settlement - rather than as one contested
 *   interpretation among structurally equivalent alternatives. The constraint
 *   is CLAIMED as mountain (the Crown institutional framing: parliamentary
 *   supremacy as constitutional bedrock) while the authored metrics describe
 *   substantially extractive, actively enforced operation with identifiable
 *   beneficiaries and victims. The divergence between claim and metrics is
 *   the measurement: a claimed natural constitutional order that operates
 *   extractively and requires active suppression of alternative readings is
 *   exactly the false summit signature the framework exists to detect.
 *
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(waitangi_sovereignty_allocation__crown_sovereignty_reading, 0.82).
domain_priors:suppression_score(waitangi_sovereignty_allocation__crown_sovereignty_reading, 0.88).
domain_priors:theater_ratio(waitangi_sovereignty_allocation__crown_sovereignty_reading, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, extractiveness, 0.82).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 0.88).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, accessibility_collapse, 0.73).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, resistance, 0.71).

% --- Constraint claim ---
narrative_ontology:constraint_claim(waitangi_sovereignty_allocation__crown_sovereignty_reading, mountain).
narrative_ontology:human_readable(waitangi_sovereignty_allocation__crown_sovereignty_reading, "Treaty of Waitangi Crown Sovereignty Reading - Complete Sovereignty Cession").
narrative_ontology:topic_domain(waitangi_sovereignty_allocation__crown_sovereignty_reading, "constitutional_law/indigenous_rights/post_colonial_governance").

domain_priors:requires_active_enforcement(waitangi_sovereignty_allocation__crown_sovereignty_reading).
domain_priors:emerges_naturally(waitangi_sovereignty_allocation__crown_sovereignty_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(waitangi_sovereignty_allocation__crown_sovereignty_reading, '8fad74a1-6c9e-4d24-84dd-7c3f4a7bfb92').
narrative_ontology:cs_kernel_codification('8fad74a1-6c9e-4d24-84dd-7c3f4a7bfb92', fixed_text).
narrative_ontology:cs_authority_grounding('8fad74a1-6c9e-4d24-84dd-7c3f4a7bfb92', lineage).
narrative_ontology:cs_interpretation_layer_present('8fad74a1-6c9e-4d24-84dd-7c3f4a7bfb92').
narrative_ontology:cs_reading_relation('8fad74a1-6c9e-4d24-84dd-7c3f4a7bfb92', waitangi_sovereignty_allocation__partnership_reading, influences).
narrative_ontology:cs_reading_relation('8fad74a1-6c9e-4d24-84dd-7c3f4a7bfb92', waitangi_sovereignty_allocation__rangatiratanga_reading, forecloses).
narrative_ontology:cs_axiom('8fad74a1-6c9e-4d24-84dd-7c3f4a7bfb92', foundational, sovereignty_complete_cession_english_text).
narrative_ontology:cs_axiom_status(sovereignty_complete_cession_english_text, holdable).
narrative_ontology:cs_axiom_grounding('8fad74a1-6c9e-4d24-84dd-7c3f4a7bfb92', sovereignty_complete_cession_english_text, conventional).
narrative_ontology:cs_axiom('8fad74a1-6c9e-4d24-84dd-7c3f4a7bfb92', foundational, parliamentary_supremacy_indivisible).
narrative_ontology:cs_axiom_status(parliamentary_supremacy_indivisible, holdable).
narrative_ontology:cs_axiom_grounding('8fad74a1-6c9e-4d24-84dd-7c3f4a7bfb92', parliamentary_supremacy_indivisible, deontological).
narrative_ontology:cs_axiom('8fad74a1-6c9e-4d24-84dd-7c3f4a7bfb92', secondary, english_text_interpretive_primacy).
narrative_ontology:cs_axiom_status(english_text_interpretive_primacy, holdable).
narrative_ontology:cs_axiom_grounding('8fad74a1-6c9e-4d24-84dd-7c3f4a7bfb92', english_text_interpretive_primacy, conventional).
narrative_ontology:cs_reference_frame('8fad74a1-6c9e-4d24-84dd-7c3f4a7bfb92', westminster_parliamentary_supremacy).
narrative_ontology:cs_drift_state('8fad74a1-6c9e-4d24-84dd-7c3f4a7bfb92', contemporary_post_colonial_era, gap(authority_erosion, substantial, false)).
narrative_ontology:cs_created_at('8fad74a1-6c9e-4d24-84dd-7c3f4a7bfb92', '').
narrative_ontology:cs_kernel_id(waitangi_sovereignty_allocation__crown_sovereignty_reading, waitangi_sovereignty_allocation).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__crown_sovereignty_reading, crown_parliament).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__crown_sovereignty_reading, settler_colonial_administration).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__crown_sovereignty_reading, westminster_legal_system).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__crown_sovereignty_reading, maori_iwi_hapu).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__crown_sovereignty_reading, indigenous_resource_holders).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__crown_sovereignty_reading, treaty_partner_claimants).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__crown_sovereignty_reading, parliamentary_supremacy_doctrine).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__crown_sovereignty_reading, unitary_sovereignty_principle).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__crown_sovereignty_reading, crown_prerogative_authority).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Exercises plenary legislative authority over all territory and persons within New Zealand, grounded in the claim that Article I of the English treaty text effected complete sovereignty cession. Enacts legislation affecting Māori lands, resources, and governance without constitutional requirement for Māori consent. Maintains that parliamentary supremacy is the foundational constitutional principle inherited from Westminster and confirmed by the treaty.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, crown_parliament, agenda_setter,
    institutional, civilizational, arbitrage, national).

% Benefits from Crown's unilateral allocation authority over land, resources, and regulatory frameworks. Administrative efficiency and legal certainty flow from the claim that one sovereign authority exists with no constitutionally mandated power-sharing. Colonial development proceeded on the premise that Crown ownership and allocation rights were absolute following sovereignty cession.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, settler_colonial_administration, beneficiary,
    institutional, generational, mobile, national).

% Operates as the exclusive source of legal authority, importing English common law and parliamentary legislative supremacy as foundational structure. The sovereignty reading validates Westminster institutional forms as the natural constitutional order, requiring no accommodation of indigenous legal systems or power-sharing mechanisms.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, westminster_legal_system, beneficiary,
    institutional, civilizational, arbitrage, national).

% Experience legislative and administrative decisions affecting ancestral lands, fisheries, and cultural resources without effective veto or co-decision authority. The sovereignty reading treats their interests as matters of policy discretion rather than constitutional right. Exit is identity-locked: relationship to land and kinship structures are constitutive; individuals can emigrate but collective iwi/hapū identity cannot exit the constitutional relationship.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, maori_iwi_hapu, payer,
    organized, civilizational, identity_locked, regional).

% Hold customary interests in land, fisheries, and other taonga that are subordinated to Crown allocation authority under the sovereignty reading. Resource alienation, regulatory taking, and environmental decisions proceed through Crown processes that do not require indigenous consent or partnership deliberation. Identity-locked through customary connection to specific resources and places.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, indigenous_resource_holders, payer,
    moderate, generational, identity_locked, local).

% Assert treaty partnership and co-decision rights, but under the sovereignty reading these claims are legally non-binding moral arguments rather than enforceable constitutional constraints. Tribunal findings and negotiated settlements occur within a framework where Crown retains ultimate unilateral authority. Exit constrained rather than identity-locked: the claimant role is adopted strategically through tribunal and negotiation processes.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, treaty_partner_claimants, payer,
    organized, generational, constrained, national).

% Advance alternative readings grounded in the Māori text Article II, arguing that tino rangatiratanga (full authority) was retained and only kāwanatanga (governorship over settlers) was ceded. Under the sovereignty reading their textual and historical arguments are treated as politically sympathetic but legally ineffective - the English text and Westminster constitutional doctrine control interpretation.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, rangatiratanga_advocates, excluded,
    organized, civilizational, identity_locked, national).

% Examine the sovereignty reading against comparative post-colonial constitutional arrangements in Canada, Australia, and elsewhere. Document that most common-law jurisdictions with indigenous treaties have evolved power-sharing, consultation requirements, or constitutional recognition mechanisms - making New Zealand's pure parliamentary supremacy reading increasingly anomalous in the Commonwealth context.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, comparative_constitutional_scholars, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes a single unambiguous source of legal authority for legislative and administrative action across the territory, avoiding jurisdictional conflicts between Crown and indigenous governance structures.
% TRANSFER_FUNCTION: Transfers plenary legislative authority and ultimate resource allocation power from distributed iwi/hapū rangatiratanga to Crown Parliament; subordinates Māori collective interests to parliamentary discretion exercised through majoritarian process.
% ABSENT_VOICES: Rangatiratanga advocates and Māori legal scholars advancing alternative constitutional readings grounded in the Māori text are structurally excluded from authoritative interpretation - the sovereignty reading grants interpretive authority to Westminster-derived courts and Parliament whose institutional interests align with unitary Crown authority.
% DISAPPEARANCE_RATIONALE: If the sovereignty reading disappeared and was replaced by constitutionally mandatory power-sharing or co-governance arrangements, legislative process would fundamentally change: resource management decisions would require Māori consent or partnership deliberation; administrative efficiency would decrease; distributive outcomes would shift toward indigenous interests; Westminster parliamentary supremacy would be displaced by a hybrid constitutional order.
% FOUNDING_PROBLEM: Colonial settlement created jurisdictional ambiguity and potential for violent conflict between Crown authority over settlers and Māori rangatiratanga over lands and peoples. A clear constitutional allocation of ultimate authority was seen as necessary to prevent ongoing jurisdictional warfare.
% FOUNDING_PROBLEM_CORROBORATION: The Crown and settler institutional actors attest the founding problem remains live, citing the need for clear legislative supremacy. Māori claimants, Treaty Tribunal findings, and comparative constitutional scholars document that the founding problem has transformed: the contemporary question is not whether to avoid violent jurisdictional conflict (that question was settled by the 19th century) but whether post-colonial legitimacy requires power-sharing arrangements - making the sovereignty reading's answer to the original problem obsolete or extractive relative to the current constitutional question.
narrative_ontology:disappearance_verdict(waitangi_sovereignty_allocation__crown_sovereignty_reading, world_rearranges).
narrative_ontology:founding_problem_status(waitangi_sovereignty_allocation__crown_sovereignty_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(waitangi_sovereignty_allocation__crown_sovereignty_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(waitangi_sovereignty_allocation__crown_sovereignty_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(waitangi_sovereignty_allocation__crown_sovereignty_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(waitangi_sovereignty_allocation__crown_sovereignty_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, ExtMetricName, E),
    domain_priors:suppression_score(waitangi_sovereignty_allocation__crown_sovereignty_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(waitangi_sovereignty_allocation__crown_sovereignty_reading),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(waitangi_sovereignty_allocation__crown_sovereignty_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is high (0.82 at interval end) because the sovereignty reading concentrates legislative and resource allocation authority in Crown institutions while subordinating Māori collective interests to parliamentary discretion - the gap between coordination benefit (clear authority structure) and extraction (unilateral power without partnership constraint) has widened as alternative power-sharing models became available in comparative constitutional practice. Suppression is higher still (0.88) because the reading's persistence depends on institutional gatekeeping: courts apply Westminster doctrine, Parliament interprets its own supremacy, and the Māori text is treated as legally subordinate to the English text. Theater ratio rises over the interval (0.15 to 0.42) as consultation processes, tribunal mechanisms, and settlement negotiations create performative partnership activity while leaving the underlying unilateral authority structure intact. Accessibility collapse is substantial (0.73): once the sovereignty doctrine is institutionally established, exit to alternative constitutional arrangements requires either revolution or negotiated constitutional replacement - individual Māori can emigrate but collective iwi/hapū cannot exit the Crown authority relationship. Resistance is high (0.71): ongoing tribunal claims, rangatiratanga advocacy, and comparative constitutional arguments demonstrate sustained contestation of the reading's legitimacy.
 *
 * PERSPECTIVAL GAP:
 *   From the Crown institutional seat, the sovereignty reading is foundational constitutional law - parliamentary supremacy is the bedrock from which all other legal arrangements derive, and treating it as constructed or extractive is incoherent within Westminster doctrine. From the Māori collective seats, the same structure operates as enforced extraction: the reading concentrates power in institutions that represent settler majority interests and systematically subordinates indigenous collective interests despite the treaty's bilateral origin. The engine computes this divergence from the structural data: high extraction and suppression from identity-locked victim seats, low extraction from beneficiary seats with arbitrage exit. The authored mountain claim reflects the Crown framing; the metrics reflect the operational reality experienced by the affected parties.
 *
 * DIRECTIONALITY LOGIC:
 *   Crown Parliament and Westminster legal institutions are structural beneficiaries: they exercise plenary authority and collect the institutional rents from unilateral allocation power (d toward beneficiary end). Settler colonial administration benefits from the legal certainty and allocation efficiency of unitary Crown authority. Māori iwi/hapū, indigenous resource holders, and treaty partner claimants are structural targets: they bear the costs of subordinated interests, resource alienation without consent, and partnership claims treated as non-binding. Their exit is identity-locked (collective relationship to land and kinship structures are constitutive) or constrained (strategic claimant role), amplifying effective extraction. Rangatiratanga advocates are excluded rather than coordinated - their constitutional arguments are structurally inadmissible under the sovereignty reading's interpretive framework.
 *
 * MANDATROPHY ANALYSIS:
 *   The sovereignty reading exhibits classic mandatrophy signatures: it was constructed to solve a genuine founding problem (jurisdictional conflict in early colonial settlement) but its persistence in unchanged form serves institutional beneficiaries (Crown Parliament, Westminster legal system) whose interests diverge from the founding mandate. The founding problem has transformed - contemporary legitimacy questions center on post-colonial power-sharing, not on preventing violent jurisdictional warfare - but the sovereignty reading continues to operate as if the original problem were live, using historical founding legitimacy to validate present extraction. The rising theater ratio (consultation processes that leave underlying unilateral authority intact) and the founding_problem_status = contested signal document the gap between claimed coordination function and operational extraction function.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    natural_vs_constructed_constitutional_order,
    'Is Westminster parliamentary supremacy a natural/inevitable constitutional structure that the Treaty confirmed, or is it one constructed interpretation of an ambiguous bilateral agreement that could equally support partnership or retained rangatiratanga readings?',
    'Comparative constitutional analysis of post-colonial treaty jurisdictions; examination of contemporaneous Māori understanding of sovereignty concepts; historical analysis of whether ''complete sovereignty cession'' was the mutually understood meaning at treaty signing or a retrospective Crown interpretation.',
    'If the sovereignty reading is one constructed interpretation among structurally equivalent alternatives, its classification shifts from mountain (natural constitutional order) to snare or tangled_rope (enforced extraction serving institutional beneficiaries). If parliamentary supremacy is the inevitable legal structure regardless of interpretive contest, the mountain classification holds and victim experiences reflect the costs of living under natural constitutional law.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(natural_vs_constructed_constitutional_order, conceptual, 'Whether unitary Crown sovereignty is natural constitutional law or constructed institutional choice').

omega_variable(
    textual_primacy_vs_partnership_intent,
    'Should constitutional interpretation privilege the English text Article I (sovereignty cession language) or weigh it equally against the Māori text Article II (rangatiratanga retention language) and evidence of Māori signatories'' understanding of the agreement as partnership rather than submission?',
    'Comparative treaty interpretation doctrine (Canadian treaty interpretation principles, international law of treaties); historical evidence of translation accuracy and Māori understanding at signing; examination of whether English text primacy is a neutral interpretive principle or a beneficiary-serving framing choice.',
    'If textual primacy is a neutral principle, the sovereignty reading''s extraction is an unfortunate but structurally necessary consequence of clear treaty language. If English text primacy is itself a constructed choice that systematically favors Crown interests over Māori interests, the sovereignty reading''s high extraction and suppression scores reflect institutional capture of interpretive authority rather than inevitable legal structure.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(textual_primacy_vs_partnership_intent, conceptual, 'Whether English text primacy is neutral interpretive principle or beneficiary-serving framing').

omega_variable(
    sovereignty_indivisibility_assumption,
    'Is sovereignty necessarily indivisible (requiring one ultimate authority) or can it be shared/distributed across partnership structures without creating intractable jurisdictional conflict?',
    'Empirical examination of power-sharing constitutional arrangements in Canada (Section 35 rights, duty to consult), Australia (Mabo native title), and other post-colonial jurisdictions with indigenous treaty partners. Test whether partnership/co-governance models produce workable legal orders or devolve into jurisdictional chaos.',
    'If sovereignty is necessarily indivisible, the coordination function of the sovereignty reading (clear unitary authority) is structurally required and high extraction is the unavoidable price of constitutional order. If sovereignty can be shared without chaos, the sovereignty reading''s unilateral authority structure is a choice serving beneficiary interests rather than a logical necessity, and the classification shifts toward enforced extraction.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(sovereignty_indivisibility_assumption, empirical, 'Whether sovereignty indivisibility is logical necessity or institutional preference').

omega_variable(
    beneficiary_identification_ambiguity,
    'Are Crown Parliament and Westminster legal institutions beneficiaries of a constitutional structure (in which case their gains are legitimate coordination rents) or beneficiaries of an extractive reading that systematically concentrates power in settler-majority institutions (in which case their gains are captured rents from suppressing alternative constitutional arrangements)?',
    'Examination of whether institutional beneficiaries actively suppress alternative readings through interpretive gatekeeping, or whether the sovereignty reading would persist even if interpretive authority were distributed to include Māori legal perspectives. Comparative analysis of whether jurisdictions with indigenous power-sharing still maintain functional governance.',
    'If beneficiary gains flow from neutral coordination function, the mountain claim holds and victim costs are the price of living under natural law. If beneficiary gains depend on active suppression of alternatives, the false summit signature is confirmed and classification shifts to tangled_rope or snare.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(beneficiary_identification_ambiguity, empirical, 'Whether institutional beneficiaries collect coordination rents or captured rents from suppressed alternatives').

omega_variable(
    founding_problem_transformation,
    'Has the founding problem (violent jurisdictional conflict between Crown and Māori authority) been genuinely solved by the sovereignty reading, or has it been transformed into a different problem (post-colonial legitimacy requiring power-sharing) to which the sovereignty reading is no longer the appropriate answer?',
    'Historical analysis of when violent jurisdictional conflict ceased (19th century military outcomes); examination of whether contemporary constitutional disputes center on jurisdictional warfare or on legitimacy and partnership obligations; comparative assessment of whether jurisdictions maintaining unilateral Crown authority face ongoing legitimacy crises.',
    'If the founding problem is still live, the sovereignty reading''s coordination function justifies its extraction and the constraint is rope or tangled_rope. If the founding problem has transformed and the sovereignty reading persists to serve institutional beneficiaries rather than to solve the current problem, the constraint exhibits mandatrophy and classifications shift toward snare or piton.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(founding_problem_transformation, conceptual, 'Whether founding problem transformation converts coordination function to extractive persistence').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(waitangi_sovereignty_allocation__crown_sovereignty_reading, 0, 180).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(wait_tr_t0, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 0, 0.15).
narrative_ontology:measurement_basis(wait_tr_t0, observed).
narrative_ontology:measurement(wait_tr_t30, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 30, 0.19).
narrative_ontology:measurement_basis(wait_tr_t30, observed).
narrative_ontology:measurement(wait_tr_t60, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 60, 0.24).
narrative_ontology:measurement_basis(wait_tr_t60, observed).
narrative_ontology:measurement(wait_tr_t90, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 90, 0.29).
narrative_ontology:measurement_basis(wait_tr_t90, observed).
narrative_ontology:measurement(wait_tr_t120, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 120, 0.35).
narrative_ontology:measurement_basis(wait_tr_t120, observed).
narrative_ontology:measurement(wait_tr_t150, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 150, 0.39).
narrative_ontology:measurement_basis(wait_tr_t150, observed).
narrative_ontology:measurement(wait_tr_t180, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 180, 0.42).
narrative_ontology:measurement_basis(wait_tr_t180, observed).

% Extraction over time
narrative_ontology:measurement(wait_be_t0, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 0, 0.58).
narrative_ontology:measurement_basis(wait_be_t0, observed).
narrative_ontology:measurement(wait_be_t30, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 30, 0.64).
narrative_ontology:measurement_basis(wait_be_t30, observed).
narrative_ontology:measurement(wait_be_t60, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 60, 0.69).
narrative_ontology:measurement_basis(wait_be_t60, observed).
narrative_ontology:measurement(wait_be_t90, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 90, 0.74).
narrative_ontology:measurement_basis(wait_be_t90, observed).
narrative_ontology:measurement(wait_be_t120, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 120, 0.78).
narrative_ontology:measurement_basis(wait_be_t120, observed).
narrative_ontology:measurement(wait_be_t150, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 150, 0.8).
narrative_ontology:measurement_basis(wait_be_t150, observed).
narrative_ontology:measurement(wait_be_t180, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 180, 0.82).
narrative_ontology:measurement_basis(wait_be_t180, observed).

% Suppression requirement over time
narrative_ontology:measurement(wait_su_t0, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 0, 0.72).
narrative_ontology:measurement_basis(wait_su_t0, observed).
narrative_ontology:measurement(wait_su_t30, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 30, 0.76).
narrative_ontology:measurement_basis(wait_su_t30, observed).
narrative_ontology:measurement(wait_su_t60, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 60, 0.79).
narrative_ontology:measurement_basis(wait_su_t60, observed).
narrative_ontology:measurement(wait_su_t90, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 90, 0.82).
narrative_ontology:measurement_basis(wait_su_t90, observed).
narrative_ontology:measurement(wait_su_t120, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 120, 0.85).
narrative_ontology:measurement_basis(wait_su_t120, observed).
narrative_ontology:measurement(wait_su_t150, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 150, 0.87).
narrative_ontology:measurement_basis(wait_su_t150, observed).
narrative_ontology:measurement(wait_su_t180, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 180, 0.88).
narrative_ontology:measurement_basis(wait_su_t180, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(waitangi_sovereignty_allocation__crown_sovereignty_reading, enforcement_mechanism).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__crown_sovereignty_reading, waitangi_sovereignty_allocation__partnership_reading).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__crown_sovereignty_reading, waitangi_sovereignty_allocation__rangatiratanga_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the waitangi_sovereignty_allocation kernel family. The sovereignty reading, partnership reading, and rangatiratanga reading are structurally distinct constraints (different ε values, different beneficiary/victim sets) instantiated from the same treaty instrument through different interpretive frameworks. Network linkage documents that the sovereignty reading's institutional supremacy claim influences the operating environment for alternative readings - Crown parliamentary authority creates structural constraints on partnership and rangatiratanga implementations even when those frameworks are nominally recognized.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
