% ============================================================================
% CONSTRAINT STORY: acceptable_risk_energy__expected_value_dominant
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_acceptable_risk_energy__expected_value_dominant, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: acceptable_risk_energy__expected_value_dominant
 *   human_readable: Expected-Value Aggregate Harm Minimization (Acceptable Risk Reading)
 *   domain: risk_assessment/energy_policy/decision_theory
 *
 * SUMMARY:
 *   This constraint is the expected-value-dominant reading of the acceptable
 *   risk kernel in energy policy. It operationalizes 'acceptable risk' as
 *   minimizing aggregate expected mortality across all pathways using
 *   mortality-per-TWh metrics, which mathematically advantages pathways with
 *   distributed chronic harm (fossil fuels) over those with concentrated
 *   catastrophic potential (nuclear). The reading is claimed as a natural
 *   feature of rational decision-making under uncertainty (mountain),
 *   grounded in expected utility theory as the unique coherent decision rule.
 *   The FSM hypothesis: the framework's mathematical structure produces
 *   systematic distributional consequences that benefit identifiable parties
 *   (fossil fuel industry, incumbent energy infrastructure) while rendering
 *   alternative risk logics illegitimate, and the 'natural law' framing
 *   forecloses contestation of those consequences.
 *
 * KEY AGENTS:
 *   - fossil_fuel_industry: Primary beneficiary (institutional/constrained) — the framework's distributional bias structurally advantages their pathway
 *   - expected_value_economists: Agenda setter (institutional/arbitrage) — sets the methodological standard
 *   - aggregate_welfare_institutions: Agenda setter (institutional/mobile) — operationalizes the framework in policy
 *   - fossil_pathway_mortality_burden_populations: Primary victim (powerless/trapped) — bears the distributed chronic mortality
 *   - nuclear_safety_advocates: Secondary victim (organized/constrained) — their tail-risk concerns are suppressed as innumerate
 *   - catastrophic_risk_researchers: Excluded (moderate/constrained) — alternative frameworks dismissed as incoherent
 *   - energy_policy_analysts: Observer (institutional/analytical) — documents the framework's distributional structure
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(acceptable_risk_energy__expected_value_dominant, 0.67).
domain_priors:suppression_score(acceptable_risk_energy__expected_value_dominant, 0.78).
domain_priors:theater_ratio(acceptable_risk_energy__expected_value_dominant, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, extractiveness, 0.67).
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, suppression_requirement, 0.78).
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, accessibility_collapse, 0.71).
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, resistance, 0.58).

% --- Constraint claim ---
narrative_ontology:constraint_claim(acceptable_risk_energy__expected_value_dominant, mountain).
narrative_ontology:human_readable(acceptable_risk_energy__expected_value_dominant, "Expected-Value Aggregate Harm Minimization (Acceptable Risk Reading)").
narrative_ontology:topic_domain(acceptable_risk_energy__expected_value_dominant, "risk_assessment/energy_policy/decision_theory").

domain_priors:requires_active_enforcement(acceptable_risk_energy__expected_value_dominant).
domain_priors:emerges_naturally(acceptable_risk_energy__expected_value_dominant).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(acceptable_risk_energy__expected_value_dominant, '260e316b-bde7-4083-b3ea-74472647e4db').
narrative_ontology:cs_kernel_codification('260e316b-bde7-4083-b3ea-74472647e4db', formalized).
narrative_ontology:cs_authority_grounding('260e316b-bde7-4083-b3ea-74472647e4db', expertise).
narrative_ontology:cs_interpretation_layer_present('260e316b-bde7-4083-b3ea-74472647e4db').
narrative_ontology:cs_reading_relation('260e316b-bde7-4083-b3ea-74472647e4db', acceptable_risk_energy__catastrophic_tail_dominant, coexists_with).
narrative_ontology:cs_reading_relation('260e316b-bde7-4083-b3ea-74472647e4db', acceptable_risk_energy__option_value_preserving, coexists_with).
narrative_ontology:cs_axiom('260e316b-bde7-4083-b3ea-74472647e4db', foundational, expected_utility_unique_coherence).
narrative_ontology:cs_axiom_status(expected_utility_unique_coherence, holdable).
narrative_ontology:cs_axiom_grounding('260e316b-bde7-4083-b3ea-74472647e4db', expected_utility_unique_coherence, empirically_contingent).
narrative_ontology:cs_axiom('260e316b-bde7-4083-b3ea-74472647e4db', secondary, probabilistic_discounting_mandatory).
narrative_ontology:cs_axiom_status(probabilistic_discounting_mandatory, holdable).
narrative_ontology:cs_axiom_grounding('260e316b-bde7-4083-b3ea-74472647e4db', probabilistic_discounting_mandatory, instrumental).
narrative_ontology:cs_reference_frame('260e316b-bde7-4083-b3ea-74472647e4db', expected_utility_axiomatic_rationality).
narrative_ontology:cs_drift_state('260e316b-bde7-4083-b3ea-74472647e4db', post_fukushima_tail_risk_salience, gap(axiom_overriding, substantial, false)).
narrative_ontology:cs_created_at('260e316b-bde7-4083-b3ea-74472647e4db', '').
narrative_ontology:cs_kernel_id(acceptable_risk_energy__expected_value_dominant, acceptable_risk_energy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__expected_value_dominant, fossil_fuel_industry).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__expected_value_dominant, expected_value_economists).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__expected_value_dominant, aggregate_welfare_institutions).
narrative_ontology:constraint_victim(acceptable_risk_energy__expected_value_dominant, fossil_pathway_mortality_burden_populations).
narrative_ontology:constraint_victim(acceptable_risk_energy__expected_value_dominant, nuclear_safety_advocates).
narrative_ontology:constraint_victim(acceptable_risk_energy__expected_value_dominant, catastrophic_risk_researchers).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__expected_value_dominant, expected_utility_theory_sufficiency).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__expected_value_dominant, probabilistic_discounting_legitimacy).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Benefits structurally from a risk framework that distributes chronic mortality across populations and time rather than concentrating it in salient catastrophic events. The mortality-per-TWh framing renders air pollution deaths — which occur diffusely over decades — statistically small compared to total energy generated, while nuclear accidents (even when probabilistically rare) concentrate visibility. The industry does not administrate the risk framework but its economic viability depends on this distributional logic remaining authoritative in policy.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, fossil_fuel_industry, beneficiary,
    institutional, generational, constrained, global).

% Set the methodological standard for acceptable risk in energy policy by publishing mortality-per-TWh analyses, serving on regulatory advisory panels, and training the next generation of policy analysts. They defend expected utility theory as the rational foundation for risk assessment and treat probabilistic discounting of tail risks as mathematically necessary. Their professional authority is grounded in this framework's claimed objectivity.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, expected_value_economists, agenda_setter,
    institutional, generational, arbitrage, global).

% International development agencies, public health bodies, and energy regulators who adopt mortality-per-TWh as the decision rule for energy pathway comparison. They commission the studies, cite the metrics in official guidance, and structure investment decisions around minimizing aggregate expected deaths. Their mandate is population-level welfare optimization, which they operationalize through this framework.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, aggregate_welfare_institutions, agenda_setter,
    institutional, generational, mobile, global).

% Bear the distributed chronic mortality from air pollution, mining accidents, and occupational disease that the framework aggregates into its denominator. They experience the harm as early death, respiratory disease, and community health collapse, but the statistical framing renders each individual death a small fraction of the total energy produced. They have no exit from the airshed or the energy system that generates the exposure.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, fossil_pathway_mortality_burden_populations, payer,
    powerless, biographical, trapped, local).

% Argue that the framework systematically underweights catastrophic nuclear risk by multiplying low probability by high consequence, producing a misleadingly small expected value. They point to Chernobyl and Fukushima as evidence that tail risks materialize and that probabilistic discounting fails when the uncertainty is deep. The framework suppresses this concern by treating their position as innumerate risk aversion rather than legitimate uncertainty about probability models.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, nuclear_safety_advocates, payer,
    organized, biographical, constrained, national).

% Propose alternative risk frameworks that weight tail outcomes by regret minimization, option value preservation, or precautionary principles rather than expected value. They are structurally excluded from policy influence because the aggregate welfare institutions treat expected utility as the only rational decision rule, dismissing non-expected-value approaches as incoherent or ideological. Their research is cited as interesting but not actionable.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, catastrophic_risk_researchers, excluded,
    moderate, civilizational, constrained, global).

% Study how different risk frameworks produce different energy pathway rankings. They document that the mortality-per-TWh metric systematically favors pathways with distributed chronic harm over those with concentrated catastrophic potential, and that this distributional bias is a feature of the mathematical structure, not an empirical discovery. They observe the framework's operation without having authority to change it.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, energy_policy_analysts, observer,
    institutional, generational, analytical, national).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a single commensurable metric (deaths per unit energy) for comparing heterogeneous risks across energy pathways, enabling rational policy optimization and resource allocation decisions.
% TRANSFER_FUNCTION: Transfers chronic mortality burden from high-salience catastrophic events to low-salience distributed deaths by mathematically discounting low-probability high-consequence outcomes, which structurally advantages pathways with diffuse harm profiles.
% ABSENT_VOICES: Alternative risk frameworks (catastrophic tail weighting, option value preservation, precautionary approaches) are excluded from policy consideration by being framed as mathematically incoherent or as irrational risk aversion rather than legitimate uncertainty management strategies.
% DISAPPEARANCE_RATIONALE: If this framework vanished, energy policy would immediately face the question of how to compare incommensurable risks. Some jurisdictions would adopt catastrophic-tail-dominant readings (prioritizing avoidance of worst-case outcomes); others would adopt option-value-preserving readings (maintaining pathway diversity); fossil-dependent economies would lose the statistical cover the framework provides for chronic mortality; nuclear advocates would gain leverage. The energy investment landscape would reorganize around the new risk logics.
% FOUNDING_PROBLEM: Energy policy in the 1970s faced proliferating pathways (nuclear expansion, coal dependence, emerging renewables) with no commensurable basis for risk comparison — different hazard types (radiation vs pollution), different temporal profiles (immediate vs delayed), different spatial distributions (localized vs diffuse) made rational comparison impossible.
% FOUNDING_PROBLEM_CORROBORATION: Expected-value economists and aggregate welfare institutions attest the problem remains live — rational policy still requires commensurable metrics. Catastrophic risk researchers and nuclear safety advocates attest the founding problem was solved (we have multiple viable comparison frameworks now) and the expected-value reading persists because it advantages incumbent energy pathways. Independent academic analysis of risk framework proliferation since the 1990s supports the shifted-function reading: the coordination problem is solved but the distributional consequences of THIS solution keep it locked in.
narrative_ontology:disappearance_verdict(acceptable_risk_energy__expected_value_dominant, world_rearranges).
narrative_ontology:founding_problem_status(acceptable_risk_energy__expected_value_dominant, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(acceptable_risk_energy__expected_value_dominant, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(acceptable_risk_energy__expected_value_dominant, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(acceptable_risk_energy__expected_value_dominant_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(acceptable_risk_energy__expected_value_dominant, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, ExtMetricName, E),
    domain_priors:suppression_score(acceptable_risk_energy__expected_value_dominant, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(acceptable_risk_energy__expected_value_dominant),
    narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(acceptable_risk_energy__expected_value_dominant_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is substantial (0.67 at interval end, rising from 0.48) because the framework systematically transfers mortality burden from salient catastrophic events to invisible distributed deaths — a transfer that advantages incumbent pathways. The rise over time reflects growing fossil dependency as the framework justifies continued investment. Suppression is high (0.78) because maintaining the framework requires actively delegitimizing alternative risk logics (tail-weighting, option value, precaution) as irrational or mathematically incoherent. Theater ratio is moderate-rising (0.42): the mortality-per-TWh studies are real empirical work, but an increasing share of institutional activity defends the expected-value axiom itself rather than comparing pathways neutrally. Accessibility collapse is high (0.71) because once expected utility is accepted as the rational standard, alternatives appear as innumerate bias. Resistance is substantial (0.58) because nuclear safety advocates and catastrophic risk researchers continue to contest the framework's adequacy despite its institutional dominance. The claimed type is mountain (asserting this is the unique rational approach), but the metrics describe enforced extraction with identifiable victims.
 *
 * PERSPECTIVAL GAP:
 *   From the expected-value economists' seat, this is a genuine natural law of rational decision-making — expected utility theory is the unique coherent rule, derived from axioms, not constructed. From the fossil pathway mortality populations' seat, the framework operates as enforced extraction: their deaths are mathematically minimized (rendered statistically invisible) to justify continued operation of the pathway that kills them. From the catastrophic risk researchers' seat, the framework is one contestable reading among several, maintained by suppressing alternatives. The engine computes these divergences from the structural data; the mountain claim asserts one perspective is foundational while the metrics describe the extraction the other perspectives experience.
 *
 * DIRECTIONALITY LOGIC:
 *   Expected-value economists and aggregate welfare institutions are structural beneficiaries (set and operationalize the standard, arbitrage/mobile exit, low d). Fossil fuel industry is a beneficiary without setting the constraint (collects the distributional advantage, constrained exit because their viability depends on it, low-to-moderate d). Fossil pathway mortality populations are full targets (trapped, powerless, bear the chronic harm that is statistically minimized, high d near 1.0). Nuclear safety advocates are secondary targets (organized but suppressed, their concerns framed as bias, moderate-high d). Catastrophic risk researchers are excluded rather than directly extracted from, but their exclusion is structural to maintaining the framework.
 *
 * MANDATROPHY ANALYSIS:
 *   The mandatrophy question: does this arrangement coordinate (solve a genuine commensurability problem) or extract (systematically advantage one pathway's harm profile by choice of metric)? The FSM-relevant observation: the framework DOES solve a coordination problem (enables rational comparison), but the CHOICE of expected value over alternative comparison methods produces systematic distributional consequences that benefit identifiable parties. A catastrophic-tail-dominant reading would reverse the pathway ranking; an option-value-preserving reading would resist lock-in to either. The extraction is not in having a metric but in which metric is treated as the unique rational one.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    natural_law_vs_constructed_metric,
    'Is expected utility theory the unique rational decision rule (a natural law of coherent choice), or is it one axiom system among several, chosen for its distributional consequences?',
    'Philosophical analysis of alternative rationality frameworks (regret minimization, maximin, precautionary principles) and historical record of which frameworks were adopted in which contexts. If alternative frameworks are coherent and their rejection correlates with beneficiary advantage, the ''natural law'' claim is refuted.',
    'If expected utility is one choice among several, the mountain claim collapses and the constraint reclassifies as tangled rope (coordination + asymmetric extraction). If it is the unique coherent rule, the framework is genuinely foundational and the distributional consequences are unavoidable features of rationality itself.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(natural_law_vs_constructed_metric, conceptual, 'Whether expected utility is a discovered law or a constructed standard.').

omega_variable(
    probability_model_uncertainty,
    'Are the probabilities used to discount nuclear tail risks empirically grounded or are they theoretical constructs that minimize uncertainty?',
    'Compare pre-accident probability estimates for Chernobyl and Fukushima with observed frequencies. If observed frequencies systematically exceed modeled probabilities, the discounting is underweighting real risk.',
    'If probabilities are systematically underestimated, the mortality-per-TWh metric for nuclear is artificially low and the pathway ranking is biased. This would establish the framework as extractive rather than coordinative.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(probability_model_uncertainty, empirical, 'Whether probabilistic discounting of nuclear risk is empirically justified.').

omega_variable(
    distributional_bias_necessity,
    'Is the framework''s bias toward distributed chronic harm over concentrated catastrophic harm a necessary feature of aggregate metrics, or could alternative aggregation methods avoid this bias?',
    'Mathematical analysis of aggregation functions that weight by harm salience, worst-case potential, or inter-temporal distribution rather than pure expected value. If such methods exist and produce different rankings, the bias is avoidable.',
    'If the bias is avoidable, the framework''s adoption reflects a choice that advantages certain pathways, not a mathematical necessity. This supports the tangled-rope reading over the mountain reading.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(distributional_bias_necessity, conceptual, 'Whether the distributional consequences are structurally necessary or avoidable.').

omega_variable(
    axiom_system_selection_process,
    'What historical process selected expected utility as the dominant framework for energy risk assessment, and did beneficiary influence shape that selection?',
    'Historical analysis of early energy policy debates (1970s-1980s), examining which institutions funded risk research, which frameworks were promoted in policy guidance, and whether fossil industry actors had structural influence over the selection process.',
    'If the selection process shows beneficiary influence, the framework''s dominance is explained by political economy rather than mathematical necessity, supporting the FSM hypothesis. If the selection was epistemically independent, the mountain reading is supported.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(axiom_system_selection_process, empirical, 'Whether the framework''s adoption was epistemically independent of beneficiary interests.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(acceptable_risk_energy__expected_value_dominant, 0, 50).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(acce_tr_t0, acceptable_risk_energy__expected_value_dominant, theater_ratio, 0, 0.22).
narrative_ontology:measurement_basis(acce_tr_t0, observed).
narrative_ontology:measurement(acce_tr_t10, acceptable_risk_energy__expected_value_dominant, theater_ratio, 10, 0.28).
narrative_ontology:measurement_basis(acce_tr_t10, observed).
narrative_ontology:measurement(acce_tr_t20, acceptable_risk_energy__expected_value_dominant, theater_ratio, 20, 0.33).
narrative_ontology:measurement_basis(acce_tr_t20, observed).
narrative_ontology:measurement(acce_tr_t30, acceptable_risk_energy__expected_value_dominant, theater_ratio, 30, 0.37).
narrative_ontology:measurement_basis(acce_tr_t30, observed).
narrative_ontology:measurement(acce_tr_t40, acceptable_risk_energy__expected_value_dominant, theater_ratio, 40, 0.4).
narrative_ontology:measurement_basis(acce_tr_t40, observed).
narrative_ontology:measurement(acce_tr_t50, acceptable_risk_energy__expected_value_dominant, theater_ratio, 50, 0.42).
narrative_ontology:measurement_basis(acce_tr_t50, observed).

% Extraction over time
narrative_ontology:measurement(acce_be_t0, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 0, 0.48).
narrative_ontology:measurement_basis(acce_be_t0, observed).
narrative_ontology:measurement(acce_be_t10, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 10, 0.54).
narrative_ontology:measurement_basis(acce_be_t10, observed).
narrative_ontology:measurement(acce_be_t20, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 20, 0.59).
narrative_ontology:measurement_basis(acce_be_t20, observed).
narrative_ontology:measurement(acce_be_t30, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 30, 0.63).
narrative_ontology:measurement_basis(acce_be_t30, observed).
narrative_ontology:measurement(acce_be_t40, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 40, 0.65).
narrative_ontology:measurement_basis(acce_be_t40, observed).
narrative_ontology:measurement(acce_be_t50, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 50, 0.67).
narrative_ontology:measurement_basis(acce_be_t50, observed).

% Suppression requirement over time
narrative_ontology:measurement(acce_su_t0, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 0, 0.58).
narrative_ontology:measurement_basis(acce_su_t0, observed).
narrative_ontology:measurement(acce_su_t10, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 10, 0.64).
narrative_ontology:measurement_basis(acce_su_t10, observed).
narrative_ontology:measurement(acce_su_t20, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 20, 0.69).
narrative_ontology:measurement_basis(acce_su_t20, observed).
narrative_ontology:measurement(acce_su_t30, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 30, 0.73).
narrative_ontology:measurement_basis(acce_su_t30, observed).
narrative_ontology:measurement(acce_su_t40, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 40, 0.76).
narrative_ontology:measurement_basis(acce_su_t40, observed).
narrative_ontology:measurement(acce_su_t50, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 50, 0.78).
narrative_ontology:measurement_basis(acce_su_t50, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(acceptable_risk_energy__expected_value_dominant, information_standard).
narrative_ontology:affects_constraint(acceptable_risk_energy__expected_value_dominant, acceptable_risk_energy__catastrophic_tail_dominant).
narrative_ontology:affects_constraint(acceptable_risk_energy__expected_value_dominant, acceptable_risk_energy__option_value_preserving).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the acceptable_risk_energy kernel. The expected-value-dominant reading operationalizes acceptable risk as expected utility maximization; the catastrophic-tail-dominant reading operationalizes it as worst-case avoidance; the option-value-preserving reading operationalizes it as maintaining decision flexibility. These are structurally different constraints (different ε, different victim sets, different institutional beneficiaries) arising from different interpretations of the same contested kernel. The family is linked via network.affects_constraints in all three files.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
