% ============================================================================
% CONSTRAINT STORY: westphalia_sovereignty__conditional_responsibility
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-01-10
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_westphalia_sovereignty__conditional_responsibility, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: westphalia_sovereignty__conditional_responsibility
 *   human_readable: Responsibility to Protect Doctrine—Conditional Sovereignty
 *   domain: international_law/political_theory
 *
 * SUMMARY:
 *   The Responsibility to Protect doctrine reconceptualizes sovereignty from
 *   absolute territorial inviolability to conditional status dependent on
 *   protecting populations from mass atrocities. Emerging from post-Cold War
 *   humanitarian crises and formalized in UN doctrine early 21st century, it
 *   establishes that states forfeit sovereignty protection when they
 *   perpetrate or fail to prevent genocide, war crimes, ethnic cleansing, or
 *   crimes against humanity. The constraint is CLAIMED as mountain (natural
 *   moral evolution, universal principle) while metrics describe
 *   substantially extractive operation with rising theater and
 *   suppression—the divergence is the measurement. The doctrine creates new
 *   beneficiaries (intervention coalitions, international institutions) and
 *   new victims (targeted regimes, non-Western states bearing asymmetric
 *   enforcement) around what proponents frame as timeless moral truth.
 *
 * KEY AGENTS:
 *   - humanitarian_intervention_coalitions: Agenda-setter (institutional/arbitrage) — determine atrocity thresholds, authorize force, collect geopolitical leverage
 *   - international_governance_institutions: Beneficiary (institutional/arbitrage) — gain adjudicative authority over state legitimacy
 *   - populations_under_atrocity_regimes: Beneficiary (powerless/trapped) — protected from state violence but objectified in their own liberation
 *   - targeted_regimes: Payer (institutional/constrained) — lose territorial inviolability, face intervention and regime change
 *   - non_western_states_generally: Payer (institutional/constrained) — bear sovereignty erosion without agenda-setting power, observe selective enforcement
 *   - classical_sovereignty_theorists: Observer (analytical/analytical) — document enforcement asymmetries and norm evolution
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(westphalia_sovereignty__conditional_responsibility, 0.68).
domain_priors:suppression_score(westphalia_sovereignty__conditional_responsibility, 0.71).
domain_priors:theater_ratio(westphalia_sovereignty__conditional_responsibility, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, extractiveness, 0.68).
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, suppression_requirement, 0.71).
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, resistance, 0.73).

% --- Constraint claim ---
narrative_ontology:constraint_claim(westphalia_sovereignty__conditional_responsibility, mountain).
narrative_ontology:human_readable(westphalia_sovereignty__conditional_responsibility, "Responsibility to Protect Doctrine—Conditional Sovereignty").
narrative_ontology:topic_domain(westphalia_sovereignty__conditional_responsibility, "international_law/political_theory").

domain_priors:requires_active_enforcement(westphalia_sovereignty__conditional_responsibility).
domain_priors:emerges_naturally(westphalia_sovereignty__conditional_responsibility).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(westphalia_sovereignty__conditional_responsibility, '07cec1ec-1bd7-4e6e-ac63-77716bfb407d').
narrative_ontology:cs_kernel_codification('07cec1ec-1bd7-4e6e-ac63-77716bfb407d', distributed).
narrative_ontology:cs_authority_grounding('07cec1ec-1bd7-4e6e-ac63-77716bfb407d', distributed).
narrative_ontology:cs_reading_relation('07cec1ec-1bd7-4e6e-ac63-77716bfb407d', westphalia_sovereignty__absolute_non_intervention, coexists_with).
narrative_ontology:cs_reading_relation('07cec1ec-1bd7-4e6e-ac63-77716bfb407d', westphalia_sovereignty__graded_sovereignty, influences).
narrative_ontology:cs_axiom('07cec1ec-1bd7-4e6e-ac63-77716bfb407d', foundational, sovereignty_conditional_on_population_protection).
narrative_ontology:cs_axiom_status(sovereignty_conditional_on_population_protection, holdable).
narrative_ontology:cs_axiom_grounding('07cec1ec-1bd7-4e6e-ac63-77716bfb407d', sovereignty_conditional_on_population_protection, deontological).
narrative_ontology:cs_axiom('07cec1ec-1bd7-4e6e-ac63-77716bfb407d', secondary, international_community_adjudicative_authority).
narrative_ontology:cs_axiom_status(international_community_adjudicative_authority, holdable).
narrative_ontology:cs_axiom_grounding('07cec1ec-1bd7-4e6e-ac63-77716bfb407d', international_community_adjudicative_authority, conventional).
narrative_ontology:cs_reference_frame('07cec1ec-1bd7-4e6e-ac63-77716bfb407d', westphalian_territorial_inviolability).
narrative_ontology:cs_drift_state('07cec1ec-1bd7-4e6e-ac63-77716bfb407d', post_cold_war_humanitarian_intervention_era, gap(axiom_overriding, substantial, false)).
narrative_ontology:cs_created_at('07cec1ec-1bd7-4e6e-ac63-77716bfb407d', '').
narrative_ontology:cs_kernel_id(westphalia_sovereignty__conditional_responsibility, westphalia_sovereignty).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, humanitarian_intervention_coalitions).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, international_governance_institutions).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, populations_under_atrocity_regimes).
narrative_ontology:constraint_victim(westphalia_sovereignty__conditional_responsibility, targeted_regimes).
narrative_ontology:constraint_victim(westphalia_sovereignty__conditional_responsibility, non_western_states_generally).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__conditional_responsibility, universal_human_rights_supremacy).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__conditional_responsibility, international_community_adjudicative_authority).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Military alliances and ad-hoc coalitions that gain legitimacy to use force across borders when atrocity thresholds are claimed. They determine which situations constitute mass atrocities warranting intervention, frame military action as protection rather than conquest, and collect geopolitical leverage from selective enforcement. Exit is choosing not to intervene, which carries no cost to the coalition itself.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, humanitarian_intervention_coalitions, agenda_setter,
    institutional, generational, arbitrage, global).

% UN bodies, international courts, human rights organizations that gain expanded jurisdictional authority to adjudicate sovereignty validity. They establish the evidentiary standards for atrocity determination, coordinate intervention authorization, and expand their mandate beyond inter-state disputes into intra-state conduct. The conditional sovereignty framework elevates their role from mediator to judge of state legitimacy.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, international_governance_institutions, beneficiary,
    institutional, generational, arbitrage, global).

% Civilians facing systematic violence from their own governments. The doctrine grants them standing as protected subjects of international law rather than purely domestic concerns. Intervention may stop immediate violence but also subjects them to military action consequences, regime collapse instability, and post-intervention governance failures. Their benefit is protection from atrocity; their cost is becoming objects rather than agents of their own political transformation.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, populations_under_atrocity_regimes, beneficiary,
    powerless, immediate, trapped, local).

% Governments accused of mass atrocities who face military intervention, regime change pressure, or international isolation. They lose the territorial inviolability protection classical sovereignty provided, cannot exclude external military force, and face legitimacy contests adjudicated by institutions they do not control. Exit would be ceasing the conduct that triggers intervention, but the evidentiary threshold and adjudication process are external to them.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, targeted_regimes, payer,
    institutional, biographical, constrained, national).

% States outside the coalition of frequent interveners who observe that conditional sovereignty is enforced asymmetrically—applied to weaker states but not to powerful ones with similar internal conduct. They bear the sovereignty erosion without the agenda-setting power, cannot credibly threaten counter-intervention, and see the doctrine as reviving colonial-era justifications for external control. Their resistance is institutional (UN General Assembly votes, regional bloc coordination) but lacks enforcement capacity.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, non_western_states_generally, payer,
    institutional, generational, constrained, global).

% Legal scholars and political theorists who analyze whether the responsibility-to-protect framework represents a genuine evolution of sovereignty norms or a power asymmetry dressed as universal principle. They examine enforcement patterns, compare intervention decisions to atrocity severity, and assess whether the doctrine's universal language masks particular interests. Their work provides the evidentiary base for the omega variables below.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, classical_sovereignty_theorists, observer,
    analytical, civilizational, analytical, universal).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes a collective security mechanism for populations facing state-perpetrated mass violence, coordinating international response to atrocities that would otherwise be purely internal matters beyond external reach.
% TRANSFER_FUNCTION: Moves sovereign immunity and territorial inviolability from states to an international adjudicative layer, conditional on domestic human rights compliance. Transfers military intervention legitimacy from defensive-only to protective use of force.
% ABSENT_VOICES: Populations in powerful states with comparable internal violence patterns who never face intervention scrutiny; non-intervening states who bear sovereignty erosion without compensation; post-intervention societies dealing with collapsed governance who had no say in the intervention decision.
% DISAPPEARANCE_RATIONALE: Proponents argue atrocities would proceed unchecked without the lowered intervention threshold—Rwanda 1994 is the paradigmatic case. Critics argue the selective enforcement pattern reveals the constraint is a tool of existing power rather than genuine humanitarian principle, and its disappearance would eliminate a legitimation mechanism for military action while leaving underlying power dynamics unchanged. The verdict itself is contested because the doctrine's advocates and targets disagree on whether it represents natural moral evolution or constructed geopolitical leverage.
% FOUNDING_PROBLEM: The post-WWII international order faced systematic state violence against domestic populations (Holocaust, genocides, ethnic cleansing) that classical sovereignty doctrine treated as internal matters beyond international jurisdiction, leaving populations with no recourse.
% FOUNDING_PROBLEM_CORROBORATION: Human rights organizations and humanitarian intervention proponents attest the problem remains live, citing ongoing atrocities. Targeted regimes and non-Western legal scholars attest the doctrine's selective enforcement reveals it addresses legitimation of power projection rather than atrocity prevention itself. Independent enforcement-pattern analysis from academic international relations research shows strong correlation between intervention and strategic interest, weak correlation between intervention and atrocity severity—corroborating the shifted-function reading from outside both beneficiary and victim sets.
narrative_ontology:disappearance_verdict(westphalia_sovereignty__conditional_responsibility, contested).
narrative_ontology:founding_problem_status(westphalia_sovereignty__conditional_responsibility, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(westphalia_sovereignty__conditional_responsibility, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(westphalia_sovereignty__conditional_responsibility, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(westphalia_sovereignty__conditional_responsibility_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(westphalia_sovereignty__conditional_responsibility, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, ExtMetricName, E),
    domain_priors:suppression_score(westphalia_sovereignty__conditional_responsibility, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(westphalia_sovereignty__conditional_responsibility),
    narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(westphalia_sovereignty__conditional_responsibility_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction rises from 0.42 to 0.68 over the interval as the doctrine expands from rare humanitarian emergencies to broader regime-change justifications, with enforcement patterns correlating more strongly to strategic interest than atrocity severity. Suppression is high (0.71) because the constraint's persistence depends on excluding targeted regimes from the adjudicative process and suppressing alternative sovereignty frameworks—the threshold determination and enforcement decision are external to those who bear the intervention. Theater ratio rises from 0.18 to 0.42 as the gap grows between universal humanitarian principle rhetoric and selective enforcement reality. Accessibility collapse is moderate (0.48) because alternative sovereignty frameworks remain live in regional organizations and among non-intervening states. Resistance is high (0.73) as targeted regimes contest legitimacy and non-Western states coordinate institutional opposition. The measurement series uses one shared time grid covering doctrine emergence through current contested enforcement.
 *
 * PERSPECTIVAL GAP:
 *   From the coalition and institutional seats, the constraint is a natural moral evolution making universal human rights enforceable—a genuine mountain where alternatives collapsed because the principle is true. From targeted regime and non-Western state seats, the same structure operates as constructed extraction: sovereignty conditionally for the weak, absolute for the powerful, with atrocity determination controlled by those who benefit from intervention authority. From the population seat under atrocity, protection is real but agency is lost. The engine computes these divergences from the structural data; the mountain claim reflects one seat's perception, not adjudication of the contest.
 *
 * DIRECTIONALITY LOGIC:
 *   Intervention coalitions and international institutions are structural beneficiaries (gain authority, legitimacy, and operational freedom; d near beneficiary end). Targeted regimes are direct victims (lose sovereignty protection, face military force; d near full-target end). Populations under atrocity regimes occupy dual position—genuine protection benefit but also objectification and post-intervention instability costs; their powerless/trapped position places them closer to target than beneficiary end despite humanitarian framing. Non-Western states generally are diffuse victims (sovereignty erosion without compensation, institutional/constrained position). The asymmetry is structural: those who set atrocity thresholds do not face intervention scrutiny; those who face intervention do not set thresholds.
 *
 * MANDATROPHY ANALYSIS:
 *   The founding problem (systematic state violence beyond international reach) was live in 1945–1990s. The conditional sovereignty response created real coordination (collective response mechanism) but layered substantial extraction (selective enforcement, expanded institutional authority, geopolitical leverage collection) on the coordination base. The analysis prevents false pure-snare classification (the protection function is genuine for some populations) and false pure-rope classification (the selective enforcement and authority accumulation are not incidental overhead). Measurements show extraction accumulating over time as the doctrine's scope expands and its application patterns diverge from its universal framing—classic mandatrophy signature of coordination function outlived by extraction apparatus.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    enforcement_pattern_asymmetry,
    'Is the doctrine''s selective enforcement—strong correlation with strategic interest, weak correlation with atrocity severity—a correctable implementation failure or structural feature revealing the constraint''s true beneficiaries?',
    'Systematic intervention-pattern analysis comparing atrocity severity indices to intervention decisions across cases, controlling for intervener strategic interests. If severe atrocities in non-strategic locations consistently fail to trigger doctrine application while lesser violations in strategic locations do, the selection pattern is structural.',
    'If structural, the doctrine is better modeled as snare or tangled_rope (legitimation tool for geopolitical projection) than as mountain (universal moral principle with implementation challenges). If correctable, remains candidate natural-law evolution with overhead.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(enforcement_pattern_asymmetry, empirical, 'Whether selective enforcement reveals true function or implementation gap').

omega_variable(
    natural_law_vs_power_construction,
    'Is the responsibility-to-protect principle a genuine discovery of timeless moral truth (populations have rights against their own states that the international community must enforce) or a constructed norm benefiting identifiable powerful actors?',
    'Historical analysis of sovereignty norm evolution, enforcement-pattern comparison across power-symmetric and power-asymmetric state pairs, and examination of which actors benefit from lowered intervention thresholds. A natural principle would apply symmetrically; a constructed norm would correlate with power position.',
    'If genuine natural law, the beneficiary structure is incidental to the principle''s truth—classification as mountain with FSM complexity but mountain-certified. If constructed norm, reclassify as tangled_rope or snare (coordination function exists but extraction is structural, not overhead).',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(natural_law_vs_power_construction, conceptual, 'Whether this is discovered moral truth or legitimated power asymmetry').

omega_variable(
    population_agency_vs_protection,
    'Do populations under atrocity regimes gain more from external military intervention (immediate violence cessation, protection) or lose more (agency over their own political transformation, post-intervention governance collapse, becoming objects of geopolitical contest)?',
    'Longitudinal outcome analysis of post-intervention societies compared to atrocity situations that did not trigger intervention—measuring violence reduction, governance stability, and population-reported agency. If intervention consistently produces worse long-term outcomes than non-intervention, the protection benefit is theatrical.',
    'If populations systematically lose more than they gain, reclassify populations_under_atrocity_regimes from beneficiary to victim—the humanitarian framing is cover for extractive intervention that harms the nominal beneficiaries. Constraint shifts from tangled_rope toward snare.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(population_agency_vs_protection, empirical, 'Whether protected populations are net beneficiaries or net victims').

omega_variable(
    universal_principle_vs_regional_norm,
    'Is conditional sovereignty an emerging universal norm converging across legal traditions, or a regional norm (Western/Atlantic) being imposed through institutional power on non-consenting legal traditions?',
    'Analysis of sovereignty doctrine in non-Western legal frameworks (African Union, ASEAN, Shanghai Cooperation Organization), treaty ratification patterns, and General Assembly voting blocs. If non-Western regional organizations consistently affirm stronger sovereignty protection and resist conditional frameworks, the universality claim is contested.',
    'If regional rather than universal, the constraint''s claimed_type as mountain (natural/universal principle) is false—it is institutionally enforced norm construction. Beneficiaries are revealed as norm entrepreneurs, victims as those resisting imposition. Classification shifts toward snare or tangled_rope with extraction dominant.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(universal_principle_vs_regional_norm, conceptual, 'Whether universality claim reflects convergence or imposition').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(westphalia_sovereignty__conditional_responsibility, 0, 35).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(west_tr_t0, westphalia_sovereignty__conditional_responsibility, theater_ratio, 0, 0.18).
narrative_ontology:measurement_basis(west_tr_t0, observed).
narrative_ontology:measurement(west_tr_t7, westphalia_sovereignty__conditional_responsibility, theater_ratio, 7, 0.24).
narrative_ontology:measurement_basis(west_tr_t7, observed).
narrative_ontology:measurement(west_tr_t14, westphalia_sovereignty__conditional_responsibility, theater_ratio, 14, 0.31).
narrative_ontology:measurement_basis(west_tr_t14, observed).
narrative_ontology:measurement(west_tr_t21, westphalia_sovereignty__conditional_responsibility, theater_ratio, 21, 0.36).
narrative_ontology:measurement_basis(west_tr_t21, observed).
narrative_ontology:measurement(west_tr_t28, westphalia_sovereignty__conditional_responsibility, theater_ratio, 28, 0.4).
narrative_ontology:measurement_basis(west_tr_t28, observed).
narrative_ontology:measurement(west_tr_t35, westphalia_sovereignty__conditional_responsibility, theater_ratio, 35, 0.42).
narrative_ontology:measurement_basis(west_tr_t35, observed).

% Extraction over time
narrative_ontology:measurement(west_be_t0, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 0, 0.42).
narrative_ontology:measurement_basis(west_be_t0, observed).
narrative_ontology:measurement(west_be_t7, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 7, 0.49).
narrative_ontology:measurement_basis(west_be_t7, observed).
narrative_ontology:measurement(west_be_t14, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 14, 0.56).
narrative_ontology:measurement_basis(west_be_t14, observed).
narrative_ontology:measurement(west_be_t21, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 21, 0.62).
narrative_ontology:measurement_basis(west_be_t21, observed).
narrative_ontology:measurement(west_be_t28, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 28, 0.66).
narrative_ontology:measurement_basis(west_be_t28, observed).
narrative_ontology:measurement(west_be_t35, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 35, 0.68).
narrative_ontology:measurement_basis(west_be_t35, observed).

% Suppression requirement over time
narrative_ontology:measurement(west_su_t0, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 0, 0.52).
narrative_ontology:measurement_basis(west_su_t0, observed).
narrative_ontology:measurement(west_su_t7, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 7, 0.58).
narrative_ontology:measurement_basis(west_su_t7, observed).
narrative_ontology:measurement(west_su_t14, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 14, 0.63).
narrative_ontology:measurement_basis(west_su_t14, observed).
narrative_ontology:measurement(west_su_t21, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 21, 0.67).
narrative_ontology:measurement_basis(west_su_t21, observed).
narrative_ontology:measurement(west_su_t28, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 28, 0.69).
narrative_ontology:measurement_basis(west_su_t28, observed).
narrative_ontology:measurement(west_su_t35, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 35, 0.71).
narrative_ontology:measurement_basis(west_su_t35, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(westphalia_sovereignty__conditional_responsibility, enforcement_mechanism).
narrative_ontology:boltzmann_floor_override(westphalia_sovereignty__conditional_responsibility, 0.12).
narrative_ontology:affects_constraint(westphalia_sovereignty__conditional_responsibility, westphalia_sovereignty__absolute_non_intervention).
narrative_ontology:affects_constraint(westphalia_sovereignty__conditional_responsibility, westphalia_sovereignty__graded_sovereignty).
narrative_ontology:affects_constraint(westphalia_sovereignty__conditional_responsibility, un_charter_article_2_4).
narrative_ontology:affects_constraint(westphalia_sovereignty__conditional_responsibility, humanitarian_intervention_legitimacy).

% DUAL FORMULATION NOTE:
% This constraint is one member of the westphalia_sovereignty constraint family—three distinct readings of contested sovereignty norms. Each reading has different beneficiary/victim structures and different ε values because they instantiate different claims about sovereignty's nature and conditions. The conditional_responsibility reading creates lower intervention thresholds and expanded institutional authority compared to absolute_non_intervention; it differs from graded_sovereignty in grounding conditionality in conduct rather than capacity. Network links connect to siblings and downstream constraints that depend on sovereignty framework choice.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
