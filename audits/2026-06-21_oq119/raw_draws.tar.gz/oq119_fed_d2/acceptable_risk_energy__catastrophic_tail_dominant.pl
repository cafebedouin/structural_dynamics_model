% ============================================================================
% CONSTRAINT STORY: acceptable_risk_energy__catastrophic_tail_dominant
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_acceptable_risk_energy__catastrophic_tail_dominant, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: acceptable_risk_energy__catastrophic_tail_dominant
 *   human_readable: Catastrophic-Tail-Dominant Acceptable Risk Framework
 *   domain: risk_assessment/energy_policy/decision_theory
 *
 * SUMMARY:
 *   This constraint instantiates one contested reading of how societies
 *   should evaluate technological risk: the catastrophic-tail-dominant
 *   framework that weights low-probability concentrated harms infinitely
 *   heavier than high-probability distributed harms. The reading is CLAIMED
 *   as mountain (a fundamental feature of human risk psychology and rational
 *   precaution) while the metrics describe substantially extractive operation
 *   with identifiable beneficiaries. The engine measures this divergence; the
 *   claim and metrics are independently authored facts. KEY AGENTS (by
 *   structural relationship): - Fossil fuel industry: Primary beneficiary
 *   (institutional/arbitrage) — benefits from suppressed nuclear competition
 *   - Risk-averse regulators: Agenda-setter (institutional/constrained) —
 *   enforce asymmetric standards - Climate-vulnerable populations: Primary
 *   victim (powerless/trapped) — bear discounted future harm -
 *   Air-pollution-affected communities: Primary victim (powerless/trapped) —
 *   bear invisible present harm - Nuclear engineering profession: Victim
 *   (moderate/constrained) — professional pathway suppressed - Quantitative
 *   risk analysts: Observer (analytical/analytical) — document mortality
 *   inversion
 *
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(acceptable_risk_energy__catastrophic_tail_dominant, 0.68).
domain_priors:suppression_score(acceptable_risk_energy__catastrophic_tail_dominant, 0.77).
domain_priors:theater_ratio(acceptable_risk_energy__catastrophic_tail_dominant, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, extractiveness, 0.68).
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 0.77).
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, accessibility_collapse, 0.71).
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, resistance, 0.58).

% --- Constraint claim ---
narrative_ontology:constraint_claim(acceptable_risk_energy__catastrophic_tail_dominant, mountain).
narrative_ontology:human_readable(acceptable_risk_energy__catastrophic_tail_dominant, "Catastrophic-Tail-Dominant Acceptable Risk Framework").
narrative_ontology:topic_domain(acceptable_risk_energy__catastrophic_tail_dominant, "risk_assessment/energy_policy/decision_theory").

domain_priors:requires_active_enforcement(acceptable_risk_energy__catastrophic_tail_dominant).
domain_priors:emerges_naturally(acceptable_risk_energy__catastrophic_tail_dominant).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(acceptable_risk_energy__catastrophic_tail_dominant, 'b2ae5fa1-1549-40f5-a54f-41c87a824b7a').
narrative_ontology:cs_kernel_codification('b2ae5fa1-1549-40f5-a54f-41c87a824b7a', distributed).
narrative_ontology:cs_authority_grounding('b2ae5fa1-1549-40f5-a54f-41c87a824b7a', practice).
narrative_ontology:cs_interpretation_layer_present('b2ae5fa1-1549-40f5-a54f-41c87a824b7a').
narrative_ontology:cs_reading_relation('b2ae5fa1-1549-40f5-a54f-41c87a824b7a', acceptable_risk_energy__expected_value_dominant, coexists_with).
narrative_ontology:cs_reading_relation('b2ae5fa1-1549-40f5-a54f-41c87a824b7a', acceptable_risk_energy__option_value_preserving, coexists_with).
narrative_ontology:cs_axiom('b2ae5fa1-1549-40f5-a54f-41c87a824b7a', foundational, concentrated_catastrophic_harm_infinite_disutility).
narrative_ontology:cs_axiom_status(concentrated_catastrophic_harm_infinite_disutility, holdable).
narrative_ontology:cs_axiom_grounding('b2ae5fa1-1549-40f5-a54f-41c87a824b7a', concentrated_catastrophic_harm_infinite_disutility, deontological).
narrative_ontology:cs_axiom('b2ae5fa1-1549-40f5-a54f-41c87a824b7a', secondary, visible_harm_morally_distinct_from_statistical_harm).
narrative_ontology:cs_axiom_status(visible_harm_morally_distinct_from_statistical_harm, holdable).
narrative_ontology:cs_axiom_grounding('b2ae5fa1-1549-40f5-a54f-41c87a824b7a', visible_harm_morally_distinct_from_statistical_harm, deontological).
narrative_ontology:cs_reference_frame('b2ae5fa1-1549-40f5-a54f-41c87a824b7a', post_chernobyl_catastrophic_primacy).
narrative_ontology:cs_drift_state('b2ae5fa1-1549-40f5-a54f-41c87a824b7a', post_fukushima_mortality_data_era, gap(axiom_overriding, substantial, false)).
narrative_ontology:cs_created_at('b2ae5fa1-1549-40f5-a54f-41c87a824b7a', '').
narrative_ontology:cs_kernel_id(acceptable_risk_energy__catastrophic_tail_dominant, acceptable_risk_energy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__catastrophic_tail_dominant, fossil_fuel_industry).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__catastrophic_tail_dominant, risk_averse_regulators).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__catastrophic_tail_dominant, anti_nuclear_advocacy).
narrative_ontology:constraint_victim(acceptable_risk_energy__catastrophic_tail_dominant, climate_vulnerable_populations).
narrative_ontology:constraint_victim(acceptable_risk_energy__catastrophic_tail_dominant, air_pollution_affected_communities).
narrative_ontology:constraint_victim(acceptable_risk_energy__catastrophic_tail_dominant, nuclear_engineering_profession).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__catastrophic_tail_dominant, precautionary_principle_supremacy).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__catastrophic_tail_dominant, visible_harm_worse_than_diffuse_harm).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Benefits from the constraint suppressing nuclear competition while fossil harm remains externalized and distributed. The catastrophic framing makes nuclear construction prohibitively expensive through regulatory requirements while fossil deaths accumulate invisibly across decades and geographies. Industry maintains operations under lighter scrutiny because its harms lack the singular-event signature that triggers catastrophic risk protocols.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, fossil_fuel_industry, beneficiary,
    institutional, biographical, arbitrage, global).

% Set and enforce safety standards weighted toward preventing identifiable catastrophic events rather than minimizing aggregate mortality. Career risk flows asymmetrically: a visible nuclear incident ends careers; diffuse fossil deaths are statistically invisible at decision time. This creates structural pressure to over-regulate low-probability high-visibility pathways and under-regulate high-probability distributed pathways.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, risk_averse_regulators, agenda_setter,
    institutional, biographical, constrained, national).

% Mobilizes public opposition using catastrophic nuclear scenarios as organizing narratives. The constraint vindicates their framing by institutionalizing the asymmetric risk calculus they advocate for. Maintains organizational relevance and funding through sustained focus on preventing nuclear expansion rather than addressing aggregate energy mortality.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, anti_nuclear_advocacy, beneficiary,
    organized, generational, mobile, global).

% Bear the long-term climate costs of suppressed nuclear deployment and continued fossil dependence. The constraint weights their distributed future harm far below concentrated present catastrophic risk, making their deaths structurally invisible in the acceptable-risk calculation. Geographic and temporal distance from decision-makers compounds their exclusion.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, climate_vulnerable_populations, payer,
    powerless, generational, trapped, global).

% Die annually from fossil combustion particulates and emissions at rates orders of magnitude higher than nuclear pathway mortality, but these deaths are distributed across geography and time rather than concentrated in visible events. The acceptable risk framework discounts their harm as reversible background risk, making fossil alternatives appear safer than actuarial analysis would support.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, air_pollution_affected_communities, payer,
    powerless, biographical, trapped, local).

% Face structural suppression of their professional pathway: university programs close, expertise atrophies, career prospects narrow as the catastrophic framing makes new nuclear construction economically prohibitive in most jurisdictions. The constraint treats their pathway as uniquely dangerous despite mortality-per-TWh data showing it as among the safest energy sources.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, nuclear_engineering_profession, payer,
    moderate, biographical, constrained, national).

% Document the mortality-per-TWh inversion where the 'catastrophic risk' framework produces higher aggregate deaths than expected-value minimization would. Publish comparisons showing nuclear as statistically safer than fossil alternatives, but these analyses are systematically discounted in policy formation because they violate the constraint's foundational premise that concentrated visible harm has infinite disutility.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, quantitative_risk_analysts, observer,
    analytical, generational, analytical, global).

% Inherit the energy infrastructure shaped by current catastrophic-risk prioritization. Cannot voice preferences in today's acceptable-risk calculations but will bear both the climate trajectory and the opportunity cost of suppressed low-carbon baseload capacity. Structural discount rate combined with catastrophic framing makes their aggregate welfare nearly weightless against present visible risk.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, future_energy_consumers, excluded,
    powerless, generational, trapped, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes shared decision rule for energy pathway selection under uncertainty: society coordinates on which probability distributions and outcome types to weight most heavily when comparing technological risks.
% TRANSFER_FUNCTION: Moves regulatory burden and construction costs onto nuclear pathway (through catastrophic-weighted standards) while externalizing and distributing fossil pathway mortality across geography and time, effectively transferring aggregate mortality risk from visible-concentrated to invisible-distributed populations.
% ABSENT_VOICES: Climate-vulnerable populations in Global South, future generations bearing climate trajectory, air-pollution-affected communities whose deaths lack the singular-event visibility that triggers catastrophic protocols. Quantitative risk analysts are present but systematically discounted.
% DISAPPEARANCE_RATIONALE: If this risk framework vanished and energy pathways were evaluated on mortality-per-TWh expected value, nuclear construction economics would transform overnight, coal phase-out would accelerate, electricity sector mortality projections would shift by orders of magnitude, and climate mitigation pathways would reopen. Regulatory agencies would restructure around aggregate harm minimization rather than catastrophic-event prevention.
% FOUNDING_PROBLEM: Mid-20th-century nuclear accidents created public demand for frameworks preventing identifiable catastrophic technological failures, particularly after high-visibility incidents demonstrated that low-probability events can materialize with severe concentrated consequences.
% FOUNDING_PROBLEM_CORROBORATION: Fossil fuel industry and anti-nuclear advocacy attest the founding problem remains live, citing ongoing nuclear safety concerns and the need for precautionary regulation. Quantitative risk analysts, climate scientists, and energy economists from outside benefiting parties attest the founding problem has been overweighted: post-Fukushima mortality data shows nuclear remains among safest energy sources per TWh, and the catastrophic framing now produces higher aggregate mortality by suppressing lower-harm pathways.
narrative_ontology:disappearance_verdict(acceptable_risk_energy__catastrophic_tail_dominant, world_rearranges).
narrative_ontology:founding_problem_status(acceptable_risk_energy__catastrophic_tail_dominant, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(acceptable_risk_energy__catastrophic_tail_dominant, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(acceptable_risk_energy__catastrophic_tail_dominant, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(acceptable_risk_energy__catastrophic_tail_dominant_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(acceptable_risk_energy__catastrophic_tail_dominant, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, ExtMetricName, E),
    domain_priors:suppression_score(acceptable_risk_energy__catastrophic_tail_dominant, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(acceptable_risk_energy__catastrophic_tail_dominant),
    narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(acceptable_risk_energy__catastrophic_tail_dominant_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is substantial (0.68 at interval end) because the framework systematically transfers mortality from visible-concentrated events to invisible-distributed populations, with identifiable parties capturing the regulatory and market benefits of nuclear suppression. Suppression is high (0.77) because maintaining the framework requires active enforcement against expected-value analysis and mortality-per-TWh comparisons that would reveal the inversion. Theater is moderate (0.42): genuine catastrophic-prevention activity exists, but growing share of regulatory apparatus defends the asymmetric weighting itself rather than minimizing aggregate harm. Accessibility collapse is high (0.71) because once the catastrophic-weighting premise is accepted, alternative risk frameworks (expected value, option value) become nearly unthinkable within policy discourse. Resistance is substantial (0.58) from quantitative analysts and climate scientists whose frameworks the constraint suppresses, but this resistance is structurally discounted by the same asymmetry it challenges.
 *
 * PERSPECTIVAL GAP:
 *   From the beneficiary seats (fossil industry, advocacy organizations), this appears as rational precaution against genuinely catastrophic outcomes — a coordination rule reflecting human psychological reality about risk perception. From the powerless victim seats (climate-vulnerable populations, pollution-affected communities), the same structure operates as enforced mortality transfer: their deaths are made structurally invisible while concentrated nuclear deaths receive infinite weight. The regulatory seat experiences both: genuine catastrophic-prevention function AND career-risk-driven over-weighting of visible events. Quantitative analysts see the mortality inversion but their framework is systematically excluded from policy formation.
 *
 * DIRECTIONALITY LOGIC:
 *   Fossil fuel industry and anti-nuclear advocacy are structural beneficiaries (d near 0.15-0.25): they collect market protection and organizational relevance from nuclear suppression without running the risk framework. Risk-averse regulators sit near symmetric (d ~0.45): genuine coordination function (preventing visible catastrophes) but also captured by career-risk asymmetry. Climate-vulnerable and air-pollution-affected populations are full targets (d near 0.95): trapped, powerless, bearing the invisible distributed mortality the framework systematically discounts. Nuclear engineering profession is target (d ~0.75): constrained exit, moderate power, professional pathway suppressed by the constraint's operation.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint's mandate (prevent catastrophic concentrated harm) has not outlived its function, but the authored metrics reveal substantial extraction beyond that function. The catastrophic framing coordinates legitimate precaution against visible technological failures AND transfers regulatory burden away from higher-mortality pathways whose harms are distributed. This is classic tangled-rope territory from the metric seat: real coordination function coexisting with asymmetric extraction. The mountain claim asserts this weighting emerges naturally from human risk psychology; the metrics document that identifiable parties benefit from its institutional instantiation. Where the computed seat type diverges from the mountain claim, that divergence measures whether 'natural risk aversion' or 'constructed regulatory asymmetry' better describes this constraint.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    natural_vs_constructed_asymmetry,
    'Does the infinite weighting of catastrophic concentrated harm over distributed harm emerge naturally from human cognitive architecture, or is it a constructed preference amplified by benefiting institutions?',
    'Cross-cultural and cross-temporal studies of risk perception absent modern institutional framing; experimental evidence on whether catastrophic-weighting persists when mortality distributions are made equally visible; analysis of whether the asymmetry strengthens or weakens with institutional incentive structure.',
    'If naturally emergent, the mountain claim is structurally valid and the constraint coordinates around an irreducible feature of human decision-making. If constructed and amplified, the constraint is a false summit: a genuine cognitive bias weaponized into institutional extraction by parties who benefit from the resulting pathway suppression.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(natural_vs_constructed_asymmetry, empirical, 'Whether catastrophic-weighting is cognitive bedrock or constructed institutional preference').

omega_variable(
    visibility_discount_mechanism,
    'Is the constraint''s differential treatment of visible vs invisible mortality a necessary consequence of catastrophic-risk framing, or a separable institutional choice that could be corrected while preserving catastrophic prevention?',
    'Policy experiment comparing jurisdictions that maintain catastrophic-prevention standards while also mandating mortality-per-TWh disclosure and regulatory consideration; test whether visibility equalization changes pathway selection.',
    'If separable, the mortality inversion is correctable extraction layered on genuine catastrophic coordination. If inseparable, the discount of distributed harm is inherent to catastrophic-weighting and the framework necessarily produces mortality transfer.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(visibility_discount_mechanism, conceptual, 'Whether visibility discount is inherent to catastrophic framing or correctable extraction').

omega_variable(
    beneficiary_amplification,
    'To what extent do the identified beneficiaries (fossil industry, anti-nuclear advocacy, risk-averse regulators) actively maintain and amplify the catastrophic framing versus passively benefiting from a framework that would persist regardless of their interests?',
    'Follow-the-money analysis of regulatory capture, lobbying expenditure correlated with catastrophic-risk standard tightening, institutional funding flows to anti-nuclear advocacy; compare pathway suppression in jurisdictions with different industry-regulator relationships.',
    'High amplification would establish this as constructed extraction with identifiable captors (false summit, reclassify to tangled_rope or snare). Low amplification would support the mountain claim that the framework persists as coordination around genuine human risk preference.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(beneficiary_amplification, empirical, 'Whether beneficiaries actively maintain the framework or passively benefit from natural persistence').

omega_variable(
    mortality_per_twh_legibility,
    'If mortality-per-TWh comparisons showing nuclear as statistically safest were made equally legible and institutionally weighted as catastrophic scenarios, would public and regulatory preferences shift, or would catastrophic-weighting persist as dominant decision rule?',
    'Jurisdictional natural experiments where expected-value frameworks are institutionalized alongside catastrophic-prevention (not replacing it); measure whether pathway selection changes when aggregate mortality becomes as visible as concentrated catastrophic scenarios.',
    'Persistent catastrophic-weighting despite equal legibility would support the mountain claim (cognitive architecture dominates institutional framing). Shifted preferences would establish current framework as constructed via differential visibility, supporting reclassification to extraction.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(mortality_per_twh_legibility, empirical, 'Whether equal legibility of aggregate vs catastrophic mortality changes decision-making').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(acceptable_risk_energy__catastrophic_tail_dominant, 0, 40).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(acce_tr_t0, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 0, 0.22).
narrative_ontology:measurement(acce_tr_t8, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 8, 0.28).
narrative_ontology:measurement(acce_tr_t16, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 16, 0.33).
narrative_ontology:measurement(acce_tr_t24, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 24, 0.37).
narrative_ontology:measurement(acce_tr_t32, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 32, 0.4).
narrative_ontology:measurement(acce_tr_t40, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 40, 0.42).

% Extraction over time
narrative_ontology:measurement(acce_be_t0, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 0, 0.48).
narrative_ontology:measurement(acce_be_t8, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 8, 0.53).
narrative_ontology:measurement(acce_be_t16, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 16, 0.59).
narrative_ontology:measurement(acce_be_t24, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 24, 0.64).
narrative_ontology:measurement(acce_be_t32, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 32, 0.66).
narrative_ontology:measurement(acce_be_t40, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 40, 0.68).

% Suppression requirement over time
narrative_ontology:measurement(acce_su_t0, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 0, 0.58).
narrative_ontology:measurement(acce_su_t8, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 8, 0.63).
narrative_ontology:measurement(acce_su_t16, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 16, 0.68).
narrative_ontology:measurement(acce_su_t24, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 24, 0.72).
narrative_ontology:measurement(acce_su_t32, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 32, 0.75).
narrative_ontology:measurement(acce_su_t40, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 40, 0.77).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(acceptable_risk_energy__catastrophic_tail_dominant, identity_coordination).
narrative_ontology:boltzmann_floor_override(acceptable_risk_energy__catastrophic_tail_dominant, 0.12).
narrative_ontology:affects_constraint(acceptable_risk_energy__catastrophic_tail_dominant, acceptable_risk_energy__expected_value_dominant).
narrative_ontology:affects_constraint(acceptable_risk_energy__catastrophic_tail_dominant, acceptable_risk_energy__option_value_preserving).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the acceptable_risk_energy kernel. The catastrophic_tail_dominant reading produces different victim sets, suppression patterns, and mortality distributions than its sibling readings (expected_value_dominant, option_value_preserving). The readings form a constraint family linked via network.affects_constraints; they are not alternative framings of one constraint but distinct constraints instantiated from contested interpretations of the same decision rule.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
