% ============================================================================
% CONSTRAINT STORY: waitangi_sovereignty_allocation__partnership_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-01-15
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_waitangi_sovereignty_allocation__partnership_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: waitangi_sovereignty_allocation__partnership_reading
 *   human_readable: Treaty of Waitangi Partnership Doctrine
 *   domain: constitutional_law/indigenous_rights/post_colonial_governance
 *
 * SUMMARY:
 *   The Treaty of Waitangi partnership reading emerged through judicial
 *   doctrine and settlement practice from 1975 onward, interpreting the 1840
 *   Treaty as establishing an ongoing partnership requiring Crown
 *   consultation and good faith. The reading holds both Treaty texts as
 *   equally authoritative and constructs 'Treaty principles' as a third
 *   interpretive layer mediating their differences. Crown and mainstream
 *   judiciary present this as constitutional bedrock—a natural resolution of
 *   the founding relationship. Rangatiratanga advocates argue the reading is
 *   a constructed compromise that privileges Crown sovereignty while
 *   co-opting partnership language. The foundational claim sits alongside
 *   real beneficiaries and excluded parties.
 *
 * KEY AGENTS:
 *   - Crown executive: Primary administrator and settlement negotiator (institutional/constrained) — controls process while gaining legitimacy
 *   - Mainstream judiciary: Doctrine developer (institutional/constrained) — expands principles through interpretation
 *   - Treaty settlement beneficiaries: Iwi with completed settlements (organized/constrained) — material gains, foreclosed sovereignty claims
 *   - Māori claimants outside settlement: Unsettled grievances (organized/identity_locked) — bear framework's structural caps
 *   - Parliament as institution: Formally supreme legislature (institutional/constrained) — operates under normative constraint
 *   - Rangatiratanga advocates: Constitutional alternative advocates (organized/identity_locked) — excluded by framework's premise
 *   - Constitutional law scholars: Analytical observers (analytical/analytical) — document asymmetry and doctrinal gaps
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(waitangi_sovereignty_allocation__partnership_reading, 0.38).
domain_priors:suppression_score(waitangi_sovereignty_allocation__partnership_reading, 0.42).
domain_priors:theater_ratio(waitangi_sovereignty_allocation__partnership_reading, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, extractiveness, 0.38).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 0.42).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, accessibility_collapse, 0.52).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, resistance, 0.58).

% --- Constraint claim ---
narrative_ontology:constraint_claim(waitangi_sovereignty_allocation__partnership_reading, mountain).
narrative_ontology:human_readable(waitangi_sovereignty_allocation__partnership_reading, "Treaty of Waitangi Partnership Doctrine").
narrative_ontology:topic_domain(waitangi_sovereignty_allocation__partnership_reading, "constitutional_law/indigenous_rights/post_colonial_governance").

domain_priors:requires_active_enforcement(waitangi_sovereignty_allocation__partnership_reading).
domain_priors:emerges_naturally(waitangi_sovereignty_allocation__partnership_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(waitangi_sovereignty_allocation__partnership_reading, 'b4d3c587-c854-4c39-9b96-b78d14f45dea').
narrative_ontology:cs_kernel_codification('b4d3c587-c854-4c39-9b96-b78d14f45dea', fixed_text).
narrative_ontology:cs_authority_grounding('b4d3c587-c854-4c39-9b96-b78d14f45dea', lineage).
narrative_ontology:cs_interpretation_layer_present('b4d3c587-c854-4c39-9b96-b78d14f45dea').
narrative_ontology:cs_reading_relation('b4d3c587-c854-4c39-9b96-b78d14f45dea', waitangi_sovereignty_allocation__crown_sovereignty_reading, coexists_with).
narrative_ontology:cs_reading_relation('b4d3c587-c854-4c39-9b96-b78d14f45dea', waitangi_sovereignty_allocation__rangatiratanga_reading, coexists_with).
narrative_ontology:cs_axiom('b4d3c587-c854-4c39-9b96-b78d14f45dea', foundational, treaty_established_ongoing_partnership).
narrative_ontology:cs_axiom_status(treaty_established_ongoing_partnership, holdable).
narrative_ontology:cs_axiom_grounding('b4d3c587-c854-4c39-9b96-b78d14f45dea', treaty_established_ongoing_partnership, conventional).
narrative_ontology:cs_axiom('b4d3c587-c854-4c39-9b96-b78d14f45dea', foundational, principles_mediate_textual_conflict).
narrative_ontology:cs_axiom_status(principles_mediate_textual_conflict, holdable).
narrative_ontology:cs_axiom_grounding('b4d3c587-c854-4c39-9b96-b78d14f45dea', principles_mediate_textual_conflict, conventional).
narrative_ontology:cs_axiom('b4d3c587-c854-4c39-9b96-b78d14f45dea', secondary, crown_sovereignty_with_partnership_obligations).
narrative_ontology:cs_axiom_status(crown_sovereignty_with_partnership_obligations, holdable).
narrative_ontology:cs_axiom_grounding('b4d3c587-c854-4c39-9b96-b78d14f45dea', crown_sovereignty_with_partnership_obligations, conventional).
narrative_ontology:cs_reference_frame('b4d3c587-c854-4c39-9b96-b78d14f45dea', treaty_partnership_constitutional_foundation).
narrative_ontology:cs_drift_state('b4d3c587-c854-4c39-9b96-b78d14f45dea', contemporary_settlement_era, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('b4d3c587-c854-4c39-9b96-b78d14f45dea', '').
narrative_ontology:cs_kernel_id(waitangi_sovereignty_allocation__partnership_reading, waitangi_sovereignty_allocation).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__partnership_reading, crown_executive).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__partnership_reading, mainstream_judiciary).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__partnership_reading, treaty_settlement_beneficiaries).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__partnership_reading, maori_claimants_outside_settlement).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__partnership_reading, parliament_as_institution).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__partnership_reading, bicultural_constitutional_framework).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__partnership_reading, treaty_principles_doctrine).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Administers the Treaty principles through settlement negotiations, consultation requirements, and policy development. Controls the settlement process timing, scope, and quantum. Frames the partnership reading as constitutional bedrock while retaining final decision-making authority. Benefits from legitimacy the partnership narrative provides while avoiding binding legal constraints on parliamentary sovereignty.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, crown_executive, agenda_setter,
    institutional, generational, constrained, national).

% Develops and applies Treaty principles doctrine through common law. Gains institutional authority from mediating Crown-Māori disputes within the partnership framework. Constrained by parliamentary sovereignty doctrine but expands principles through interpretation. The partnership reading provides doctrinal space for incremental rights expansion without constitutional crisis.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, mainstream_judiciary, beneficiary,
    institutional, generational, constrained, national).

% Iwi and hapū who have negotiated Treaty settlements under the partnership framework. Receive financial redress, return of cultural sites, co-governance arrangements, and Crown apologies. Accept settlements as 'full and final' in exchange for concrete benefits. Benefit materially but forgo broader sovereignty claims that other readings would support.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, treaty_settlement_beneficiaries, beneficiary,
    organized, generational, constrained, regional).

% Māori with ongoing grievances not yet settled, or who reject settlement terms as inadequate. Bear costs of the partnership framework's structural limitations: settlements are capped, process is Crown-controlled, and partnership reading forecloses stronger sovereignty arguments. Identity-locked because exiting the Treaty framework entirely would abandon the constitutional relationship their claims depend on.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, maori_claimants_outside_settlement, payer,
    organized, generational, identity_locked, national).

% Westminster parliamentary sovereignty doctrine is constrained by Treaty principles in practice. Legislation affecting Māori interests faces consultation requirements, potential judicial review for principles compliance, and political costs of breaching partnership norms. Retains formal supremacy but operates under substantial normative constraint the partnership reading imposes.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, parliament_as_institution, payer,
    institutional, generational, constrained, national).

% Māori constitutional scholars, activists, and iwi leaders who argue the Māori text retained full sovereignty. Excluded from the settlement table and judicial doctrine by the partnership reading's foundational premise that sovereignty was ceded. Would argue for co-sovereignty or Māori constitutional priority if the framework permitted.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, rangatiratanga_advocates, excluded,
    organized, generational, identity_locked, national).

% Analyze the partnership doctrine's coherence, doctrinal development, and comparative constitutional status. Document the gap between the reading's rhetorical equality and its operational asymmetry. Observe how the framework manages competing sovereignty claims without resolving them.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, constitutional_law_scholars, observer,
    analytical, generational, analytical, national).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a constitutional framework managing Crown-Māori relations after colonization: consultation processes, grievance redress mechanisms, and shared governance in specific domains solve the coordination problem of two peoples sharing territorial sovereignty claims.
% TRANSFER_FUNCTION: Transfers decision-making authority from unilateral Crown action toward consultation-mediated processes; transfers resources from Crown to iwi via settlements; transfers legitimacy to Crown governance by framing it as partnership rather than conquest.
% ABSENT_VOICES: Rangatiratanga advocates arguing the Māori text retained full sovereignty are structurally excluded: the partnership reading's premise that both parties ceded and gained authority forecloses their constitutional claim before it can be heard.
% DISAPPEARANCE_RATIONALE: If the partnership doctrine vanished, Treaty settlements would halt, consultation requirements would disappear, co-governance arrangements would collapse, and the constitutional relationship would revert to either raw parliamentary supremacy or open sovereignty contest. Crown legitimacy over Māori affairs and resource allocation would fundamentally reorganize.
% FOUNDING_PROBLEM: Post-1840 constitutional relationship between Crown and Māori was legally ambiguous and politically unstable due to textual differences between English and Māori Treaty versions and lack of clear sovereignty allocation mechanism.
% FOUNDING_PROBLEM_CORROBORATION: Crown and mainstream judiciary attest the founding problem is resolved by partnership doctrine. Rangatiratanga advocates and critical Treaty scholars attest the problem persists: textual ambiguity remains unresolved and partnership reading is a Crown-controlled interpretation that avoided rather than solved the sovereignty question. Waitangi Tribunal historical reports and independent constitutional scholarship document both the unresolved textual conflict and the partnership doctrine's political function.
narrative_ontology:disappearance_verdict(waitangi_sovereignty_allocation__partnership_reading, world_rearranges).
narrative_ontology:founding_problem_status(waitangi_sovereignty_allocation__partnership_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(waitangi_sovereignty_allocation__partnership_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(waitangi_sovereignty_allocation__partnership_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(waitangi_sovereignty_allocation__partnership_reading_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, ExtMetricName, E),
    domain_priors:suppression_score(waitangi_sovereignty_allocation__partnership_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(waitangi_sovereignty_allocation__partnership_reading),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(waitangi_sovereignty_allocation__partnership_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is moderate (0.38) because the partnership framework channels Māori claims into Crown-controlled settlement processes with structural caps, while extracting legitimacy for Crown governance through partnership narrative. Suppression is moderate (0.42) because the reading forecloses stronger sovereignty arguments and requires active enforcement through doctrine and settlement practice. Theater ratio is moderate-low (0.28): consultation requirements and principles doctrine create real constraints on Crown action, but a growing share of activity maintains partnership symbolism while avoiding constitutional power reallocation. Accessibility collapse is moderate (0.52): the framework appears as constitutional necessity within mainstream legal culture but remains contested. Resistance is moderate-high (0.58): rangatiratanga advocates and scholars actively contest the reading's legitimacy and constitutional adequacy.
 *
 * PERSPECTIVAL GAP:
 *   From Crown and judicial seats, the partnership reading is foundational constitutional law naturally emerging from Treaty text and colonial history. From rangatiratanga advocate seats, the same reading is a constructed compromise that naturalized Crown sovereignty while dressing it in partnership language. From settlement beneficiary seats, it is pragmatic accommodation trading sovereignty claims for material redress. The claimed mountain type reflects the Crown/judicial framing; the metrics reflect the operational asymmetry and enforcement requirements the reading depends on.
 *
 * DIRECTIONALITY LOGIC:
 *   Crown executive and mainstream judiciary are structural beneficiaries: they administer and interpret the framework while it legitimizes their authority. Treaty settlement beneficiaries receive material gains but at the cost of foreclosed sovereignty claims—mixed position. Māori claimants outside settlement and rangatiratanga advocates are targets: the framework's structural limits extract from their claims. Parliament bears normative constraint. The engine will compute divergent per-seat classifications from these positions.
 *
 * MANDATROPHY ANALYSIS:
 *   The partnership reading prevents misclassifying unilateral Crown sovereignty as pure extraction by documenting the genuine consultation requirements and settlement redress it created. It also prevents misclassifying the framework as pure coordination by naming the structural beneficiaries (Crown legitimacy), the excluded voices (rangatiratanga advocates), and the extraction mechanisms (settlement caps, foreclosed sovereignty claims). The engine computes type from metrics and structural data; divergence between claimed mountain and computed type is the measurement.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    constitutional_vs_constructed_partnership,
    'Is the partnership doctrine a natural constitutional resolution emerging from Treaty text, or a judicially-constructed compromise that naturalized Crown sovereignty?',
    'Comparative constitutional analysis of how other post-colonial jurisdictions resolved analogous textual ambiguities; examination of which elements of partnership doctrine were present in 1840 Treaty negotiation versus developed in 20th century jurisprudence.',
    'If naturally emerging, the mountain claim is warranted and the framework''s legitimacy is foundational. If constructed compromise, the constraint is tangled_rope—genuine coordination function (grievance redress) layered with extraction (Crown sovereignty legitimization, foreclosure of rangatiratanga claims)—and the beneficiary structure drives classification.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(constitutional_vs_constructed_partnership, conceptual, 'Whether partnership doctrine is constitutional bedrock or constructed interpretive layer').

omega_variable(
    textual_ambiguity_vs_power_asymmetry,
    'Do the Treaty texts'' differences reflect genuine translation ambiguity resolvable through partnership principles, or intentional asymmetric promises made to different audiences?',
    'Historical linguistics analysis of 1840s Māori and English Treaty discourse; examination of Crown negotiators'' internal correspondence and contemporaneous Māori understanding of terms like ''kāwanatanga'' versus ''sovereignty''.',
    'If genuine ambiguity, partnership reading is reasonable mediation. If asymmetric promises, partnership doctrine obscures rather than resolves the founding relationship, and the framework operates as legitimization of colonial fait accompli.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(textual_ambiguity_vs_power_asymmetry, empirical, 'Whether Treaty textual differences reflect translation error or strategic ambiguity').

omega_variable(
    settlement_cap_necessity,
    'Are fiscal and jurisdictional caps on Treaty settlements structurally necessary features of the partnership framework, or extraction mechanisms that could be removed while preserving partnership?',
    'Comparative analysis of indigenous rights frameworks in Canada, Australia, Scandinavia that operate without settlement caps; examination of whether uncapped settlements would destabilize Crown fiscal capacity or merely reduce Crown benefit from the process.',
    'If caps are necessity, lower extraction score warranted. If caps are removable extraction, higher extraction score and stronger tangled_rope classification from claimant seats. Affects whether partnership framework coordinates or extracts at the settlement boundary.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(settlement_cap_necessity, empirical, 'Whether settlement caps are partnership''s structural feature or extractive overlay').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(waitangi_sovereignty_allocation__partnership_reading, 1975, 2025).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(wait_tr_t1975, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 1975, 0.15).
narrative_ontology:measurement_basis(wait_tr_t1975, observed).
narrative_ontology:measurement(wait_tr_t1985, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 1985, 0.18).
narrative_ontology:measurement_basis(wait_tr_t1985, observed).
narrative_ontology:measurement(wait_tr_t1995, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 1995, 0.21).
narrative_ontology:measurement_basis(wait_tr_t1995, observed).
narrative_ontology:measurement(wait_tr_t2005, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 2005, 0.24).
narrative_ontology:measurement_basis(wait_tr_t2005, observed).
narrative_ontology:measurement(wait_tr_t2015, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 2015, 0.26).
narrative_ontology:measurement_basis(wait_tr_t2015, observed).
narrative_ontology:measurement(wait_tr_t2025, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 2025, 0.28).
narrative_ontology:measurement_basis(wait_tr_t2025, observed).

% Extraction over time
narrative_ontology:measurement(wait_be_t1975, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 1975, 0.25).
narrative_ontology:measurement_basis(wait_be_t1975, observed).
narrative_ontology:measurement(wait_be_t1985, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 1985, 0.28).
narrative_ontology:measurement_basis(wait_be_t1985, observed).
narrative_ontology:measurement(wait_be_t1995, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 1995, 0.32).
narrative_ontology:measurement_basis(wait_be_t1995, observed).
narrative_ontology:measurement(wait_be_t2005, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 2005, 0.35).
narrative_ontology:measurement_basis(wait_be_t2005, observed).
narrative_ontology:measurement(wait_be_t2015, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 2015, 0.37).
narrative_ontology:measurement_basis(wait_be_t2015, observed).
narrative_ontology:measurement(wait_be_t2025, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 2025, 0.38).
narrative_ontology:measurement_basis(wait_be_t2025, observed).

% Suppression requirement over time
narrative_ontology:measurement(wait_su_t1975, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 1975, 0.35).
narrative_ontology:measurement_basis(wait_su_t1975, observed).
narrative_ontology:measurement(wait_su_t1985, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 1985, 0.37).
narrative_ontology:measurement_basis(wait_su_t1985, observed).
narrative_ontology:measurement(wait_su_t1995, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 1995, 0.39).
narrative_ontology:measurement_basis(wait_su_t1995, observed).
narrative_ontology:measurement(wait_su_t2005, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 2005, 0.4).
narrative_ontology:measurement_basis(wait_su_t2005, observed).
narrative_ontology:measurement(wait_su_t2015, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 2015, 0.41).
narrative_ontology:measurement_basis(wait_su_t2015, observed).
narrative_ontology:measurement(wait_su_t2025, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 2025, 0.42).
narrative_ontology:measurement_basis(wait_su_t2025, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(waitangi_sovereignty_allocation__partnership_reading, enforcement_mechanism).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__partnership_reading, waitangi_sovereignty_allocation__crown_sovereignty_reading).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__partnership_reading, waitangi_sovereignty_allocation__rangatiratanga_reading).

% DUAL FORMULATION NOTE:
% This constraint is the partnership_reading member of the waitangi_sovereignty_allocation kernel family. The crown_sovereignty_reading member treats English text as authoritative and imposes no partnership obligations. The rangatiratanga_reading member treats Māori text as authoritative and recognizes retained Māori sovereignty. Each reading instantiates a different constraint with different beneficiary structures and different ε values. Partnership reading creates moderate extraction through settlement caps and foreclosed sovereignty claims; crown sovereignty reading would create higher extraction through unmoderated parliamentary power; rangatiratanga reading would reverse the beneficiary structure entirely, making Crown the constrained party.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
