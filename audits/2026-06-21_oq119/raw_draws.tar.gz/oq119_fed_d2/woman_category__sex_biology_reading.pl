% ============================================================================
% CONSTRAINT STORY: woman_category__sex_biology_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_woman_category__sex_biology_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: woman_category__sex_biology_reading
 *   human_readable: Woman Category: Sex Biology Reading
 *   domain: political_philosophy/law/social_policy/bioethics
 *
 * SUMMARY:
 *   This constraint operationalizes the sex-biology reading of the contested
 *   'woman' category kernel. Under this reading, category membership is
 *   determined by chromosomal and anatomical criteria (typically XX
 *   chromosomes, female reproductive anatomy), treating these as objective,
 *   measurable, and jurisdictionally stable facts. The reading is codified in
 *   competitive sports eligibility rules, prison assignment policies,
 *   single-sex facility access standards, and civil rights data collection
 *   frameworks in jurisdictions that adopt chromosomal definitions. It is
 *   CLAIMED as a mountain (a natural/foundational feature grounded in
 *   biological reality), but the metrics describe substantial extraction from
 *   excluded populations and rising enforcement requirements. The
 *   claim/metric divergence is deliberate and should NOT be reconciled — the
 *   engine measures whether the operational reality supports the foundational
 *   claim.
 *
 * KEY AGENTS:
 *   - female_athletes_competitive_sports: Primary beneficiary (organized/constrained) — maintain competitive category access defined by natal sex
 *   - sex_based_policy_advocates: Agenda setter (institutional/mobile) — codify chromosomal standards into law and policy
 *   - single_sex_service_providers: Beneficiary (institutional/mobile) — operate sex-segregated spaces using chromosomal criteria
 *   - transgender_women: Primary victim (organized/identity_locked) — excluded from female-designated protections and categories
 *   - intersex_people_excluded_variants: Victim (powerless/trapped) — ambiguously positioned by binary standard, no exit from categorization
 *   - gender_identity_advocates: Excluded (organized/mobile) — argue for alternative reading, structurally excluded from definitional authority
 *   - bioethics_researchers: Observer (analytical/analytical) — document empirical dimensions without taking definitional stance
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(woman_category__sex_biology_reading, 0.68).
domain_priors:suppression_score(woman_category__sex_biology_reading, 0.71).
domain_priors:theater_ratio(woman_category__sex_biology_reading, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, extractiveness, 0.68).
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, suppression_requirement, 0.71).
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, accessibility_collapse, 0.73).
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, resistance, 0.79).

% --- Constraint claim ---
narrative_ontology:constraint_claim(woman_category__sex_biology_reading, mountain).
narrative_ontology:human_readable(woman_category__sex_biology_reading, "Woman Category: Sex Biology Reading").
narrative_ontology:topic_domain(woman_category__sex_biology_reading, "political_philosophy/law/social_policy/bioethics").

domain_priors:requires_active_enforcement(woman_category__sex_biology_reading).
domain_priors:emerges_naturally(woman_category__sex_biology_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(woman_category__sex_biology_reading, 'a477a8b4-d769-4bdd-be7b-4ac65dc52044').
narrative_ontology:cs_kernel_codification('a477a8b4-d769-4bdd-be7b-4ac65dc52044', formalized).
narrative_ontology:cs_authority_grounding('a477a8b4-d769-4bdd-be7b-4ac65dc52044', extraction).
narrative_ontology:cs_reading_relation('a477a8b4-d769-4bdd-be7b-4ac65dc52044', woman_category__gender_identity_reading, forecloses).
narrative_ontology:cs_reading_relation('a477a8b4-d769-4bdd-be7b-4ac65dc52044', woman_category__intersex_accommodation_reading, influences).
narrative_ontology:cs_axiom('a477a8b4-d769-4bdd-be7b-4ac65dc52044', foundational, chromosomal_sex_determines_category_membership).
narrative_ontology:cs_axiom_status(chromosomal_sex_determines_category_membership, holdable).
narrative_ontology:cs_axiom_grounding('a477a8b4-d769-4bdd-be7b-4ac65dc52044', chromosomal_sex_determines_category_membership, empirically_contingent).
narrative_ontology:cs_axiom('a477a8b4-d769-4bdd-be7b-4ac65dc52044', secondary, gender_identity_irrelevant_to_legal_sex_class).
narrative_ontology:cs_axiom_status(gender_identity_irrelevant_to_legal_sex_class, holdable).
narrative_ontology:cs_axiom_grounding('a477a8b4-d769-4bdd-be7b-4ac65dc52044', gender_identity_irrelevant_to_legal_sex_class, conventional).
narrative_ontology:cs_reference_frame('a477a8b4-d769-4bdd-be7b-4ac65dc52044', binary_sex_biological_essentialism).
narrative_ontology:cs_drift_state('a477a8b4-d769-4bdd-be7b-4ac65dc52044', post_transgender_rights_emergence, gap(authority_erosion, substantial, false)).
narrative_ontology:cs_created_at('a477a8b4-d769-4bdd-be7b-4ac65dc52044', '').
narrative_ontology:cs_kernel_id(woman_category__sex_biology_reading, woman_category).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(woman_category__sex_biology_reading, female_athletes_competitive_sports).
narrative_ontology:constraint_beneficiary(woman_category__sex_biology_reading, sex_based_policy_advocates).
narrative_ontology:constraint_beneficiary(woman_category__sex_biology_reading, single_sex_service_providers).
narrative_ontology:constraint_victim(woman_category__sex_biology_reading, transgender_women).
narrative_ontology:constraint_victim(woman_category__sex_biology_reading, intersex_people_excluded_variants).
narrative_ontology:constraint_vindicates(woman_category__sex_biology_reading, binary_sex_classification_doctrine).
narrative_ontology:constraint_vindicates(woman_category__sex_biology_reading, chromosomal_determinism_thesis).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Compete in sex-segregated sports categories where eligibility is determined by natal sex. Maintain access to competitive categories and scholarship opportunities defined by chromosomal/anatomical criteria. Exit would mean competing against individuals with male-typical physiology or leaving competitive athletics entirely.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, female_athletes_competitive_sports, beneficiary,
    organized, biographical, constrained, global).

% Legislators, policy organizations, and advocacy groups who codify sex-biology definitions into law for purposes of data collection, violence-against-women services, healthcare resource allocation, and civil rights protections. Control definitional standards in regulatory frameworks and institutional policies.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, sex_based_policy_advocates, agenda_setter,
    institutional, generational, mobile, national).

% Operate shelters, prisons, healthcare facilities, and other sex-segregated spaces using chromosomal/anatomical criteria for admission. Justify exclusion of transgender women on grounds of safety, privacy, or institutional capacity. Can choose different definitions but face legal/regulatory constraints depending on jurisdiction.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, single_sex_service_providers, beneficiary,
    institutional, biographical, mobile, national).

% Excluded from sex-segregated protections, facilities, and competitive categories reserved for natal females. Face barriers to accessing women's shelters, sports categories, healthcare services defined by natal sex. Cannot exit the exclusion without abandoning gender identity; legal recognition varies by jurisdiction but chromosomal criteria override identity claims where this reading governs.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, transgender_women, payer,
    organized, biographical, identity_locked, global).

% People with chromosomal or anatomical variations (XY with CAIS, mosaicism, ambiguous genitalia) who do not fit the typical XX/female anatomy standard. Ambiguously positioned: sometimes included if raised female and anatomically typical enough, sometimes excluded if chromosomal/hormonal profile deviates. No clear exit from the ambiguity; medical and legal systems impose categorization without their input.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, intersex_people_excluded_variants, payer,
    powerless, biographical, trapped, global).

% Advocacy groups, civil rights organizations, and policy coalitions that argue for self-identification standards and inclusion of transgender women in female-designated spaces. Structurally excluded from policy-setting where chromosomal definitions are codified; their alternative reading is foreclosed by this framework's legal adoption.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, gender_identity_advocates, excluded,
    organized, generational, mobile, global).

% Study the empirical, ethical, and policy dimensions of sex categorization. Document performance advantages in sports, safety outcomes in single-sex spaces, and intersex prevalence. Provide data used by all parties but take no definitional position as researchers.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, bioethics_researchers, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes a binary, biologically-grounded standard for sex-segregated resource allocation, data collection, and legal protections where consistency and bright-line rules are operationally necessary.
% TRANSFER_FUNCTION: Allocates access to competitive sports categories, sex-segregated facilities, violence-against-women services, and legal sex-class protections to people meeting chromosomal/anatomical criteria; denies access to those who do not.
% ABSENT_VOICES: Gender identity advocates and intersex rights organizations are structurally excluded from definitional authority where chromosomal standards are legislatively codified. They argue for self-identification and spectrum-based frameworks but are kept outside the legal rule-making that implements this reading.
% DISAPPEARANCE_RATIONALE: If chromosomal/anatomical definitions disappeared from law overnight, eligibility for sex-segregated sports, shelter admission criteria, prison assignment policies, and civil rights data collection would immediately fragment across jurisdictions. Service providers would adopt self-identification standards or case-by-case discretion; competitive athletics would face classification disputes; legal sex-class protections would lose operational clarity.
% FOUNDING_PROBLEM: Early sex-segregation policy (Title IX, single-sex prisons, women's refuges from male violence) was built to address measurable disparities in physical capacity, violence victimization, and reproductive healthcare needs between males and females as biological classes.
% FOUNDING_PROBLEM_CORROBORATION: Sex-based policy advocates attest the founding problem remains live, citing persistent disparities in athletic performance, male-pattern violence statistics, and sex-specific healthcare needs. Gender identity advocates and human rights organizations attest the founding problem has been reframed by the emergence of gender identity as a protected class and that chromosomal criteria now exclude a vulnerable population from the protections the policy was built to provide. Independent empirical research from bioethics and sports science (performance advantage data, violence statistics disaggregated by natal sex) supports the measurable-disparity claim; human rights scholarship documents exclusion harms.
narrative_ontology:disappearance_verdict(woman_category__sex_biology_reading, world_rearranges).
narrative_ontology:founding_problem_status(woman_category__sex_biology_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(woman_category__sex_biology_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(woman_category__sex_biology_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(woman_category__sex_biology_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(woman_category__sex_biology_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(woman_category__sex_biology_reading, ExtMetricName, E),
    domain_priors:suppression_score(woman_category__sex_biology_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(woman_category__sex_biology_reading),
    narrative_ontology:constraint_metric(woman_category__sex_biology_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(woman_category__sex_biology_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(woman_category__sex_biology_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is substantial (0.68) because exclusion of transgender women from sex-segregated protections imposes measurable harms (safety, healthcare access, competitive opportunity) while benefiting groups whose access depends on chromosomal gatekeeping. Suppression is high (0.71) because the constraint requires active enforcement: legal codification, eligibility verification, and exclusion from spaces/categories defined as female-only. Theater ratio is moderate (0.42): chromosomal testing and anatomical verification serve real gatekeeping functions, but a growing share of enforcement activity is performative boundary maintenance rather than operational necessity. Accessibility collapse is high (0.73) because chromosomal facts are largely immutable — but resistance is also high (0.79) because the excluded population and their advocates contest the reading's legitimacy and mount legal/political challenges. The constraint is CLAIMED as a mountain but exhibits extraction, suppression, and contestation dynamics characteristic of enforced social policy.
 *
 * PERSPECTIVAL GAP:
 *   From the agenda-setter and beneficiary seats, this constraint is a necessary, biologically-grounded bright-line rule that preserves fair competition and sex-based protections. From the victim seats (transgender women, intersex people), the same structure operates as enforced exclusion from protections and opportunities they need, justified by a naturalness claim that denies their lived reality. The observer seat sees both the measurable physical disparities the reading was built to address and the exclusion harms it produces. The engine computes per-seat classifications from this structural asymmetry.
 *
 * DIRECTIONALITY LOGIC:
 *   Female athletes and single-sex service providers are structural beneficiaries: they collect access to protected categories and operational authority from the constraint's enforcement. Sex-based policy advocates are agenda setters with high mobility and institutional power. Transgender women are the primary victim class: identity-locked (cannot exit exclusion without abandoning gender identity), bearing concentrated harm from the constraint's operation. Intersex people are victims with even less power (trapped, ambiguously categorized). Gender identity advocates are excluded from definitional authority. The engine should compute low directionality (low effective extraction) for beneficiaries and high directionality (high effective extraction) for victims.
 *
 * MANDATROPHY ANALYSIS:
 *   This is not straightforward mandatrophy (the founding problem — measurable sex-based disparities — remains empirically live in sports performance and violence statistics). Instead, the contest is whether chromosomal criteria remain fit-for-purpose given the emergence of gender identity as a protected class. The reading treats biological sex as the only relevant axis; sibling readings argue identity or intersex accommodation should govern. The classification challenge is distinguishing genuine coordination (bright-line rules for resource allocation) from extraction riding on biological essentialism.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    biological_essentialism_vs_social_construction,
    'Is the category ''woman'' a pre-social biological fact (chromosomes and anatomy determine membership independently of social recognition), or is category membership a social/legal construction that can be revised to include transgender women and intersex variations?',
    'Philosophical and empirical analysis distinguishing between (a) the empirical fact of chromosomal/anatomical dimorphism, (b) the claim that dimorphism is the ONLY legitimate basis for category membership, and (c) evidence of harms produced by chromosomal exclusivity. Cannot be resolved by biology alone; requires normative judgment about what categories are FOR.',
    'If biological essentialism is correct, this constraint is a genuine mountain and transgender exclusion is a necessary consequence of reality. If category membership is socially constructed, this constraint is a tangled rope or snare — coordination riding on exclusion.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(biological_essentialism_vs_social_construction, conceptual, 'Whether sex-category membership is pre-social biological fact or revisable social construction.').

omega_variable(
    performance_advantage_necessity,
    'In competitive sports, is chromosomal/anatomical classification strictly necessary to preserve fair competition, or can performance-based standards (hormone levels, muscle mass, VO2 max) achieve the same coordination function without categorical exclusion?',
    'Longitudinal data on transgender women athletes'' performance post-transition, compared to natal female performance distributions. If post-transition performance converges with natal female ranges, categorical exclusion is unnecessary for fairness. If advantages persist despite hormone therapy, categorical exclusion may be coordination rather than extraction.',
    'If performance advantages dissolve post-transition, the chromosomal standard extracts more than necessary (could use performance proxies instead). If advantages persist, the standard is genuinely coordinating fair competition and extraction is lower.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(performance_advantage_necessity, empirical, 'Whether chromosomal exclusion in sports is necessary for fairness or over-inclusive.').

omega_variable(
    intersex_inclusion_boundary,
    'Where does this reading place the inclusion boundary for intersex people? Does it include all people raised as female regardless of chromosomal variation, only XX individuals, or only those with typical female anatomy? The boundary is underspecified.',
    'Examination of actual policy implementation: how do sports governing bodies, prisons, and shelters handle CAIS, mosaicism, and ambiguous anatomy cases? The reading''s operational boundary may be stricter or more accommodating than its theoretical claim.',
    'A strict chromosomal boundary (XX-only) produces higher extraction and more victims (excludes XY/CAIS people raised as women). A functional anatomy boundary (raised female + typical anatomy) reduces extraction but concedes that chromosomes alone don''t determine membership.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(intersex_inclusion_boundary, empirical, 'Intersex inclusion ambiguity within the chromosomal standard.').

omega_variable(
    false_summit_mountain_claim,
    'Is this constraint a genuine natural law (biological sex is immutable and determinative), or is it a constructed policy reading that benefits identifiable groups (natal female athletes, sex-based policy advocates) and suppresses alternatives?',
    'FSM detection: mountain claim + declared beneficiaries + rising extractiveness over time. If enforcement intensification and theater ratio growth indicate constructed maintenance rather than natural persistence, reclassify as tangled rope or snare.',
    'If genuine mountain, exclusion of transgender women is a necessary consequence of biological reality and beneficiaries are incidental. If false summit, exclusion is extraction riding on biological essentialism, beneficiaries are structural (not incidental), and the constraint is actively maintained against resistance.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(false_summit_mountain_claim, conceptual, 'Mountain claim vs. constructed policy with identifiable beneficiaries (FSM candidate).').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(woman_category__sex_biology_reading, 0, 30).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(woma_tr_t0, woman_category__sex_biology_reading, theater_ratio, 0, 0.22).
narrative_ontology:measurement_basis(woma_tr_t0, observed).
narrative_ontology:measurement(woma_tr_t6, woman_category__sex_biology_reading, theater_ratio, 6, 0.26).
narrative_ontology:measurement_basis(woma_tr_t6, observed).
narrative_ontology:measurement(woma_tr_t12, woman_category__sex_biology_reading, theater_ratio, 12, 0.31).
narrative_ontology:measurement_basis(woma_tr_t12, observed).
narrative_ontology:measurement(woma_tr_t18, woman_category__sex_biology_reading, theater_ratio, 18, 0.35).
narrative_ontology:measurement_basis(woma_tr_t18, observed).
narrative_ontology:measurement(woma_tr_t24, woman_category__sex_biology_reading, theater_ratio, 24, 0.39).
narrative_ontology:measurement_basis(woma_tr_t24, observed).
narrative_ontology:measurement(woma_tr_t30, woman_category__sex_biology_reading, theater_ratio, 30, 0.42).
narrative_ontology:measurement_basis(woma_tr_t30, observed).

% Extraction over time
narrative_ontology:measurement(woma_be_t0, woman_category__sex_biology_reading, base_extractiveness, 0, 0.48).
narrative_ontology:measurement_basis(woma_be_t0, observed).
narrative_ontology:measurement(woma_be_t6, woman_category__sex_biology_reading, base_extractiveness, 6, 0.52).
narrative_ontology:measurement_basis(woma_be_t6, observed).
narrative_ontology:measurement(woma_be_t12, woman_category__sex_biology_reading, base_extractiveness, 12, 0.57).
narrative_ontology:measurement_basis(woma_be_t12, observed).
narrative_ontology:measurement(woma_be_t18, woman_category__sex_biology_reading, base_extractiveness, 18, 0.62).
narrative_ontology:measurement_basis(woma_be_t18, observed).
narrative_ontology:measurement(woma_be_t24, woman_category__sex_biology_reading, base_extractiveness, 24, 0.65).
narrative_ontology:measurement_basis(woma_be_t24, observed).
narrative_ontology:measurement(woma_be_t30, woman_category__sex_biology_reading, base_extractiveness, 30, 0.68).
narrative_ontology:measurement_basis(woma_be_t30, observed).

% Suppression requirement over time
narrative_ontology:measurement(woma_su_t0, woman_category__sex_biology_reading, suppression_requirement, 0, 0.52).
narrative_ontology:measurement_basis(woma_su_t0, observed).
narrative_ontology:measurement(woma_su_t6, woman_category__sex_biology_reading, suppression_requirement, 6, 0.57).
narrative_ontology:measurement_basis(woma_su_t6, observed).
narrative_ontology:measurement(woma_su_t12, woman_category__sex_biology_reading, suppression_requirement, 12, 0.62).
narrative_ontology:measurement_basis(woma_su_t12, observed).
narrative_ontology:measurement(woma_su_t18, woman_category__sex_biology_reading, suppression_requirement, 18, 0.66).
narrative_ontology:measurement_basis(woma_su_t18, observed).
narrative_ontology:measurement(woma_su_t24, woman_category__sex_biology_reading, suppression_requirement, 24, 0.69).
narrative_ontology:measurement_basis(woma_su_t24, observed).
narrative_ontology:measurement(woma_su_t30, woman_category__sex_biology_reading, suppression_requirement, 30, 0.71).
narrative_ontology:measurement_basis(woma_su_t30, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(woman_category__sex_biology_reading, identity_coordination).
narrative_ontology:affects_constraint(woman_category__sex_biology_reading, woman_category__gender_identity_reading).
narrative_ontology:affects_constraint(woman_category__sex_biology_reading, woman_category__intersex_accommodation_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the woman_category kernel. All three readings (sex_biology, gender_identity, intersex_accommodation) are separate constraints with different epsilon values, different victim sets, and different beneficiary structures. They are linked via network.affects_constraints because they are alternative operationalizations of the same natural-language concept ('woman'). The sex_biology reading has higher extraction in contexts where it legally forecloses the gender_identity reading (sports, prisons, shelter access); the gender_identity reading has higher extraction where it is codified and forecloses sex_biology protections (women-only spaces, data collection). The intersex_accommodation reading is an attempt to resolve both by acknowledging biological spectrum, but it remains contested and underspecified.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
