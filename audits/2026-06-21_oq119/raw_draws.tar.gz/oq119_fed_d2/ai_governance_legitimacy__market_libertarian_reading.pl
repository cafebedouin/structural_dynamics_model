% ============================================================================
% CONSTRAINT STORY: ai_governance_legitimacy__market_libertarian_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_ai_governance_legitimacy__market_libertarian_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: ai_governance_legitimacy__market_libertarian_reading
 *   human_readable: Market Libertarian Reading of AI Governance Legitimacy
 *   domain: theological_ethics/technology_governance/political_theology
 *
 * SUMMARY:
 *   This constraint represents the market-libertarian reading of AI
 *   governance legitimacy from within the kernel of competing readings
 *   responding to Laudate Deum's intervention in technology ethics. It
 *   grounds legitimacy in property rights and voluntary exchange treated as
 *   pre-political natural law, rejecting the encyclical's claim that economic
 *   freedom must be subordinated to solidarity and common good as defined by
 *   political authority. KEY AGENTS: technology_entrepreneurs and
 *   venture_investors (powerful/institutional beneficiaries with arbitrage
 *   exit), low_market_power_workers and coordination_dependent_communities
 *   (powerless/organized payers with trapped/constrained exit),
 *   magisterial_authority (excluded voice claiming binding moral authority
 *   this reading rejects), political_theologian_observer (analytical seat
 *   seeing the structural contest).
 *
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(ai_governance_legitimacy__market_libertarian_reading, 0.25).
domain_priors:suppression_score(ai_governance_legitimacy__market_libertarian_reading, 0.18).
domain_priors:theater_ratio(ai_governance_legitimacy__market_libertarian_reading, 0.12).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, extractiveness, 0.25).
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 0.18).
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 0.12).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, accessibility_collapse, 0.82).
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, resistance, 0.35).

% --- Constraint claim ---
narrative_ontology:constraint_claim(ai_governance_legitimacy__market_libertarian_reading, mountain).
narrative_ontology:human_readable(ai_governance_legitimacy__market_libertarian_reading, "Market Libertarian Reading of AI Governance Legitimacy").
narrative_ontology:topic_domain(ai_governance_legitimacy__market_libertarian_reading, "theological_ethics/technology_governance/political_theology").

domain_priors:emerges_naturally(ai_governance_legitimacy__market_libertarian_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(ai_governance_legitimacy__market_libertarian_reading, '05ae8806-d213-4d4e-908e-41d44c883557').
narrative_ontology:cs_kernel_codification('05ae8806-d213-4d4e-908e-41d44c883557', distributed).
narrative_ontology:cs_authority_grounding('05ae8806-d213-4d4e-908e-41d44c883557', distributed).
narrative_ontology:cs_reading_relation('05ae8806-d213-4d4e-908e-41d44c883557', ai_governance_legitimacy__magisterial_subsidiarity_reading, forecloses).
narrative_ontology:cs_reading_relation('05ae8806-d213-4d4e-908e-41d44c883557', ai_governance_legitimacy__technocratic_optimization_reading, coexists_with).
narrative_ontology:cs_reading_relation('05ae8806-d213-4d4e-908e-41d44c883557', ai_governance_legitimacy__democratic_pluralist_reading, influences).
narrative_ontology:cs_axiom('05ae8806-d213-4d4e-908e-41d44c883557', foundational, property_rights_pre_political).
narrative_ontology:cs_axiom_status(property_rights_pre_political, holdable).
narrative_ontology:cs_axiom_grounding('05ae8806-d213-4d4e-908e-41d44c883557', property_rights_pre_political, deontological).
narrative_ontology:cs_axiom('05ae8806-d213-4d4e-908e-41d44c883557', foundational, solidarity_mandates_illegitimate_coercion).
narrative_ontology:cs_axiom_status(solidarity_mandates_illegitimate_coercion, holdable).
narrative_ontology:cs_axiom_grounding('05ae8806-d213-4d4e-908e-41d44c883557', solidarity_mandates_illegitimate_coercion, deontological).
narrative_ontology:cs_reference_frame('05ae8806-d213-4d4e-908e-41d44c883557', lockean_property_rights_framework).
narrative_ontology:cs_drift_state('05ae8806-d213-4d4e-908e-41d44c883557', contemporary_ai_concentration, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('05ae8806-d213-4d4e-908e-41d44c883557', '').
narrative_ontology:cs_kernel_id(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__market_libertarian_reading, technology_entrepreneurs).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__market_libertarian_reading, venture_investors).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__market_libertarian_reading, high_autonomy_professionals).
narrative_ontology:constraint_victim(ai_governance_legitimacy__market_libertarian_reading, low_market_power_workers).
narrative_ontology:constraint_victim(ai_governance_legitimacy__market_libertarian_reading, coordination_dependent_communities).
narrative_ontology:constraint_victim(ai_governance_legitimacy__market_libertarian_reading, monopsony_labor_markets).
narrative_ontology:constraint_vindicates(ai_governance_legitimacy__market_libertarian_reading, property_rights_pre_political_status).
narrative_ontology:constraint_vindicates(ai_governance_legitimacy__market_libertarian_reading, voluntary_exchange_primacy).
narrative_ontology:constraint_vindicates(ai_governance_legitimacy__market_libertarian_reading, spontaneous_order_doctrine).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Build and deploy AI systems under contract law and voluntary agreements without prior collective authorization. Exit options include jurisdictional arbitrage across regulatory environments. Collect returns on innovation and risk-taking through market mechanisms. The constraint protects their autonomy from collective mandates.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, technology_entrepreneurs, beneficiary,
    powerful, biographical, arbitrage, global).

% Allocate capital to AI ventures without collective oversight beyond contractual enforcement. Portfolio diversification and jurisdictional mobility provide risk management. The constraint ensures returns accrue through voluntary exchange rather than being redistributed through solidarity mechanisms.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, venture_investors, beneficiary,
    institutional, biographical, arbitrage, global).

% Negotiate individual terms for AI tool usage and data sharing through contract. Possess skills and resources to exit unfavorable arrangements. The constraint protects their capacity to choose arrangements that maximize personal utility without collective interference.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, high_autonomy_professionals, beneficiary,
    moderate, biographical, mobile, global).

% Face AI-driven labor displacement and algorithmic management with limited individual negotiating capacity. Cannot afford jurisdictional exit. The constraint prohibits collective bargaining mechanisms or redistributive protections as illegitimate coercion, leaving them to accept whatever terms employers offer or exit the labor market entirely.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, low_market_power_workers, payer,
    powerless, biographical, trapped, national).

% Require collective action to manage AI externalities like surveillance infrastructure or environmental costs. The constraint treats their coordination attempts as illegitimate coercion when they bind dissenting members. Exit requires relocating entire communities, which is structurally infeasible.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, coordination_dependent_communities, payer,
    organized, generational, constrained, regional).

% Workers in company towns or specialized industries where one employer dominates. AI-driven productivity monitoring and wage-setting occur under formally voluntary contracts but structurally coercive conditions. The constraint prohibits regulatory intervention as market interference.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, monopsony_labor_markets, payer,
    powerless, biographical, trapped, regional).

% Claims interpretive authority over AI governance through Catholic Social Doctrine. This reading treats magisterial claims as one voice among many market participants rather than binding moral authority. The magisterium would argue solidarity and common good must constrain market freedom; this constraint excludes that claim as illegitimate coercion.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, magisterial_authority, excluded,
    institutional, civilizational, analytical, global).

% Analyzes competing readings of governance legitimacy. Notes this reading rejects the encyclical's subordination of economic freedom to common good by treating property rights as pre-political natural law rather than socially constructed arrangements subject to ethical constraint.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, political_theologian_observer, observer,
    analytical, civilizational, analytical, universal).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes clear property boundaries and contract enforcement for AI development. Solves the double-spending problem and enables investment by securing returns to innovation through exclusive rights rather than collective allocation.
% TRANSFER_FUNCTION: Moves AI-generated productivity gains to those who own capital and IP, with wage gains flowing through competitive bidding for scarce skills. Concentration occurs through market mechanisms; redistribution through solidarity is prohibited as coercion.
% ABSENT_VOICES: Workers lacking exit options, communities facing coordination failures, and the magisterial tradition asserting that economic arrangements must serve universal human dignity are structurally excluded. They would argue market freedom requires collective constraints; this constraint treats those constraints as illegitimate.
% DISAPPEARANCE_RATIONALE: Proponents claim arrangements would collapse into inefficient rent-seeking and stifled innovation without property-rights protection. Critics claim arrangements would reorganize around democratic governance and solidarity principles, with innovation continuing under different incentive structures. The contest is fundamentally about whether property rights are discovered or constructed.
% FOUNDING_PROBLEM: Uncertainty about ownership and returns discourages investment in innovation. Without clear property rights, creators cannot capture gains from AI development, leading to underinvestment relative to social optimum.
% FOUNDING_PROBLEM_CORROBORATION: Libertarian legal scholars and Austrian economists attest the problem remains live and property rights remain the solution. Development economists, labor historians, and Catholic social teaching scholars attest the founding problem was solved through multiple institutional arrangements historically, and current property-rights maximalism serves rent extraction rather than innovation incentives.
narrative_ontology:disappearance_verdict(ai_governance_legitimacy__market_libertarian_reading, contested).
narrative_ontology:founding_problem_status(ai_governance_legitimacy__market_libertarian_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(ai_governance_legitimacy__market_libertarian_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(ai_governance_legitimacy__market_libertarian_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(ai_governance_legitimacy__market_libertarian_reading_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, ExtMetricName, E),
    domain_priors:suppression_score(ai_governance_legitimacy__market_libertarian_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(ai_governance_legitimacy__market_libertarian_reading),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(ai_governance_legitimacy__market_libertarian_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is low (0.25) because this reading permits concentration through voluntary exchange without viewing market-power accumulation as extraction—only coerced transfers qualify. Suppression is low (0.18) because the constraint operates through contract enforcement rather than active prohibition of alternatives. Theater is very low (0.12) because property-rights enforcement is functional rather than performative. Accessibility collapse is high (0.82) because this reading treats property rights as pre-political—once you understand the natural-law claim, no coherent alternative arrangement exists within the framework. Resistance is moderate (0.35) because substantial constituencies reject property-rights maximalism and assert collective governance authority. The measurement series shows gradual extraction accumulation as market concentration increases and monopsony conditions harden, with suppression rising as enforcement machinery expands to prohibit solidarity mechanisms.
 *
 * PERSPECTIVAL GAP:
 *   From the high-autonomy beneficiary seats, this constraint operates as genuine coordination securing innovation incentives through clear property boundaries. From the trapped-payer seats, the same structure operates as enforced extraction prohibiting collective response to structural power asymmetries. The engine computes this divergence from the power/exit differentials; the authored mountain claim reflects the reading's self-understanding as discovering natural law rather than constructing social arrangements.
 *
 * DIRECTIONALITY LOGIC:
 *   Entrepreneurs and investors are structural beneficiaries: they collect returns secured by property rights, possess arbitrage exit across jurisdictions, and face minimal constraints from collective mandates. Workers without market power are structural targets: they bear costs of algorithmic management and displacement, lack exit options, and are prohibited from collective response mechanisms this reading treats as coercion. Communities facing coordination problems are also targets: required to solve collective-action problems through unanimous voluntary agreement, an infeasible standard. The magisterial tradition is excluded rather than coordinated—its claim to moral authority over economic arrangements is rejected as one market participant's preference.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint's coordination function (property-rights clarity enabling investment) is genuine but operates at the entrepreneur/investor level. The extraction (concentration of AI gains with prohibition of solidarity mechanisms) operates at the worker/community level. This is structural tangled-rope territory—genuine coordination for some, enforced extraction for others—but this reading claims mountain status by treating property rights as pre-political. The FSM evaluation should detect this: a mountain with identifiable beneficiaries and victims, where accessibility collapse is high but resistance is substantial, suggests a constructed constraint claiming natural-law status.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    property_rights_natural_or_constructed,
    'Are property rights in AI systems discovered natural law prior to political authority, or socially constructed arrangements subject to democratic revision?',
    'Historical analysis of property-regime variation across societies and epochs, plus philosophical examination of whether property claims can be derived from human nature independent of social context. If property rights are constructed, collective constraints are legitimate governance; if natural law, such constraints are coercion.',
    'If property rights are natural law, this constraint is a genuine mountain and solidarity mechanisms are illegitimate coercion. If they are constructed, the constraint is a tangled rope or snare where high-autonomy actors benefit from a social arrangement while trapped actors bear costs.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(property_rights_natural_or_constructed, conceptual, 'Whether property rights are pre-political natural law or constructed social arrangements.').

omega_variable(
    exit_accessibility_for_low_power_agents,
    'Do low-market-power workers and coordination-dependent communities possess meaningful exit from AI-governance arrangements, or is their ''voluntary'' participation structurally coerced?',
    'Empirical measurement of labor-market mobility, community relocation feasibility, and bargaining-power distribution. If exit is structurally infeasible for substantial populations, the constraint''s suppression is higher than measured and its voluntary-exchange claim is cover for extraction.',
    'If exit is accessible, the constraint operates as claimed coordination. If exit is structurally blocked, the constraint extracts from trapped populations while claiming voluntary exchange, and the measured extractiveness is artificially low.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(exit_accessibility_for_low_power_agents, empirical, 'Whether exit options for low-power agents are real or nominal.').

omega_variable(
    monopsony_prevalence,
    'What proportion of AI-affected labor markets exhibit monopsony conditions where employers possess structural wage-setting power?',
    'Labor-economics analysis of AI-sector concentration, worker mobility, and wage-deviation from competitive equilibrium. High monopsony prevalence means the constraint permits extraction through formally voluntary contracts.',
    'Widespread monopsony would establish that the constraint''s low measured extractiveness conceals substantial transfer from workers to capital through structural rather than contractual mechanisms, making the mountain claim untenable.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(monopsony_prevalence, empirical, 'Extent of employer market power in AI-affected sectors.').

omega_variable(
    coordination_failure_frequency,
    'How often do communities face AI-governance coordination problems (surveillance, environmental costs, algorithmic discrimination) that require collective action but cannot be solved through unanimous voluntary agreement?',
    'Case-study analysis of community attempts to regulate AI externalities. If coordination failures are frequent and unanimous-consent requirement blocks solutions, the constraint''s suppression is higher than measured.',
    'Frequent coordination failures blocked by unanimity requirements would establish the constraint as extractive: it prevents collective response to harms while claiming to protect voluntary choice, concentrating costs on communities that cannot exit.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(coordination_failure_frequency, empirical, 'Prevalence of coordination failures under unanimity constraint.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(ai_governance_legitimacy__market_libertarian_reading, 0, 30).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(ai_g_tr_t0, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 0, 0.08).
narrative_ontology:measurement(ai_g_tr_t6, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 6, 0.09).
narrative_ontology:measurement(ai_g_tr_t12, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 12, 0.1).
narrative_ontology:measurement(ai_g_tr_t18, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 18, 0.11).
narrative_ontology:measurement(ai_g_tr_t24, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 24, 0.11).
narrative_ontology:measurement(ai_g_tr_t30, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 30, 0.12).

% Extraction over time
narrative_ontology:measurement(ai_g_be_t0, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 0, 0.15).
narrative_ontology:measurement(ai_g_be_t6, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 6, 0.18).
narrative_ontology:measurement(ai_g_be_t12, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 12, 0.21).
narrative_ontology:measurement(ai_g_be_t18, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 18, 0.23).
narrative_ontology:measurement(ai_g_be_t24, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 24, 0.24).
narrative_ontology:measurement(ai_g_be_t30, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 30, 0.25).

% Suppression requirement over time
narrative_ontology:measurement(ai_g_su_t0, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 0, 0.12).
narrative_ontology:measurement(ai_g_su_t6, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 6, 0.14).
narrative_ontology:measurement(ai_g_su_t12, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 12, 0.15).
narrative_ontology:measurement(ai_g_su_t18, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 18, 0.17).
narrative_ontology:measurement(ai_g_su_t24, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 24, 0.18).
narrative_ontology:measurement(ai_g_su_t30, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 30, 0.18).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(ai_governance_legitimacy__market_libertarian_reading, resource_allocation).
narrative_ontology:affects_constraint(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy__magisterial_subsidiarity_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy__technocratic_optimization_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy__democratic_pluralist_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading within the ai_governance_legitimacy kernel family. All four readings derive legitimacy claims from different foundational sources and authorize different governance structures. The market-libertarian reading treats property rights as natural law, foreclosing collective mandates; the magisterial reading subordinates economic freedom to common good; the technocratic reading treats ethics as optimization parameters; the democratic reading grounds legitimacy in deliberation. They are structurally distinct constraints with different beneficiary/victim sets, not different measurements of one constraint.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
