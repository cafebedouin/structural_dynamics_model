% ============================================================================
% CONSTRAINT STORY: acceptable_risk_energy__option_value_preserving
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_acceptable_risk_energy__option_value_preserving, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:stakeholder_non_agent/2,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: acceptable_risk_energy__option_value_preserving
 *   human_readable: Option Value Preserving Risk Framework in Energy Policy
 *   domain: risk_assessment/energy_policy/decision_theory
 *
 * SUMMARY:
 *   The option-value preserving reading treats acceptable risk in energy
 *   policy as fundamentally about maintaining decision flexibility under deep
 *   uncertainty. It asserts that rational policy keeps multiple energy
 *   pathways viable—fossil, nuclear, and renewable—rather than committing
 *   early to any single pathway, because the costs of premature closure are
 *   irreversible while the costs of delay are gradual and potentially
 *   recoverable. This reading is claimed as mountain (a foundational
 *   principle of decision theory under uncertainty) while the metrics
 *   describe moderately extractive operation with rising suppression—the
 *   engine measures whether the foundational claim holds against the
 *   operational reality. The committer frame matters here: this is one of
 *   three incompatible readings of what 'acceptable risk' means in energy
 *   policy, each producing different victim sets and different policy
 *   equilibria from the same contested kernel.
 *
 * KEY AGENTS:
 *   - incumbent_energy_producers: Primary beneficiary (institutional/mobile) — portfolio protection
 *   - energy_flexibility_advocates: Agenda setter (institutional/analytical) — framework developers
 *   - climate_mitigation_timeline: Primary victim (powerless/trapped, non-agent) — bears emissions cost of delay
 *   - renewable_transition_advocates: Payer (organized/constrained) — policy delay costs
 *   - communities_near_continued_fossil_operations: Payer (powerless/trapped) — local health externalities
 *   - decision_theorists: Observer (analytical/analytical) — full structure visibility
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(acceptable_risk_energy__option_value_preserving, 0.48).
domain_priors:suppression_score(acceptable_risk_energy__option_value_preserving, 0.52).
domain_priors:theater_ratio(acceptable_risk_energy__option_value_preserving, 0.38).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, extractiveness, 0.48).
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, suppression_requirement, 0.52).
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, theater_ratio, 0.38).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, accessibility_collapse, 0.42).
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, resistance, 0.58).

% --- Constraint claim ---
narrative_ontology:constraint_claim(acceptable_risk_energy__option_value_preserving, mountain).
narrative_ontology:human_readable(acceptable_risk_energy__option_value_preserving, "Option Value Preserving Risk Framework in Energy Policy").
narrative_ontology:topic_domain(acceptable_risk_energy__option_value_preserving, "risk_assessment/energy_policy/decision_theory").

domain_priors:requires_active_enforcement(acceptable_risk_energy__option_value_preserving).
domain_priors:emerges_naturally(acceptable_risk_energy__option_value_preserving).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(acceptable_risk_energy__option_value_preserving, '5033b725-e7d2-42b2-9a6d-3b597d836774').
narrative_ontology:cs_kernel_codification('5033b725-e7d2-42b2-9a6d-3b597d836774', formalized).
narrative_ontology:cs_authority_grounding('5033b725-e7d2-42b2-9a6d-3b597d836774', expertise).
narrative_ontology:cs_interpretation_layer_present('5033b725-e7d2-42b2-9a6d-3b597d836774').
narrative_ontology:cs_reading_relation('5033b725-e7d2-42b2-9a6d-3b597d836774', acceptable_risk_energy__catastrophic_tail_dominant, coexists_with).
narrative_ontology:cs_reading_relation('5033b725-e7d2-42b2-9a6d-3b597d836774', acceptable_risk_energy__expected_value_dominant, coexists_with).
narrative_ontology:cs_axiom('5033b725-e7d2-42b2-9a6d-3b597d836774', foundational, flexibility_value_dominates_commitment_value).
narrative_ontology:cs_axiom_status(flexibility_value_dominates_commitment_value, holdable).
narrative_ontology:cs_axiom_grounding('5033b725-e7d2-42b2-9a6d-3b597d836774', flexibility_value_dominates_commitment_value, instrumental).
narrative_ontology:cs_axiom('5033b725-e7d2-42b2-9a6d-3b597d836774', foundational, uncertainty_warrants_portfolio_maintenance).
narrative_ontology:cs_axiom_status(uncertainty_warrants_portfolio_maintenance, holdable).
narrative_ontology:cs_axiom_grounding('5033b725-e7d2-42b2-9a6d-3b597d836774', uncertainty_warrants_portfolio_maintenance, empirically_contingent).
narrative_ontology:cs_axiom('5033b725-e7d2-42b2-9a6d-3b597d836774', secondary, irreversibility_asymmetry_favoring_incumbents).
narrative_ontology:cs_axiom_status(irreversibility_asymmetry_favoring_incumbents, holdable).
narrative_ontology:cs_axiom_grounding('5033b725-e7d2-42b2-9a6d-3b597d836774', irreversibility_asymmetry_favoring_incumbents, empirically_contingent).
narrative_ontology:cs_reference_frame('5033b725-e7d2-42b2-9a6d-3b597d836774', real_options_decision_theory).
narrative_ontology:cs_drift_state('5033b725-e7d2-42b2-9a6d-3b597d836774', post_renewable_empirical_resolution, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('5033b725-e7d2-42b2-9a6d-3b597d836774', '').
narrative_ontology:cs_kernel_id(acceptable_risk_energy__option_value_preserving, acceptable_risk_energy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__option_value_preserving, incumbent_energy_producers).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__option_value_preserving, energy_flexibility_advocates).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__option_value_preserving, diversified_energy_investors).
narrative_ontology:constraint_victim(acceptable_risk_energy__option_value_preserving, climate_mitigation_timeline).
narrative_ontology:constraint_victim(acceptable_risk_energy__option_value_preserving, renewable_transition_advocates).
narrative_ontology:constraint_victim(acceptable_risk_energy__option_value_preserving, communities_near_continued_fossil_operations).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__option_value_preserving, nuclear_industry).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__option_value_preserving, grid_reliability_regulators).
narrative_ontology:constraint_victim(acceptable_risk_energy__option_value_preserving, nuclear_industry).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Operate existing fossil and nuclear infrastructure whose continued viability is protected by the option-value framework. The reading treats premature closure as destroying irreversible option value, which justifies maintaining their assets longer than alternative risk frameworks would permit. They fund research institutes that produce option-value analyses and testify that energy security requires keeping all proven pathways open.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, incumbent_energy_producers, beneficiary,
    institutional, generational, mobile, global).

% Academic economists and policy analysts who develop and promote real-options modeling for energy transitions. They frame the problem as decision-making under deep uncertainty where preserving multiple pathways is rational insurance. They publish models showing that early commitment to any single pathway destroys value and recommend portfolio approaches that keep both nuclear and fossil baseload available alongside renewable expansion.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, energy_flexibility_advocates, agenda_setter,
    institutional, generational, analytical, national).

% Hold portfolios spanning fossil, nuclear, and renewable assets. The option-value reading protects the full portfolio's value by preventing policy that would strand fossil or nuclear holdings before their economic life ends. They benefit from regulatory frameworks that treat diversification itself as prudent risk management rather than as hedging against necessary transition.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, diversified_energy_investors, beneficiary,
    powerful, biographical, arbitrage, global).

% The physical timeline for avoiding severe climate outcomes pays the cost of maintaining fossil pathways beyond what aggressive mitigation would require. Every year that coal or gas generation continues under option-value protection is a year of additional emissions. This is not an agent but represents the cumulative climate budget consumed by the slower transition the framework justifies.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, climate_mitigation_timeline, payer,
    powerless, generational, trapped, global).
narrative_ontology:stakeholder_non_agent(acceptable_risk_energy__option_value_preserving, climate_mitigation_timeline).

% Climate organizations and renewable developers who argue the option-value framework systematically delays fossil retirement by treating uncertainty as symmetric when climate risks are not. They bear the cost of policies that defer commitments: slower renewable deployment, continued subsidies for fossil backup capacity, regulatory frameworks that require demonstrating renewables can fully replace incumbents before any closures proceed. They produce alternative analyses showing the option value of early renewable commitment exceeds the flexibility value of keeping fossil options open, but these analyses are treated as partisan within the option-value reading's frame.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, renewable_transition_advocates, payer,
    organized, generational, constrained, global).

% Live adjacent to coal plants, gas extraction sites, or refineries whose operational life is extended by option-value justifications. They experience the local health costs of continued operation—particulate pollution, water contamination, industrial accidents—that are externalized in the option-value calculation which focuses on system-level flexibility. Their mortality and morbidity are the denominator in flexibility metrics that treat continued operation as maintaining valuable options.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, communities_near_continued_fossil_operations, payer,
    powerless, biographical, trapped, local).

% Benefits from the reading's treatment of nuclear as a non-carbon baseload option worth preserving, but also bears costs where the same framework treats early nuclear expansion as premature commitment. The option-value logic cuts both ways: it protects existing nuclear from early closure but also justifies deferring new nuclear construction until uncertainty about small modular reactors or fusion resolves. The industry both invokes and contests the framework depending on whether existing assets or new builds are at stake.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, nuclear_industry, beneficiary,
    institutional, civilizational, identity_locked, global).
narrative_ontology:stakeholder_secondary_role(acceptable_risk_energy__option_value_preserving, nuclear_industry, payer).

% Set reliability standards that determine what counts as adequate backup capacity. The option-value framework gives them cover to require maintaining dispatchable fossil and nuclear capacity as insurance against renewable intermittency, which defers the operational and regulatory changes that full renewable systems would require of them. They frame this as prudent engineering but the institutional preference for familiar baseload sources is protected by the uncertainty the framework emphasizes.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, grid_reliability_regulators, agenda_setter,
    institutional, generational, constrained, national).
narrative_ontology:stakeholder_secondary_role(acceptable_risk_energy__option_value_preserving, grid_reliability_regulators, beneficiary).

% Study how real-options models perform under different uncertainty structures. They observe that the option-value reading treats climate, technology, and demand uncertainty as symmetric when the empirical distributions are not, and that this asymmetry systematically biases toward incumbent technologies with known failure modes over emerging technologies with unknown failure modes. They document that the framework's conclusions are sensitive to modeling choices about when options become irreversible, but these sensitivity analyses rarely penetrate policy application.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, decision_theorists, observer,
    analytical, civilizational, analytical, universal).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a shared decision framework for managing energy transitions under uncertainty: all parties can justify their positions in option-value terms, which prevents policy deadlock by treating portfolio maintenance as rational rather than as special pleading for incumbents.
% TRANSFER_FUNCTION: Moves policy space and capital from rapid single-pathway commitment (aggressive renewable transition or nuclear expansion) toward portfolio maintenance that keeps fossil, nuclear, and renewable pathways simultaneously viable. The transfer flows from those who bear climate and local health costs of continued fossil operation to those whose assets and institutional arrangements are protected by the slower transition.
% ABSENT_VOICES: Future generations whose climate inheritance is being determined, and communities in the Global South facing climate impacts whose severity the option-value calculus discounts by treating all uncertainty as symmetric. Also absent: ecological systems whose degradation under continued fossil operation is not modeled as destroying option value.
% DISAPPEARANCE_RATIONALE: If the option-value reading vanished overnight, energy policy would reorganize around either expected-value mortality metrics (driving rapid fossil retirement) or tail-risk catastrophe avoidance (driving rapid nuclear or renewable commitment depending on which tail dominates). The current policy equilibrium that keeps all pathways viable would collapse and capital would flow rapidly toward whichever alternative reading captured regulatory authority. Grid planning, subsidy structures, and retirement schedules would all shift within a single policy cycle.
% FOUNDING_PROBLEM: Early 21st-century energy policy faced genuine deep uncertainty about renewable scalability, storage costs, nuclear safety post-Fukushima, and climate trajectory. Premature commitment to any single pathway risked stranding massive capital and locking in suboptimal infrastructure.
% FOUNDING_PROBLEM_CORROBORATION: The energy flexibility advocates and incumbent producers attest the uncertainty remains unresolved and the problem is still live. Renewable transition advocates and climate scientists attest that renewable scalability and climate trajectory are now substantially resolved by empirical data, and that continued invocation of deep uncertainty is increasingly a framing choice rather than an empirical constraint. Academic debate remains live but the empirical basis for symmetry has eroded—corroboration from outside benefiting parties supports the shifted-function reading.
narrative_ontology:disappearance_verdict(acceptable_risk_energy__option_value_preserving, world_rearranges).
narrative_ontology:founding_problem_status(acceptable_risk_energy__option_value_preserving, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(acceptable_risk_energy__option_value_preserving, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(acceptable_risk_energy__option_value_preserving, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(acceptable_risk_energy__option_value_preserving_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(acceptable_risk_energy__option_value_preserving, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, ExtMetricName, E),
    domain_priors:suppression_score(acceptable_risk_energy__option_value_preserving, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(acceptable_risk_energy__option_value_preserving),
    narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(acceptable_risk_energy__option_value_preserving_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is moderate-low (0.48 at interval end) because the reading's coordination function—preventing premature lock-in—has genuine decision-theoretic grounding, but extraction accumulates as empirical resolution of uncertainties (renewable scalability, storage costs) is not incorporated into policy and the framework increasingly protects incumbents from stranded-asset risk rather than society from commitment error. Suppression is moderate (0.52) because both aggressive renewable commitment and aggressive nuclear expansion are treated as imprudent within the framework's terms, but the suppression is intellectual rather than coercive—alternative risk readings remain articulable. Theater ratio rises (0.25→0.38) as option-value analyses are increasingly commissioned to justify predetermined conclusions about pathway maintenance rather than to genuinely inform decisions under uncertainty. Accessibility collapse is moderate-low (0.42) because alternative risk frameworks remain conceptually accessible—expected-value and tail-risk readings are live academic positions—but the option-value reading has achieved policy dominance. Resistance is moderate-high (0.58) because renewable advocates actively contest the framework and produce alternative analyses, but their resistance is channeled into academic debate rather than policy displacement.
 *
 * PERSPECTIVAL GAP:
 *   From the incumbent and flexibility-advocate seats, the constraint operates as genuine prudent risk management: keeping multiple pathways viable is rational insurance against model uncertainty and the alternative readings represent dangerous premature commitment. From the climate-timeline and renewable-advocate seats, the same structure operates as systematically biased delay: the framework treats uncertainties as symmetric when climate risks are asymmetric and treats fossil lock-in as reversible when it is not. The decision-theorist seat sees both the legitimate decision-theoretic core and the modeling choices (what counts as irreversible, how to weight tail risks, which uncertainties to emphasize) that bias outcomes toward incumbents. The engine computes these divergent seat classifications from the structural data; the authored mountain claim does not adjudicate between them.
 *
 * DIRECTIONALITY LOGIC:
 *   Incumbent energy producers and diversified investors are structural beneficiaries: the reading protects their portfolio value by treating continued operation as preserving options rather than as delaying transition. Energy flexibility advocates are agenda setters whose institutional role is protected by the framework's dominance. Climate mitigation timeline (non-agent) and renewable transition advocates are victims: they bear the costs of delay that the option-value reading systematically generates. Communities near fossil operations are localized victims bearing health externalities that the flexibility calculation externalizes. Nuclear industry is genuinely dual-positioned: benefits from existing-asset protection, pays when the same logic defers new builds. Grid reliability regulators are both agenda setters and beneficiaries: they set standards and the framework protects their institutional preference for dispatchable baseload.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint presents risk of mandatrophy: the founding problem (genuine deep uncertainty about energy pathways circa 2010) is increasingly resolved by empirical data on renewable scalability and climate trajectory, but the option-value framework persists and is increasingly invoked to protect incumbent assets rather than to navigate genuine uncertainty. The theater ratio trajectory and the contested founding_problem_status both signal this drift. However, the coordination function is not entirely vestigial—some genuine uncertainty about nuclear, storage, and grid transformation remains—so this is not yet full piton. The classification challenge is distinguishing rational prudence under remaining uncertainty from strategic invocation of resolved uncertainties to justify incumbent protection.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    uncertainty_resolution_incorporation,
    'As empirical uncertainties about renewable scalability, storage costs, and climate trajectory resolve over time, does the option-value framework incorporate this resolution into its policy recommendations, or does it treat uncertainty as a permanent feature justifying continued pathway maintenance?',
    'Longitudinal analysis of option-value studies: do the modeled uncertainty bounds narrow as empirical data accumulates, or do the studies continue to invoke the same uncertainty levels regardless of data? Natural experiment from jurisdictions that committed early to renewable transitions: if their outcomes match or exceed portfolio-maintenance jurisdictions, the uncertainty was overstated.',
    'If the framework fails to incorporate empirical resolution, it operates as incumbent protection rather than as genuine decision theory under uncertainty, and the mountain claim collapses to tangled_rope. If it does incorporate resolution and still recommends portfolio maintenance, the foundational claim is stronger.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(uncertainty_resolution_incorporation, empirical, 'Whether option-value framework updates on empirical uncertainty resolution').

omega_variable(
    irreversibility_asymmetry,
    'The framework treats premature closure of fossil and nuclear capacity as destroying irreversible option value. Is this irreversibility assessment symmetric—does continued fossil operation also destroy irreversible climate and ecological option value that cannot be recovered?',
    'Climate science consensus on path dependence and tipping points: if certain warming thresholds create irreversible changes, then fossil operation past those thresholds destroys options just as capacity closure does. Economic analysis of stranded renewable investment: if capital committed to fossil backup capacity crowds out renewable R&D, the opportunity cost may be irreversible.',
    'If irreversibility is asymmetric and the framework only models the closure direction, it systematically biases toward incumbents. This would reclassify from mountain to tangled_rope with identifiable extraction. If irreversibility is genuinely symmetric and the framework models both directions, the foundational claim strengthens.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(irreversibility_asymmetry, conceptual, 'Whether the framework''s irreversibility modeling is directionally symmetric').

omega_variable(
    genuine_vs_strategic_uncertainty_invocation,
    'When incumbent producers fund option-value analyses that recommend maintaining their assets, is the modeled uncertainty genuine decision-theoretic uncertainty, or is it strategically emphasized uncertainty selected to justify predetermined conclusions?',
    'Comparative analysis of uncertainty quantification: do independent academic option-value studies produce similar uncertainty bounds to industry-funded studies? Meta-analysis of which uncertainties are emphasized in policy-facing vs. academic-facing option-value work. Comparison to other domains: how does energy option-value modeling compare to real-options modeling in industries without the same incumbent-protection incentives?',
    'If uncertainty invocation is strategic rather than epistemic, the framework operates as legitimation machinery for extraction and the mountain claim is false. If the uncertainty modeling is robust across funding sources and comparable to other domains, the coordination function is genuine.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(genuine_vs_strategic_uncertainty_invocation, empirical, 'Whether uncertainty modeling is epistemically genuine or strategically motivated').

omega_variable(
    committer_frame_structural_invariance,
    'This constraint is one reading of the acceptable_risk_energy kernel. The three readings (catastrophic_tail_dominant, expected_value_dominant, option_value_preserving) produce different victim sets and different beneficiary structures from the same empirical evidence base. Is the choice among readings itself a structural fact about risk assessment, or does one reading more accurately capture the actual structure of energy risk?',
    'Cross-reading empirical test: do the different readings make distinguishable predictions about policy outcomes, and if so, which reading''s predictions are borne out by jurisdictions that have implemented its recommendations? Philosophical analysis: is risk assessment framework choice a matter of empirical fit, normative preference, or stakeholder position?',
    'If one reading demonstrably fits observed energy policy outcomes better than the others, the committer frame collapses to observer frame and the kernel is not genuinely contested—one reading is correct and the others are misreadings. If the readings remain empirically underdetermined even after policy experiments, the kernel is genuinely contested and the committer axis is load-bearing.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(committer_frame_structural_invariance, conceptual, 'Whether the kernel''s contested readings are empirically distinguishable').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(acceptable_risk_energy__option_value_preserving, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(acce_tr_t0, acceptable_risk_energy__option_value_preserving, theater_ratio, 0, 0.25).
narrative_ontology:measurement_basis(acce_tr_t0, observed).
narrative_ontology:measurement(acce_tr_t5, acceptable_risk_energy__option_value_preserving, theater_ratio, 5, 0.28).
narrative_ontology:measurement_basis(acce_tr_t5, observed).
narrative_ontology:measurement(acce_tr_t10, acceptable_risk_energy__option_value_preserving, theater_ratio, 10, 0.31).
narrative_ontology:measurement_basis(acce_tr_t10, observed).
narrative_ontology:measurement(acce_tr_t15, acceptable_risk_energy__option_value_preserving, theater_ratio, 15, 0.34).
narrative_ontology:measurement_basis(acce_tr_t15, observed).
narrative_ontology:measurement(acce_tr_t20, acceptable_risk_energy__option_value_preserving, theater_ratio, 20, 0.36).
narrative_ontology:measurement_basis(acce_tr_t20, observed).
narrative_ontology:measurement(acce_tr_t25, acceptable_risk_energy__option_value_preserving, theater_ratio, 25, 0.38).
narrative_ontology:measurement_basis(acce_tr_t25, observed).

% Extraction over time
narrative_ontology:measurement(acce_be_t0, acceptable_risk_energy__option_value_preserving, base_extractiveness, 0, 0.35).
narrative_ontology:measurement_basis(acce_be_t0, observed).
narrative_ontology:measurement(acce_be_t5, acceptable_risk_energy__option_value_preserving, base_extractiveness, 5, 0.38).
narrative_ontology:measurement_basis(acce_be_t5, observed).
narrative_ontology:measurement(acce_be_t10, acceptable_risk_energy__option_value_preserving, base_extractiveness, 10, 0.41).
narrative_ontology:measurement_basis(acce_be_t10, observed).
narrative_ontology:measurement(acce_be_t15, acceptable_risk_energy__option_value_preserving, base_extractiveness, 15, 0.44).
narrative_ontology:measurement_basis(acce_be_t15, observed).
narrative_ontology:measurement(acce_be_t20, acceptable_risk_energy__option_value_preserving, base_extractiveness, 20, 0.46).
narrative_ontology:measurement_basis(acce_be_t20, observed).
narrative_ontology:measurement(acce_be_t25, acceptable_risk_energy__option_value_preserving, base_extractiveness, 25, 0.48).
narrative_ontology:measurement_basis(acce_be_t25, observed).

% Suppression requirement over time
narrative_ontology:measurement(acce_su_t0, acceptable_risk_energy__option_value_preserving, suppression_requirement, 0, 0.42).
narrative_ontology:measurement_basis(acce_su_t0, observed).
narrative_ontology:measurement(acce_su_t5, acceptable_risk_energy__option_value_preserving, suppression_requirement, 5, 0.45).
narrative_ontology:measurement_basis(acce_su_t5, observed).
narrative_ontology:measurement(acce_su_t10, acceptable_risk_energy__option_value_preserving, suppression_requirement, 10, 0.47).
narrative_ontology:measurement_basis(acce_su_t10, observed).
narrative_ontology:measurement(acce_su_t15, acceptable_risk_energy__option_value_preserving, suppression_requirement, 15, 0.49).
narrative_ontology:measurement_basis(acce_su_t15, observed).
narrative_ontology:measurement(acce_su_t20, acceptable_risk_energy__option_value_preserving, suppression_requirement, 20, 0.51).
narrative_ontology:measurement_basis(acce_su_t20, observed).
narrative_ontology:measurement(acce_su_t25, acceptable_risk_energy__option_value_preserving, suppression_requirement, 25, 0.52).
narrative_ontology:measurement_basis(acce_su_t25, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(acceptable_risk_energy__option_value_preserving, identity_coordination).
narrative_ontology:boltzmann_floor_override(acceptable_risk_energy__option_value_preserving, 0.12).
narrative_ontology:affects_constraint(acceptable_risk_energy__option_value_preserving, acceptable_risk_energy__catastrophic_tail_dominant).
narrative_ontology:affects_constraint(acceptable_risk_energy__option_value_preserving, acceptable_risk_energy__expected_value_dominant).

% DUAL FORMULATION NOTE:
% This constraint is one of three readings of the acceptable_risk_energy kernel. The sibling readings (catastrophic_tail_dominant and expected_value_dominant) are separate constraint stories linked via network.affects_constraints. The option_value_preserving reading influences both siblings by occupying policy space: when flexibility preservation is the dominant reading, both tail-risk and expected-value arguments are treated as premature commitment and suppressed. The ε values differ substantially across readings because the beneficiary and victim sets change—expected_value optimization produces different transfers than tail-risk avoidance or option preservation.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
