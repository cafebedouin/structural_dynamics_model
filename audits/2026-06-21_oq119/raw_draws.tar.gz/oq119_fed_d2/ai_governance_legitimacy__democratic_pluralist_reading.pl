% ============================================================================
% CONSTRAINT STORY: ai_governance_legitimacy__democratic_pluralist_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-01-15
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_ai_governance_legitimacy__democratic_pluralist_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    constraint_indexing:directionality_override/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: ai_governance_legitimacy__democratic_pluralist_reading
 *   human_readable: Democratic Pluralist AI Governance Legitimacy
 *   domain: political_theology/technology_governance
 *
 * SUMMARY:
 *   This constraint instantiates the democratic pluralist reading of AI
 *   governance legitimacy: authority derives from inclusive deliberation and
 *   consent rather than from technocratic expertise or religious doctrine.
 *   The encyclical's dignity framework contributes one voice among many but
 *   holds no interpretive monopoly. Legitimacy requires transparent political
 *   processes that balance diverse values through public reason. The
 *   constraint is CLAIMED as mountain (a natural feature of pluralist
 *   political order) while the metrics describe moderate extraction (0.38)
 *   and suppression (0.42) as deliberative processes impose costs on excluded
 *   populations and concentrate benefits on organized civil society. The
 *   claim/metric divergence is deliberate and measured by design.
 *
 * KEY AGENTS:
 *   - civil_society_organizations: Primary beneficiary (organized/mobile) — gain structural authority in deliberative processes
 *   - democratic_institutions: Agenda setter (institutional/constrained) — administer deliberative mechanisms, face capture pressure
 *   - minority_rights_holders: Beneficiary (moderate/constrained) — protected by inclusive public reason requirements
 *   - excluded_populations: Payer (powerless/trapped) — bear costs when deliberation fails to include them
 *   - authoritarian_regime_subjects: Payer (powerless/trapped) — experience rhetoric without protection
 *   - magisterial_institutions: Excluded (institutional/mobile) — one voice among many, denied unique authority
 *   - technocratic_elites: Excluded (powerful/arbitrage) — subordinated to democratic oversight, resist through capture
 *   - political_theorists: Observer (analytical) — measure gap between procedural ideals and institutional reality
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(ai_governance_legitimacy__democratic_pluralist_reading, 0.38).
domain_priors:suppression_score(ai_governance_legitimacy__democratic_pluralist_reading, 0.42).
domain_priors:theater_ratio(ai_governance_legitimacy__democratic_pluralist_reading, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, extractiveness, 0.38).
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 0.42).
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, accessibility_collapse, 0.35).
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, resistance, 0.55).

% --- Constraint claim ---
narrative_ontology:constraint_claim(ai_governance_legitimacy__democratic_pluralist_reading, mountain).
narrative_ontology:human_readable(ai_governance_legitimacy__democratic_pluralist_reading, "Democratic Pluralist AI Governance Legitimacy").
narrative_ontology:topic_domain(ai_governance_legitimacy__democratic_pluralist_reading, "political_theology/technology_governance").

domain_priors:requires_active_enforcement(ai_governance_legitimacy__democratic_pluralist_reading).
domain_priors:emerges_naturally(ai_governance_legitimacy__democratic_pluralist_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(ai_governance_legitimacy__democratic_pluralist_reading, 'e703a8a7-26e6-4349-90c5-fdd50bac8a91').
narrative_ontology:cs_kernel_codification('e703a8a7-26e6-4349-90c5-fdd50bac8a91', distributed).
narrative_ontology:cs_authority_grounding('e703a8a7-26e6-4349-90c5-fdd50bac8a91', practice).
narrative_ontology:cs_interpretation_layer_present('e703a8a7-26e6-4349-90c5-fdd50bac8a91').
narrative_ontology:cs_reading_relation('e703a8a7-26e6-4349-90c5-fdd50bac8a91', ai_governance_legitimacy__magisterial_subsidiarity_reading, coexists_with).
narrative_ontology:cs_reading_relation('e703a8a7-26e6-4349-90c5-fdd50bac8a91', ai_governance_legitimacy__technocratic_optimization_reading, influences).
narrative_ontology:cs_reading_relation('e703a8a7-26e6-4349-90c5-fdd50bac8a91', ai_governance_legitimacy__market_libertarian_reading, coexists_with).
narrative_ontology:cs_axiom('e703a8a7-26e6-4349-90c5-fdd50bac8a91', foundational, no_interpretive_monopoly_permissible).
narrative_ontology:cs_axiom_status(no_interpretive_monopoly_permissible, holdable).
narrative_ontology:cs_axiom_grounding('e703a8a7-26e6-4349-90c5-fdd50bac8a91', no_interpretive_monopoly_permissible, deontological).
narrative_ontology:cs_axiom('e703a8a7-26e6-4349-90c5-fdd50bac8a91', foundational, consent_grounds_legitimate_authority).
narrative_ontology:cs_axiom_status(consent_grounds_legitimate_authority, holdable).
narrative_ontology:cs_axiom_grounding('e703a8a7-26e6-4349-90c5-fdd50bac8a91', consent_grounds_legitimate_authority, conventional).
narrative_ontology:cs_axiom('e703a8a7-26e6-4349-90c5-fdd50bac8a91', secondary, inclusive_deliberation_aggregates_values).
narrative_ontology:cs_axiom_status(inclusive_deliberation_aggregates_values, holdable).
narrative_ontology:cs_axiom_grounding('e703a8a7-26e6-4349-90c5-fdd50bac8a91', inclusive_deliberation_aggregates_values, empirically_contingent).
narrative_ontology:cs_reference_frame('e703a8a7-26e6-4349-90c5-fdd50bac8a91', postwar_pluralist_democratic_settlement).
narrative_ontology:cs_drift_state('e703a8a7-26e6-4349-90c5-fdd50bac8a91', contemporary_regulatory_capture_era, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('e703a8a7-26e6-4349-90c5-fdd50bac8a91', '').
narrative_ontology:cs_kernel_id(ai_governance_legitimacy__democratic_pluralist_reading, ai_governance_legitimacy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__democratic_pluralist_reading, civil_society_organizations).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__democratic_pluralist_reading, democratic_institutions).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__democratic_pluralist_reading, minority_rights_holders).
narrative_ontology:constraint_victim(ai_governance_legitimacy__democratic_pluralist_reading, excluded_populations).
narrative_ontology:constraint_victim(ai_governance_legitimacy__democratic_pluralist_reading, authoritarian_regime_subjects).
narrative_ontology:constraint_vindicates(ai_governance_legitimacy__democratic_pluralist_reading, democratic_legitimacy_doctrine).
narrative_ontology:constraint_vindicates(ai_governance_legitimacy__democratic_pluralist_reading, procedural_justice_principle).
narrative_ontology:constraint_vindicates(ai_governance_legitimacy__democratic_pluralist_reading, epistemic_humility_norm).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Participate in deliberative governance frameworks as recognized voices representing diverse constituencies. Gain structural authority to contest technocratic or religious monopolies over AI ethics. Their legitimacy depends on maintaining inclusive participation and transparent processes; their influence scales with the constraint's institutionalization.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, civil_society_organizations, beneficiary,
    organized, generational, mobile, global).

% Administer the deliberative processes and electoral accountability mechanisms that ground AI governance legitimacy under this reading. They benefit from enhanced scope as arbiters of contested values, but their authority is conditional on maintaining procedural fairness and responsiveness. They face persistent pressure from technocratic capture and authoritarian challenge.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, democratic_institutions, agenda_setter,
    institutional, generational, constrained, national).
narrative_ontology:stakeholder_secondary_role(ai_governance_legitimacy__democratic_pluralist_reading, democratic_institutions, beneficiary).

% Gain structural protection through inclusive public reason requirements that prevent majoritarian or technocratic override of their dignity claims. Their participation in deliberative processes is what validates governance outcomes under this reading. Exit is geographic or withdrawal from civic participation; both carry substantial costs.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, minority_rights_holders, beneficiary,
    moderate, biographical, constrained, national).

% Bear costs when deliberative processes fail to include them or when democratic institutions lack capacity to enforce agreed principles. They experience the constraint as aspirational language that does not translate into protection. Their absence from decision-making is the failure mode this reading nominally guards against but structurally permits.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, excluded_populations, payer,
    powerless, biographical, trapped, regional).

% Live under AI governance systems that invoke democratic legitimacy rhetoric while excluding meaningful consent. The constraint's global scope norm does not reach them; enforcement mechanisms terminate at national borders. They pay the full cost of AI deployment without access to the deliberative protections the constraint promises.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, authoritarian_regime_subjects, payer,
    powerless, biographical, trapped, national).

% Contribute moral frameworks and dignity claims to public deliberation but are denied unique interpretive authority under this reading. They operate as one voice among many rather than as authoritative teachers. Their influence depends on persuasion in pluralist forums rather than doctrinal assertion.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, magisterial_institutions, excluded,
    institutional, civilizational, mobile, global).

% Possess technical expertise in AI development and deployment but are structurally subordinated to democratic oversight under this reading. They resist the constraint through regulatory capture, complexity arguments, and jurisdictional arbitrage. They frame democratic governance as inefficient drag on innovation.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, technocratic_elites, excluded,
    powerful, biographical, arbitrage, global).

% Analyze whether deliberative processes genuinely produce consent or merely formalize elite preferences under democratic cover. They document the gap between procedural ideals and institutional reality, measure inclusion failures, and identify conditions under which the constraint's coordination function collapses into extraction.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, political_theorists, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Coordinates diverse moral traditions and technical communities around AI governance through inclusive deliberation that no single authority monopolizes. Prevents both technocratic override and religious imposition by requiring transparent justification to pluralist publics.
% TRANSFER_FUNCTION: Transfers governance authority from technocratic elites and religious institutions to democratic processes and civil society; transfers decision-making power from expert monopoly to inclusive public reason; imposes deliberative costs on all participants while concentrating protection benefits on those whose inclusion is structurally enforced.
% ABSENT_VOICES: Populations in authoritarian regimes and structurally excluded communities lack meaningful participation in the deliberative processes that ground legitimacy claims. They would contest the universality of democratic consent when their own consent is neither sought nor enforceable. Their absence is geographic and political rather than conceptual.
% DISAPPEARANCE_RATIONALE: If the constraint vanished overnight, AI governance legitimacy would fragment among competing authorities: technocratic bodies would claim expertise-based mandate, religious institutions would assert doctrinal authority, market actors would invoke consumer sovereignty, and authoritarian states would deploy AI without external constraint. The deliberative infrastructure and civil society organizations structurally positioned by this reading would lose their coordinating function.
% FOUNDING_PROBLEM: Mid-20th century emergence of technology governance questions in pluralist democracies where neither religious tradition nor technocratic expertise commanded universal authority. How to legitimate collective decisions about powerful technologies when citizens hold incommensurable values and no single institution can claim interpretive monopoly.
% FOUNDING_PROBLEM_CORROBORATION: Political theorists across multiple traditions attest the legitimacy problem remains unresolved. The proliferation of AI ethics frameworks with competing foundations and the persistent contestation over governance authority in international forums demonstrates the problem's live status. Independent of whether democratic institutions successfully solve it, no alternative authority has achieved stable recognition.
narrative_ontology:disappearance_verdict(ai_governance_legitimacy__democratic_pluralist_reading, world_rearranges).
narrative_ontology:founding_problem_status(ai_governance_legitimacy__democratic_pluralist_reading, live).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(ai_governance_legitimacy__democratic_pluralist_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(ai_governance_legitimacy__democratic_pluralist_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(ai_governance_legitimacy__democratic_pluralist_reading_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, ExtMetricName, E),
    domain_priors:suppression_score(ai_governance_legitimacy__democratic_pluralist_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(ai_governance_legitimacy__democratic_pluralist_reading),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(ai_governance_legitimacy__democratic_pluralist_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction (0.38) is moderate because deliberative processes impose real costs on participants and systematically exclude populations without access to democratic institutions, while concentrating governance authority and protection benefits on organized civil society. Suppression (0.42) tracks enforcement mechanisms that prevent technocratic or religious override but also suppress alternative authority claims from expertise-based or doctrinal traditions. Theater ratio (0.28) reflects growing gap between inclusive deliberation rhetoric and actual participation rates, especially in captured regulatory processes. Accessibility collapse (0.35) is modest because alternative governance frameworks remain conceptually available. Resistance (0.55) is substantial from both technocratic elites and religious institutions denied monopoly status, plus from excluded populations experiencing legitimacy rhetoric without protection.
 *
 * PERSPECTIVAL GAP:
 *   From the agenda-setter seat (democratic institutions), this constraint is coordination infrastructure solving legitimacy contests in pluralist societies. From organized civil society, it is beneficial expansion of participation rights. From excluded populations, the same structure operates as extraction dressed in democratic language: they experience governance rhetoric that does not translate into protection, pay costs of exclusion while others capture benefits, and lack the power to enforce their nominal inclusion. From technocratic elites, it is illegitimate suppression of expertise-based authority. The engine computes these divergent classifications from the power/exit/benefit/victim structural data; the mountain claim is assessed independently against the metrics.
 *
 * DIRECTIONALITY LOGIC:
 *   Democratic institutions and civil society organizations are structural beneficiaries (d near 0.2–0.3): they gain authority to coordinate AI governance and their organizational legitimacy scales with the constraint's institutionalization. Minority rights holders sit near symmetric (d ~0.4): genuine protection benefit when included, but inclusion costs and the constraint's failure modes impose real burdens. Excluded populations and authoritarian regime subjects are full targets (d near 0.9): they bear deliberation's costs without access to its protections, experience rhetoric without enforcement, and have no exit. Magisterial institutions and technocratic elites are structurally excluded (d ~0.7): they lose interpretive monopoly and are subordinated to pluralist processes, though mobile exit options moderate their exposure.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint's founding problem (legitimating technology governance in pluralist democracies without monopoly authority) remains live, but the institutional response exhibits drift: deliberative processes increasingly formalize elite preferences under democratic cover rather than genuinely aggregating diverse values. Rising theater ratio documents this gap. The mismatch between live founding problem and growing performance orientation suggests the coordination function persists while extraction accumulates around civil society gatekeeping and regulatory capture. This is measured drift within a live mandate, not mandatrophy.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    democratic_legitimacy_naturalization,
    'Is democratic legitimacy a natural feature of political order (mountain) or a constructed coordination mechanism with identifiable beneficiaries (rope/tangled_rope)?',
    'Historical analysis of whether pluralist legitimacy norms emerge independently across diverse political contexts or require institutional construction and maintenance. Comparative study of legitimacy crises in democracies versus other regime types. Assessment of whether organized civil society''s structural position is consequence of natural political dynamics or product of specific institutional design.',
    'If mountain, the constraint''s moderate extraction is inherent coordination cost. If constructed, the extraction flows to civil society organizations and democratic institutions as designed beneficiaries, and the mountain claim functions as false summit rhetoric obscuring the beneficiary structure.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(democratic_legitimacy_naturalization, conceptual, 'Whether democratic legitimacy is natural political fact or constructed arrangement benefiting specific institutional actors').

omega_variable(
    inclusive_deliberation_sufficiency,
    'Do inclusive deliberative processes genuinely produce consent, or do they formalize pre-existing power distributions under democratic cover?',
    'Longitudinal tracking of policy outcomes from deliberative processes versus pre-deliberation elite preferences. Measurement of correlation between participation breadth and outcome variance. Analysis of whether deliberative mechanisms change distributions of benefits or merely legitimate predetermined allocations.',
    'If deliberation genuinely aggregates diverse values, the constraint''s coordination function is real and extraction is bounded. If deliberation formalizes elite preferences, the constraint operates as extraction mechanism dressed in procedural legitimacy language, and victims are systematically produced rather than accidentally excluded.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(inclusive_deliberation_sufficiency, empirical, 'Whether deliberative processes genuinely coordinate or merely formalize elite capture').

omega_variable(
    geographic_scope_enforcement_gap,
    'Can a constraint claiming universal legitimacy requirements remain mountain-type when its enforcement terminates at national borders?',
    'Analysis of whether authoritarian regimes'' exclusion from deliberative processes is contingent feature or structural necessity. Assessment of whether international governance coordination mechanisms could extend democratic legitimacy requirements globally, or whether national sovereignty inherently limits the constraint''s scope.',
    'If enforcement gap is contingent, the constraint''s victims are temporarily excluded and the mountain claim can be maintained. If structural, authoritarian regime subjects are permanent victims of a coordination mechanism that benefits organized actors in democracies, and the universal legitimacy claim is false.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(geographic_scope_enforcement_gap, conceptual, 'Whether deliberative legitimacy requirements can be structurally universal or necessarily exclude populations under authoritarian governance').

omega_variable(
    committer_frame_pluralism_boundary,
    'This is one reading of a contested kernel about AI governance legitimacy. Does pluralist democracy itself privilege this reading by design, making the contest structurally asymmetric?',
    'Analysis of whether democratic institutions systematically advantage procedural legitimacy claims over substantive authority claims (religious or technocratic). Examination of whether ''one voice among many'' framing structurally subordinates traditions claiming unique interpretive authority. Assessment of whether the kernel contest occurs on neutral ground or within institutional frameworks that pre-adjudicate the outcome.',
    'If the contest is structurally symmetric, this reading competes fairly with siblings and the constraint''s coordination function is genuine. If democratic institutional context privileges procedural over substantive authority, this reading benefits from background conditions it does not acknowledge, and the sibling readings face suppression dressed as neutral pluralism.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(committer_frame_pluralism_boundary, conceptual, 'Whether the institutional context of the kernel contest privileges procedural legitimacy readings over substantive authority readings').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(ai_governance_legitimacy__democratic_pluralist_reading, 0, 30).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(ai_g_tr_t0, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 0, 0.2).
narrative_ontology:measurement_basis(ai_g_tr_t0, observed).
narrative_ontology:measurement(ai_g_tr_t6, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 6, 0.22).
narrative_ontology:measurement_basis(ai_g_tr_t6, observed).
narrative_ontology:measurement(ai_g_tr_t12, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 12, 0.24).
narrative_ontology:measurement_basis(ai_g_tr_t12, observed).
narrative_ontology:measurement(ai_g_tr_t18, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 18, 0.26).
narrative_ontology:measurement_basis(ai_g_tr_t18, observed).
narrative_ontology:measurement(ai_g_tr_t24, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 24, 0.27).
narrative_ontology:measurement_basis(ai_g_tr_t24, observed).
narrative_ontology:measurement(ai_g_tr_t30, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 30, 0.28).
narrative_ontology:measurement_basis(ai_g_tr_t30, observed).

% Extraction over time
narrative_ontology:measurement(ai_g_be_t0, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 0, 0.3).
narrative_ontology:measurement_basis(ai_g_be_t0, observed).
narrative_ontology:measurement(ai_g_be_t6, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 6, 0.32).
narrative_ontology:measurement_basis(ai_g_be_t6, observed).
narrative_ontology:measurement(ai_g_be_t12, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 12, 0.35).
narrative_ontology:measurement_basis(ai_g_be_t12, observed).
narrative_ontology:measurement(ai_g_be_t18, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 18, 0.37).
narrative_ontology:measurement_basis(ai_g_be_t18, observed).
narrative_ontology:measurement(ai_g_be_t24, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 24, 0.38).
narrative_ontology:measurement_basis(ai_g_be_t24, observed).
narrative_ontology:measurement(ai_g_be_t30, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 30, 0.38).
narrative_ontology:measurement_basis(ai_g_be_t30, observed).

% Suppression requirement over time
narrative_ontology:measurement(ai_g_su_t0, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 0, 0.35).
narrative_ontology:measurement_basis(ai_g_su_t0, observed).
narrative_ontology:measurement(ai_g_su_t6, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 6, 0.37).
narrative_ontology:measurement_basis(ai_g_su_t6, observed).
narrative_ontology:measurement(ai_g_su_t12, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 12, 0.39).
narrative_ontology:measurement_basis(ai_g_su_t12, observed).
narrative_ontology:measurement(ai_g_su_t18, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 18, 0.4).
narrative_ontology:measurement_basis(ai_g_su_t18, observed).
narrative_ontology:measurement(ai_g_su_t24, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 24, 0.41).
narrative_ontology:measurement_basis(ai_g_su_t24, observed).
narrative_ontology:measurement(ai_g_su_t30, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 30, 0.42).
narrative_ontology:measurement_basis(ai_g_su_t30, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(ai_governance_legitimacy__democratic_pluralist_reading, identity_coordination).
narrative_ontology:boltzmann_floor_override(ai_governance_legitimacy__democratic_pluralist_reading, 0.12).
narrative_ontology:affects_constraint(ai_governance_legitimacy__democratic_pluralist_reading, ai_governance_legitimacy__magisterial_subsidiarity_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__democratic_pluralist_reading, ai_governance_legitimacy__technocratic_optimization_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__democratic_pluralist_reading, ai_governance_legitimacy__market_libertarian_reading).

% DUAL FORMULATION NOTE:
% This constraint is the democratic_pluralist_reading within the ai_governance_legitimacy kernel family. The natural-language concept 'AI governance legitimacy' decomposes into four distinct readings with different beneficiary structures, enforcement mechanisms, and extraction profiles. This reading grounds authority in democratic consent; magisterial_subsidiarity_reading grounds it in Catholic Social Doctrine; technocratic_optimization_reading grounds it in expertise and aggregate welfare; market_libertarian_reading grounds it in voluntary exchange. Each reading is a separate constraint with stable ε within its own frame.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

constraint_indexing:directionality_override(ai_governance_legitimacy__democratic_pluralist_reading, institutional, 0.25).
constraint_indexing:directionality_override(ai_governance_legitimacy__democratic_pluralist_reading, organized, 0.3).

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
