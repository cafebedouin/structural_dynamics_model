% ============================================================================
% CONSTRAINT STORY: westphalia_sovereignty__absolute_non_intervention
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-01-15
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_westphalia_sovereignty__absolute_non_intervention, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: westphalia_sovereignty__absolute_non_intervention
 *   human_readable: Westphalian Sovereignty — Absolute Non-Intervention Reading
 *   domain: international_law/political_theory
 *
 * SUMMARY:
 *   The Westphalian sovereignty system grounds interstate relations in
 *   categorical territorial inviolability: what happens within state borders
 *   is that state's exclusive domain, and external interference is per se
 *   illegitimate regardless of internal conduct. This reading—the absolute
 *   non-intervention interpretation—is presented by its advocates as
 *   foundational natural law, the necessary condition for a stable interstate
 *   order. The claim/metric gap is deliberate: the constraint is CLAIMED as
 *   mountain (sovereignty doctrine's own framing) while the authored metrics
 *   describe substantially extractive operation with identifiable
 *   beneficiaries and victims—the engine measures that divergence; do not
 *   reconcile the claim to the metrics. The absolute reading is one of three
 *   live interpretations of the sovereignty kernel; it competes with
 *   conditional-responsibility readings that permit intervention during mass
 *   atrocities, and with graded-sovereignty readings that calibrate authority
 *   to state capacity.
 *
 * KEY AGENTS:
 *   - state_elites_authoritarian_regimes: Primary beneficiary (institutional/arbitrage) — collect immunity from external accountability
 *   - sovereignty_doctrine_advocates: Agenda-setter (institutional/analytical) — maintain and transmit the absolute reading
 *   - populations_under_authoritarian_control: Primary victim (powerless/trapped) — bear the cost of immunity that shields their oppressors
 *   - stateless_populations: Victim (powerless/trapped) — excluded from the sovereignty system itself
 *   - genocide_survivors_advocacy_networks: Excluded (organized/constrained) — petition for conditional sovereignty but remain external to state-to-state system
 *   - humanitarian_intervention_coalitions: Excluded (institutional/constrained) — operate under contested authority when acting
 *   - international_law_scholars_critical_tradition: Analytical observer (analytical/analytical) — document sovereignty as contingent construction
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(westphalia_sovereignty__absolute_non_intervention, 0.68).
domain_priors:suppression_score(westphalia_sovereignty__absolute_non_intervention, 0.79).
domain_priors:theater_ratio(westphalia_sovereignty__absolute_non_intervention, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, extractiveness, 0.68).
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 0.79).
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, accessibility_collapse, 0.71).
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, resistance, 0.58).

% --- Constraint claim ---
narrative_ontology:constraint_claim(westphalia_sovereignty__absolute_non_intervention, mountain).
narrative_ontology:human_readable(westphalia_sovereignty__absolute_non_intervention, "Westphalian Sovereignty — Absolute Non-Intervention Reading").
narrative_ontology:topic_domain(westphalia_sovereignty__absolute_non_intervention, "international_law/political_theory").

domain_priors:requires_active_enforcement(westphalia_sovereignty__absolute_non_intervention).
domain_priors:emerges_naturally(westphalia_sovereignty__absolute_non_intervention).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(westphalia_sovereignty__absolute_non_intervention, '46455b69-46a7-4a01-b1be-5de62fd3be69').
narrative_ontology:cs_kernel_codification('46455b69-46a7-4a01-b1be-5de62fd3be69', formalized).
narrative_ontology:cs_authority_grounding('46455b69-46a7-4a01-b1be-5de62fd3be69', lineage).
narrative_ontology:cs_interpretation_layer_present('46455b69-46a7-4a01-b1be-5de62fd3be69').
narrative_ontology:cs_reading_relation('46455b69-46a7-4a01-b1be-5de62fd3be69', westphalia_sovereignty__conditional_responsibility, coexists_with).
narrative_ontology:cs_reading_relation('46455b69-46a7-4a01-b1be-5de62fd3be69', westphalia_sovereignty__graded_sovereignty, coexists_with).
narrative_ontology:cs_axiom('46455b69-46a7-4a01-b1be-5de62fd3be69', foundational, territorial_inviolability_categorical).
narrative_ontology:cs_axiom_status(territorial_inviolability_categorical, holdable).
narrative_ontology:cs_axiom_grounding('46455b69-46a7-4a01-b1be-5de62fd3be69', territorial_inviolability_categorical, conventional).
narrative_ontology:cs_axiom('46455b69-46a7-4a01-b1be-5de62fd3be69', foundational, internal_conduct_irrelevant_to_external_legitimacy).
narrative_ontology:cs_axiom_status(internal_conduct_irrelevant_to_external_legitimacy, holdable).
narrative_ontology:cs_axiom_grounding('46455b69-46a7-4a01-b1be-5de62fd3be69', internal_conduct_irrelevant_to_external_legitimacy, deontological).
narrative_ontology:cs_reference_frame('46455b69-46a7-4a01-b1be-5de62fd3be69', westphalian_treaty_settlement).
narrative_ontology:cs_drift_state('46455b69-46a7-4a01-b1be-5de62fd3be69', post_genocide_convention_era, gap(authority_erosion, substantial, false)).
narrative_ontology:cs_created_at('46455b69-46a7-4a01-b1be-5de62fd3be69', '').
narrative_ontology:cs_kernel_id(westphalia_sovereignty__absolute_non_intervention, westphalia_sovereignty).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__absolute_non_intervention, state_elites_authoritarian_regimes).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__absolute_non_intervention, sovereignty_doctrine_advocates).
narrative_ontology:constraint_victim(westphalia_sovereignty__absolute_non_intervention, populations_under_authoritarian_control).
narrative_ontology:constraint_victim(westphalia_sovereignty__absolute_non_intervention, stateless_populations).
narrative_ontology:constraint_victim(westphalia_sovereignty__absolute_non_intervention, genocide_survivors_advocacy_networks).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__absolute_non_intervention, territorial_integrity_as_foundational_principle).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__absolute_non_intervention, domestic_jurisdiction_doctrine).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Control national territory and claim categorical immunity from external scrutiny regardless of internal conduct. Invoke the sovereignty principle to block international investigations, humanitarian intervention, and human rights enforcement. Frame any external pressure as colonial interference. Collect the benefit of territorial monopoly without accountability constraint.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, state_elites_authoritarian_regimes, beneficiary,
    institutional, generational, arbitrage, national).

% Academic international lawyers, diplomatic historians, and postcolonial theorists who ground the interstate system in categorical non-intervention. Maintain that sovereignty's foundational status requires absolute protection—any conditional reading opens the door to abuse. Argue that the principle's universality depends on refusing all exception clauses.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, sovereignty_doctrine_advocates, agenda_setter,
    institutional, civilizational, analytical, global).

% Live under regimes that commit systematic human rights violations while invoking sovereignty to prevent external rescue. Their appeals for protection are categorized as internal matters; the international system treats their suffering as the domestic prerogative of their government. Exit requires fleeing the territory, which the regime typically blocks.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, populations_under_authoritarian_control, payer,
    powerless, biographical, trapped, national).

% Exist between state jurisdictions without the protection of any sovereignty claim. The absolute reading treats them as residual: no state's responsibility, no basis for intervention. Their structural exclusion from the sovereignty system itself is what makes them vulnerable, yet the system offers no remedy because remedy would require admitting state failure.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, stateless_populations, payer,
    powerless, generational, trapped, regional).

% Document atrocities and petition for international response. Under the absolute reading, their evidence is acknowledged but categorized as insufficient to override sovereignty—mass killing within borders remains a domestic matter. They lobby for conditional sovereignty frameworks but are structurally external to the state-to-state system that holds the absolute reading in place.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, genocide_survivors_advocacy_networks, excluded,
    organized, generational, constrained, global).

% States and international bodies prepared to intervene on humanitarian grounds. The absolute reading treats any such intervention as aggression regardless of motive. Their legitimacy claims are rejected in principle: internal conduct cannot license external action. They operate under contested legal authority, risking their own standing by acting.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, humanitarian_intervention_coalitions, excluded,
    institutional, biographical, constrained, global).

% Analyze sovereignty as a historically contingent political arrangement rather than natural law. Document how the absolute reading was constructed in specific treaty contexts and has shifted over time. Argue that treating it as categorical forecloses evolution the system demonstrably underwent—yet their revisionist histories do not displace the doctrine's hold on state practice.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, international_law_scholars_critical_tradition, observer,
    analytical, civilizational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes predictable territorial boundaries and prevents interstate conflict by making internal affairs categorically off-limits to external actors, reducing the risk of sovereignty disputes escalating into war.
% TRANSFER_FUNCTION: Grants state elites immunity from external accountability for internal conduct, transferring the cost of that immunity onto populations under authoritarian control who cannot appeal beyond their government.
% ABSENT_VOICES: Genocide survivors, stateless populations, and humanitarian coalitions are structurally excluded—they would argue for conditional sovereignty that permits intervention during mass atrocities, but the state-centric system categorizes their claims as illegitimate interference.
% DISAPPEARANCE_RATIONALE: If the absolute reading vanished overnight, humanitarian coalitions would intervene in ongoing atrocities within months, authoritarian regimes would lose their immunity shield, and the interstate system would reorganize around conditional sovereignty norms where internal conduct affects external legitimacy.
% FOUNDING_PROBLEM: The Thirty Years' War demonstrated that religious and territorial disputes without a fixed boundary principle produce indefinite conflict; the absolute sovereignty reading was constructed to end perpetual intervention by establishing categorical territorial inviolability.
% FOUNDING_PROBLEM_CORROBORATION: Sovereignty advocates attest the founding problem remains live, citing ongoing great-power rivalry and the risk of intervention pretexts. Critical international law scholars, genocide studies researchers, and human rights organizations attest that the foundational war-prevention function has shifted: modern interstate conflict rarely stems from sovereignty disputes, while the absolute reading now primarily shields authoritarian regimes from accountability. Historical treaty analysis and comparative atrocity-response data from outside the benefiting state elites support the shifted-function reading.
narrative_ontology:disappearance_verdict(westphalia_sovereignty__absolute_non_intervention, world_rearranges).
narrative_ontology:founding_problem_status(westphalia_sovereignty__absolute_non_intervention, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(westphalia_sovereignty__absolute_non_intervention, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(westphalia_sovereignty__absolute_non_intervention, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(westphalia_sovereignty__absolute_non_intervention_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(westphalia_sovereignty__absolute_non_intervention, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, ExtMetricName, E),
    domain_priors:suppression_score(westphalia_sovereignty__absolute_non_intervention, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(westphalia_sovereignty__absolute_non_intervention),
    narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(westphalia_sovereignty__absolute_non_intervention_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is substantial (0.68 at interval end) because the absolute reading grants immunity to state elites regardless of internal conduct, transferring the cost of that immunity onto populations under authoritarian control who have no recourse. The extraction has accumulated over the interval as the founding war-prevention function atrophied while the immunity shield for authoritarian regimes strengthened. Suppression is high (0.79) because the reading's persistence depends on actively excluding humanitarian intervention and categorizing internal atrocities as outside the scope of international concern—populations under authoritarian control are trapped by definition. Theater ratio is moderate (0.42): sovereignty doctrine continues to coordinate legitimate state boundaries, but a growing share of sovereignty invocations now defend regime immunity rather than prevent interstate conflict. Accessibility collapse is high (0.71) because once the absolute reading is adopted, alternative frameworks (conditional sovereignty, graded authority) are categorized as destabilizing—the system treats them as incoherent. Resistance is substantial (0.58) because genocide survivors, human rights networks, and revisionist scholars actively contest the absolute reading, yet it persists through institutional inertia and the beneficiaries' defense. The measurement series runs on one shared time grid; every metric is authored at every examined time point.
 *
 * PERSPECTIVAL GAP:
 *   The victim seats and the beneficiary/agenda-setter seats should compute differently: from the position of state elites and sovereignty doctrine advocates, the absolute reading is a foundational principle necessary for interstate stability—natural law. From the position of populations under authoritarian control, the same structure operates as enforced extraction that shields their oppressors from accountability. The engine computes this divergence from the structural data—the authored claim does not adjudicate it.
 *
 * DIRECTIONALITY LOGIC:
 *   State elites in authoritarian regimes are the structural beneficiaries (collect immunity, control the territorial monopoly—d near the beneficiary end). Sovereignty doctrine advocates are agenda-setters who maintain the reading but are analytically positioned rather than extractively positioned. Populations under authoritarian control and stateless populations are the primary victims (bear the cost of immunity that shields their oppressors, trapped exit—d near the target end). Humanitarian coalitions and genocide survivors are excluded rather than coordinated—their exclusion is the enforcement object itself. The critical scholars' seat is analytical.
 *
 * MANDATROPHY ANALYSIS:
 *   The absolute sovereignty reading is a candidate for mandatrophy: its founding mandate was to prevent interstate war by establishing categorical territorial boundaries (Thirty Years' War resolution), but modern interstate conflict rarely stems from sovereignty disputes. The reading now primarily functions to shield authoritarian regimes from external accountability—a different function than the one that justified its construction. The R5 genealogy interview records this: founding problem contested, corroboration split between sovereignty advocates (who attest the war-prevention function is still live) and critical scholars plus human rights networks (who attest the function has shifted to regime immunity). The disappearance verdict is world_rearranges because authoritarian elites depend on the immunity the reading provides; if it vanished, humanitarian intervention would reorganize around conditional sovereignty norms within months.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    natural_law_vs_constructed_immunity,
    'Is categorical territorial inviolability a necessary feature of any stable interstate system (natural law), or is it a historically contingent political arrangement that benefits specific actors (constructed constraint)?',
    'Comparative analysis of interstate systems that operated under conditional sovereignty norms (post-WWII human rights regime, Responsibility to Protect doctrine where adopted) versus absolute sovereignty norms. If stable interstate relations obtain under conditional readings, the absolute reading is not structurally necessary.',
    'If natural law, the constraint is a genuine mountain and the measured extraction is an unavoidable cost of interstate stability. If constructed, the constraint is a false summit: sovereignty doctrine advocates and authoritarian state elites benefit from treating a contingent arrangement as foundational, and the measured extraction is rent collection rather than coordination cost.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(natural_law_vs_constructed_immunity, empirical, 'Whether absolute sovereignty is natural law or constructed to benefit authoritarian regimes.').

omega_variable(
    founding_function_vs_current_function,
    'Does the absolute reading still primarily prevent interstate war (its founding function), or does it now primarily shield authoritarian regimes from accountability (a shifted function)?',
    'Longitudinal analysis of sovereignty invocations: coding each invocation by whether it defended against interstate aggression or blocked humanitarian intervention. If the majority of contemporary invocations block accountability rather than prevent war, the function has shifted.',
    'If the founding function is live, the constraint remains coordination with unavoidable extraction. If the function has shifted, the constraint exhibits mandatrophy: the founding mandate is dead but the structure persists because beneficiaries (authoritarian elites) capture its operation.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(founding_function_vs_current_function, empirical, 'Whether sovereignty''s war-prevention function or immunity-shield function is dominant.').

omega_variable(
    sibling_reading_viability,
    'Can the interstate system adopt conditional sovereignty readings (intervention permitted during mass atrocities) without collapsing into unstable intervention pretexts, or does conditional sovereignty inevitably degrade into great-power opportunism?',
    'Natural experiment from jurisdictions that implemented Responsibility to Protect or similar conditional frameworks: measure interstate stability and intervention abuse rates compared to absolute sovereignty baselines.',
    'If conditional readings prove stable, the absolute reading''s claim to necessity is empirically false—it is sustained by ideology rather than structural requirement. If conditional readings degrade into abuse, the absolute reading''s high extraction may be the unavoidable price of preventing worse outcomes.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(sibling_reading_viability, empirical, 'Whether conditional sovereignty frameworks can operate without abuse.').

omega_variable(
    kernel_reading_framing,
    'The absolute reading, conditional reading, and graded reading are three interpretations of the sovereignty kernel. What signals or institutional context determine which reading a given actor adopts?',
    'Cross-national and cross-institutional analysis: code state and scholar positions on sovereignty by regime type, colonial history, and great-power status. If authoritarian regimes systematically adopt the absolute reading while democracies and atrocity-survivor networks adopt conditional readings, the reading choice is interest-aligned rather than analytically determined.',
    'If reading choice tracks interest, the absolute reading is sustained by beneficiaries rather than by its analytical superiority. This routes the kernel contest through the omega infrastructure: the different readings are not equally valid framings but structurally interested claims.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(kernel_reading_framing, conceptual, 'What determines which kernel reading an actor adopts—analytical merit or material interest.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(westphalia_sovereignty__absolute_non_intervention, 0, 40).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(west_tr_t0, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 0, 0.22).
narrative_ontology:measurement_basis(west_tr_t0, observed).
narrative_ontology:measurement(west_tr_t8, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 8, 0.26).
narrative_ontology:measurement_basis(west_tr_t8, observed).
narrative_ontology:measurement(west_tr_t16, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 16, 0.31).
narrative_ontology:measurement_basis(west_tr_t16, observed).
narrative_ontology:measurement(west_tr_t24, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 24, 0.36).
narrative_ontology:measurement_basis(west_tr_t24, observed).
narrative_ontology:measurement(west_tr_t32, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 32, 0.39).
narrative_ontology:measurement_basis(west_tr_t32, observed).
narrative_ontology:measurement(west_tr_t40, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 40, 0.42).
narrative_ontology:measurement_basis(west_tr_t40, observed).

% Extraction over time
narrative_ontology:measurement(west_be_t0, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 0, 0.48).
narrative_ontology:measurement_basis(west_be_t0, observed).
narrative_ontology:measurement(west_be_t8, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 8, 0.52).
narrative_ontology:measurement_basis(west_be_t8, observed).
narrative_ontology:measurement(west_be_t16, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 16, 0.58).
narrative_ontology:measurement_basis(west_be_t16, observed).
narrative_ontology:measurement(west_be_t24, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 24, 0.63).
narrative_ontology:measurement_basis(west_be_t24, observed).
narrative_ontology:measurement(west_be_t32, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 32, 0.66).
narrative_ontology:measurement_basis(west_be_t32, observed).
narrative_ontology:measurement(west_be_t40, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 40, 0.68).
narrative_ontology:measurement_basis(west_be_t40, observed).

% Suppression requirement over time
narrative_ontology:measurement(west_su_t0, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 0, 0.58).
narrative_ontology:measurement_basis(west_su_t0, observed).
narrative_ontology:measurement(west_su_t8, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 8, 0.62).
narrative_ontology:measurement_basis(west_su_t8, observed).
narrative_ontology:measurement(west_su_t16, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 16, 0.67).
narrative_ontology:measurement_basis(west_su_t16, observed).
narrative_ontology:measurement(west_su_t24, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 24, 0.72).
narrative_ontology:measurement_basis(west_su_t24, observed).
narrative_ontology:measurement(west_su_t32, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 32, 0.76).
narrative_ontology:measurement_basis(west_su_t32, observed).
narrative_ontology:measurement(west_su_t40, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 40, 0.79).
narrative_ontology:measurement_basis(west_su_t40, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:affects_constraint(westphalia_sovereignty__absolute_non_intervention, westphalia_sovereignty__conditional_responsibility).
narrative_ontology:affects_constraint(westphalia_sovereignty__absolute_non_intervention, westphalia_sovereignty__graded_sovereignty).
narrative_ontology:affects_constraint(westphalia_sovereignty__absolute_non_intervention, humanitarian_intervention_legal_framework).
narrative_ontology:affects_constraint(westphalia_sovereignty__absolute_non_intervention, international_criminal_court_jurisdiction).

% DUAL FORMULATION NOTE:
% This constraint is one member of the westphalia_sovereignty family. All three readings—absolute_non_intervention, conditional_responsibility, graded_sovereignty—are modeled as separate constraints linked via network.affects_constraints because their ε values differ by a wide margin (absolute ~0.68, conditional substantially lower, graded variable). The absolute reading influences the conditional and graded readings by setting the baseline expectation in international law: conditional and graded frameworks must argue against the absolute reading's presumptive status. The confusion was in the language (the label 'sovereignty' conflates three structurally distinct claims), not in the mathematics.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
