% ============================================================================
% CONSTRAINT STORY: woman_category__intersex_accommodation_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_woman_category__intersex_accommodation_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: woman_category__intersex_accommodation_reading
 *   human_readable: Woman Category Membership via Intersex Accommodation Reading
 *   domain: political_philosophy/law/social_policy/bioethics
 *
 * SUMMARY:
 *   This constraint operationalizes one reading of the contested 'woman'
 *   category kernel: membership is determined by acknowledging biological sex
 *   as a non-binary spectrum, where 'woman' includes typical female biology
 *   plus intersex variations that do not fit the male category. The reading
 *   emerged from intersex rights advocacy addressing historical medical
 *   coercion and legal invisibility. Its application expanded from
 *   anti-discrimination contexts (low ε, small affected population) into
 *   competitive athletics (high ε, zero-sum displacement), where biological
 *   advantages correlated with intersex variations create systematic
 *   redistribution of opportunity from typical-female-biology athletes to
 *   those with performance-relevant variations. The constraint is claimed as
 *   tangled_rope: it coordinates a genuine problem (legal recognition for
 *   intersex individuals) while extracting from typical-female-biology
 *   populations in competitive domains through enforced category expansion.
 *
 * KEY AGENTS:
 *   - intersex_rights_advocacy_organizations: Primary agenda-setter (organized/constrained) — built the reading, press for adoption, collect institutional legitimacy
 *   - non_binary_typical_female_athletes: Beneficiary (moderate/constrained) — gain competitive access under accommodation
 *   - typical_female_biology_athletes: Payer (moderate/trapped) — bear competitive displacement, objections suppressed as discriminatory
 *   - female_typical_biology_populations_in_elite_competition: Payer (powerless/trapped) — class-level displacement from zero-sum redistribution
 *   - institutions_with_binary_infrastructure: Payer (institutional/constrained) — absorb retrofit and compliance costs
 *   - bioethics_researchers: Observer (analytical/analytical) — measure empirical distribution and performance correlations
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(woman_category__intersex_accommodation_reading, 0.72).
domain_priors:suppression_score(woman_category__intersex_accommodation_reading, 0.68).
domain_priors:theater_ratio(woman_category__intersex_accommodation_reading, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, extractiveness, 0.72).
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, suppression_requirement, 0.68).
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, accessibility_collapse, 0.58).
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, resistance, 0.64).

% --- Constraint claim ---
narrative_ontology:constraint_claim(woman_category__intersex_accommodation_reading, tangled_rope).
narrative_ontology:human_readable(woman_category__intersex_accommodation_reading, "Woman Category Membership via Intersex Accommodation Reading").
narrative_ontology:topic_domain(woman_category__intersex_accommodation_reading, "political_philosophy/law/social_policy/bioethics").

domain_priors:requires_active_enforcement(woman_category__intersex_accommodation_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(woman_category__intersex_accommodation_reading, 'f47fdaf0-fff0-410c-9313-5b0feefa8b83').
narrative_ontology:cs_kernel_codification('f47fdaf0-fff0-410c-9313-5b0feefa8b83', distributed).
narrative_ontology:cs_authority_grounding('f47fdaf0-fff0-410c-9313-5b0feefa8b83', distributed).
narrative_ontology:cs_reading_relation('f47fdaf0-fff0-410c-9313-5b0feefa8b83', woman_category__sex_biology_reading, coexists_with).
narrative_ontology:cs_reading_relation('f47fdaf0-fff0-410c-9313-5b0feefa8b83', woman_category__gender_identity_reading, influences).
narrative_ontology:cs_axiom('f47fdaf0-fff0-410c-9313-5b0feefa8b83', foundational, biological_sex_non_binary_spectrum).
narrative_ontology:cs_axiom_status(biological_sex_non_binary_spectrum, holdable).
narrative_ontology:cs_axiom_grounding('f47fdaf0-fff0-410c-9313-5b0feefa8b83', biological_sex_non_binary_spectrum, empirically_contingent).
narrative_ontology:cs_axiom('f47fdaf0-fff0-410c-9313-5b0feefa8b83', foundational, category_expansion_required_for_intersex_inclusion).
narrative_ontology:cs_axiom_status(category_expansion_required_for_intersex_inclusion, holdable).
narrative_ontology:cs_axiom_grounding('f47fdaf0-fff0-410c-9313-5b0feefa8b83', category_expansion_required_for_intersex_inclusion, instrumental).
narrative_ontology:cs_axiom('f47fdaf0-fff0-410c-9313-5b0feefa8b83', secondary, competitive_fairness_subordinate_to_inclusion).
narrative_ontology:cs_axiom_status(competitive_fairness_subordinate_to_inclusion, holdable).
narrative_ontology:cs_axiom_grounding('f47fdaf0-fff0-410c-9313-5b0feefa8b83', competitive_fairness_subordinate_to_inclusion, deontological).
narrative_ontology:cs_reference_frame('f47fdaf0-fff0-410c-9313-5b0feefa8b83', binary_sex_with_intersex_medical_coercion).
narrative_ontology:cs_drift_state('f47fdaf0-fff0-410c-9313-5b0feefa8b83', post_athletic_accommodation_expansion, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('f47fdaf0-fff0-410c-9313-5b0feefa8b83', '').
narrative_ontology:cs_kernel_id(woman_category__intersex_accommodation_reading, woman_category).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(woman_category__intersex_accommodation_reading, intersex_rights_advocacy_organizations).
narrative_ontology:constraint_beneficiary(woman_category__intersex_accommodation_reading, medical_institutions_with_intersex_specialization).
narrative_ontology:constraint_beneficiary(woman_category__intersex_accommodation_reading, non_binary_typical_female_athletes).
narrative_ontology:constraint_victim(woman_category__intersex_accommodation_reading, typical_female_biology_athletes).
narrative_ontology:constraint_victim(woman_category__intersex_accommodation_reading, institutions_with_binary_infrastructure).
narrative_ontology:constraint_victim(woman_category__intersex_accommodation_reading, female_typical_biology_populations_in_elite_competition).
narrative_ontology:constraint_vindicates(woman_category__intersex_accommodation_reading, biological_sex_spectrum_claim).
narrative_ontology:constraint_vindicates(woman_category__intersex_accommodation_reading, binary_inadequacy_doctrine).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Advocate for legal recognition of intersex variation as natural biological diversity. Press for category definitions that acknowledge non-binary biology. Successfully lobby medical and athletic governance bodies to adopt spectrum-based classification. Collect institutional legitimacy and influence from this framing's adoption, though enforcement costs fall elsewhere.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, intersex_rights_advocacy_organizations, agenda_setter,
    organized, generational, constrained, global).

% Provide diagnostic and care services for intersex conditions. Benefit from this reading's legitimation of spectrum-based medical categories, which expands their professional jurisdiction. Can credibly claim expertise in adjudicating edge cases. Exit option is viable because they operate across multiple framings depending on institutional context.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, medical_institutions_with_intersex_specialization, beneficiary,
    institutional, biographical, mobile, national).

% Athletes with intersex variations or ambiguous biology who are included in women's competition categories under this reading. Gain access to competitive opportunities they would be excluded from under strict binary enforcement. Their athletic careers depend on this accommodation remaining in force.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, non_binary_typical_female_athletes, beneficiary,
    moderate, biographical, constrained, global).

% Female athletes with typical XX biology competing in elite sports where performance advantages correlate with testosterone levels or intersex variations. Bear the competitive cost when category boundaries expand to include athletes with biological advantages. Cannot exit the category without abandoning their sport; their objections are characterized as discriminatory.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, typical_female_biology_athletes, payer,
    moderate, biographical, trapped, global).

% Schools, prisons, hospitals, athletic organizations with built infrastructure assuming binary sex categories. Must retrofit physical spaces, update records systems, retrain staff, and absorb litigation risk from classification errors. The accommodation requirement is imposed externally; the cost of compliance is substantial and ongoing.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, institutions_with_binary_infrastructure, payer,
    institutional, generational, constrained, national).

% The class of athletes with typical female biology competing at the highest levels where marginal biological advantages determine outcomes. Experience displacement from podium positions and scholarships when competitors with intersex advantages are accommodated. Individual members lack standing to challenge the rule; collective organization is suppressed as bigotry.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, female_typical_biology_populations_in_elite_competition, payer,
    powerless, biographical, trapped, global).

% Organizations advocating for sex-based rights and spaces defined by reproductive biology. Argue that accommodating intersex variation in the woman category erodes the category's coherence and defeats its protective function. Their position is increasingly excluded from institutional policy-making and characterized as discriminatory rather than engaged on merits.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, strict_binary_enforcement_advocates, excluded,
    organized, generational, constrained, global).

% Study the empirical questions: what is the distribution of intersex conditions, what performance advantages correlate with which variations, where does accommodation create zero-sum displacement. Attempt to distinguish genuine biological spectrum from strategic boundary gaming. Their findings are consumed selectively depending on which reading they support.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, bioethics_researchers, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Acknowledges the empirical reality of intersex biology and provides a legal and institutional category for people whose biology does not fit binary male/female classification, preventing their systemic exclusion from gendered spaces and entitlements.
% TRANSFER_FUNCTION: Transfers competitive opportunity and resource access from typical-female-biology populations to intersex and ambiguous-biology populations by expanding the woman category to include non-binary-typical cases. In elite sports contexts, transfers medals, scholarships, and sponsorships from those without biological advantages to those with them.
% ABSENT_VOICES: Female athletes with typical biology who are displaced by intersex competitors are structurally discouraged from objecting; framing their concerns as discrimination rather than fairness suppresses organized resistance. Institutions bearing retrofit costs lack standing to challenge the mandate.
% DISAPPEARANCE_RATIONALE: If this reading disappeared overnight, athletic governing bodies would revert to stricter binary enforcement or testosterone-based eligibility criteria, intersex individuals would face renewed exclusion from single-sex spaces, and institutions would no longer face accommodation mandates. Legal disputes over category boundaries would shift to different framings.
% FOUNDING_PROBLEM: Intersex individuals were historically subjected to coercive medical intervention, legal invisibility, and systematic exclusion from single-sex spaces because binary categories could not accommodate their biology.
% FOUNDING_PROBLEM_CORROBORATION: Medical historians and intersex advocacy organizations document historical coercion and exclusion. However, athletic governance bodies and women's rights organizations contest whether the founding problem (medical coercion and legal invisibility) requires this specific solution (category expansion) or is better addressed through distinct intersex recognition without collapsing category boundaries. Independent bioethicists note the founding problem concerned marginalization of a small population, while the current reading's application in competitive contexts creates zero-sum redistribution affecting much larger populations.
narrative_ontology:disappearance_verdict(woman_category__intersex_accommodation_reading, world_rearranges).
narrative_ontology:founding_problem_status(woman_category__intersex_accommodation_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(woman_category__intersex_accommodation_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(woman_category__intersex_accommodation_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(woman_category__intersex_accommodation_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(woman_category__intersex_accommodation_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(woman_category__intersex_accommodation_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction rises from 0.35 to 0.72 over the interval as the reading's application expands from anti-discrimination (genuine coordination, small population) into elite athletics (zero-sum redistribution, performance advantages). Suppression rises from 0.32 to 0.68 as enforcement intensifies: objections from displaced athletes are characterized as discrimination rather than fairness claims, institutions face mandate compliance regardless of cost, and the framing itself makes resistance socially costly. Theater rises from 0.18 to 0.42: early in the interval, accommodation addresses genuine exclusion; later, the boundary becomes strategic as enforcement focuses on defending expanded category definitions against empirical challenge rather than protecting intersex individuals from coercion. Accessibility_collapse is 0.58: alternatives exist (distinct intersex recognition, performance-based rather than category-based eligibility) but are increasingly foreclosed as discriminatory. Resistance is 0.64: typical-female-biology athletes, women's sports advocates, and institutions bearing costs actively resist, but their resistance is suppressed through reputational cost and institutional exclusion.
 *
 * PERSPECTIVAL GAP:
 *   From the agenda-setter and beneficiary seats, this reading solves a genuine coordination problem (legal recognition for intersex biology) and the costs are justified accommodation of natural variation. From the payer seats (typical-female-biology athletes, institutions bearing retrofit costs), the same structure operates as enforced extraction: category expansion that creates zero-sum displacement in competitive domains and imposes substantial compliance costs, with resistance suppressed as bigotry. The engine computes this divergence from the structural data; the claim does not adjudicate between the framings.
 *
 * DIRECTIONALITY LOGIC:
 *   Intersex advocacy organizations are structural beneficiaries (collect legitimacy and influence from the reading's adoption, constrained exit because their mission is fused with this framing — d near beneficiary end). Non-binary-typical-female athletes are beneficiaries (gain competitive access, constrained exit because their careers depend on accommodation — d moderately toward beneficiary). Typical-female-biology athletes and the class population in elite competition are targets (bear displacement, trapped exit because leaving means abandoning sport, suppression makes objection costly — d near target end). Institutions with binary infrastructure are targets (bear retrofit costs, constrained exit because mandate is external — d toward target end). Medical institutions are beneficiaries with viable exit (jurisdictional expansion, can operate across framings — d moderately toward beneficiary). Bioethics researchers are analytical (observe and measure without stake in outcome — d at analytical default).
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint exhibits mandatrophy characteristics in competitive athletics: the founding problem (medical coercion and legal invisibility of intersex individuals) is substantially resolved in most policy domains, but the accommodation mandate persists and expands into zero-sum contexts where it redistributes opportunity rather than prevents exclusion. The growing theater_ratio reflects this: enforcement increasingly defends expanded category boundaries against empirical challenge rather than addressing the founding problem. However, the founding problem remains live in some jurisdictions (ongoing medical coercion in countries without intersex protections), making the status 'contested' rather than cleanly 'dead'. The victim structure is clear: typical-female-biology athletes in elite competition bear costs disproportionate to the intersex population size, and their resistance is structurally suppressed.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    intersex_prevalence_vs_elite_representation,
    'What is the base rate of intersex conditions in the general population versus their representation in elite women''s athletics, particularly in events where testosterone-linked advantages matter?',
    'Systematic demographic study of elite athletic populations compared to general population prevalence rates, controlled for sport type and performance level. Already partially resolved: known intersex conditions affect ~0.02-1.7% of births depending on definition, but representation in some elite women''s events is orders of magnitude higher.',
    'If elite representation substantially exceeds base rate prevalence in performance-advantage contexts, it establishes that the accommodation functions as systematic redistribution rather than inclusion of a marginalized group at natural frequency. If representation matches base rate, the displacement concern weakens.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(intersex_prevalence_vs_elite_representation, empirical, 'Whether intersex accommodation in elite athletics is proportional inclusion or performance-advantage redistribution').

omega_variable(
    category_coherence_under_spectrum_framing,
    'Can the ''woman'' category maintain its protective and organizational function if it is defined by a biological spectrum rather than a binary, or does spectrum framing dissolve the category''s boundaries entirely?',
    'Conceptual analysis plus observation of institutional outcomes: do spectrum-based definitions allow workable category boundaries, or do they collapse into either arbitrary line-drawing or full self-identification? Track whether institutions adopting spectrum framing can sustain distinct women''s spaces or revert to either strict binary or identity-based definitions.',
    'If spectrum framing allows stable category boundaries that accommodate intersex variation without collapsing to self-identification, this reading is structurally coherent. If spectrum framing empirically collapses boundaries, it is a transitional form that either reverts to binary or advances to identity-based determination.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(category_coherence_under_spectrum_framing, conceptual, 'Whether biological-spectrum framing can sustain workable category boundaries or collapses to other readings').

omega_variable(
    founding_problem_domain_specificity,
    'Is the founding problem (medical coercion and legal invisibility of intersex individuals) solved by category accommodation in competitive athletics, or is it better addressed through distinct intersex recognition without expanding binary categories?',
    'Natural experiment from jurisdictions that adopt distinct legal recognition for intersex status without collapsing sex-based category boundaries: do intersex individuals achieve protection from coercion and gain legal standing without requiring accommodation in competitive single-sex contexts? Track medical coercion rates and legal standing outcomes across policy approaches.',
    'If distinct recognition solves the founding problem without competitive redistribution, the athletic accommodation is extractive rather than coordinative. If only category expansion prevents coercion and invisibility, the extraction is the unavoidable cost of the coordination.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(founding_problem_domain_specificity, empirical, 'Whether the founding problem requires category expansion or is solvable through distinct recognition').

omega_variable(
    suppression_mechanism_identity_fusion,
    'Is the suppression of typical-female-biology athletes'' objections structural (reputational cost, platform denial, institutional exclusion) or internalized (athletes themselves believe their displacement concerns are illegitimate)?',
    'Anonymous survey of displaced athletes post-career, after exit from competitive context: do they maintain their objections were legitimate fairness concerns, or do they retrospectively endorse the accommodation framing? If objections persist after exit, suppression is structural; if athletes adopt the accommodation narrative post-exit, suppression was partially internalized.',
    'Structural suppression indicates the constraint''s persistence depends on active enforcement against resistance. Internalized suppression indicates the framing has achieved ideological dominance and may be self-sustaining even if enforcement relaxes.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(suppression_mechanism_identity_fusion, empirical, 'Whether athlete suppression is structural enforcement or internalized acceptance of accommodation narrative').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(woman_category__intersex_accommodation_reading, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(woma_tr_t0, woman_category__intersex_accommodation_reading, theater_ratio, 0, 0.18).
narrative_ontology:measurement_basis(woma_tr_t0, observed).
narrative_ontology:measurement(woma_tr_t5, woman_category__intersex_accommodation_reading, theater_ratio, 5, 0.23).
narrative_ontology:measurement_basis(woma_tr_t5, observed).
narrative_ontology:measurement(woma_tr_t10, woman_category__intersex_accommodation_reading, theater_ratio, 10, 0.29).
narrative_ontology:measurement_basis(woma_tr_t10, observed).
narrative_ontology:measurement(woma_tr_t15, woman_category__intersex_accommodation_reading, theater_ratio, 15, 0.34).
narrative_ontology:measurement_basis(woma_tr_t15, observed).
narrative_ontology:measurement(woma_tr_t20, woman_category__intersex_accommodation_reading, theater_ratio, 20, 0.38).
narrative_ontology:measurement_basis(woma_tr_t20, observed).
narrative_ontology:measurement(woma_tr_t25, woman_category__intersex_accommodation_reading, theater_ratio, 25, 0.42).
narrative_ontology:measurement_basis(woma_tr_t25, observed).

% Extraction over time
narrative_ontology:measurement(woma_be_t0, woman_category__intersex_accommodation_reading, base_extractiveness, 0, 0.35).
narrative_ontology:measurement_basis(woma_be_t0, observed).
narrative_ontology:measurement(woma_be_t5, woman_category__intersex_accommodation_reading, base_extractiveness, 5, 0.42).
narrative_ontology:measurement_basis(woma_be_t5, observed).
narrative_ontology:measurement(woma_be_t10, woman_category__intersex_accommodation_reading, base_extractiveness, 10, 0.51).
narrative_ontology:measurement_basis(woma_be_t10, observed).
narrative_ontology:measurement(woma_be_t15, woman_category__intersex_accommodation_reading, base_extractiveness, 15, 0.59).
narrative_ontology:measurement_basis(woma_be_t15, observed).
narrative_ontology:measurement(woma_be_t20, woman_category__intersex_accommodation_reading, base_extractiveness, 20, 0.66).
narrative_ontology:measurement_basis(woma_be_t20, observed).
narrative_ontology:measurement(woma_be_t25, woman_category__intersex_accommodation_reading, base_extractiveness, 25, 0.72).
narrative_ontology:measurement_basis(woma_be_t25, observed).

% Suppression requirement over time
narrative_ontology:measurement(woma_su_t0, woman_category__intersex_accommodation_reading, suppression_requirement, 0, 0.32).
narrative_ontology:measurement_basis(woma_su_t0, observed).
narrative_ontology:measurement(woma_su_t5, woman_category__intersex_accommodation_reading, suppression_requirement, 5, 0.41).
narrative_ontology:measurement_basis(woma_su_t5, observed).
narrative_ontology:measurement(woma_su_t10, woman_category__intersex_accommodation_reading, suppression_requirement, 10, 0.49).
narrative_ontology:measurement_basis(woma_su_t10, observed).
narrative_ontology:measurement(woma_su_t15, woman_category__intersex_accommodation_reading, suppression_requirement, 15, 0.56).
narrative_ontology:measurement_basis(woma_su_t15, observed).
narrative_ontology:measurement(woma_su_t20, woman_category__intersex_accommodation_reading, suppression_requirement, 20, 0.62).
narrative_ontology:measurement_basis(woma_su_t20, observed).
narrative_ontology:measurement(woma_su_t25, woman_category__intersex_accommodation_reading, suppression_requirement, 25, 0.68).
narrative_ontology:measurement_basis(woma_su_t25, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:affects_constraint(woman_category__intersex_accommodation_reading, woman_category__gender_identity_reading).
narrative_ontology:affects_constraint(woman_category__intersex_accommodation_reading, woman_category__sex_biology_reading).

% DUAL FORMULATION NOTE:
% This constraint is one of three readings of the woman_category kernel. The sex_biology_reading enforces strict binary based on chromosomes/anatomy. The gender_identity_reading enforces category membership by self-identification. This intersex_accommodation_reading occupies a middle position: acknowledges biological spectrum but retains some connection to biology rather than pure self-identification. The readings produce different ε values because their victim sets differ: biology_reading excludes intersex individuals (small victim set), identity_reading permits self-identification (large potential victim set of female-typical-biology populations), this reading accommodates intersex variation (victim set is domain-specific — small in most contexts, substantial in elite athletics). The ε-invariance principle requires separate stories for each reading; they are linked here via network.affects_constraints.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
