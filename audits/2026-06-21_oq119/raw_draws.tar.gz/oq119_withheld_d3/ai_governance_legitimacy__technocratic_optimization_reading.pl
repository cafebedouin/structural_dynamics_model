% ============================================================================
% CONSTRAINT STORY: ai_governance_legitimacy__technocratic_optimization_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-19
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_ai_governance_legitimacy__technocratic_optimization_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: ai_governance_legitimacy__technocratic_optimization_reading
 *   human_readable: AI Governance Legitimacy via Technocratic Optimization
 *   domain: theological_ethics/technology_governance/political_theology
 *
 * SUMMARY:
 *   This constraint is one reading of the contested kernel 'AI governance
 *   legitimacy'. Under the technocratic optimization reading, legitimacy
 *   derives from maximizing aggregate welfare, efficiency, and innovation.
 *   Ethical constraints including human dignity become secondary optimization
 *   parameters rather than binding limits. Authority rests with technical
 *   experts and market actors who demonstrate performance, not with
 *   democratic publics or religious interpreters. The encyclical's principles
 *   are treated as aspirational values to be balanced against feasibility and
 *   growth rather than as authoritative constraints. This reading coordinates
 *   AI governance around measurable efficiency metrics but extracts from
 *   populations lacking the power or expertise to contest the optimization
 *   criteria.
 *
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(ai_governance_legitimacy__technocratic_optimization_reading, 0.35).
domain_priors:suppression_score(ai_governance_legitimacy__technocratic_optimization_reading, 0.42).
domain_priors:theater_ratio(ai_governance_legitimacy__technocratic_optimization_reading, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, extractiveness, 0.35).
narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 0.42).
narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, resistance, 0.58).

% --- Constraint claim ---
narrative_ontology:constraint_claim(ai_governance_legitimacy__technocratic_optimization_reading, rope).
narrative_ontology:human_readable(ai_governance_legitimacy__technocratic_optimization_reading, "AI Governance Legitimacy via Technocratic Optimization").
narrative_ontology:topic_domain(ai_governance_legitimacy__technocratic_optimization_reading, "theological_ethics/technology_governance/political_theology").

domain_priors:requires_active_enforcement(ai_governance_legitimacy__technocratic_optimization_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(ai_governance_legitimacy__technocratic_optimization_reading, 'e35f8133-1f61-4cf3-9960-2770aa42b87f').
narrative_ontology:cs_kernel_codification('e35f8133-1f61-4cf3-9960-2770aa42b87f', distributed).
narrative_ontology:cs_authority_grounding('e35f8133-1f61-4cf3-9960-2770aa42b87f', expertise).
narrative_ontology:cs_interpretation_layer_present('e35f8133-1f61-4cf3-9960-2770aa42b87f').
narrative_ontology:cs_reading_relation('e35f8133-1f61-4cf3-9960-2770aa42b87f', ai_governance_legitimacy__magisterial_subsidiarity_reading, coexists_with).
narrative_ontology:cs_reading_relation('e35f8133-1f61-4cf3-9960-2770aa42b87f', ai_governance_legitimacy__democratic_pluralist_reading, coexists_with).
narrative_ontology:cs_reading_relation('e35f8133-1f61-4cf3-9960-2770aa42b87f', ai_governance_legitimacy__market_libertarian_reading, coexists_with).
narrative_ontology:cs_axiom('e35f8133-1f61-4cf3-9960-2770aa42b87f', foundational, aggregate_welfare_optimization_primacy).
narrative_ontology:cs_axiom_status(aggregate_welfare_optimization_primacy, holdable).
narrative_ontology:cs_axiom_grounding('e35f8133-1f61-4cf3-9960-2770aa42b87f', aggregate_welfare_optimization_primacy, instrumental).
narrative_ontology:cs_axiom('e35f8133-1f61-4cf3-9960-2770aa42b87f', foundational, expertise_based_governance_authority).
narrative_ontology:cs_axiom_status(expertise_based_governance_authority, holdable).
narrative_ontology:cs_axiom_grounding('e35f8133-1f61-4cf3-9960-2770aa42b87f', expertise_based_governance_authority, empirically_contingent).
narrative_ontology:cs_axiom('e35f8133-1f61-4cf3-9960-2770aa42b87f', secondary, dignity_as_optimization_constraint).
narrative_ontology:cs_axiom_status(dignity_as_optimization_constraint, holdable).
narrative_ontology:cs_axiom_grounding('e35f8133-1f61-4cf3-9960-2770aa42b87f', dignity_as_optimization_constraint, instrumental).
narrative_ontology:cs_reference_frame('e35f8133-1f61-4cf3-9960-2770aa42b87f', expert_consensus_governance_paradigm).
narrative_ontology:cs_drift_state('e35f8133-1f61-4cf3-9960-2770aa42b87f', contemporary_ai_deployment_era, gap(authority_erosion, substantial, false)).
narrative_ontology:cs_created_at('e35f8133-1f61-4cf3-9960-2770aa42b87f', '').
narrative_ontology:cs_kernel_id(ai_governance_legitimacy__technocratic_optimization_reading, ai_governance_legitimacy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__technocratic_optimization_reading, technology_firms).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__technocratic_optimization_reading, institutional_investors).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__technocratic_optimization_reading, high_skill_workers).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__technocratic_optimization_reading, early_adopters).
narrative_ontology:constraint_victim(ai_governance_legitimacy__technocratic_optimization_reading, displaced_workers).
narrative_ontology:constraint_victim(ai_governance_legitimacy__technocratic_optimization_reading, digitally_marginalized_communities).
narrative_ontology:constraint_victim(ai_governance_legitimacy__technocratic_optimization_reading, algorithmically_profiled_populations).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Develop and deploy AI systems under governance frameworks that prioritize efficiency metrics and innovation velocity. Benefit from regulatory environments shaped by technical feasibility arguments and demonstrated performance rather than normative constraints. Their expertise grants them substantial agenda-setting authority in defining what counts as optimal governance.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, technology_firms, beneficiary,
    institutional, generational, arbitrage, global).

% Profit from AI development operating under growth-oriented governance that treats ethical considerations as secondary optimization parameters. Their capital flows shape which governance approaches gain traction, favoring frameworks that maximize returns over distributional concerns.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, institutional_investors, beneficiary,
    powerful, biographical, mobile, global).

% Possess the technical credentials and adaptive capacity to thrive in efficiency-optimized AI economies. Their market power and exit options allow them to capture wage premiums while the governance framework subordinates dignity considerations to performance metrics.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, high_skill_workers, beneficiary,
    moderate, biographical, mobile, global).

% Gain first-mover advantages and productivity gains from rapid AI deployment. They trade some privacy and autonomy for efficiency gains, a bargain made viable by their relative power and digital literacy, but the governance framework extends this trade-off to populations with fewer resources to negotiate it.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, early_adopters, beneficiary,
    moderate, biographical, constrained, regional).

% Bear the transition costs of efficiency-optimized automation. Their skills are devalued by AI systems deployed at speeds prioritizing aggregate productivity over employment stability. The governance framework treats their displacement as an acceptable externality balanced against innovation imperatives rather than as a dignity violation requiring remediation.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, displaced_workers, payer,
    powerless, biographical, trapped, national).

% Lack the infrastructure and capital to participate in AI-enabled gains but are subject to AI-driven allocation decisions in credit, housing, and public services. The optimization framework measures success by aggregate efficiency rather than equitable access, systematically deprioritizing their needs.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, digitally_marginalized_communities, payer,
    powerless, generational, trapped, regional).

% Are subject to opaque algorithmic classification and risk scoring that determines their access to credit, employment, and services. The governance framework prioritizes predictive accuracy and operational efficiency over transparency or contestability, treating their autonomy as a parameter to be traded off against system performance.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, algorithmically_profiled_populations, payer,
    powerless, biographical, identity_locked, national).

% Offer an alternative legitimacy grounding in Catholic Social Doctrine that would subordinate efficiency to dignity. Under this reading they are structurally excluded from governance authority: their principles are treated as aspirational values to be balanced rather than as binding constraints, and their interpretive authority is displaced by technical expertise.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, magisterial_interpreters, excluded,
    institutional, civilizational, constrained, global).

% Are the nominal source of political legitimacy but lack the technical expertise to meaningfully contest optimization criteria. The governance framework channels democratic input through expert intermediaries who translate political demands into feasibility constraints, effectively demoting popular sovereignty to a secondary consideration.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, democratic_publics, excluded,
    organized, generational, constrained, national).

% Study how different legitimacy groundings shape AI deployment patterns and distributional outcomes. They document the gap between optimization-based governance and dignity-based alternatives, providing empirical evidence that informs contestation between readings.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, governance_researchers, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Coordinates AI development and deployment around measurable efficiency metrics, innovation velocity, and aggregate welfare gains. Solves the problem of multiple competing normative frameworks by subordinating them to a common optimization criterion.
% TRANSFER_FUNCTION: Moves authority over AI governance from democratic publics and normative traditions to technical experts and market actors. Moves AI-generated gains disproportionately to capital holders and high-skill workers while distributing transition costs to displaced workers and marginalized communities.
% ABSENT_VOICES: Magisterial interpreters who would ground legitimacy in Catholic Social Doctrine are structurally excluded from governance authority. Democratic publics lack the technical standing to contest optimization criteria. Displaced workers and marginalized communities are absent from the expert forums where governance frameworks are negotiated.
% DISAPPEARANCE_RATIONALE: If this legitimacy grounding disappeared, AI governance would shift toward either democratic deliberation, magisterial constraint, or market libertarianism. Technology firms would lose their expertise-based agenda-setting authority. Efficiency metrics would no longer automatically trump dignity considerations. Investment flows would redirect toward governance frameworks that privilege different values.
% FOUNDING_PROBLEM: Early AI governance debates were fragmented across incompatible normative frameworks with no shared legitimacy criterion. Technical deployment outpaced political deliberation. Optimization-based governance emerged as a pragmatic solution that could coordinate action across diverse stakeholders by translating ethical disputes into efficiency parameters.
% FOUNDING_PROBLEM_CORROBORATION: Technology firms and investors attest the founding problem remains live, citing the need for actionable governance amid normative pluralism. Governance researchers document that the shift from fragmentation to optimization-based coordination has occurred. Magisterial interpreters and democratic theorists attest the problem is misdiagnosed: the arrangement does not solve coordination failure but rather forecloses democratic and normative alternatives by reframing legitimacy questions as technical optimization problems.
narrative_ontology:disappearance_verdict(ai_governance_legitimacy__technocratic_optimization_reading, world_rearranges).
narrative_ontology:founding_problem_status(ai_governance_legitimacy__technocratic_optimization_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(ai_governance_legitimacy__technocratic_optimization_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(ai_governance_legitimacy__technocratic_optimization_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(ai_governance_legitimacy__technocratic_optimization_reading_tests).
:- end_tests(ai_governance_legitimacy__technocratic_optimization_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is moderate (0.35) because the framework genuinely coordinates around shared efficiency metrics but concentrates gains among capital and skill while distributing transition costs to powerless populations. Suppression is moderate (0.42) because the arrangement depends on excluding alternative legitimacy groundings from governance authority: democratic publics lack technical standing, magisterial interpreters are demoted to advisory status. Theater ratio is rising (0.28) as ethics review boards and impact assessments increasingly function to legitimate predetermined optimization choices rather than constrain them. Accessibility collapse is moderate (0.48) because alternative governance frameworks remain conceptually available even as the optimization reading gains institutional dominance. Resistance is substantial (0.58) from displaced workers, faith communities, and democratic theorists who contest the legitimacy grounding itself.
 *
 * PERSPECTIVAL GAP:
 *   From the technology firm and investor seats, this arrangement is genuine coordination that enables actionable governance amid normative pluralism. From displaced workers and marginalized communities, the same structure operates as extractive: their dignity is traded off against efficiency gains they do not share. From the magisterial and democratic seats, the arrangement forecloses their legitimacy groundings by reframing governance questions as technical optimization problems. The engine computes these seat-level classifications from the structural data; the claimed type 'rope' reflects the coordination function while the metrics reflect the asymmetric extraction.
 *
 * DIRECTIONALITY LOGIC:
 *   Technology firms and investors are structural beneficiaries: they gain authority, capital flows, and regulatory environments optimized for growth. High-skill workers and early adopters benefit from efficiency gains and market premiums. Displaced workers, digitally marginalized communities, and algorithmically profiled populations are structural targets: they bear transition costs, infrastructure gaps, and autonomy erosion while the governance framework treats these harms as acceptable trade-offs. Magisterial interpreters and democratic publics are excluded: their legitimacy claims are subordinated to technical expertise. The structural asymmetry is that beneficiaries set optimization criteria while victims lack standing to contest them.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint's founding problem was genuine: coordinating AI governance across incompatible normative frameworks. But the solution displaced democratic and religious legitimacy rather than integrating them. As extractiveness accumulates, the arrangement risks mandatrophy: optimization-based coordination that persists after its founding coordination function has been captured by beneficiaries who now use it to foreclose alternatives. The theater ratio trajectory suggests growing divergence between stated ethical commitments and actual governance criteria.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    aggregate_welfare_vs_distributional_justice,
    'Does maximizing aggregate welfare adequately protect human dignity, or does the optimization framework systematically sacrifice dignity of powerless populations for efficiency gains?',
    'Longitudinal empirical study comparing dignity outcomes under optimization-based governance versus dignity-constrained governance in comparable jurisdictions. Measurement of distributional patterns in AI-generated gains and harms across power strata.',
    'If aggregate optimization systematically harms powerless populations, the rope classification conceals extractive operation and the legitimacy grounding itself is contested. If distributional patterns are neutral or correctable within the framework, the coordination function is genuine.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(aggregate_welfare_vs_distributional_justice, empirical, 'Whether aggregate optimization is compatible with dignity protection or systematically trades dignity for efficiency').

omega_variable(
    technical_expertise_vs_democratic_sovereignty,
    'Is technical expertise a legitimate basis for governance authority over questions that involve fundamental value trade-offs, or does expertise-based authority constitute democratic displacement?',
    'Conceptual analysis of where technical expertise ends and normative choice begins in AI governance decisions. Historical comparison with other domains where expert authority displaced democratic deliberation.',
    'If governance questions are inherently normative, expertise-based authority is extraction disguised as coordination and the excluded democratic publics are structural victims. If questions are primarily technical, the arrangement is coordination with expertise as a necessary input.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(technical_expertise_vs_democratic_sovereignty, conceptual, 'Whether expertise grounds governance authority or displaces democratic legitimacy').

omega_variable(
    reading_contest_resolution,
    'This is one reading of the ai_governance_legitimacy kernel. The technocratic_optimization_reading treats dignity as a constraint on optimization. The magisterial_subsidiarity_reading treats dignity as the optimization target. Which structural relationship better describes AI systems actually being deployed?',
    'Empirical audit of deployed AI systems: what gets optimized, what gets constrained, and whose dignity is protected versus traded off. Governance documents analysis to identify whether dignity appears as an objective function or as a side constraint.',
    'If deployed systems optimize efficiency subject to dignity constraints, this reading is descriptively accurate. If systems routinely sacrifice dignity for efficiency where victims lack power to contest, the magisterial or democratic readings better describe the structure and this reading functions as cover.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(reading_contest_resolution, empirical, 'Which reading of the kernel better describes governance as practiced').

omega_variable(
    committer_framing_underdetermination,
    'The kernel can be framed as a legitimacy question or as an optimization problem. This reading adopts the optimization framing. Would framing it as a legitimacy question change the structural relationships and beneficiary/victim identification?',
    'Alternative constraint story treating the same governance structure as a legitimacy contest rather than an optimization problem. Comparison of beneficiary/victim sets and extractiveness estimates under both framings.',
    'If the framings produce different constraint classifications, the committer axis is under-determined and the choice of framing is itself a substantive claim about the constraint''s nature. If classifications converge, the framing choice is presentational.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(committer_framing_underdetermination, conceptual, 'Whether optimization versus legitimacy framing affects structural analysis').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(ai_governance_legitimacy__technocratic_optimization_reading, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(ai_g_tr_t0, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 0, 0.12).
narrative_ontology:measurement(ai_g_tr_t5, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 5, 0.16).
narrative_ontology:measurement(ai_g_tr_t10, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 10, 0.2).
narrative_ontology:measurement(ai_g_tr_t15, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 15, 0.24).
narrative_ontology:measurement(ai_g_tr_t20, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 20, 0.27).
narrative_ontology:measurement(ai_g_tr_t25, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 25, 0.28).

% Extraction over time
narrative_ontology:measurement(ai_g_be_t0, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 0, 0.22).
narrative_ontology:measurement(ai_g_be_t5, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 5, 0.26).
narrative_ontology:measurement(ai_g_be_t10, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 10, 0.3).
narrative_ontology:measurement(ai_g_be_t15, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 15, 0.33).
narrative_ontology:measurement(ai_g_be_t20, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 20, 0.35).
narrative_ontology:measurement(ai_g_be_t25, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 25, 0.35).

% Suppression requirement over time
narrative_ontology:measurement(ai_g_su_t0, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 0, 0.28).
narrative_ontology:measurement(ai_g_su_t5, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 5, 0.32).
narrative_ontology:measurement(ai_g_su_t10, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 10, 0.36).
narrative_ontology:measurement(ai_g_su_t15, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 15, 0.39).
narrative_ontology:measurement(ai_g_su_t20, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 20, 0.41).
narrative_ontology:measurement(ai_g_su_t25, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 25, 0.42).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(ai_governance_legitimacy__technocratic_optimization_reading, identity_coordination).
narrative_ontology:affects_constraint(ai_governance_legitimacy__technocratic_optimization_reading, ai_governance_legitimacy__magisterial_subsidiarity_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__technocratic_optimization_reading, ai_governance_legitimacy__democratic_pluralist_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__technocratic_optimization_reading, ai_governance_legitimacy__market_libertarian_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the ai_governance_legitimacy kernel, which decomposes into four structurally distinct constraints corresponding to different legitimacy groundings. The readings share a common governance domain but differ fundamentally in what grounds authority, who holds it, and whether dignity is the optimization target or a constraint on other objectives. The technocratic_optimization_reading presented here treats technical expertise and demonstrated performance as the legitimacy criterion, contrasting with magisterial (religious authority), democratic (popular sovereignty), and libertarian (voluntary exchange) alternatives.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
