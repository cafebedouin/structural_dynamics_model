% ============================================================================
% CONSTRAINT STORY: ai_governance_legitimacy__market_libertarian_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2024-01-09
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_ai_governance_legitimacy__market_libertarian_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    constraint_indexing:directionality_override/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: ai_governance_legitimacy__market_libertarian_reading
 *   human_readable: Market Libertarian Reading of AI Governance Legitimacy
 *   domain: theological_ethics/technology_governance/political_theology
 *
 * SUMMARY:
 *   This constraint instantiates the market-libertarian reading of the
 *   ai_governance_legitimacy kernel. It holds that AI governance legitimacy
 *   flows from voluntary exchange and property rights, treated as
 *   pre-political natural law. The encyclical's solidarity demands are
 *   rejected as illegitimate coercion. The constraint is claimed as mountain
 *   (natural law grounding in property rights and non-coercion), but authored
 *   metrics show modest extraction and suppression rising gradually over the
 *   interval as market concentration grows and nominal exit options diverge
 *   from effective choice for powerless actors. The claim/metric independence
 *   is deliberate: this reading asserts mountain status; the engine measures
 *   whether the structural reality matches.
 *
 * KEY AGENTS:
 *   - technology_entrepreneurs: Primary beneficiaries (powerful/arbitrage) — capture innovation rents under minimal constraint
 *   - venture_investors: Primary beneficiaries (powerful/arbitrage) — finance unregulated development with high return expectations
 *   - high_autonomy_individuals: Beneficiaries (powerful/mobile) — navigate AI markets with genuine exit options
 *   - low_market_power_workers: Primary targets (powerless/trapped) — bear labor displacement and wage compression without exit
 *   - monopsony_labor_participants: Targets (powerless/trapped) — face algorithmic management without bargaining power
 *   - coordination_dependent_communities: Targets (moderate/constrained) — suffer unpriced externalities the market cannot solve
 *   - magisterial_interpreters: Excluded (institutional/analytical) — their interpretive authority over property rights is rejected
 *   - democratic_theorists: Excluded (organized/analytical) — their claim that legitimacy derives from consent is foreclosed
 *   - political_economists: Observers (institutional/analytical) — study whether market mechanisms deliver promised protections
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(ai_governance_legitimacy__market_libertarian_reading, 0.25).
domain_priors:suppression_score(ai_governance_legitimacy__market_libertarian_reading, 0.18).
domain_priors:theater_ratio(ai_governance_legitimacy__market_libertarian_reading, 0.12).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, extractiveness, 0.25).
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 0.18).
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 0.12).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, accessibility_collapse, 0.82).
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, resistance, 0.15).

% --- Constraint claim ---
narrative_ontology:constraint_claim(ai_governance_legitimacy__market_libertarian_reading, mountain).
narrative_ontology:human_readable(ai_governance_legitimacy__market_libertarian_reading, "Market Libertarian Reading of AI Governance Legitimacy").
narrative_ontology:topic_domain(ai_governance_legitimacy__market_libertarian_reading, "theological_ethics/technology_governance/political_theology").

domain_priors:emerges_naturally(ai_governance_legitimacy__market_libertarian_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(ai_governance_legitimacy__market_libertarian_reading, '189d9eab-e07c-47bb-ba85-2823d560a880').
narrative_ontology:cs_kernel_codification('189d9eab-e07c-47bb-ba85-2823d560a880', formalized).
narrative_ontology:cs_authority_grounding('189d9eab-e07c-47bb-ba85-2823d560a880', lineage).
narrative_ontology:cs_interpretation_layer_present('189d9eab-e07c-47bb-ba85-2823d560a880').
narrative_ontology:cs_reading_relation('189d9eab-e07c-47bb-ba85-2823d560a880', ai_governance_legitimacy__magisterial_subsidiarity_reading, forecloses).
narrative_ontology:cs_reading_relation('189d9eab-e07c-47bb-ba85-2823d560a880', ai_governance_legitimacy__technocratic_optimization_reading, influences).
narrative_ontology:cs_reading_relation('189d9eab-e07c-47bb-ba85-2823d560a880', ai_governance_legitimacy__democratic_pluralist_reading, forecloses).
narrative_ontology:cs_axiom('189d9eab-e07c-47bb-ba85-2823d560a880', foundational, property_rights_are_prepolitical).
narrative_ontology:cs_axiom_status(property_rights_are_prepolitical, holdable).
narrative_ontology:cs_axiom_grounding('189d9eab-e07c-47bb-ba85-2823d560a880', property_rights_are_prepolitical, deontological).
narrative_ontology:cs_axiom('189d9eab-e07c-47bb-ba85-2823d560a880', foundational, collective_obligations_are_coercion).
narrative_ontology:cs_axiom_status(collective_obligations_are_coercion, holdable).
narrative_ontology:cs_axiom_grounding('189d9eab-e07c-47bb-ba85-2823d560a880', collective_obligations_are_coercion, deontological).
narrative_ontology:cs_axiom('189d9eab-e07c-47bb-ba85-2823d560a880', secondary, exit_protects_dignity).
narrative_ontology:cs_axiom_status(exit_protects_dignity, holdable).
narrative_ontology:cs_axiom_grounding('189d9eab-e07c-47bb-ba85-2823d560a880', exit_protects_dignity, empirically_contingent).
narrative_ontology:cs_reference_frame('189d9eab-e07c-47bb-ba85-2823d560a880', lockean_property_rights_framework).
narrative_ontology:cs_drift_state('189d9eab-e07c-47bb-ba85-2823d560a880', contemporary_ai_era, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('189d9eab-e07c-47bb-ba85-2823d560a880', '').
narrative_ontology:cs_kernel_id(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__market_libertarian_reading, technology_entrepreneurs).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__market_libertarian_reading, venture_investors).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__market_libertarian_reading, high_autonomy_individuals).
narrative_ontology:constraint_victim(ai_governance_legitimacy__market_libertarian_reading, low_market_power_workers).
narrative_ontology:constraint_victim(ai_governance_legitimacy__market_libertarian_reading, monopsony_labor_participants).
narrative_ontology:constraint_victim(ai_governance_legitimacy__market_libertarian_reading, coordination_dependent_communities).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Build AI systems under minimal regulatory constraint, capturing innovation rents through intellectual property and first-mover advantages. Exit options include jurisdictional arbitrage and private ordering through contracts. The constraint's coordination function (property rights, contract enforcement) enables their activity while its resistance to collective mandates protects accumulated capital.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, technology_entrepreneurs, beneficiary,
    powerful, biographical, arbitrage, global).

% Finance AI development with expectation of high returns predicated on unregulated innovation velocity. Portfolio diversification and capital mobility provide structural exit. They benefit from the constraint's treatment of capital allocation as a private decision protected from collective interference.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, venture_investors, beneficiary,
    powerful, biographical, arbitrage, global).

% Possess skills, credentials, or wealth enabling exit from arrangements they dislike. Navigate AI-mediated labor and service markets as consumers with choice. The constraint's emphasis on exit-as-protection aligns with their actual structural position.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, high_autonomy_individuals, beneficiary,
    powerful, biographical, mobile, global).

% Face AI-driven labor displacement, wage compression, or surveillance with minimal bargaining leverage. Exit is notional: alternative employment may not exist, retraining is costly and uncertain, and collective action is discouraged by the constraint's framing of solidarity demands as coercion. Bear the coordination failures the constraint's resistance to collective governance leaves unsolved.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, low_market_power_workers, payer,
    powerless, immediate, trapped, local).

% Work in markets dominated by one or few employers whose AI systems set wages and working conditions. The constraint's prohibition on collective bargaining or regulatory wage floors leaves them price-takers. Exit would require geographic relocation or industry change, often infeasible.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, monopsony_labor_participants, payer,
    powerless, immediate, trapped, regional).

% Require collective solutions to AI externalities (automated vehicle safety, algorithmic discrimination, data privacy) that individual exit cannot address. The constraint blocks regulatory mechanisms as illegitimate coercion, leaving coordination failures unresolved. Their costs accumulate as private harms the market does not price.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, coordination_dependent_communities, payer,
    moderate, generational, constrained, local).

% Assert that Catholic Social Doctrine provides authoritative norms for technology governance, including solidarity obligations and common good constraints on property rights. This reading excludes their interpretive authority by treating property rights as pre-political natural law that no religious tradition can override.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, magisterial_interpreters, excluded,
    institutional, civilizational, analytical, global).

% Argue that AI governance legitimacy must derive from democratic consent, not from pre-political property rights claims. This reading forecloses their framework by asserting that voluntary exchange preceded and grounds political authority, not vice versa.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, democratic_theorists, excluded,
    organized, generational, analytical, global).

% Study distributional consequences of AI development under various governance regimes. Document whether unregulated markets actually provide exit options and competitive protections for all participants, or whether market power concentrates and exit becomes structural fiction for the powerless.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, political_economists, observer,
    institutional, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides stable property rights and contract enforcement enabling decentralized AI innovation. Solves the problem of resource allocation under uncertainty by allowing entrepreneurs to capture returns from successful ventures, incentivizing risk-taking and experimentation.
% TRANSFER_FUNCTION: Moves innovation rents from successful AI ventures to entrepreneurs and investors. Moves risks of technological unemployment, wage compression, and unpriced externalities onto workers and communities with limited market power or exit options.
% ABSENT_VOICES: Those who lack market power and for whom exit is structural fiction: displaced workers without retraining resources, communities facing coordination failures the market cannot solve, populations subject to algorithmic harms with no individual remedy. Also excluded: religious traditions asserting that property rights are contingent on social function, not pre-political absolutes.
% DISAPPEARANCE_RATIONALE: If this constraint disappeared, AI governance would be subject to collective deliberation and regulatory intervention. Property rights in AI systems would become contingent on demonstrated social benefit. Entrepreneurs would face mandatory impact assessments, workers could organize collectively without being labeled coercive, and communities could impose democratically-chosen constraints on AI deployment. Investment would redirect toward jurisdictions with remaining market-libertarian regimes, and innovation velocity would shift depending on whether regulatory costs exceeded coordination benefits.
% FOUNDING_PROBLEM: Historical state overreach and central planning failures demonstrating that concentrated political authority misallocates resources and suppresses innovation. The founding problem as understood by this reading is protection of individual liberty and property from collective coercion.
% FOUNDING_PROBLEM_CORROBORATION: Technology entrepreneurs and libertarian intellectuals attest the problem is live, citing regulatory capture and bureaucratic inefficiency. Political economists and social ethicists outside the beneficiary set document that the historical problem of state overreach has been replaced by a contemporary problem of market concentration and structural powerlessness, where nominal exit options do not translate to effective choice for most participants. Democratic theorists note that treating all collective action as coercion is itself a political claim requiring justification, not a natural fact.
narrative_ontology:disappearance_verdict(ai_governance_legitimacy__market_libertarian_reading, world_rearranges).
narrative_ontology:founding_problem_status(ai_governance_legitimacy__market_libertarian_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(ai_governance_legitimacy__market_libertarian_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(ai_governance_legitimacy__market_libertarian_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(ai_governance_legitimacy__market_libertarian_reading_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, ExtMetricName, E),
    domain_priors:suppression_score(ai_governance_legitimacy__market_libertarian_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(ai_governance_legitimacy__market_libertarian_reading),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(ai_governance_legitimacy__market_libertarian_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is low-moderate (0.25 at interval end) because the constraint genuinely coordinates resource allocation through property rights and delivers innovation benefits, but extraction accumulates as market power concentrates and the gap between nominal and effective exit widens for powerless actors. Suppression is low (0.18) because enforcement relies primarily on contract law and reputational mechanisms rather than state coercion, but rises slightly as the constraint must suppress collective bargaining and regulatory demands to maintain coherence. Theater is very low (0.12): the coordination function is real, though the claim that exit protects all participants is increasingly performative for trapped actors. Accessibility collapse is high (0.82): once property rights and contract are accepted as foundational, alternative collective governance frameworks appear incoherent to those within the reading. Resistance is low (0.15): elites who benefit accept the framework; powerless actors resist but lack organized capacity. Measurements are on one shared grid; all three metrics authored at all six time points.
 *
 * PERSPECTIVAL GAP:
 *   From the entrepreneur and investor seats, this arrangement is genuine coordination enabling innovation through clear property rights and minimal interference. From the powerless-worker seats, the same structure operates as enforced extraction: they bear technological unemployment and wage compression while being told their protection is exit they cannot actually exercise. From the community seat, the constraint blocks collective solutions to coordination failures while claiming those solutions are coercion. The engine computes these seat-level divergences from the authored power, exit, and beneficiary/victim structure.
 *
 * DIRECTIONALITY LOGIC:
 *   Technology entrepreneurs and venture investors are structural beneficiaries: they capture innovation rents and operate with genuine exit through jurisdictional and capital arbitrage (d near beneficiary end, low or negative χ). High-autonomy individuals benefit from the constraint's emphasis on choice but less directly (d slightly higher). Low-market-power workers and monopsony labor participants are targets: they bear coordination failures and labor market harms with exit that is structural fiction (d near target end, high χ). Coordination-dependent communities are targets with slightly more power but still constrained exit. Magisterial interpreters and democratic theorists are excluded rather than coordinated; their frameworks are ruled out by the constraint's pre-political property rights claim.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint's mandate (protect innovation by preventing collective interference with property rights) has not outlived its function from the reading's own perspective: property rights coordination remains live and beneficiaries still capture returns. However, the tension is whether the founding problem (state overreach) has been replaced by a new problem (market concentration and structural powerlessness) that the constraint is not equipped to address and whose acknowledgment the constraint actively suppresses. The measurements show gradual extraction accumulation and rising suppression requirement, consistent with a coordination function under increasing strain as the beneficiary/victim asymmetry widens.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    property_rights_as_natural_law,
    'Are property rights in AI systems pre-political natural law (as this reading claims), or are they constructed political arrangements whose legitimacy depends on ongoing justification and consent?',
    'Historical and comparative institutional analysis showing whether property regimes are stable across political contexts or require continuous political enforcement and evolution. Philosophical analysis of whether any rights can be truly pre-political given that their enforcement requires political institutions.',
    'If property rights are constructed rather than natural, the constraint reclassifies from mountain to tangled_rope or snare: it coordinates resource allocation (real function) while extracting rents from those without market power (asymmetric burden) through suppression of alternative governance frameworks (active enforcement).',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(property_rights_as_natural_law, conceptual, 'Whether property rights are natural law or constructed political arrangements.').

omega_variable(
    exit_as_fiction,
    'Do exit options and competitive markets actually protect dignity for powerless actors, or is exit a structural fiction when retraining is costly, alternative employment scarce, and collective action suppressed?',
    'Empirical measurement of actual exit rates and outcomes for displaced workers and monopsony labor participants. Comparison of welfare outcomes under market-libertarian versus regulated AI governance regimes, controlling for innovation velocity.',
    'If exit is structural fiction for powerless actors, the constraint''s extraction is higher than measured: what is framed as coordination (you can always leave) operates as coercion (you cannot actually leave and we prevent you from organizing collective alternatives). This would support reclassification from mountain to snare.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(exit_as_fiction, empirical, 'Whether exit options are real or structural fiction for powerless actors.').

omega_variable(
    solidarity_as_coercion,
    'Are collective solidarity obligations (mandatory AI safety standards, labor protections, algorithmic accountability) illegitimate coercion, or are they legitimate exercises of democratic authority addressing coordination failures individual exit cannot solve?',
    'Political theory analysis of what distinguishes legitimate collective action from coercion. Empirical study of whether unregulated AI markets produce stable equilibria or require collective intervention to prevent race-to-bottom dynamics.',
    'If solidarity obligations are legitimate rather than coercive, the constraint''s suppression of collective governance is itself an extractive political choice benefiting those with market power. The constraint would reclassify from mountain (natural law against coercion) to tangled_rope (coordinates innovation while suppressing collective alternatives that would redistribute costs).',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(solidarity_as_coercion, preference, 'Whether solidarity demands are coercion or legitimate collective governance.').

omega_variable(
    beneficiary_concentration,
    'How concentrated are the innovation rents captured under this constraint, and does concentration increase over time as first-movers compound advantages?',
    'Longitudinal tracking of AI market concentration, wealth accumulation among technology entrepreneurs and investors, and distributional outcomes for workers and communities. Measurement of whether property rights in AI translate to persistent extraction or diffuse broadly.',
    'High and rising concentration would support reclassification to snare: a small beneficiary class captures rents through suppression of collective alternatives, while presenting the arrangement as natural law protecting everyone. Rising extraction measurements are consistent with this trajectory.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(beneficiary_concentration, empirical, 'Whether innovation rents concentrate or diffuse under this governance regime.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(ai_governance_legitimacy__market_libertarian_reading, 0, 30).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(ai_g_tr_t0, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 0, 0.1).
narrative_ontology:measurement(ai_g_tr_t6, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 6, 0.1).
narrative_ontology:measurement(ai_g_tr_t12, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 12, 0.11).
narrative_ontology:measurement(ai_g_tr_t18, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 18, 0.11).
narrative_ontology:measurement(ai_g_tr_t24, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 24, 0.12).
narrative_ontology:measurement(ai_g_tr_t30, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 30, 0.12).

% Extraction over time
narrative_ontology:measurement(ai_g_be_t0, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 0, 0.18).
narrative_ontology:measurement(ai_g_be_t6, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 6, 0.2).
narrative_ontology:measurement(ai_g_be_t12, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 12, 0.22).
narrative_ontology:measurement(ai_g_be_t18, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 18, 0.23).
narrative_ontology:measurement(ai_g_be_t24, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 24, 0.24).
narrative_ontology:measurement(ai_g_be_t30, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 30, 0.25).

% Suppression requirement over time
narrative_ontology:measurement(ai_g_su_t0, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 0, 0.15).
narrative_ontology:measurement(ai_g_su_t6, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 6, 0.16).
narrative_ontology:measurement(ai_g_su_t12, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 12, 0.17).
narrative_ontology:measurement(ai_g_su_t18, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 18, 0.17).
narrative_ontology:measurement(ai_g_su_t24, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 24, 0.18).
narrative_ontology:measurement(ai_g_su_t30, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 30, 0.18).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(ai_governance_legitimacy__market_libertarian_reading, resource_allocation).
narrative_ontology:affects_constraint(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy__magisterial_subsidiarity_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy__technocratic_optimization_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy__democratic_pluralist_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the ai_governance_legitimacy kernel. The kernel decomposes into four constraint stories because each reading instantiates a structurally distinct constraint with different ε, beneficiary/victim structures, and enforcement mechanisms. The market_libertarian_reading treats property rights as pre-political natural law (low ε, claimed mountain) and forecloses collective governance as coercion. The magisterial_subsidiarity_reading treats property rights as contingent on common good (moderate ε, claimed tangled_rope) and subordinates markets to solidarity. The technocratic_optimization_reading treats ethical constraints as optimization parameters (higher ε, likely snare) and centers technical expertise. The democratic_pluralist_reading treats legitimacy as derived from consent (variable ε depending on deliberation outcomes, likely rope or scaffold) and rejects all pre-political authority claims. Each is linked in the network; together they map the contested kernel's constraint family.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

constraint_indexing:directionality_override(ai_governance_legitimacy__market_libertarian_reading, powerless, 0.88).

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
