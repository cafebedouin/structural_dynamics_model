% ============================================================================
% CONSTRAINT STORY: waitangi_sovereignty_allocation__partnership_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_waitangi_sovereignty_allocation__partnership_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:stakeholder_gain_flow/2,
    narrative_ontology:fixing_cost_class/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: waitangi_sovereignty_allocation__partnership_reading
 *   human_readable: Treaty of Waitangi Partnership Reading: Crown-Māori Co-Governance Framework
 *   domain: constitutional_law/indigenous_rights/post_colonial_governance
 *
 * SUMMARY:
 *   The partnership reading of the Treaty of Waitangi interprets the 1840
 *   text as establishing an ongoing relationship between Crown and Māori
 *   requiring good faith consultation and active protection of Māori
 *   interests. Developed through judicial decisions and legislative
 *   principles from the 1970s onward, this reading absorbs the Treaty's
 *   textual ambiguity by treating both versions as founding a relational
 *   obligation rather than a fixed sovereignty allocation. The Crown retains
 *   parliamentary supremacy while accepting that legitimate exercise of that
 *   supremacy requires consultation and redress. This is ONE READING of the
 *   waitangi_sovereignty_allocation kernel; sibling readings are
 *   crown_sovereignty_reading (Westminster supremacy without limitation) and
 *   rangatiratanga_reading (retained Māori authority over resources and
 *   peoples).
 *
 * KEY AGENTS:
 *   - crown_apparatus: Institutional agenda-setter (institutional/analytical) — retains sovereignty, administers consultation, controls settlement terms
 *   - maori_communities: Primary beneficiary and payer (organized/identity_locked) — gain consultation rights and settlements, pay cost of engaging within Crown-defined processes
 *   - treaty_settlement_negotiators: Professional beneficiary (organized/mobile) — mediate framework, depend on partnership remaining primary mechanism
 *   - maori_sovereignty_advocates: Structural victim (moderate/identity_locked) — bear cost of stronger self-determination claims being foreclosed
 *   - resource_developers: Economic payer (powerful/constrained) — absorb consultation delays and co-governance requirements
 *   - constitutional_scholars: Analytical observer (analytical/analytical) — document Westminster adaptation and principles evolution
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(waitangi_sovereignty_allocation__partnership_reading, 0.58).
domain_priors:suppression_score(waitangi_sovereignty_allocation__partnership_reading, 0.62).
domain_priors:theater_ratio(waitangi_sovereignty_allocation__partnership_reading, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, extractiveness, 0.58).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 0.62).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, resistance, 0.54).

% --- Constraint claim ---
narrative_ontology:constraint_claim(waitangi_sovereignty_allocation__partnership_reading, tangled_rope).
narrative_ontology:human_readable(waitangi_sovereignty_allocation__partnership_reading, "Treaty of Waitangi Partnership Reading: Crown-Māori Co-Governance Framework").
narrative_ontology:topic_domain(waitangi_sovereignty_allocation__partnership_reading, "constitutional_law/indigenous_rights/post_colonial_governance").

domain_priors:requires_active_enforcement(waitangi_sovereignty_allocation__partnership_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(waitangi_sovereignty_allocation__partnership_reading, '6b437e33-820f-49e6-b415-1d0fab0001a0').
narrative_ontology:cs_kernel_codification('6b437e33-820f-49e6-b415-1d0fab0001a0', fixed_text).
narrative_ontology:cs_authority_grounding('6b437e33-820f-49e6-b415-1d0fab0001a0', lineage).
narrative_ontology:cs_interpretation_layer_present('6b437e33-820f-49e6-b415-1d0fab0001a0').
narrative_ontology:cs_reading_relation('6b437e33-820f-49e6-b415-1d0fab0001a0', waitangi_sovereignty_allocation__crown_sovereignty_reading, coexists_with).
narrative_ontology:cs_reading_relation('6b437e33-820f-49e6-b415-1d0fab0001a0', waitangi_sovereignty_allocation__rangatiratanga_reading, influences).
narrative_ontology:cs_axiom('6b437e33-820f-49e6-b415-1d0fab0001a0', foundational, treaty_as_ongoing_relationship).
narrative_ontology:cs_axiom_status(treaty_as_ongoing_relationship, holdable).
narrative_ontology:cs_axiom_grounding('6b437e33-820f-49e6-b415-1d0fab0001a0', treaty_as_ongoing_relationship, conventional).
narrative_ontology:cs_axiom('6b437e33-820f-49e6-b415-1d0fab0001a0', secondary, consultation_satisfies_protection_obligation).
narrative_ontology:cs_axiom_status(consultation_satisfies_protection_obligation, holdable).
narrative_ontology:cs_axiom_grounding('6b437e33-820f-49e6-b415-1d0fab0001a0', consultation_satisfies_protection_obligation, instrumental).
narrative_ontology:cs_reference_frame('6b437e33-820f-49e6-b415-1d0fab0001a0', treaty_partnership_principles_framework).
narrative_ontology:cs_drift_state('6b437e33-820f-49e6-b415-1d0fab0001a0', contemporary_co_governance_era, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('6b437e33-820f-49e6-b415-1d0fab0001a0', '').
narrative_ontology:cs_kernel_id(waitangi_sovereignty_allocation__partnership_reading, waitangi_sovereignty_allocation).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__partnership_reading, crown_apparatus).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__partnership_reading, maori_communities).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__partnership_reading, treaty_settlement_negotiators).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__partnership_reading, maori_sovereignty_advocates).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__partnership_reading, resource_developers).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__partnership_reading, maori_communities).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__partnership_reading, liberal_accommodation_doctrine).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__partnership_reading, consultation_as_reconciliation).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Retains parliamentary sovereignty and final legislative authority while absorbing consultation requirements as a legitimate constraint on the exercise of that authority. Sets the consultation standards, determines when they are met, and controls the pace and scope of Treaty settlements. Benefits from the partnership framing's legitimacy grant while maintaining ultimate decision-making power.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, crown_apparatus, agenda_setter,
    institutional, generational, analytical, national).
narrative_ontology:stakeholder_secondary_role(waitangi_sovereignty_allocation__partnership_reading, crown_apparatus, beneficiary).

% Gain formal consultation rights, Treaty settlement redress, and co-governance seats on resource management bodies. Pay the cost of engaging within Crown-defined consultation processes that set the terms of what counts as good faith and adequate protection. Exit would mean abandoning generations of negotiated gains and the only recognized legal pathway to addressing historical grievances.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, maori_communities, beneficiary,
    organized, civilizational, identity_locked, national).
narrative_ontology:stakeholder_secondary_role(waitangi_sovereignty_allocation__partnership_reading, maori_communities, payer).

% Professional class that mediates between Crown and iwi, translating partnership principles into settlement agreements. Their livelihood depends on the partnership framework remaining the primary mechanism for resolving Treaty claims. They benefit from the ongoing need for expertise in navigating the consultation and settlement processes.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, treaty_settlement_negotiators, beneficiary,
    organized, biographical, mobile, national).

% Bear the cost of partnership framing foreclosing stronger self-determination claims. The principles doctrine treats tino rangatiratanga as a consultative input rather than a retained sovereignty, making their reading of Article II legally unenforceable. They are bound by identity to continue advocacy within or against the partnership framework.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, maori_sovereignty_advocates, payer,
    moderate, civilizational, identity_locked, national).

% Absorb consultation delays and co-governance requirements as the price of resource access. They cannot exit the jurisdiction without abandoning existing investments and access to the resource base. Their operating costs increase as partnership obligations expand, though they retain project approval rights after consultation is completed.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, resource_developers, payer,
    powerful, biographical, constrained, national).

% Experience partnership obligations as constraints on democratic majority rule and sometimes as special rights. They participate through electoral politics that can resist but not remove Treaty obligations, as the partnership doctrine operates above ordinary legislation.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, non_maori_citizens, observer,
    organized, biographical, mobile, national).

% Analyze the partnership reading as a Westminster adaptation that grafts ongoing indigenous consultation onto parliamentary sovereignty. They document how the principles doctrine absorbs Treaty ambiguity through evolving judicial interpretation rather than textual resolution.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, constitutional_scholars, observer,
    analytical, generational, analytical, national).

% --- OQ-92 receipt surface: who RECEIVES the extraction (capture half).
% 'diffuse' = authored no-capture (piton-side); a seat name = capturer.
% ABSENT field = not authored, fail-closed. Never synthesized. ---
narrative_ontology:stakeholder_gain_flow(waitangi_sovereignty_allocation__partnership_reading, crown_apparatus).
narrative_ontology:fixing_cost_class(waitangi_sovereignty_allocation__partnership_reading, prohibitive).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Coordinates post-colonial governance by establishing a consultation framework that allows the Crown to exercise sovereignty while recognizing Māori interests, preventing either full Crown unilateralism or ongoing constitutional crisis over legitimacy.
% TRANSFER_FUNCTION: Moves decision-making authority and resource access from unrestricted Crown exercise to consultation-constrained Crown exercise, while transferring settlement capital and co-governance seats from Crown to iwi as redress for historical breaches.
% ABSENT_VOICES: The rangatiratanga reading's proponents are structurally present as Māori sovereignty advocates but their claim that Article II retained full authority is translated into consultation rights rather than recognized as retained sovereignty. Alternative constitutional frameworks that reject Westminster supremacy entirely are absent from the negotiation space.
% DISAPPEARANCE_RATIONALE: If the partnership reading vanished, Crown decision-making would either revert to unilateral parliamentary supremacy (the crown_sovereignty_reading position) or face sustained challenge from rangatiratanga claims that the Treaty retained Māori authority. Resource management would lose its consultation requirements, Treaty settlements would halt, and the legitimacy basis for post-colonial governance would fracture.
% FOUNDING_PROBLEM: The 1840 Treaty of Waitangi's textual ambiguity between the English version (Crown sovereignty) and Māori version (rangatiratanga retained) created an unresolved allocation of authority that by the 1970s was producing sustained Māori protest and Crown legitimacy crisis.
% FOUNDING_PROBLEM_CORROBORATION: Crown and Treaty settlement negotiators attest the founding problem was resolved through the partnership principles framework. Māori sovereignty advocates attest the textual ambiguity was not resolved but rather suppressed: the partnership reading adopted the Crown sovereignty baseline and offered consultation as compensation rather than recognizing retained authority. Academic legal analysis from outside beneficiary groups confirms the principles doctrine chose one horn of the ambiguity rather than resolving it.
narrative_ontology:disappearance_verdict(waitangi_sovereignty_allocation__partnership_reading, world_rearranges).
narrative_ontology:founding_problem_status(waitangi_sovereignty_allocation__partnership_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(waitangi_sovereignty_allocation__partnership_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(waitangi_sovereignty_allocation__partnership_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(waitangi_sovereignty_allocation__partnership_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(waitangi_sovereignty_allocation__partnership_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(waitangi_sovereignty_allocation__partnership_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness (0.58) reflects that while Māori gain consultation rights and settlement redress, the Crown retains final decision authority and defines the terms of what counts as adequate consultation. Suppression (0.62) captures that exit from the partnership framework means abandoning the only legally recognized pathway to redress, making the framework coercive despite its consultation language. Theater ratio (0.42) represents the gap between partnership rhetoric of equal standing and the structural reality of consultation-constrained Crown authority rather than shared sovereignty. The temporal measurements show steady increase across all three metrics as the partnership framework matures and its consultation requirements become more elaborate while the underlying sovereignty allocation remains unchanged. Accessibility collapse is moderate (0.48) because alternative constitutional readings remain theoretically available but practically foreclosed by the established legal framework. Resistance (0.54) reflects ongoing challenge from both rangatiratanga advocates and Crown sovereignty purists. The claim/metric independence is preserved: claimed as tangled_rope (genuine coordination plus asymmetric extraction), measured as substantially extractive with moderate-high suppression.
 *
 * PERSPECTIVAL GAP:
 *   The Crown seat and the Māori sovereignty advocate seat experience fundamentally different constraints. From the Crown position, partnership principles are a legitimate constraint on sovereignty that preserves ultimate authority while demonstrating good faith. From the sovereignty advocate position, the same structure operates as suppression of the rangatiratanga reading: consultation is offered as compensation for sovereignty not as recognition of retained authority. The engine computes this divergence from power, exit, and beneficiary/victim structure.
 *
 * DIRECTIONALITY LOGIC:
 *   Crown apparatus is the primary beneficiary: it retains sovereignty while gaining legitimacy from the consultation framework, and controls the pace and terms of settlements. Its d-value is near the beneficiary end. Māori communities are dual-positioned: beneficiaries of consultation rights and settlement capital, but payers of the cost that the partnership reading forecloses rangatiratanga claims. Their d-value sits near symmetric with a slight target tilt due to identity-lock. Māori sovereignty advocates are clear targets: they bear the cost of their reading being translated into consultation rather than recognized as retained authority, with identity-lock and no exit. Resource developers are payers with constrained exit. Treaty settlement negotiators are beneficiaries with mobile exit.
 *
 * MANDATROPHY ANALYSIS:
 *   The partnership reading's coordination function is real: it provides a framework for ongoing Crown-Māori engagement that prevents both unilateral Crown action and constitutional deadlock. But the extraction is also real and structural: by adopting parliamentary sovereignty as the baseline and treating rangatiratanga as a consultative input rather than retained authority, the framework extracts ongoing Crown control while offering redress for past breaches. This is precisely the tangled_rope signature: those coordinated (Māori communities gaining settlements and consultation) and those who pay (sovereignty advocates whose claims are foreclosed) are overlapping but distinct groups within the broader Māori population. The settlement negotiators are a third group who benefit from the framework's persistence.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    consultation_threshold_ambiguity,
    'What level of Māori agreement or consent is required to satisfy good faith consultation under partnership principles?',
    'Judicial review of specific consultation processes, or legislative codification of consultation standards. Currently determined case-by-case with no bright-line rule.',
    'A high consent threshold would shift partnership toward co-governance and reduce extraction; a low threshold (consultation-as-information-only) would confirm the arrangement as primarily extractive. The ambiguity allows both coordination and extraction readings to coexist.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(consultation_threshold_ambiguity, conceptual, 'Ambiguity in what satisfies partnership consultation requirements').

omega_variable(
    rangatiratanga_suppression_naturalized,
    'Is the rangatiratanga reading''s foreclosure a structural consequence of Westminster constitutionalism, or a contingent choice the partnership reading made?',
    'Comparative analysis of other post-colonial jurisdictions with indigenous sovereignty claims and different constitutional frameworks; historical analysis of alternative paths in New Zealand''s 1970s-1980s constitutional debate.',
    'If the foreclosure is contingent, the partnership reading is an actively extractive choice that could have been otherwise. If structural to Westminster systems, the reading is genuinely constrained coordination within an inherited framework. This omega addresses whether the Crown''s retention of sovereignty is a feature or the arrangement itself.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(rangatiratanga_suppression_naturalized, conceptual, 'Whether rangatiratanga foreclosure is structural or contingent').

omega_variable(
    settlement_finality_legitimacy,
    'Do Treaty settlements that exchange historical claims for capital and co-governance seats constitute legitimate redress, or coerced waiver of ongoing rights?',
    'Long-term assessment of whether settled iwi regard settlements as adequate; analysis of what rights settlements extinguish versus preserve; potential future challenge to full-and-final settlement doctrine.',
    'If settlements are legitimate redress, the partnership reading''s extraction is bounded and the arrangement trends toward rope. If settlements are coerced waivers, extraction is ongoing and structural, confirming snare classification from sovereignty advocate seats.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(settlement_finality_legitimacy, preference, 'Legitimacy of settlement-as-closure for historical Treaty breaches').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(waitangi_sovereignty_allocation__partnership_reading, 0, 50).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(wait_tr_t0, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 0, 0.28).
narrative_ontology:measurement_basis(wait_tr_t0, observed).
narrative_ontology:measurement(wait_tr_t10, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 10, 0.31).
narrative_ontology:measurement_basis(wait_tr_t10, observed).
narrative_ontology:measurement(wait_tr_t20, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 20, 0.35).
narrative_ontology:measurement_basis(wait_tr_t20, observed).
narrative_ontology:measurement(wait_tr_t30, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 30, 0.38).
narrative_ontology:measurement_basis(wait_tr_t30, observed).
narrative_ontology:measurement(wait_tr_t40, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 40, 0.4).
narrative_ontology:measurement_basis(wait_tr_t40, observed).
narrative_ontology:measurement(wait_tr_t50, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 50, 0.42).
narrative_ontology:measurement_basis(wait_tr_t50, observed).

% Extraction over time
narrative_ontology:measurement(wait_be_t0, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 0, 0.45).
narrative_ontology:measurement_basis(wait_be_t0, observed).
narrative_ontology:measurement(wait_be_t10, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 10, 0.48).
narrative_ontology:measurement_basis(wait_be_t10, observed).
narrative_ontology:measurement(wait_be_t20, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 20, 0.52).
narrative_ontology:measurement_basis(wait_be_t20, observed).
narrative_ontology:measurement(wait_be_t30, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 30, 0.55).
narrative_ontology:measurement_basis(wait_be_t30, observed).
narrative_ontology:measurement(wait_be_t40, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 40, 0.57).
narrative_ontology:measurement_basis(wait_be_t40, observed).
narrative_ontology:measurement(wait_be_t50, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 50, 0.58).
narrative_ontology:measurement_basis(wait_be_t50, observed).

% Suppression requirement over time
narrative_ontology:measurement(wait_su_t0, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 0, 0.5).
narrative_ontology:measurement_basis(wait_su_t0, observed).
narrative_ontology:measurement(wait_su_t10, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 10, 0.53).
narrative_ontology:measurement_basis(wait_su_t10, observed).
narrative_ontology:measurement(wait_su_t20, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 20, 0.56).
narrative_ontology:measurement_basis(wait_su_t20, observed).
narrative_ontology:measurement(wait_su_t30, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 30, 0.59).
narrative_ontology:measurement_basis(wait_su_t30, observed).
narrative_ontology:measurement(wait_su_t40, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 40, 0.61).
narrative_ontology:measurement_basis(wait_su_t40, observed).
narrative_ontology:measurement(wait_su_t50, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 50, 0.62).
narrative_ontology:measurement_basis(wait_su_t50, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(waitangi_sovereignty_allocation__partnership_reading, identity_coordination).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__partnership_reading, waitangi_sovereignty_allocation__crown_sovereignty_reading).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__partnership_reading, waitangi_sovereignty_allocation__rangatiratanga_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the waitangi_sovereignty_allocation kernel. The kernel is the Treaty of Waitangi's textual ambiguity about sovereignty allocation. Three readings form the constraint family: crown_sovereignty_reading (Westminster supremacy, negligible extraction from Crown seat), partnership_reading (consultation-constrained Crown authority, moderate extraction), rangatiratanga_reading (retained Māori authority, high extraction from Māori seat under current law). Each reading has distinct ε because they describe different constraints operating from the same 1840 text. All three are linked via network.affects_constraints.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
