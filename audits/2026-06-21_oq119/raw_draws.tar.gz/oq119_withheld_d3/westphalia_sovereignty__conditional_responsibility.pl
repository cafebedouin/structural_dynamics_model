% ============================================================================
% CONSTRAINT STORY: westphalia_sovereignty__conditional_responsibility
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2025-01-01
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_westphalia_sovereignty__conditional_responsibility, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: westphalia_sovereignty__conditional_responsibility
 *   human_readable: Responsibility to Protect Doctrine (R2P) - Conditional Sovereignty Reading
 *   domain: international_law/political_theory/state_systems
 *
 * SUMMARY:
 *   The Responsibility to Protect (R2P) doctrine emerged after 1990s mass
 *   atrocities, codifying the principle that sovereignty is conditional on
 *   protecting populations from genocide, ethnic cleansing, war crimes, and
 *   crimes against humanity. Under this reading, states that fail this
 *   responsibility forfeit territorial inviolability, and the international
 *   community gains authority to intervene. The constraint is CLAIMED as
 *   tangled_rope: genuine coordination function (preventing mass atrocities
 *   where domestic structures fail) coupled with asymmetric extraction
 *   (discretionary enforcement concentrated in powerful states, used
 *   selectively based on intervener interests). The metrics describe
 *   substantially extractive operation with rising theater and suppression
 *   over time—the engine measures claim/metric alignment; the divergence is
 *   the data point.
 *
 * KEY AGENTS:
 *   - humanitarian_intervention_coalitions: Agenda-setters (institutional/arbitrage) — NATO, coalition forces; define atrocity thresholds, conduct interventions, collect expanded mandate for force projection
 *   - global_governance_institutions: Agenda-setters (institutional/arbitrage) — UN bodies, ICC; codify doctrine, authorize interventions, gain adjudicative authority over sovereignty itself
 *   - populations_under_atrocity_threat: Beneficiaries (powerless/trapped) — civilians facing mass violence; gain potential protection unavailable under absolute sovereignty
 *   - targeted_regimes: Payers (institutional/constrained) — governments adjudicated as failing protection duty; face intervention, regime change, sovereignty revocation
 *   - border_case_states: Payers (organized/constrained) — states near but not clearly over atrocity thresholds; live under permanent intervention threat, pay compliance costs
 *   - non_western_regional_powers: Payers (institutional/constrained) — perceive R2P as Western adjudicative authority over sovereignty; excluded from legitimacy discourse
 *   - permanent_council_members: Beneficiaries (institutional/arbitrage) — gain selective enforcement: invoke against rivals, block when clients targeted
 *   - international_law_scholars: Observers (analytical/analytical) — track invocation patterns, threshold drift, correlation with intervener interests
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(westphalia_sovereignty__conditional_responsibility, 0.68).
domain_priors:suppression_score(westphalia_sovereignty__conditional_responsibility, 0.72).
domain_priors:theater_ratio(westphalia_sovereignty__conditional_responsibility, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, extractiveness, 0.68).
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, suppression_requirement, 0.72).
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, resistance, 0.71).

% --- Constraint claim ---
narrative_ontology:constraint_claim(westphalia_sovereignty__conditional_responsibility, tangled_rope).
narrative_ontology:human_readable(westphalia_sovereignty__conditional_responsibility, "Responsibility to Protect Doctrine (R2P) - Conditional Sovereignty Reading").
narrative_ontology:topic_domain(westphalia_sovereignty__conditional_responsibility, "international_law/political_theory/state_systems").

domain_priors:requires_active_enforcement(westphalia_sovereignty__conditional_responsibility).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(westphalia_sovereignty__conditional_responsibility, 'b883b319-6757-470e-a9ea-dac21e0ea9cb').
narrative_ontology:cs_kernel_codification('b883b319-6757-470e-a9ea-dac21e0ea9cb', formalized).
narrative_ontology:cs_authority_grounding('b883b319-6757-470e-a9ea-dac21e0ea9cb', distributed).
narrative_ontology:cs_reading_relation('b883b319-6757-470e-a9ea-dac21e0ea9cb', westphalia_sovereignty__absolute_non_intervention, forecloses).
narrative_ontology:cs_reading_relation('b883b319-6757-470e-a9ea-dac21e0ea9cb', westphalia_sovereignty__graded_sovereignty, coexists_with).
narrative_ontology:cs_axiom('b883b319-6757-470e-a9ea-dac21e0ea9cb', foundational, sovereignty_conditional_on_protection).
narrative_ontology:cs_axiom_status(sovereignty_conditional_on_protection, holdable).
narrative_ontology:cs_axiom_grounding('b883b319-6757-470e-a9ea-dac21e0ea9cb', sovereignty_conditional_on_protection, deontological).
narrative_ontology:cs_axiom('b883b319-6757-470e-a9ea-dac21e0ea9cb', foundational, international_community_protective_authority).
narrative_ontology:cs_axiom_status(international_community_protective_authority, holdable).
narrative_ontology:cs_axiom_grounding('b883b319-6757-470e-a9ea-dac21e0ea9cb', international_community_protective_authority, conventional).
narrative_ontology:cs_axiom('b883b319-6757-470e-a9ea-dac21e0ea9cb', secondary, atrocity_prevention_supersedes_non_intervention).
narrative_ontology:cs_axiom_status(atrocity_prevention_supersedes_non_intervention, holdable).
narrative_ontology:cs_axiom_grounding('b883b319-6757-470e-a9ea-dac21e0ea9cb', atrocity_prevention_supersedes_non_intervention, deontological).
narrative_ontology:cs_reference_frame('b883b319-6757-470e-a9ea-dac21e0ea9cb', post_westphalian_humanitarian_order).
narrative_ontology:cs_drift_state('b883b319-6757-470e-a9ea-dac21e0ea9cb', contemporary_multipolar_contestation, gap(authority_erosion, substantial, false)).
narrative_ontology:cs_created_at('b883b319-6757-470e-a9ea-dac21e0ea9cb', '').
narrative_ontology:cs_kernel_id(westphalia_sovereignty__conditional_responsibility, westphalia_sovereignty).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, humanitarian_intervention_coalitions).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, global_governance_institutions).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, populations_under_atrocity_threat).
narrative_ontology:constraint_victim(westphalia_sovereignty__conditional_responsibility, targeted_regimes).
narrative_ontology:constraint_victim(westphalia_sovereignty__conditional_responsibility, border_case_states).
narrative_ontology:constraint_victim(westphalia_sovereignty__conditional_responsibility, non_western_regional_powers).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, permanent_council_members).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__conditional_responsibility, universal_human_rights_supremacy).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__conditional_responsibility, international_community_protective_authority).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Military alliances and coalitions that gain authorization to intervene in sovereign states when atrocity thresholds are invoked. They define operational criteria for 'mass atrocities,' conduct threat assessments, and execute interventions. Collect expanded mandate for force projection justified as humanitarian protection rather than conquest. Control both the adjudication machinery and the enforcement capacity.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, humanitarian_intervention_coalitions, agenda_setter,
    institutional, generational, arbitrage, global).

% International bodies that codify R2P doctrine, authorize interventions, and gain expanded jurisdiction over domestic state conduct. They set the atrocity threshold, certify failures to protect, and legitimate external interference. Benefit from expanded authority to adjudicate sovereignty itself rather than merely mediating between sovereigns.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, global_governance_institutions, agenda_setter,
    institutional, civilizational, arbitrage, global).
narrative_ontology:stakeholder_secondary_role(westphalia_sovereignty__conditional_responsibility, global_governance_institutions, beneficiary).

% Civilian populations facing genocide, ethnic cleansing, crimes against humanity, or war crimes whose own states cannot or will not protect them. Gain potential external protection that would be unavailable under absolute sovereignty norms. Bear the costs of intervention warfare (displacement, collateral harm, post-intervention instability) alongside the benefits of stopped atrocities.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, populations_under_atrocity_threat, beneficiary,
    powerless, immediate, trapped, local).

% Governments adjudicated as failing their protection responsibilities and thereby forfeiting territorial inviolability. Face military intervention, regime change, or coercive sanctions justified under R2P. Their sovereignty claim is conditionally revoked by external authorities. Exit requires either meeting protection standards set by intervening powers or surviving intervention attempts.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, targeted_regimes, payer,
    institutional, biographical, constrained, national).

% States with internal conflicts, ethnic tensions, or repressive governance that approach but do not clearly cross atrocity thresholds. Live under permanent threat that their domestic conduct could trigger external intervention. Pay compliance costs to remain below intervention thresholds and face uncertainty about where the line is drawn. The doctrine's vagueness functions as ongoing suppression of domestic autonomy.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, border_case_states, payer,
    organized, generational, constrained, national).

% States with regional security interests and historical experience of colonial intervention. Perceive R2P as Western powers claiming adjudicative authority over sovereignty itself, with 'humanitarian' justification recycling imperial prerogatives. Pay through constrained regional action and loss of sovereign equality doctrine. Their objections are systematically excluded from R2P legitimacy discourse as defending atrocities rather than defending sovereignty.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, non_western_regional_powers, payer,
    institutional, generational, constrained, continental).
narrative_ontology:stakeholder_secondary_role(westphalia_sovereignty__conditional_responsibility, non_western_regional_powers, excluded).

% States with veto authority over intervention authorization. Gain selective enforcement capacity: can invoke R2P against rivals while blocking it when their own clients are targeted. The doctrine's codification expands their authority to legitimate or block force while their veto exempts them from its application.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, permanent_council_members, beneficiary,
    institutional, civilizational, arbitrage, global).

% Analyze whether R2P represents genuine norm evolution, selective enforcement masking power projection, or both. Track invocation patterns, threshold drift, and correlation between intervention decisions and intervener strategic interests. Their analysis reveals the doctrine's dual character but does not adjudicate between coordination and extraction readings.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, international_law_scholars, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Solves a genuine collective action problem: provides international legal framework for stopping mass atrocities when domestic sovereignty structures have failed or turned predatory, where absolute sovereignty doctrine would leave populations unprotected.
% TRANSFER_FUNCTION: Moves adjudicative authority over sovereignty itself from states to international institutions; moves legitimacy for military intervention from self-defense to humanitarian protection; concentrates enforcement discretion in powerful states with intervention capacity.
% ABSENT_VOICES: States that have experienced colonial or imperial intervention under humanitarian pretexts; regional powers excluded from intervention authorization processes; post-colonial theorists who read R2P as sovereignty hierarchy dressed in protection language. They are structurally excluded from R2P legitimacy discourse—objections are framed as defending atrocities rather than defending equal sovereignty.
% DISAPPEARANCE_RATIONALE: If R2P doctrine vanished overnight, atrocity prevention would revert to absolute sovereignty framework; states facing internal conflict would regain territorial inviolability; intervention coalitions would lose humanitarian legitimacy cover; global governance institutions would lose adjudicative authority over domestic conduct; border-case states would escape compliance pressure. The international system would reorganize around harder sovereignty boundaries.
% FOUNDING_PROBLEM: The Rwandan genocide and Balkan ethnic cleansing: situations where territorial sovereignty shielded mass atrocities from external intervention, and absolute non-intervention doctrine left civilian populations with no protection when their own states became predators.
% FOUNDING_PROBLEM_CORROBORATION: International criminal tribunals, genocide scholars, and human rights NGOs attest the founding problem remains live, citing ongoing atrocity situations. Post-colonial legal scholars and non-Western regional powers attest the doctrine's application is selective: invoked against weak states, blocked when great powers or their clients are perpetrators, suggesting the founding problem is instrumentalized rather than solved. Independent analysis of intervention patterns supports selective enforcement reading.
narrative_ontology:disappearance_verdict(westphalia_sovereignty__conditional_responsibility, world_rearranges).
narrative_ontology:founding_problem_status(westphalia_sovereignty__conditional_responsibility, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(westphalia_sovereignty__conditional_responsibility, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(westphalia_sovereignty__conditional_responsibility, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(westphalia_sovereignty__conditional_responsibility_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(westphalia_sovereignty__conditional_responsibility, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(westphalia_sovereignty__conditional_responsibility_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is high (0.68) because enforcement is selective: R2P is invoked against weak states but blocked when great powers or their clients perpetrate atrocities, revealing discretionary application rather than universal protection principle. Suppression is higher (0.72) because the doctrine's vague thresholds and centralized adjudication create permanent constraint on border-case states' domestic autonomy—they cannot know where the line is and must comply preemptively. Theater ratio is moderate (0.42) and rising: genuine atrocity prevention function coexists with growing emphasis on legitimacy performance over protection outcomes (lengthy authorization debates while atrocities continue, post-intervention state-building theater, selective humanitarian concern). Accessibility collapse is moderate (0.48) because alternatives persist: absolute sovereignty remains defensible, regional security arrangements offer competing frameworks, and non-intervention doctrine remains invoked by many states. Resistance is high (0.71) because non-Western powers actively contest R2P as sovereignty hierarchy, targeted states resist intervention, and post-colonial scholars identify it as imperial continuity. The measurement series shows extraction accumulation (0.55→0.68), theater drift (0.28→0.42), and enforcement intensification (0.58→0.72) over the doctrine's operational history—coordination function remains but extractive overhead increases as enforcement patterns reveal selectivity.
 *
 * PERSPECTIVAL GAP:
 *   The agenda-setter seats (coalitions, institutions) and payer seats (targeted regimes, border-case states, regional powers) should compute dramatically different types. From the intervention coalition seat, R2P is coordination with legitimate authority delegation—expanding protective mandate where domestic structures fail. From the targeted regime seat, the same structure operates as discretionary extraction—sovereignty revocation based on selective threshold application. From the border-case state seat, it is ongoing suppression—permanent compliance pressure under vague criteria. From the non-Western regional power seat, it is sovereignty hierarchy—Western powers claiming adjudicative authority they exempt themselves from. The engine computes this divergence from power/exit/scope differentials; the authored claim does not resolve it.
 *
 * DIRECTIONALITY LOGIC:
 *   Intervention coalitions and global governance institutions are structural beneficiaries: they gain expanded authority (adjudicative over sovereignty, operational for force projection) that accrues whether or not protection succeeds. Populations under atrocity threat are genuine beneficiaries when protection is delivered but bear intervention costs; their d is low because the constraint creates protection possibility unavailable under absolute sovereignty. Targeted regimes are clear targets (d near 1.0): they lose sovereignty without consent based on external adjudication. Border-case states are also targets: they pay ongoing compliance costs under threat ambiguity. Non-Western regional powers pay through constrained action and loss of sovereign equality—their d is high because the doctrine extracts deference to Western-centered adjudication. Permanent council members sit near beneficiary end: veto power gives them arbitrage over enforcement while exempting them from application.
 *
 * MANDATROPHY ANALYSIS:
 *   R2P is NOT pure extraction masking as coordination (snare) because the atrocity-prevention function is real: interventions have stopped ongoing mass violence in some cases, and the doctrine creates international legal framework previously absent. It is NOT pure coordination (rope) because enforcement is demonstrably selective based on intervener strategic interests rather than atrocity severity alone, and adjudicative authority concentrates in powerful states. The tangled_rope classification captures both: genuine collective action problem (stopping atrocities when domestic sovereignty fails) solved through a structure that also enables asymmetric extraction (discretionary enforcement, sovereignty hierarchy, expanded intervention mandate). The coordination function prevents mislabeling it as pure snare; the extraction pattern prevents mislabeling it as pure rope. Mandatrophy resolution: the doctrine's dual character is structural, not observer-dependent.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    threshold_determinacy,
    'Are the atrocity thresholds triggering sovereignty forfeiture determinate enough to distinguish genuine protection from discretionary intervention, or is threshold vagueness itself part of the extraction mechanism?',
    'Systematic analysis of invocation patterns: if intervention decisions correlate more strongly with intervener strategic interests than with atrocity severity (controlling for intervention feasibility), thresholds are functioning as post-hoc legitimation rather than ex-ante criteria.',
    'If thresholds are genuinely determinate, selective enforcement is a compliance gap that could be closed; if vagueness is structural, the coordination and extraction functions are inseparable and the constraint is permanently tangled.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(threshold_determinacy, empirical, 'Whether atrocity thresholds are determinate criteria or discretionary tools').

omega_variable(
    universal_vs_selective_enforcement,
    'Is selective enforcement a deviation from R2P''s coordination function (fixable by expanding enforcement capacity or political will), or is selective enforcement intrinsic to the structure (powerful states gain authority they will only exercise when aligned with their interests)?',
    'Observation of enforcement against powerful states or their clients: if R2P is never invoked when permanent council members or their close allies perpetrate atrocities, selectivity is structural; if invoked in such cases with institutional resistance, selectivity is a political constraint on the coordination function.',
    'If selectivity is intrinsic, the extraction component cannot be separated from coordination without fundamentally restructuring adjudicative authority. If selectivity is contingent political failure, the coordination function could be preserved while reducing extraction.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(universal_vs_selective_enforcement, conceptual, 'Whether selective enforcement is structural or contingent on current power distribution').

omega_variable(
    protection_vs_sovereignty_hierarchy,
    'Does R2P instantiate universal protection principles applied conditionally to all states, or does it instantiate sovereignty hierarchy where powerful states claim adjudicative authority over weaker states they exempt themselves from?',
    'Examination of whether R2P doctrine or practice includes accountability mechanisms for interveners'' own atrocities or failures: if powerful states accept reciprocal vulnerability to R2P authorization against them, universal principle reading is supported; if they systematically block reciprocal application, hierarchy reading is supported.',
    'Universal principle reading supports coordination frame (extraction is deviation); hierarchy reading supports that extraction is the primary function with genuine protection as secondary effect. This determines whether the constraint is primarily tangled_rope or primarily snare with coordination theater.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(protection_vs_sovereignty_hierarchy, conceptual, 'Whether R2P is universal principle or sovereignty hierarchy').

omega_variable(
    committer_frame_kernel_reading,
    'Is this constraint (conditional_responsibility) one reading of a contested kernel (Westphalian sovereignty), or is it THE correct understanding with other positions being rationalizations of particular interests?',
    'Recognition that sovereignty organization admits multiple coherent framings: absolute sovereignty solves colonial intervention problem but creates atrocity shield; conditional sovereignty solves atrocity shield but creates intervention discretion risk; graded sovereignty attempts to thread between them. Each reading instantiates different constraints with different beneficiary/victim structures.',
    'If this is one reading among several, the classification applies to THIS constraint (conditional sovereignty as implemented through R2P) and sibling readings remain valid alternatives. If this is THE correct reading, absolute and graded readings are false consciousness of those with interests in alternative distributions of authority.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(committer_frame_kernel_reading, conceptual, 'Whether conditional sovereignty is one reading or the correct understanding of sovereignty itself').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(westphalia_sovereignty__conditional_responsibility, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(west_tr_t0, westphalia_sovereignty__conditional_responsibility, theater_ratio, 0, 0.28).
narrative_ontology:measurement_basis(west_tr_t0, observed).
narrative_ontology:measurement(west_tr_t5, westphalia_sovereignty__conditional_responsibility, theater_ratio, 5, 0.32).
narrative_ontology:measurement_basis(west_tr_t5, observed).
narrative_ontology:measurement(west_tr_t10, westphalia_sovereignty__conditional_responsibility, theater_ratio, 10, 0.36).
narrative_ontology:measurement_basis(west_tr_t10, observed).
narrative_ontology:measurement(west_tr_t15, westphalia_sovereignty__conditional_responsibility, theater_ratio, 15, 0.39).
narrative_ontology:measurement_basis(west_tr_t15, observed).
narrative_ontology:measurement(west_tr_t20, westphalia_sovereignty__conditional_responsibility, theater_ratio, 20, 0.41).
narrative_ontology:measurement_basis(west_tr_t20, observed).
narrative_ontology:measurement(west_tr_t25, westphalia_sovereignty__conditional_responsibility, theater_ratio, 25, 0.42).
narrative_ontology:measurement_basis(west_tr_t25, observed).

% Extraction over time
narrative_ontology:measurement(west_be_t0, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 0, 0.55).
narrative_ontology:measurement_basis(west_be_t0, observed).
narrative_ontology:measurement(west_be_t5, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 5, 0.59).
narrative_ontology:measurement_basis(west_be_t5, observed).
narrative_ontology:measurement(west_be_t10, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 10, 0.63).
narrative_ontology:measurement_basis(west_be_t10, observed).
narrative_ontology:measurement(west_be_t15, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 15, 0.66).
narrative_ontology:measurement_basis(west_be_t15, observed).
narrative_ontology:measurement(west_be_t20, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 20, 0.67).
narrative_ontology:measurement_basis(west_be_t20, observed).
narrative_ontology:measurement(west_be_t25, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 25, 0.68).
narrative_ontology:measurement_basis(west_be_t25, observed).

% Suppression requirement over time
narrative_ontology:measurement(west_su_t0, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 0, 0.58).
narrative_ontology:measurement_basis(west_su_t0, observed).
narrative_ontology:measurement(west_su_t5, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 5, 0.62).
narrative_ontology:measurement_basis(west_su_t5, observed).
narrative_ontology:measurement(west_su_t10, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 10, 0.66).
narrative_ontology:measurement_basis(west_su_t10, observed).
narrative_ontology:measurement(west_su_t15, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 15, 0.69).
narrative_ontology:measurement_basis(west_su_t15, observed).
narrative_ontology:measurement(west_su_t20, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 20, 0.71).
narrative_ontology:measurement_basis(west_su_t20, observed).
narrative_ontology:measurement(west_su_t25, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 25, 0.72).
narrative_ontology:measurement_basis(west_su_t25, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(westphalia_sovereignty__conditional_responsibility, enforcement_mechanism).
narrative_ontology:boltzmann_floor_override(westphalia_sovereignty__conditional_responsibility, 0.12).
narrative_ontology:affects_constraint(westphalia_sovereignty__conditional_responsibility, westphalia_sovereignty__absolute_non_intervention).
narrative_ontology:affects_constraint(westphalia_sovereignty__conditional_responsibility, westphalia_sovereignty__graded_sovereignty).
narrative_ontology:affects_constraint(westphalia_sovereignty__conditional_responsibility, humanitarian_intervention_authorization).
narrative_ontology:affects_constraint(westphalia_sovereignty__conditional_responsibility, international_criminal_jurisdiction).

% DUAL FORMULATION NOTE:
% Part of Westphalian sovereignty kernel family with absolute_non_intervention and graded_sovereignty readings. Each reading produces different ε values (this reading: 0.68 extraction due to selective enforcement; absolute reading: lower extraction, higher suppression of atrocity response; graded reading: different beneficiary structure with capacity-assessment machinery). Readings linked via network.affects_constraints; decomposition documented in omega_variable committer_frame_kernel_reading.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
