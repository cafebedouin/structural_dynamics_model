% ============================================================================
% CONSTRAINT STORY: westphalia_sovereignty__absolute_non_intervention
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-12
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_westphalia_sovereignty__absolute_non_intervention, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: westphalia_sovereignty__absolute_non_intervention
 *   human_readable: Westphalian Absolute Non-Intervention Sovereignty
 *   domain: international_law/political_theory/state_systems
 *
 * SUMMARY:
 *   The Westphalian absolute non-intervention reading treats state
 *   sovereignty as categorical territorial inviolability: external
 *   interference in domestic affairs is per se illegitimate regardless of
 *   what occurs inside the territory. This reading crystallized from the 1648
 *   Peace of Westphalia, which ended religious wars by establishing mutual
 *   non-interference in internal governance. The constraint coordinates
 *   interstate expectations (each state accepts others' domestic monopoly in
 *   exchange for its own) but also transfers immunity from populations
 *   suffering state violence to the regimes perpetrating it. Over the
 *   interval measured, the coordination function's share has declined
 *   (theater_ratio rising from 0.28 to 0.48) as alternative
 *   norms—Responsibility to Protect, international criminal law—have grown,
 *   making the absolute barrier's persistence increasingly dependent on
 *   active diplomatic defense by authoritarian regimes and major powers
 *   rather than on functional necessity. The claimed type is tangled_rope
 *   (genuine coordination + asymmetric extraction + active enforcement); the
 *   metrics describe substantially extractive operation with rising theater,
 *   meeting strong resistance from excluded populations and humanitarian
 *   advocates.
 *
 * KEY AGENTS:
 *   - authoritarian_state_elites: Primary beneficiaries (institutional/constrained) — collect territorial immunity, invoke doctrine to deflect accountability for internal repression
 *   - major_powers_with_territorial_disputes: Beneficiaries and agenda-setters (institutional/arbitrage) — defend absolute reading in international forums to protect allied regimes and contested territorial claims
 *   - populations_under_authoritarian_regimes: Primary targets (powerless/trapped) — bear regime violence with no external recourse; sovereignty barrier blocks intervention even under systematic repression
 *   - ethnic_minorities_facing_state_violence: Targets (powerless/trapped) — experience organized violence classified as internal matter; appeals deflected as interference
 *   - stateless_populations: Targets (powerless/trapped) — fall through the gap: no state claims them, but territorial norm prevents intervention where they reside
 *   - humanitarian_intervention_advocates: Excluded (organized/mobile) — propose conditional sovereignty norms; structurally sidelined in treaty formation
 *   - international_legal_scholars: Observers (analytical) — document the gap between absolute doctrine and emergent responsibility norms
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(westphalia_sovereignty__absolute_non_intervention, 0.71).
domain_priors:suppression_score(westphalia_sovereignty__absolute_non_intervention, 0.82).
domain_priors:theater_ratio(westphalia_sovereignty__absolute_non_intervention, 0.48).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, extractiveness, 0.71).
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 0.82).
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, theater_ratio, 0.48).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, accessibility_collapse, 0.34).
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, resistance, 0.73).

% --- Constraint claim ---
narrative_ontology:constraint_claim(westphalia_sovereignty__absolute_non_intervention, tangled_rope).
narrative_ontology:human_readable(westphalia_sovereignty__absolute_non_intervention, "Westphalian Absolute Non-Intervention Sovereignty").
narrative_ontology:topic_domain(westphalia_sovereignty__absolute_non_intervention, "international_law/political_theory/state_systems").

domain_priors:requires_active_enforcement(westphalia_sovereignty__absolute_non_intervention).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(westphalia_sovereignty__absolute_non_intervention, '14c2c753-cda8-47d4-bdd6-8ebf6edff793').
narrative_ontology:cs_kernel_codification('14c2c753-cda8-47d4-bdd6-8ebf6edff793', formalized).
narrative_ontology:cs_authority_grounding('14c2c753-cda8-47d4-bdd6-8ebf6edff793', lineage).
narrative_ontology:cs_interpretation_layer_present('14c2c753-cda8-47d4-bdd6-8ebf6edff793').
narrative_ontology:cs_reading_relation('14c2c753-cda8-47d4-bdd6-8ebf6edff793', westphalia_sovereignty__conditional_responsibility, coexists_with).
narrative_ontology:cs_reading_relation('14c2c753-cda8-47d4-bdd6-8ebf6edff793', westphalia_sovereignty__graded_sovereignty, coexists_with).
narrative_ontology:cs_axiom('14c2c753-cda8-47d4-bdd6-8ebf6edff793', foundational, territorial_inviolability_categorical).
narrative_ontology:cs_axiom_status(territorial_inviolability_categorical, holdable).
narrative_ontology:cs_axiom_grounding('14c2c753-cda8-47d4-bdd6-8ebf6edff793', territorial_inviolability_categorical, conventional).
narrative_ontology:cs_axiom('14c2c753-cda8-47d4-bdd6-8ebf6edff793', secondary, domestic_jurisdiction_unreviewable).
narrative_ontology:cs_axiom_status(domestic_jurisdiction_unreviewable, holdable).
narrative_ontology:cs_axiom_grounding('14c2c753-cda8-47d4-bdd6-8ebf6edff793', domestic_jurisdiction_unreviewable, conventional).
narrative_ontology:cs_reference_frame('14c2c753-cda8-47d4-bdd6-8ebf6edff793', westphalian_territorial_primacy).
narrative_ontology:cs_drift_state('14c2c753-cda8-47d4-bdd6-8ebf6edff793', post_r2p_contemporary, gap(authority_erosion, substantial, false)).
narrative_ontology:cs_created_at('14c2c753-cda8-47d4-bdd6-8ebf6edff793', '').
narrative_ontology:cs_kernel_id(westphalia_sovereignty__absolute_non_intervention, westphalia_sovereignty).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__absolute_non_intervention, authoritarian_state_elites).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__absolute_non_intervention, major_powers_with_territorial_disputes).
narrative_ontology:constraint_victim(westphalia_sovereignty__absolute_non_intervention, stateless_populations).
narrative_ontology:constraint_victim(westphalia_sovereignty__absolute_non_intervention, populations_under_authoritarian_regimes).
narrative_ontology:constraint_victim(westphalia_sovereignty__absolute_non_intervention, ethnic_minorities_facing_state_violence).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__absolute_non_intervention, westphalian_territorial_primacy).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__absolute_non_intervention, state_sovereignty_absolutism).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Control domestic territory with immunity from external challenge. Invoke sovereignty doctrine to deflect scrutiny of internal repression, mass displacement, or atrocity crimes. The doctrine provides legitimacy cover for conduct that would otherwise invite intervention or sanctions. Their tenure depends on maintaining territorial monopoly without external accountability.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, authoritarian_state_elites, beneficiary,
    institutional, biographical, constrained, national).

% Defend the absolute reading in international forums to preserve their own territorial claims and forestall intervention in allied regimes. They benefit from mutual non-interference norms that insulate contested border regions, occupied territories, or separatist conflicts from external legal challenge. They shape treaty language and Security Council resolutions to harden the non-intervention barrier.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, major_powers_with_territorial_disputes, beneficiary,
    institutional, generational, arbitrage, global).
narrative_ontology:stakeholder_secondary_role(westphalia_sovereignty__absolute_non_intervention, major_powers_with_territorial_disputes, agenda_setter).

% Bear the cost of regime violence with no recourse to external protection. The sovereignty barrier makes international intervention legally and politically prohibitive even when facing systematic repression, torture, or forced displacement. Their suffering is classified as an internal matter. Exit means refugee flight, often blocked by the same territorial control the doctrine protects.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, populations_under_authoritarian_regimes, payer,
    powerless, biographical, trapped, national).

% Experience organized violence—ethnic cleansing, cultural suppression, discriminatory legal regimes—while sovereignty doctrine blocks external accountability. When they appeal to international bodies, their claims are deflected as interference in domestic jurisdiction. The absolute reading treats their protection as subordinate to territorial inviolability.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, ethnic_minorities_facing_state_violence, payer,
    powerless, generational, trapped, regional).

% Exist outside the state system's protection entirely. No state claims them, so no sovereignty norm shields them; but the same norm prevents intervention in the territory where they reside. They fall through the gap: the doctrine protects the territorial state's authority to exclude them without protecting their rights.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, stateless_populations, payer,
    powerless, generational, trapped, regional).

% Argue for Responsibility to Protect norms and conditional sovereignty but are structurally sidelined in treaty formation and Security Council practice. Their proposed doctrines—intervention to stop genocide, atrocity prevention mandates—are rejected as incompatible with absolute territorial inviolability. They document atrocities that the reading classifies as non-justiciable.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, humanitarian_intervention_advocates, excluded,
    organized, generational, mobile, global).

% Analyze the doctrine's treaty history, opinio juris, and state practice. They note the gap between codified absolute non-interference and emergent responsibility norms, track when the absolute reading is invoked versus when it is selectively breached, and document the populations excluded from its protection.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, international_legal_scholars, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Coordinates expectations among states about territorial jurisdiction: each state accepts others' domestic authority in exchange for its own, reducing interstate conflict over internal governance and establishing stable boundaries for diplomatic recognition and treaty obligation.
% TRANSFER_FUNCTION: Transfers legal immunity from international accountability from populations suffering state violence to the regimes exercising that violence, by classifying atrocities as matters of domestic jurisdiction beyond external legal reach.
% ABSENT_VOICES: Populations facing state-organized violence, ethnic minorities under discriminatory regimes, stateless persons, and humanitarian advocates who would argue for intervention thresholds are structurally excluded from the interstate system that authors and enforces the norm. Their objections are classified as interference rather than valid claims.
% DISAPPEARANCE_RATIONALE: If the absolute barrier vanished, regimes currently insulated from accountability would face intervention pressure or criminal referral; major powers would lose the mutual non-interference cover that protects allied authoritarian clients; humanitarian law would reorganize around protection thresholds rather than territorial primacy; populations currently trapped under abusive regimes would gain external recourse.
% FOUNDING_PROBLEM: Post-Thirty Years War Europe: interstate religious warfare was devastating and boundless; no stable expectation about where one sovereign's authority ended and another's began; confessional conflicts repeatedly escalated into continent-wide violence.
% FOUNDING_PROBLEM_CORROBORATION: The founding problem—boundless confessional war threatening state survival—is extinct per the historical record: modern interstate violence is not organized along religious lines, and territorial boundaries are globally stabilized through recognition regimes and treaty law. International legal scholars and historians attest the Westphalian settlement solved its original problem by the 18th century. Authoritarian regimes and major powers with territorial disputes attest the problem remains live, but their attestation is self-serving: they are the primary beneficiaries of the absolute reading's persistence, and no external corroboration supports the claim that contemporary interstate stability depends on insulating domestic atrocities from accountability.
narrative_ontology:disappearance_verdict(westphalia_sovereignty__absolute_non_intervention, world_rearranges).
narrative_ontology:founding_problem_status(westphalia_sovereignty__absolute_non_intervention, dead).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(westphalia_sovereignty__absolute_non_intervention, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(westphalia_sovereignty__absolute_non_intervention, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(westphalia_sovereignty__absolute_non_intervention_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(westphalia_sovereignty__absolute_non_intervention, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(westphalia_sovereignty__absolute_non_intervention_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is high (0.71) because the doctrine immunizes conduct—torture, ethnic cleansing, forced displacement—that populations would reject if given external recourse; it operates by denying standing to the victims. Suppression is higher still (0.82) because persistence depends on active enforcement: major powers block Security Council referrals, veto humanitarian intervention proposals, and suppress competing norms in treaty negotiations. Theater is moderate and rising (0.48 at interval end): the coordination story—'territorial stability requires mutual non-interference'—was functional in post-Westphalian Europe but is increasingly displaced by the extractive reality (insulating authoritarian regimes from accountability); a growing share of diplomatic activity defends the doctrine rather than relying on it. Accessibility_collapse is moderate-low (0.34): alternative norms (R2P, ICC jurisdiction, sanctions regimes) persist as live options and gain traction in international discourse, even when blocked in practice. Resistance is high (0.73): populations under authoritarian control, humanitarian advocates, and smaller states excluded from Security Council power actively contest the absolute reading, producing sustained international legal debate. The measurement series tracks drift over four decades: extraction accumulated as the founding problem (confessional war) became obsolete and the doctrine's beneficiaries shifted from all states symmetrically to authoritarian regimes asymmetrically; theater rose as coordination justification weakened; suppression intensified as resistance mounted.
 *
 * PERSPECTIVAL GAP:
 *   From the agenda-setter seats (major powers defending the doctrine), the constraint is necessary coordination preventing chaotic interstate intervention and preserving the legal architecture of mutual recognition. From the powerless/trapped target seats (populations suffering state violence), the same structure operates as enforced extraction—their protection is sacrificed to maintain regime immunity, and the sovereignty norm is the mechanism of that sacrifice. The engine computes this divergence from the structural asymmetry: beneficiaries collect immunity with arbitrage or constrained exit; victims bear violence with trapped exit and no recourse.
 *
 * DIRECTIONALITY LOGIC:
 *   Authoritarian state elites and major powers with territorial disputes are structural beneficiaries: they collect immunity (d near 0.1–0.2, low effective extraction). Populations under authoritarian regimes, ethnic minorities facing state violence, and stateless populations are the targets: the constraint extracts their protection and transfers it to territorial monopolists (d near 0.9–0.95, high effective extraction, trapped exit amplifies). Humanitarian intervention advocates are excluded rather than coordinated—their proposed threshold norms would dissolve the absolute barrier, so the doctrine's enforcement machinery is organized to sideline them. Analytical observers see the full structure.
 *
 * MANDATROPHY ANALYSIS:
 *   The founding problem (boundless confessional war) is dead per the historical record, yet the constraint persists with intensifying enforcement. The R5 genealogy mismatch (founding_problem_status: dead + disappearance_verdict: world_rearranges) flags capture: the arrangement is maintained not because the original coordination problem remains live but because current beneficiaries profit from its persistence. Authoritarian elites and major powers with territorial disputes extract immunity from accountability; the populations who would be protected by conditional sovereignty norms are structurally excluded from the interstate system that authors the doctrine. The classification challenge is distinguishing the genuine coordination function (interstate stability, mutual recognition) from the extractive overlay (insulating atrocities). The tangled_rope claim asserts both are present and inseparable under active enforcement; the metrics support substantial extraction riding on decaying coordination.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    coordination_extraction_separability,
    'Is the interstate coordination function (territorial stability, mutual recognition) structurally separable from the immunity-transfer function (insulating domestic atrocities from accountability)?',
    'Natural experiment from norm evolution: if conditional sovereignty regimes (R2P, ICC jurisdiction) maintain interstate stability while opening intervention thresholds, the functions are separable. If intervention norms destabilize recognition and treaty compliance, they are inseparable.',
    'If separable, the extractive component (immunity for atrocities) is parasitic on genuine coordination and could be removed without collapsing the territorial order. If inseparable, measured extraction is the inherent cost of coordination. Determines whether tangled_rope or rope is structurally accurate.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(coordination_extraction_separability, empirical, 'Whether coordination and extraction components are structurally separable.').

omega_variable(
    alternative_reading_displacement,
    'This is one reading of a contested kernel. The conditional_responsibility and graded_sovereignty readings offer alternative framings of when intervention is legitimate. Is the absolute reading''s persistence due to functional necessity or beneficiary capture?',
    'Cross-reading comparison: track which readings are invoked by which state actors in which contexts. If authoritarian regimes invoke absolute inviolability while powerful democracies invoke graded capacity when intervening, the reading serves beneficiary interests rather than universal coordination. If all states apply one reading consistently, it reflects shared functional logic.',
    'If selective invocation, the absolute reading is an extractive tool maintained by specific beneficiaries. If universal application, it reflects genuine coordination necessity. Informs whether the constraint is better modeled as rope (coordination-dominant) or snare (extraction-dominant with coordination cover).',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(alternative_reading_displacement, empirical, 'Whether the absolute reading''s persistence reflects functional necessity or beneficiary capture across competing kernel readings.').

omega_variable(
    founding_problem_obsolescence,
    'The founding problem (confessional war threatening state survival) is historically extinct. Does contemporary interstate stability depend on the absolute barrier, or does it persist for other reasons?',
    'Counterfactual analysis: examine state practice in eras when conditional intervention norms were stronger (decolonization, post-Cold War) versus when absolute sovereignty was reasserted. If stability held under conditional norms, the absolute barrier is not structurally necessary for coordination.',
    'If the founding problem is genuinely obsolete and stability persists without the absolute barrier, the constraint is a zombie—maintained by beneficiaries whose interests diverged from its original function. This would support mandatrophy_resolved and reclassification toward snare.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(founding_problem_obsolescence, empirical, 'Whether the absolute sovereignty barrier remains functionally necessary after its founding problem became obsolete.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(westphalia_sovereignty__absolute_non_intervention, 0, 40).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(west_tr_t0, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 0, 0.28).
narrative_ontology:measurement(west_tr_t8, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 8, 0.33).
narrative_ontology:measurement(west_tr_t16, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 16, 0.38).
narrative_ontology:measurement(west_tr_t24, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 24, 0.42).
narrative_ontology:measurement(west_tr_t32, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 32, 0.45).
narrative_ontology:measurement(west_tr_t40, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 40, 0.48).

% Extraction over time
narrative_ontology:measurement(west_be_t0, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 0, 0.52).
narrative_ontology:measurement(west_be_t8, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 8, 0.58).
narrative_ontology:measurement(west_be_t16, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 16, 0.63).
narrative_ontology:measurement(west_be_t24, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 24, 0.67).
narrative_ontology:measurement(west_be_t32, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 32, 0.69).
narrative_ontology:measurement(west_be_t40, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 40, 0.71).

% Suppression requirement over time
narrative_ontology:measurement(west_su_t0, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 0, 0.68).
narrative_ontology:measurement(west_su_t8, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 8, 0.72).
narrative_ontology:measurement(west_su_t16, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 16, 0.75).
narrative_ontology:measurement(west_su_t24, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 24, 0.78).
narrative_ontology:measurement(west_su_t32, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 32, 0.8).
narrative_ontology:measurement(west_su_t40, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 40, 0.82).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(westphalia_sovereignty__absolute_non_intervention, global_infrastructure).
narrative_ontology:affects_constraint(westphalia_sovereignty__absolute_non_intervention, westphalia_sovereignty__conditional_responsibility).
narrative_ontology:affects_constraint(westphalia_sovereignty__absolute_non_intervention, westphalia_sovereignty__graded_sovereignty).

% DUAL FORMULATION NOTE:
% This constraint is one of three readings of the westphalia_sovereignty kernel. The kernel decomposes because different structural framings of sovereignty—absolute inviolability, conditional responsibility, graded capacity—produce constraints with different ε values, different beneficiary/victim structures, and different enforcement logics. The absolute_non_intervention reading (this story) treats territorial inviolability as categorical; conditional_responsibility (sibling) makes sovereignty conditional on protecting populations; graded_sovereignty (sibling) treats authority as scalar. All three readings coexist in international legal discourse; their selective invocation by state actors is the primary signal of which reading serves coordination versus extraction.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
