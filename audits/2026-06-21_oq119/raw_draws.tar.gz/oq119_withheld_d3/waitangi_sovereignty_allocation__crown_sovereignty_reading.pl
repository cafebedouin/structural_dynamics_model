% ============================================================================
% CONSTRAINT STORY: waitangi_sovereignty_allocation__crown_sovereignty_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2025-01-15
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_waitangi_sovereignty_allocation__crown_sovereignty_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: waitangi_sovereignty_allocation__crown_sovereignty_reading
 *   human_readable: Crown Sovereignty Reading of Treaty of Waitangi Article I
 *   domain: constitutional_law/indigenous_rights/post_colonial_governance
 *
 * SUMMARY:
 *   The Crown sovereignty reading treats the English text of Treaty of
 *   Waitangi Article I as ceding complete sovereignty from Māori chiefs to
 *   the British Crown, establishing Westminster parliamentary supremacy as
 *   the sole constitutional authority in New Zealand. Under this reading, the
 *   Crown exercises plenary legislative power without Māori consent
 *   requirements, allocates resources unilaterally, and subordinates Māori
 *   interests to parliamentary will. This is ONE READING of the
 *   waitangi_sovereignty_allocation kernel; sibling readings
 *   (partnership_reading, rangatiratanga_reading) instantiate different
 *   constraints from the same historical agreement. The claimed type (snare)
 *   reflects the reading's structural operation from the victim seats; the
 *   metrics describe its extractive enforcement pattern; the engine computes
 *   per-seat classifications from this structural data.
 *
 * KEY AGENTS:
 *   - Crown Government: Institutional agenda-setter (institutional/arbitrage) — exercises unconstrained legislative power, allocates resources unilaterally, benefits from parliamentary supremacy doctrine
 *   - Settler Population: Beneficiary (organized/mobile) — receives secure property and legal certainty under Crown allocation
 *   - Māori Iwi: Primary victims (organized/identity_locked) — bear land dispossession and authority subordination, cannot exit without cultural extinction
 *   - Māori Hapū: Secondary victims (moderate/identity_locked) — face more acute localized extraction, identity-locked to specific rohe
 *   - Waitangi Tribunal: Observer (institutional/constrained) — documents Crown breaches without enforcement power
 *   - Constitutional Courts: Dual-positioned (institutional/constrained) — administer the constraint while capable of analytical distance
 *   - Alternative Treaty Readings Advocates: Excluded (organized/constrained) — structurally barred from constitutional authority their readings would require
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(waitangi_sovereignty_allocation__crown_sovereignty_reading, 0.81).
domain_priors:suppression_score(waitangi_sovereignty_allocation__crown_sovereignty_reading, 0.88).
domain_priors:theater_ratio(waitangi_sovereignty_allocation__crown_sovereignty_reading, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, extractiveness, 0.81).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 0.88).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, accessibility_collapse, 0.47).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, resistance, 0.79).

% --- Constraint claim ---
narrative_ontology:constraint_claim(waitangi_sovereignty_allocation__crown_sovereignty_reading, snare).
narrative_ontology:human_readable(waitangi_sovereignty_allocation__crown_sovereignty_reading, "Crown Sovereignty Reading of Treaty of Waitangi Article I").
narrative_ontology:topic_domain(waitangi_sovereignty_allocation__crown_sovereignty_reading, "constitutional_law/indigenous_rights/post_colonial_governance").

domain_priors:requires_active_enforcement(waitangi_sovereignty_allocation__crown_sovereignty_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(waitangi_sovereignty_allocation__crown_sovereignty_reading, 'a5c03fe7-7291-4008-ad7f-775991fd72dd').
narrative_ontology:cs_kernel_codification('a5c03fe7-7291-4008-ad7f-775991fd72dd', fixed_text).
narrative_ontology:cs_authority_grounding('a5c03fe7-7291-4008-ad7f-775991fd72dd', lineage).
narrative_ontology:cs_interpretation_layer_present('a5c03fe7-7291-4008-ad7f-775991fd72dd').
narrative_ontology:cs_reading_relation('a5c03fe7-7291-4008-ad7f-775991fd72dd', waitangi_sovereignty_allocation__partnership_reading, coexists_with).
narrative_ontology:cs_reading_relation('a5c03fe7-7291-4008-ad7f-775991fd72dd', waitangi_sovereignty_allocation__rangatiratanga_reading, coexists_with).
narrative_ontology:cs_axiom('a5c03fe7-7291-4008-ad7f-775991fd72dd', foundational, complete_sovereignty_cession_1840).
narrative_ontology:cs_axiom_status(complete_sovereignty_cession_1840, holdable).
narrative_ontology:cs_axiom_grounding('a5c03fe7-7291-4008-ad7f-775991fd72dd', complete_sovereignty_cession_1840, conventional).
narrative_ontology:cs_axiom('a5c03fe7-7291-4008-ad7f-775991fd72dd', foundational, parliamentary_supremacy_unchallengeable).
narrative_ontology:cs_axiom_status(parliamentary_supremacy_unchallengeable, holdable).
narrative_ontology:cs_axiom_grounding('a5c03fe7-7291-4008-ad7f-775991fd72dd', parliamentary_supremacy_unchallengeable, conventional).
narrative_ontology:cs_axiom('a5c03fe7-7291-4008-ad7f-775991fd72dd', secondary, english_text_primacy).
narrative_ontology:cs_axiom_status(english_text_primacy, holdable).
narrative_ontology:cs_axiom_grounding('a5c03fe7-7291-4008-ad7f-775991fd72dd', english_text_primacy, conventional).
narrative_ontology:cs_reference_frame('a5c03fe7-7291-4008-ad7f-775991fd72dd', westminster_parliamentary_supremacy).
narrative_ontology:cs_drift_state('a5c03fe7-7291-4008-ad7f-775991fd72dd', contemporary_treaty_settlement_era, gap(authority_erosion, substantial, false)).
narrative_ontology:cs_created_at('a5c03fe7-7291-4008-ad7f-775991fd72dd', '').
narrative_ontology:cs_kernel_id(waitangi_sovereignty_allocation__crown_sovereignty_reading, waitangi_sovereignty_allocation).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__crown_sovereignty_reading, crown_government).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__crown_sovereignty_reading, settler_population).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__crown_sovereignty_reading, maori_iwi).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__crown_sovereignty_reading, maori_hapu).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__crown_sovereignty_reading, westminster_parliamentary_supremacy).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__crown_sovereignty_reading, unitary_crown_sovereignty).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Exercises plenary legislative power over all persons and resources within New Zealand under the sovereignty reading of Article I. Allocates land, resources, and regulatory authority without Māori consent requirement. Treats parliamentary supremacy as absolute and legally unchallengeable. Benefits structurally from unconstrained law-making power and unilateral resource disposition.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, crown_government, agenda_setter,
    institutional, generational, arbitrage, national).

% Receives secure property rights, resource access, and legal certainty under Crown allocation. Benefits from parliamentary governance treating all subjects equally without special Māori authority. Exit options include emigration or political participation within the Westminster framework. Costs are diffuse (taxation, general governance burdens) while benefits are concentrated (property security, resource access).
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, settler_population, beneficiary,
    organized, biographical, mobile, national).

% Bear systematic land alienation, resource dispossession, and subordination of traditional authority structures under Crown sovereignty doctrine. Cannot exit without abandoning ancestral lands, cultural practices, and identity as tangata whenua. Political and legal redress requires navigating Crown institutions that do not recognize tino rangatiratanga. Resistance meets state enforcement; accommodation means accepting subordinate status.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, maori_iwi, payer,
    organized, civilizational, identity_locked, national).

% Experience more acute vulnerability than iwi-level structures due to smaller scale and more localized resource base. Face direct Crown interference in customary governance, resource management, and intergenerational transmission of authority. Identity-locked by connection to specific rohe and whakapapa. No meaningful exit from Crown jurisdiction without cultural extinction.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, maori_hapu, payer,
    moderate, civilizational, identity_locked, regional).

% Investigates Crown breaches of Treaty principles but lacks binding enforcement power under the sovereignty reading. Produces historical findings documenting systematic dispossession and Crown failures, which Parliament may choose to remedy or ignore. Structurally constrained by its advisory status within the same Crown apparatus it evaluates.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, waitangi_tribunal, observer,
    institutional, generational, constrained, national).

% Interpret Treaty significance within existing constitutional law but cannot invalidate parliamentary legislation under Westminster supremacy doctrine. May recognize Treaty principles as informing statutory interpretation or common law, but lack authority to enforce Crown obligations against Parliament itself. Dual-positioned: administer the constraint while also capable of analytical distance from it.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, constitutional_courts, agenda_setter,
    institutional, generational, constrained, national).
narrative_ontology:stakeholder_secondary_role(waitangi_sovereignty_allocation__crown_sovereignty_reading, constitutional_courts, observer).

% Argue for partnership or rangatiratanga readings that would constrain Crown authority, but are structurally excluded from constitutional design. Can litigate, protest, and advocate for Treaty settlements, but cannot force Crown to recognize co-sovereignty or Māori veto over legislation. Their exclusion from constitutional authority is what the sovereignty reading exists to maintain.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, alternative_treaty_readings_advocates, excluded,
    organized, generational, constrained, national).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes singular, hierarchical legal authority for post-contact governance: one ultimate lawmaker, clear property allocation mechanisms, unified jurisdiction. Solves the coordination problem of multiple competing authority claims in contested territory.
% TRANSFER_FUNCTION: Transfers plenary legislative power, resource allocation authority, and jurisdictional control from iwi/hapū to Crown. Moves land, sovereignty rights, and governance capacity from Māori communities to Westminster parliamentary framework.
% ABSENT_VOICES: Māori signatories operating under the Māori-language text understanding (Article II retained tino rangatiratanga) are structurally excluded from the constitutional settlement. Their understanding that they ceded only kāwanatanga (governorship over settlers) while retaining full authority over their own domains is treated as historically superseded. International indigenous rights advocates and decolonial constitutional scholars are also absent from the framework's legitimation.
% DISAPPEARANCE_RATIONALE: If the Crown sovereignty reading vanished overnight and tino rangatiratanga were recognized as co-equal authority, the entire constitutional structure would reorganize: resource allocation would require Māori consent, parliamentary supremacy would yield to Treaty partnership principles, historical land claims would gain enforceable remedies, and the legal status of Crown land grants would become contestable. The New Zealand state's authority basis would fundamentally shift.
% FOUNDING_PROBLEM: Post-1840 contact era faced competing sovereignty claims, unclear property rights between British settlers and Māori, potential for ongoing violent conflict, and absence of agreed legal framework for governance and resource allocation.
% FOUNDING_PROBLEM_CORROBORATION: Crown Government attests the founding problem is resolved by the sovereignty settlement and parliamentary supremacy. Waitangi Tribunal findings, Māori iwi/hapū authorities, and international indigenous rights bodies attest the founding problem was misconstructed: the Treaty created partnership obligations that Crown unilaterally abandoned, replacing coordination with extraction. Tribunal reports and historical scholarship from outside Crown institutions document systematic Crown breaches.
narrative_ontology:disappearance_verdict(waitangi_sovereignty_allocation__crown_sovereignty_reading, world_rearranges).
narrative_ontology:founding_problem_status(waitangi_sovereignty_allocation__crown_sovereignty_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(waitangi_sovereignty_allocation__crown_sovereignty_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(waitangi_sovereignty_allocation__crown_sovereignty_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(waitangi_sovereignty_allocation__crown_sovereignty_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(waitangi_sovereignty_allocation__crown_sovereignty_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(waitangi_sovereignty_allocation__crown_sovereignty_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is high (0.81) because the reading enables systematic resource transfer and authority dispossession from identity-locked victims with no consent requirement or meaningful redress mechanism. Suppression is higher (0.88) because the constraint's persistence requires active enforcement against Māori resistance and suppression of alternative Treaty interpretations through legal and institutional mechanisms. Theater ratio is moderate (0.42): Treaty settlements and Tribunal processes are real but increasingly performative relative to continued Crown sovereignty claims — acknowledgment without structural authority transfer. Accessibility collapse is lower (0.47) because alternative readings remain contested and legally viable in other jurisdictions; resistance is high (0.79) reflecting ongoing Māori political mobilization. Measurements show extraction rising through the confiscation period (1840-1900), stabilizing at high levels through assimilation era (1900-1975), then slight moderation post-Tribunal establishment (1975-2025) as theater ratio rises.
 *
 * PERSPECTIVAL GAP:
 *   The Crown and settler seats experience this as legitimate constitutional order providing legal certainty and unified governance. The Māori seats experience the same structure as systematic extraction enforced through suppression of their Treaty understanding. The divergence is structural, not perceptual: the reading that vests plenary power in one party necessarily extracts authority from the other. The engine computes this seat-divergence from the power/exit differentials and beneficiary/victim declarations; the claimed type does not adjudicate between them.
 *
 * DIRECTIONALITY LOGIC:
 *   Crown Government is the structural beneficiary and agenda-setter: collects plenary legislative power, sets all rules, arbitrage exit (could recognize partnership principles but chooses not to) — directionality near full beneficiary. Settler population benefits from resource security and legal clarity under Crown allocation, mobile exit — directionality beneficiary-side. Māori iwi and hapū are full targets: bear dispossession, identity-locked (cannot exit without cultural extinction), powerless within Westminster framework — directionality near full target. Waitangi Tribunal and Courts are constrained institutional observers: see the full structure but operate within it. Alternative readings advocates are excluded: their structural position is defined by what this reading denies them.
 *
 * MANDATROPHY ANALYSIS:
 *   The founding problem (competing sovereignty claims, unclear property rights, potential for conflict) was real in 1840. The sovereignty reading's coordination function (singular legal authority, clear allocation rules) is also real. But the extraction function has grown beyond the coordination requirement: systematic land alienation, cultural suppression, and denial of tino rangatiratanga exceed what coordination alone required. The theater ratio trajectory shows growing performative maintenance (Tribunal processes, Treaty settlements) alongside continued sovereignty claims — acknowledgment of harm without authority transfer. The constraint operates as tangled rope from the Crown seat (coordination with extraction) and as snare from the Māori seats (extraction maintained through suppression of alternatives).
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    textual_primacy_ambiguity,
    'When English and Māori Treaty texts substantively differ on sovereignty transfer, which text governs constitutional interpretation?',
    'International treaty law and indigenous rights jurisprudence provide interpretive frameworks (contra proferentem, indigenous understanding priority in ambiguous cessions), but New Zealand constitutional law has not definitively adopted either. Resolution would require explicit parliamentary or judicial determination of textual hierarchy.',
    'If Māori text governs, tino rangatiratanga was retained and Crown sovereignty reading lacks textual foundation; if English text governs, rangatiratanga reading lacks textual foundation. If both texts are treated as authentic but contradictory, partnership reading gains support as reconciliation framework.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(textual_primacy_ambiguity, conceptual, 'Which Treaty text governs when they conflict on sovereignty transfer').

omega_variable(
    sovereignty_divisibility,
    'Is sovereignty in post-colonial context necessarily unitary and indivisible, or can Crown sovereignty and tino rangatiratanga coexist as distinct but coordinated authorities?',
    'Comparative constitutional analysis of federal systems, indigenous self-determination arrangements, and treaty-based co-sovereignty models. New Zealand would need to explicitly adopt or reject divisible sovereignty doctrine.',
    'If sovereignty is indivisible, one reading must prevail completely (likely Crown sovereignty given enforcement capacity). If sovereignty is divisible, partnership or rangatiratanga readings become constitutionally coherent and the sovereignty reading''s exclusivity claim fails.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(sovereignty_divisibility, conceptual, 'Whether sovereignty must be unitary or can be shared').

omega_variable(
    historical_consent_validity,
    'Did Māori signatories in 1840 understand themselves to be ceding complete sovereignty as the English text claims, or only kāwanatanga as the Māori text states?',
    'Historical evidence from Māori oral tradition, contemporary Māori-language accounts, missionary translator testimony, and subsequent Māori political action. Waitangi Tribunal has compiled substantial evidence; question is whether this evidence can override legal positivist interpretation.',
    'If signatories understood they were retaining tino rangatiratanga, the sovereignty reading rests on a foundational misunderstanding or deliberate misrepresentation, undermining its legitimacy claim. If they understood complete sovereignty cession despite Māori text, sovereignty reading gains historical support.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(historical_consent_validity, empirical, 'What Māori signatories understood they were agreeing to in 1840').

omega_variable(
    committer_frame_kernel_decomposition,
    'Are the three readings (sovereignty, partnership, rangatiratanga) truly distinct constraints from a single kernel, or are they irreconcilable commitments that cannot coexist even as alternatives?',
    'If the readings can be held simultaneously by different parties as live constitutional options (as currently in New Zealand), they are kernel readings. If adopting one logically forecloses the others within any coherent framework, they are competing kernels, not readings.',
    'If they are readings of one kernel, the committer frame applies and the constraint family structure is valid. If they are separate incompatible kernels, each should be modeled as an independent constraint with affects_constraints edges but not kernel_id linkage.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(committer_frame_kernel_decomposition, conceptual, 'Whether Treaty interpretations are readings of one kernel or competing kernels').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(waitangi_sovereignty_allocation__crown_sovereignty_reading, 1840, 2025).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(wait_tr_t1840, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 1840, 0.12).
narrative_ontology:measurement_basis(wait_tr_t1840, observed).
narrative_ontology:measurement(wait_tr_t1865, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 1865, 0.18).
narrative_ontology:measurement_basis(wait_tr_t1865, observed).
narrative_ontology:measurement(wait_tr_t1900, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 1900, 0.25).
narrative_ontology:measurement_basis(wait_tr_t1900, observed).
narrative_ontology:measurement(wait_tr_t1940, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 1940, 0.32).
narrative_ontology:measurement_basis(wait_tr_t1940, observed).
narrative_ontology:measurement(wait_tr_t1975, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 1975, 0.38).
narrative_ontology:measurement_basis(wait_tr_t1975, observed).
narrative_ontology:measurement(wait_tr_t2000, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 2000, 0.41).
narrative_ontology:measurement_basis(wait_tr_t2000, observed).
narrative_ontology:measurement(wait_tr_t2025, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 2025, 0.42).
narrative_ontology:measurement_basis(wait_tr_t2025, observed).

% Extraction over time
narrative_ontology:measurement(wait_be_t1840, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 1840, 0.58).
narrative_ontology:measurement_basis(wait_be_t1840, observed).
narrative_ontology:measurement(wait_be_t1865, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 1865, 0.71).
narrative_ontology:measurement_basis(wait_be_t1865, observed).
narrative_ontology:measurement(wait_be_t1900, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 1900, 0.78).
narrative_ontology:measurement_basis(wait_be_t1900, observed).
narrative_ontology:measurement(wait_be_t1940, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 1940, 0.82).
narrative_ontology:measurement_basis(wait_be_t1940, observed).
narrative_ontology:measurement(wait_be_t1975, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 1975, 0.83).
narrative_ontology:measurement_basis(wait_be_t1975, observed).
narrative_ontology:measurement(wait_be_t2000, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 2000, 0.82).
narrative_ontology:measurement_basis(wait_be_t2000, observed).
narrative_ontology:measurement(wait_be_t2025, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 2025, 0.81).
narrative_ontology:measurement_basis(wait_be_t2025, observed).

% Suppression requirement over time
narrative_ontology:measurement(wait_su_t1840, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 1840, 0.65).
narrative_ontology:measurement_basis(wait_su_t1840, observed).
narrative_ontology:measurement(wait_su_t1865, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 1865, 0.79).
narrative_ontology:measurement_basis(wait_su_t1865, observed).
narrative_ontology:measurement(wait_su_t1900, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 1900, 0.85).
narrative_ontology:measurement_basis(wait_su_t1900, observed).
narrative_ontology:measurement(wait_su_t1940, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 1940, 0.88).
narrative_ontology:measurement_basis(wait_su_t1940, observed).
narrative_ontology:measurement(wait_su_t1975, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 1975, 0.91).
narrative_ontology:measurement_basis(wait_su_t1975, observed).
narrative_ontology:measurement(wait_su_t2000, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 2000, 0.89).
narrative_ontology:measurement_basis(wait_su_t2000, observed).
narrative_ontology:measurement(wait_su_t2025, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 2025, 0.88).
narrative_ontology:measurement_basis(wait_su_t2025, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(waitangi_sovereignty_allocation__crown_sovereignty_reading, enforcement_mechanism).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__crown_sovereignty_reading, waitangi_sovereignty_allocation__partnership_reading).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__crown_sovereignty_reading, waitangi_sovereignty_allocation__rangatiratanga_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the waitangi_sovereignty_allocation kernel. The kernel decomposes into three structurally distinct constraints because their ε values differ substantially: crown_sovereignty_reading has high extraction (0.81) from identity-locked Māori victims with minimal coordination overhead; partnership_reading would have moderate extraction balanced by genuine consultation requirements; rangatiratanga_reading would have low extraction with coordination costs of parallel authority structures. These are not three perspectives on one constraint — they instantiate different constitutional arrangements with different victim sets, different enforcement costs, and different persistence mechanisms.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
