% ============================================================================
% CONSTRAINT STORY: waitangi_sovereignty_allocation__rangatiratanga_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2024-01-09
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_waitangi_sovereignty_allocation__rangatiratanga_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: waitangi_sovereignty_allocation__rangatiratanga_reading
 *   human_readable: Treaty of Waitangi Sovereignty Allocation (Rangatiratanga Reading)
 *   domain: constitutional_law/indigenous_rights/post_colonial_governance
 *
 * SUMMARY:
 *   The Treaty of Waitangi (1840) was signed in two texts with divergent
 *   allocations of authority. The Māori-language text—the only version most
 *   chiefs read—granted the Crown kāwanatanga (a borrowed term understood as
 *   governorship over settlers) while explicitly retaining tino
 *   rangatiratanga (full chiefly authority) over Māori lands, villages, and
 *   taonga. The English text claimed cession of 'sovereignty.' This
 *   constraint story models the rangatiratanga reading: the allocation Māori
 *   chiefs understood themselves to be making. The enacted constraint
 *   diverged sharply: successive Crown governments legislated plenary
 *   authority, extinguished customary title, confiscated lands, and
 *   subordinated iwi authority to parliamentary statute—creating a 180-year
 *   structure of extraction under coordination cover. KEY AGENTS (by
 *   structural relationship): - Iwi/hapū collectives: Primary targets
 *   (organized/identity_locked) — bear jurisdictional extraction through
 *   statutory override of retained authority - Crown administrative
 *   apparatus: Agenda setter (institutional/arbitrage) — administers and
 *   enforces plenary power despite bounded kāwanatanga grant - Settler
 *   colonial economy: Primary beneficiary (powerful/mobile) — operates under
 *   statutory certainty derived from Crown's institutional capture of
 *   rangatiratanga - Māori resource holders: Secondary targets
 *   (moderate/constrained) — participate in limited co-governance within
 *   Crown frameworks; pay ongoing subordination costs - Waitangi Tribunal:
 *   Observer (institutional/analytical) — documents treaty breaches without
 *   enforcement power - International indigenous rights observers: Excluded
 *   (institutional/analytical) — findings carry no domestic legal force
 *
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(waitangi_sovereignty_allocation__rangatiratanga_reading, 0.72).
domain_priors:suppression_score(waitangi_sovereignty_allocation__rangatiratanga_reading, 0.81).
domain_priors:theater_ratio(waitangi_sovereignty_allocation__rangatiratanga_reading, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, extractiveness, 0.72).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 0.81).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, accessibility_collapse, 0.34).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, resistance, 0.76).

% --- Constraint claim ---
narrative_ontology:constraint_claim(waitangi_sovereignty_allocation__rangatiratanga_reading, tangled_rope).
narrative_ontology:human_readable(waitangi_sovereignty_allocation__rangatiratanga_reading, "Treaty of Waitangi Sovereignty Allocation (Rangatiratanga Reading)").
narrative_ontology:topic_domain(waitangi_sovereignty_allocation__rangatiratanga_reading, "constitutional_law/indigenous_rights/post_colonial_governance").

domain_priors:requires_active_enforcement(waitangi_sovereignty_allocation__rangatiratanga_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(waitangi_sovereignty_allocation__rangatiratanga_reading, '9a731a7c-5e74-43ea-9e0a-b3be43a32de5').
narrative_ontology:cs_kernel_codification('9a731a7c-5e74-43ea-9e0a-b3be43a32de5', fixed_text).
narrative_ontology:cs_authority_grounding('9a731a7c-5e74-43ea-9e0a-b3be43a32de5', extraction).
narrative_ontology:cs_interpretation_layer_present('9a731a7c-5e74-43ea-9e0a-b3be43a32de5').
narrative_ontology:cs_reading_relation('9a731a7c-5e74-43ea-9e0a-b3be43a32de5', waitangi_sovereignty_allocation__crown_sovereignty_reading, forecloses).
narrative_ontology:cs_reading_relation('9a731a7c-5e74-43ea-9e0a-b3be43a32de5', waitangi_sovereignty_allocation__partnership_reading, influences).
narrative_ontology:cs_axiom('9a731a7c-5e74-43ea-9e0a-b3be43a32de5', foundational, tino_rangatiratanga_retained_as_full_sovereignty).
narrative_ontology:cs_axiom_status(tino_rangatiratanga_retained_as_full_sovereignty, holdable).
narrative_ontology:cs_axiom_grounding('9a731a7c-5e74-43ea-9e0a-b3be43a32de5', tino_rangatiratanga_retained_as_full_sovereignty, conventional).
narrative_ontology:cs_axiom('9a731a7c-5e74-43ea-9e0a-b3be43a32de5', foundational, kawanatanga_limited_to_settler_governance).
narrative_ontology:cs_axiom_status(kawanatanga_limited_to_settler_governance, holdable).
narrative_ontology:cs_axiom_grounding('9a731a7c-5e74-43ea-9e0a-b3be43a32de5', kawanatanga_limited_to_settler_governance, conventional).
narrative_ontology:cs_axiom('9a731a7c-5e74-43ea-9e0a-b3be43a32de5', secondary, maori_text_interpretive_primacy).
narrative_ontology:cs_axiom_status(maori_text_interpretive_primacy, holdable).
narrative_ontology:cs_axiom_grounding('9a731a7c-5e74-43ea-9e0a-b3be43a32de5', maori_text_interpretive_primacy, conventional).
narrative_ontology:cs_reference_frame('9a731a7c-5e74-43ea-9e0a-b3be43a32de5', maori_text_jurisdictional_boundary).
narrative_ontology:cs_drift_state('9a731a7c-5e74-43ea-9e0a-b3be43a32de5', contemporary_post_tribunal_era, gap(codification_collapse, severe, false)).
narrative_ontology:cs_created_at('9a731a7c-5e74-43ea-9e0a-b3be43a32de5', '').
narrative_ontology:cs_kernel_id(waitangi_sovereignty_allocation__rangatiratanga_reading, waitangi_sovereignty_allocation).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__rangatiratanga_reading, crown_administrative_apparatus).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__rangatiratanga_reading, settler_colonial_economy).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__rangatiratanga_reading, iwi_hapu_collectives).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__rangatiratanga_reading, maori_resource_holders).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__rangatiratanga_reading, maori_resource_holders).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__rangatiratanga_reading, westminster_parliamentary_supremacy_doctrine).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Hold multi-generational claims to lands, fisheries, forests, and culturally significant sites under tino rangatiratanga (full chiefly authority). The Māori text they signed explicitly retained this authority while ceding only kāwanatanga (governorship over settlers). In practice, successive Crown governments legislated over these domains without consent, confiscated lands, extinguished customary title through statutory declaration, and required iwi to petition the Crown for return of what was never ceded. Exit is identity-locked: the authority relationship is constitutive of iwi identity and intergenerational obligation—walking away would mean abandoning ancestors' treaty commitments and the land itself.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, iwi_hapu_collectives, payer,
    organized, civilizational, identity_locked, national).

% Administers all land tenure, resource extraction licensing, environmental regulation, and statutory allocation of rights. Treats Article I (English text: cession of sovereignty) as granting plenary legislative power, relegating Article II (Māori text: retention of rangatiratanga) to a cultural-consultation obligation rather than a jurisdictional limit. Controls treaty interpretation through courts it appoints and statutes it enacts. Can selectively engage co-governance when politically expedient; can legislate unilaterally when expedient overrides consultation cost.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, crown_administrative_apparatus, agenda_setter,
    institutional, generational, arbitrage, national).

% Operates under statutory property and resource rights granted by Crown legislation. Farming estates, forestry corporations, fishing quota holders, and mining interests all derive title from Crown grants that override or extinguish customary Māori authority. These actors are insulated from iwi jurisdiction and benefit from the Crown's institutional capture of rangatiratanga: they negotiate with a single sovereign entity (the Crown) rather than multiple iwi with independent authority over overlapping territories. High mobility: corporate assets are liquid; individual settlers can relocate if arrangements deteriorate.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, settler_colonial_economy, beneficiary,
    powerful, biographical, mobile, national).

% Individuals and whānau groups with residual interests in Māori-titled land or treaty settlement assets. Benefit from limited co-governance arrangements (e.g., fisheries quota, specific conservation co-management) won through Waitangi Tribunal processes—but these settlements operate within Crown statutory frameworks and do not restore the independent jurisdictional authority the Māori text reserved. Pay ongoing costs: land returned is often marginal or degraded; co-governance seats require operating within Crown bureaucratic norms; settlement quantum rarely reflects full historical loss. Constrained exit: can participate in Crown-structured arrangements or forego influence entirely.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, maori_resource_holders, payer,
    moderate, generational, constrained, regional).
narrative_ontology:stakeholder_secondary_role(waitangi_sovereignty_allocation__rangatiratanga_reading, maori_resource_holders, beneficiary).

% Permanent commission of inquiry established by Crown statute to investigate treaty breaches. Findings are recommendations only; Crown is not bound to implement them. The Tribunal has systematically documented Crown overreach beyond kāwanatanga into domains the Māori text reserved to rangatiratanga, but cannot compel remedies. Operates as institutional record-keeper and moral authority, documenting the gap between the Māori text's allocation and the Crown's enacted supremacy.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, waitangi_tribunal, observer,
    institutional, generational, analytical, national).

% UN bodies and regional indigenous rights mechanisms have repeatedly found Crown conduct inconsistent with UNDRIP and with the treaty text Māori actually signed. These findings carry no domestic legal force; the Crown cites parliamentary supremacy to override international obligations. Observers document systematic subordination but are excluded from enforcement mechanisms.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, international_indigenous_rights_observers, excluded,
    institutional, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: The treaty coordinated initial Crown settlement within Aotearoa by establishing a jurisdictional boundary: Māori retained tino rangatiratanga (full authority) over their lands and taonga; Crown exercised kāwanatanga (governorship) over British subjects. This solved the immediate coordination problem of defining spheres of authority without requiring either party to submit entirely to the other.
% TRANSFER_FUNCTION: In enacted practice, the arrangement transfers legislative and administrative authority over all Māori-held lands, resources, and culturally significant sites from iwi/hapū to the Crown. The transfer operates through statutory extinguishment, compulsory acquisition, and Crown assertion of plenary power—despite the Māori text explicitly retaining these domains under rangatiratanga.
% ABSENT_VOICES: International indigenous rights observers and the global decolonization framework are structurally excluded. Domestic Crown courts have rejected international law arguments, citing parliamentary supremacy. Iwi claims grounded in the Māori text are heard only within Crown-controlled forums (Tribunal, domestic courts) that cannot compel restoration of the jurisdictional authority the Māori text reserved.
% DISAPPEARANCE_RATIONALE: If this allocation vanished—if the Crown's institutional override of rangatiratanga ceased—land tenure, resource licensing, environmental regulation, and fisheries management would immediately require renegotiation with iwi as independent authorities. Statutory property rights derived from Crown grants would face jurisdictional challenge. The settler economy's single-sovereign transactional certainty would dissolve into multi-party territorial complexity. Crown administrative apparatus would lose plenary legislative power and revert to the bounded kāwanatanga role the Māori text defined.
% FOUNDING_PROBLEM: The founding problem was coordinating British settlement and trade within Aotearoa while Māori retained political authority and control over their territories. Unregulated British settlement was generating land disputes, resource conflicts, and lawlessness; Māori chiefs sought a framework to manage settler presence without ceding sovereignty over their own domains.
% FOUNDING_PROBLEM_CORROBORATION: The original coordination problem (managing unregulated settlement while preserving Māori authority) was resolved unilaterally by Crown legislative overreach, not by the treaty's jurisdictional boundary. Waitangi Tribunal historical findings, documented across hundreds of claims, establish that the Crown systematically exceeded kāwanatanga and extinguished rangatiratanga through statute and confiscation. International indigenous rights observers (UN Special Rapporteurs, CERD) independently corroborate that the founding jurisdictional boundary collapsed into Crown supremacy within decades of signing. The Tribunal itself—a Crown body—has repeatedly found the enacted arrangement bears no resemblance to the jurisdictional allocation Māori signed.
narrative_ontology:disappearance_verdict(waitangi_sovereignty_allocation__rangatiratanga_reading, world_rearranges).
narrative_ontology:founding_problem_status(waitangi_sovereignty_allocation__rangatiratanga_reading, dead).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(waitangi_sovereignty_allocation__rangatiratanga_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(waitangi_sovereignty_allocation__rangatiratanga_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(waitangi_sovereignty_allocation__rangatiratanga_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(waitangi_sovereignty_allocation__rangatiratanga_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(waitangi_sovereignty_allocation__rangatiratanga_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Base extractiveness rises steeply in the first 60 years (0.15 → 0.61) as Crown legislation systematically extinguished customary authority and confiscated lands, then stabilizes at high extraction (0.68–0.73) as the institutional override becomes normalized through statute, judicial precedent, and administrative practice. The endpoint value (0.72) reflects ongoing extraction: iwi must petition Crown institutions for co-governance arrangements that grant far less authority than the Māori text reserved, and settlements operate within Crown statutory frameworks that preserve parliamentary supremacy.
 *   
 *   Suppression follows a similar trajectory: initially low (0.25) when the treaty's jurisdictional boundary was still being tested, rising sharply (0.58 at t=30, 0.73 at t=60) through armed conflict, statutory confiscation, and judicial validation of Crown supremacy, then stabilizing at high suppression (0.79–0.83) as the apparatus of legislative override became institutionally entrenched. The suppression is structural (statutory extinguishment, Crown courts as sole arbiter) and partly internalized (some Māori resource holders operate within Crown frameworks as the only available path).
 *   
 *   Theater ratio rises gradually (0.05 → 0.28) as the gap between treaty rhetoric and enacted subordination becomes undeniable. Early Crown administration maintained the fiction of honoring rangatiratanga; by the contemporary period, co-governance arrangements and Treaty settlements perform consultation while preserving Crown plenary power—the Tribunal documents breaches but cannot compel restoration of the jurisdictional authority the Māori text allocated.
 *   
 *   Accessibility collapse is low-moderate (0.34): alternatives remain conceptually and legally available. The Māori text exists as documentary evidence; Tribunal findings establish systematic breach; international law provides framework for indigenous self-determination; iwi continue asserting rangatiratanga claims. The constraint's persistence requires active enforcement (parliamentary supremacy doctrine, judicial rejection of Māori-text priority) rather than inevitability.
 *   
 *   Resistance is high (0.76): iwi have never accepted the enacted override as legitimate. Continuous resistance through Tribunal claims, direct action, Treaty settlement negotiations that demand more than compensation, and assertion of mana whenua (territorial authority) in co-governance forums. The constraint persists despite sustained resistance because the Crown controls legislative and judicial enforcement mechanisms.
 *
 * PERSPECTIVAL GAP:
 *   The Crown administrative apparatus experiences this as legitimate parliamentary supremacy grounded in the English text's sovereignty cession—a stable constitutional arrangement requiring normal legislative and judicial maintenance. Iwi/hapū collectives experience the same structure as ongoing jurisdictional theft: the Crown systematically exceeded the limited kāwanatanga they granted and extinguished the tino rangatiratanga they explicitly retained. The Māori text they signed is treated as subordinate to the English text they largely did not read.
 *   
 *   The engine computes this divergence from the structural data: the agenda-setter seat with arbitrage exit operates in a different constraint (coordination of settlement within agreed boundaries) than the identity-locked target seats (systematic override of retained authority). The gap is not reconcilable through consultation or settlement—the readings describe incompatible jurisdictional allocations.
 *
 * DIRECTIONALITY LOGIC:
 *   Iwi/hapū collectives are structural targets with identity-locked exit: d → 0.9+. The treaty relationship is constitutive of iwi identity—walking away would mean abandoning both ancestors' commitments and the lands themselves. They bear the full weight of jurisdictional extraction: retained authority systematically overridden, customary title extinguished, co-governance limited to Crown-structured arrangements.
 *   
 *   Crown administrative apparatus is the primary beneficiary with arbitrage exit: d → 0.1. It collects jurisdictional monopoly over all land and resource allocation, enabling single-sovereign transactional certainty for the settler economy. Can selectively engage co-governance when politically useful; can legislate unilaterally when expedient. The constraint's maintenance is its institutional function.
 *   
 *   Settler colonial economy is a secondary beneficiary with mobile exit: d → 0.15–0.2. Benefits from statutory property certainty derived from Crown's override of iwi authority, but does not directly administer the constraint. Mobile: corporate actors can relocate; individual settlers can exit if arrangements deteriorate.
 *   
 *   Māori resource holders sit near 0.6–0.7: constrained exit, mixed position. They participate in co-governance arrangements that grant limited influence within Crown frameworks (partial benefit), but these arrangements preserve the jurisdictional subordination the Māori text should have prevented (ongoing extraction). The Treaty settlements they receive are compensation for breach, not restoration of authority.
 *   
 *   Waitangi Tribunal and international observers are analytical seats (d → 0.5): neither collect from nor pay into the arrangement's operation; they document and evaluate from outside the enforcement structure.
 *
 * MANDATROPHY ANALYSIS:
 *   The mandate has outlived its founding function. The original problem was coordinating British settlement while preserving Māori territorial authority; the treaty established a jurisdictional boundary to solve this. That boundary was systematically violated within decades. The contemporary arrangement is mandatrophy: iwi are required to petition Crown institutions for co-governance of domains the Māori text never ceded, and settlements compensate for past breaches while preserving the institutional override that caused them. The Tribunal documents this gap extensively but cannot compel restoration of the authority allocation Māori chiefs understood themselves to be making.
 *   
 *   The theater ratio (0.28 at interval end) reflects this: co-governance rhetoric performs respect for rangatiratanga while preserving Crown legislative supremacy. The constraint persists not because the founding coordination problem remains unsolved, but because the settler colonial economy depends on statutory certainty derived from Crown monopoly over jurisdictional authority—an authority the Māori text granted only over settlers, not over Māori lands and taonga.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    textual_primacy,
    'Which text governs when the Māori and English versions allocate authority incompatibly—the text most chiefs signed and understood, or the text the Crown relies on?',
    'Legal doctrine resolving interpretive priority when treaty texts diverge. International law (Vienna Convention on treaty interpretation) provides framework: ambiguity resolved in favor of indigenous-language text when it was the version presented to indigenous signatories. New Zealand courts have inconsistently applied this principle.',
    'If Māori text has primacy, Crown exceeded its granted authority and owes restoration of jurisdictional independence, not mere consultation. If English text governs despite most chiefs never reading it, Crown legislative supremacy is validated and settlements remain compensatory rather than restorative.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(textual_primacy, conceptual, 'Which treaty text has interpretive primacy when allocations conflict').

omega_variable(
    rangatiratanga_translational_load,
    'Did ''tino rangatiratanga'' in 1840 Māori political vocabulary mean full retained sovereignty (as contemporary iwi assert) or a subordinate authority subject to Crown override (as Crown legal interpretation claims)?',
    'Historical linguistic analysis of 1840s Māori political discourse, examination of how ''tino rangatiratanga'' was used in other contemporary contexts, and evidence of what chiefs understood the term to mean when they signed. Waitangi Tribunal has commissioned extensive research; findings support the full-authority reading but lack binding force.',
    'If ''tino rangatiratanga'' meant full retained sovereignty, the Crown''s legislative override was ultra vires from inception and the enacted allocation is wholesale breach. If it meant subordinate authority, Crown supremacy was within the granted power and resistance is renegotiation rather than enforcement of original terms.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(rangatiratanga_translational_load, empirical, 'What authority ''tino rangatiratanga'' actually denoted in 1840 Māori political vocabulary').

omega_variable(
    jurisdictional_severability,
    'Can the coordination function (Crown governance of settlers, trade regulation, law and order) be severed from the extraction function (Crown legislative override of Māori territorial authority)?',
    'Constitutional reform establishing independent Māori jurisdiction over traditional territories while Crown retains governance of non-Māori populations—the allocation the Māori text described. Natural experiment if implemented: does settler economy destabilize with multi-jurisdictional complexity, or does coordination hold with bounded Crown authority?',
    'If functions are severable, the constraint is a tangled rope with identifiable victims and restoration of the Māori-text allocation is structurally possible. If inseparable, Crown plenary power is necessary for coordination and the extraction is the unavoidable price of preventing inter-jurisdictional conflict.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(jurisdictional_severability, empirical, 'Whether Crown governance of settlers requires legislative override of Māori territorial authority').

omega_variable(
    settlement_foreclosure_mechanism,
    'Do Treaty settlements that provide compensation and limited co-governance legally foreclose future claims for restoration of full rangatiratanga, even though settlements preserve Crown legislative supremacy?',
    'Examination of settlement legislation full-and-final clauses, and whether accepting a settlement bars subsequent assertion of jurisdictional independence. Some iwi have refused settlements on these grounds; others have settled while maintaining that settlements address historical grievances but do not extinguish ongoing rangatiratanga.',
    'If settlements foreclose jurisdictional claims, they convert the constraint''s victims into consent-by-acceptance and retrospectively validate the override. If settlements are compensation for past breach but do not foreclose ongoing authority claims, resistance continues and the constraint remains contested.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(settlement_foreclosure_mechanism, conceptual, 'Whether Treaty settlements extinguish future claims for jurisdictional restoration').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(waitangi_sovereignty_allocation__rangatiratanga_reading, 0, 180).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(wait_tr_t0, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 0, 0.05).
narrative_ontology:measurement_basis(wait_tr_t0, observed).
narrative_ontology:measurement(wait_tr_t30, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 30, 0.08).
narrative_ontology:measurement_basis(wait_tr_t30, observed).
narrative_ontology:measurement(wait_tr_t60, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 60, 0.12).
narrative_ontology:measurement_basis(wait_tr_t60, observed).
narrative_ontology:measurement(wait_tr_t90, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 90, 0.18).
narrative_ontology:measurement_basis(wait_tr_t90, observed).
narrative_ontology:measurement(wait_tr_t120, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 120, 0.23).
narrative_ontology:measurement_basis(wait_tr_t120, observed).
narrative_ontology:measurement(wait_tr_t150, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 150, 0.26).
narrative_ontology:measurement_basis(wait_tr_t150, observed).
narrative_ontology:measurement(wait_tr_t180, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 180, 0.28).
narrative_ontology:measurement_basis(wait_tr_t180, observed).

% Extraction over time
narrative_ontology:measurement(wait_be_t0, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 0, 0.15).
narrative_ontology:measurement_basis(wait_be_t0, observed).
narrative_ontology:measurement(wait_be_t30, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 30, 0.42).
narrative_ontology:measurement_basis(wait_be_t30, observed).
narrative_ontology:measurement(wait_be_t60, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 60, 0.61).
narrative_ontology:measurement_basis(wait_be_t60, observed).
narrative_ontology:measurement(wait_be_t90, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 90, 0.68).
narrative_ontology:measurement_basis(wait_be_t90, observed).
narrative_ontology:measurement(wait_be_t120, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 120, 0.71).
narrative_ontology:measurement_basis(wait_be_t120, observed).
narrative_ontology:measurement(wait_be_t150, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 150, 0.73).
narrative_ontology:measurement_basis(wait_be_t150, observed).
narrative_ontology:measurement(wait_be_t180, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 180, 0.72).
narrative_ontology:measurement_basis(wait_be_t180, observed).

% Suppression requirement over time
narrative_ontology:measurement(wait_su_t0, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 0, 0.25).
narrative_ontology:measurement_basis(wait_su_t0, observed).
narrative_ontology:measurement(wait_su_t30, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 30, 0.58).
narrative_ontology:measurement_basis(wait_su_t30, observed).
narrative_ontology:measurement(wait_su_t60, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 60, 0.73).
narrative_ontology:measurement_basis(wait_su_t60, observed).
narrative_ontology:measurement(wait_su_t90, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 90, 0.79).
narrative_ontology:measurement_basis(wait_su_t90, observed).
narrative_ontology:measurement(wait_su_t120, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 120, 0.82).
narrative_ontology:measurement_basis(wait_su_t120, observed).
narrative_ontology:measurement(wait_su_t150, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 150, 0.83).
narrative_ontology:measurement_basis(wait_su_t150, observed).
narrative_ontology:measurement(wait_su_t180, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 180, 0.81).
narrative_ontology:measurement_basis(wait_su_t180, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(waitangi_sovereignty_allocation__rangatiratanga_reading, enforcement_mechanism).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__rangatiratanga_reading, waitangi_sovereignty_allocation__crown_sovereignty_reading).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__rangatiratanga_reading, waitangi_sovereignty_allocation__partnership_reading).

% DUAL FORMULATION NOTE:
% The Treaty of Waitangi kernel decomposes into three readings with distinct ε values and beneficiary structures. The rangatiratanga reading (this story) models the allocation Māori chiefs understood from the Māori text: retention of tino rangatiratanga, Crown granted only kāwanatanga over settlers. Extractiveness is high (0.72) because the enacted constraint systematically overrides the reserved authority. The crown_sovereignty_reading models the English text's full cession claim—lower extractiveness from the Crown's institutional perspective because parliamentary supremacy is the legitimate starting allocation. The partnership_reading models contemporary Treaty jurisprudence emphasizing ongoing relationship and good-faith obligations—moderate extractiveness, as it acknowledges historical breach but preserves Crown legislative supremacy through consultation rather than restoration of jurisdictional independence. The ε divergence is the point: these are structurally distinct allocations, not measurement error.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
