% ============================================================================
% CONSTRAINT STORY: woman_category__sex_biology_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2025-01-02
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_woman_category__sex_biology_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: woman_category__sex_biology_reading
 *   human_readable: Sex-Biology Category Boundary for Legal Woman Status
 *   domain: political_philosophy/law/social_policy/bioethics
 *
 * SUMMARY:
 *   This constraint instantiates the biological-sex reading of the contested
 *   woman-category kernel. Under this reading, legal and social woman status
 *   is determined by chromosomal and reproductive anatomy (XX chromosomes,
 *   typical female anatomy), treating these as immutable and dispositive. The
 *   reading coordinates sex-segregated spaces and protections around
 *   biological difference while extracting from transgender women (excluded
 *   despite living as women) and intersex people (forced into a binary that
 *   erases their variation). The constraint is claimed as tangled_rope:
 *   genuine coordination function (organizing single-sex protections) coupled
 *   with asymmetric extraction (concentrated harm on identity-locked excluded
 *   groups). Metrics describe rising enforcement intensity as the boundary
 *   hardens in response to challenges from sibling readings.
 *
 * KEY AGENTS:
 *   - female_biology_advocates: agenda_setter (organized/mobile) — define and defend the biological boundary, frame it as protecting women's rights
 *   - sex_segregated_sports_administrators: beneficiary (institutional/constrained) — gain administrative simplicity from bright-line biological rules
 *   - sex_based_data_collection_institutions: beneficiary (institutional/constrained) — preserve longitudinal data comparability anchored to biological categories
 *   - transgender_women: payer (organized/identity_locked) — excluded from woman status, bear safety and recognition costs, cannot exit without abandoning identity
 *   - intersex_people_with_ambiguous_classification: payer (powerless/trapped) — erased as a category, face administrative limbo and forced medical clarification
 *   - bioethicists_and_legal_scholars: observer (analytical) — document harm distribution and enforcement mechanisms
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(woman_category__sex_biology_reading, 0.68).
domain_priors:suppression_score(woman_category__sex_biology_reading, 0.72).
domain_priors:theater_ratio(woman_category__sex_biology_reading, 0.41).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, extractiveness, 0.68).
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, suppression_requirement, 0.72).
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, theater_ratio, 0.41).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, accessibility_collapse, 0.58).
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, resistance, 0.71).

% --- Constraint claim ---
narrative_ontology:constraint_claim(woman_category__sex_biology_reading, tangled_rope).
narrative_ontology:human_readable(woman_category__sex_biology_reading, "Sex-Biology Category Boundary for Legal Woman Status").
narrative_ontology:topic_domain(woman_category__sex_biology_reading, "political_philosophy/law/social_policy/bioethics").

domain_priors:requires_active_enforcement(woman_category__sex_biology_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(woman_category__sex_biology_reading, '9c077f50-cacb-4616-87dc-fa6da461e659').
narrative_ontology:cs_kernel_codification('9c077f50-cacb-4616-87dc-fa6da461e659', formalized).
narrative_ontology:cs_authority_grounding('9c077f50-cacb-4616-87dc-fa6da461e659', lineage).
narrative_ontology:cs_interpretation_layer_present('9c077f50-cacb-4616-87dc-fa6da461e659').
narrative_ontology:cs_reading_relation('9c077f50-cacb-4616-87dc-fa6da461e659', woman_category__gender_identity_reading, coexists_with).
narrative_ontology:cs_reading_relation('9c077f50-cacb-4616-87dc-fa6da461e659', woman_category__intersex_accommodation_reading, influences).
narrative_ontology:cs_axiom('9c077f50-cacb-4616-87dc-fa6da461e659', foundational, sex_is_binary_and_immutable).
narrative_ontology:cs_axiom_status(sex_is_binary_and_immutable, holdable).
narrative_ontology:cs_axiom_grounding('9c077f50-cacb-4616-87dc-fa6da461e659', sex_is_binary_and_immutable, empirically_contingent).
narrative_ontology:cs_axiom('9c077f50-cacb-4616-87dc-fa6da461e659', foundational, biological_sex_determines_legal_category).
narrative_ontology:cs_axiom_status(biological_sex_determines_legal_category, holdable).
narrative_ontology:cs_axiom_grounding('9c077f50-cacb-4616-87dc-fa6da461e659', biological_sex_determines_legal_category, conventional).
narrative_ontology:cs_reference_frame('9c077f50-cacb-4616-87dc-fa6da461e659', second_wave_feminist_sex_based_rights).
narrative_ontology:cs_drift_state('9c077f50-cacb-4616-87dc-fa6da461e659', contemporary_gender_identity_recognition_era, gap(axiom_overriding, substantial, false)).
narrative_ontology:cs_created_at('9c077f50-cacb-4616-87dc-fa6da461e659', '').
narrative_ontology:cs_kernel_id(woman_category__sex_biology_reading, woman_category).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(woman_category__sex_biology_reading, female_biology_advocates).
narrative_ontology:constraint_beneficiary(woman_category__sex_biology_reading, sex_segregated_sports_administrators).
narrative_ontology:constraint_beneficiary(woman_category__sex_biology_reading, sex_based_data_collection_institutions).
narrative_ontology:constraint_victim(woman_category__sex_biology_reading, transgender_women).
narrative_ontology:constraint_victim(woman_category__sex_biology_reading, intersex_people_with_ambiguous_classification).
narrative_ontology:constraint_vindicates(woman_category__sex_biology_reading, sex_immutability_doctrine).
narrative_ontology:constraint_vindicates(woman_category__sex_biology_reading, biological_essentialism_framework).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Organize to define legal woman status by chromosomal and reproductive anatomy, arguing this preserves sex-based rights and protections built on biological difference. They control definitional authority in jurisdictions where this reading is codified and advocate for its adoption elsewhere. Frame the boundary as protecting women's safety in single-sex spaces and fairness in sex-segregated competition.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, female_biology_advocates, agenda_setter,
    organized, generational, mobile, national).

% Benefit from clear categorical boundaries for competition eligibility: chromosomal/anatomical criteria provide administratively simple rules that avoid case-by-case adjudication. Treat the biological standard as resolving fairness questions about performance advantage, though this reading generates ongoing litigation and protest from excluded athletes.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, sex_segregated_sports_administrators, beneficiary,
    institutional, biographical, constrained, global).

% Public health agencies, census bureaus, and research institutions that track sex-disaggregated outcomes. Benefit from stable, biologically anchored categories for longitudinal data comparability and epidemiological analysis. Under this reading, data on violence against women, reproductive health, and sex-specific disease tracks people with female biology regardless of gender identity.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, sex_based_data_collection_institutions, beneficiary,
    institutional, generational, constrained, national).

% Excluded from legal recognition as women under this reading despite living as women and often undergoing medical transition. Bear exclusion from sex-segregated facilities, sports, and legal protections tied to woman status. Cannot exit the constraint without either abandoning their gender identity or relocating to jurisdictions using different definitional frameworks. Face heightened violence risk when forced into male spaces.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, transgender_women, payer,
    organized, biographical, identity_locked, global).

% People with chromosomal or anatomical variations that do not fit the XX/typical-female-anatomy standard fall into legal ambiguity. Some are classified as women by convention despite not meeting the stated criteria; others face administrative denial or forced medical intervention to 'clarify' their status. The constraint's enforcement erases their existence as a distinct category.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, intersex_people_with_ambiguous_classification, payer,
    powerless, biographical, trapped, global).

% Transgender men with female biology are misclassified as women under this reading; nonbinary people with female biology are forced into a binary they reject. They contest the framework but are structurally outside the woman-category dispute itself—their objection is to the binary frame, not to where the line is drawn within it.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, transgender_men_and_nonbinary_people, excluded,
    organized, biographical, identity_locked, global).

% Organizations and movements advocating for self-identification as the basis for legal woman status. Structurally excluded from definitional authority in jurisdictions where the biological reading is codified. Mount legal challenges, lobby for legislative change, and provide support to people harmed by biological-category enforcement.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, gender_identity_advocates, excluded,
    organized, generational, mobile, global).

% Analyze how definitional choices distribute harms and benefits across populations. Document the constraint's enforcement mechanisms, the administrative burden it imposes on intersex people, and the violence-exposure gap for excluded transgender women. Neither set the boundary nor bear its direct costs.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, bioethicists_and_legal_scholars, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a categorical boundary for sex-segregated legal protections, facilities, and athletic competition. Coordinates single-sex spaces around a shared understanding of biological sex as the relevant organizing principle, enabling rules that treat typical male and typical female bodies differently without case-by-case determination.
% TRANSFER_FUNCTION: Transfers legal recognition, access to sex-segregated protections, and eligibility for woman-specific programs from transgender women (and ambiguously classified intersex people) to institutions and advocates who define and enforce the biological boundary. The constraint concentrates definitional authority and preserves existing data infrastructure while imposing identity erasure and safety costs on the excluded.
% ABSENT_VOICES: Transgender women are present in the discourse but structurally excluded from definitional authority—they are subjects of the policy, not participants in setting it. Intersex people are largely absent: the binary frame erases intersex variation as a category and forces case-by-case adjudication that the standard was meant to avoid. Nonbinary people are outside the frame entirely.
% DISAPPEARANCE_RATIONALE: If the biological boundary vanished overnight, sex-segregated sports eligibility would require new standards, single-sex facilities would need alternative access rules, legal definitions of discrimination against women would shift, longitudinal public health datasets would lose comparability, and transgender women would gain access to spaces and protections currently denied. The rearrangement would be immediate and contested.
% FOUNDING_PROBLEM: Early feminist legal reforms sought to remedy sex-based discrimination and violence against women. These protections were built on the premise that biological sex is the axis of oppression: female biology subjects people to reproductive control, sexual violence, and economic subordination. The category 'woman' was anchored to biology to capture everyone subject to sex-based harm.
% FOUNDING_PROBLEM_CORROBORATION: Biological-category advocates attest the founding problem is still live: sex-based violence and discrimination persist, and biological sex remains the relevant axis. Gender-identity advocates and scholars of transgender experience attest the founding problem has shifted: gender identity now also structures violence and discrimination, and a rigid biological boundary excludes people who face woman-targeted harm. Independent violence and employment data from jurisdictions with self-ID laws provide mixed evidence—some studies show transgender women face comparable or higher rates of gender-based violence than cisgender women; others show different risk profiles.
narrative_ontology:disappearance_verdict(woman_category__sex_biology_reading, world_rearranges).
narrative_ontology:founding_problem_status(woman_category__sex_biology_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(woman_category__sex_biology_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(woman_category__sex_biology_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(woman_category__sex_biology_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(woman_category__sex_biology_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(woman_category__sex_biology_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is substantial (0.68 at interval end) because the constraint imposes concentrated identity-erasure and safety costs on transgender women while diffusing coordination benefits across female-biology populations. The XX/anatomy standard excludes people who live as women and face woman-targeted violence, routing them into male spaces with heightened risk. Suppression is high (0.72) because enforcement requires active policing of the boundary: legal challenges, bathroom-access enforcement, sports eligibility verification, and administrative denial of identity documents. Theater ratio is moderate (0.41): the sex-segregation function is real, but a growing share of enforcement activity defends the definitional boundary itself against challenges from excluded groups rather than serving the original safety and fairness goals. The measurement series shows extraction and suppression rising as the boundary hardens—early in the interval the standard operated quietly; later it requires increasingly active defense. Accessibility collapse is moderate (0.58): alternative identity-based frameworks exist in some jurisdictions, but most legal structures worldwide anchor to biological sex. Resistance is high (0.71): transgender advocates, intersex organizations, and some feminist legal scholars actively contest the boundary.
 *
 * PERSPECTIVAL GAP:
 *   The agenda-setter seat and the payer seats should compute radically differently. From the female-biology-advocate position, the constraint is necessary coordination protecting sex-based rights from erasure—a rope maintaining boundaries that feminism built. From the transgender-women seat, the same structure operates as enforced exclusion that denies their lived reality and exposes them to violence—a snare weaponizing biology against identity. From the intersex seat, the constraint is an imposed binary that erases their existence—extraction without even the theater of inclusion. The engine computes this divergence from power, exit, and beneficiary/victim declarations; the authored claim (tangled_rope) names the hybrid structure but does not adjudicate which perception is correct.
 *
 * DIRECTIONALITY LOGIC:
 *   Female-biology advocates are structural beneficiaries (control definitional authority, present the reading as protecting women—d near beneficiary end). Sports administrators and data institutions are secondary beneficiaries (gain administrative clarity without running the constraint—d slightly toward beneficiary). Transgender women are primary targets (excluded despite identity, identity-locked exit, bear concentrated harm—d near full target). Intersex people with ambiguous classification are also targets (erased, trapped, forced into administrative violence—d near full target). The constraint operates asymmetrically: coordination benefits are diffuse across people with female biology; extraction concentrates on two small, structurally vulnerable populations.
 *
 * MANDATROPHY ANALYSIS:
 *   The tangled-rope classification prevents mislabeling this as pure extraction (snare) by recognizing the genuine coordination function: sex-segregated spaces were built to protect people with female biology from male violence, and biological boundaries enable those protections without individualized adjudication. It also prevents mislabeling as pure coordination (rope) by documenting the asymmetric extraction: the reading concentrates harm on transgender women (identity-locked, excluded from protections they need) and intersex people (erased, administratively violated). The constraint coordinates some while extracting from others—the engine measures whether the extraction could be reduced without destroying the coordination function.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    immutability_vs_plasticity,
    'Is biological sex an immutable binary (XX/XY, stable across lifespan) or a partially mutable multivariate construct (chromosomal, hormonal, anatomical, and neurological components that can be altered)?',
    'Endocrinological and neurobiological evidence on the effects of hormone therapy and surgical intervention on sex-typed physiology; legal precedent on whether post-transition biology counts as ''changed sex'' or merely ''altered presentation of natal sex.''',
    'If sex is immutable, the biological reading is a mountain (natural category) and exclusion of transgender women follows from category boundaries. If sex is partially mutable, the reading is constructed—a policy choice to privilege chromosomal assignment over other biological markers—and exclusion becomes extractive (denying recognition to people whose biology has partially shifted).',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(immutability_vs_plasticity, empirical, 'Whether biological sex is an immutable natural kind or a mutable constructed boundary.').

omega_variable(
    coordination_extraction_separability,
    'Is the sex-segregation coordination function separable from the biological-exclusion extraction function, or does protecting female-biology populations require excluding transgender women?',
    'Natural experiments from jurisdictions that allow self-ID for legal woman status while maintaining single-sex spaces by other criteria (e.g., threat-assessment, behavioral rules). If safety and fairness outcomes hold under self-ID, the functions are separable; if outcomes degrade, exclusion is structural to coordination.',
    'If separable, the constraint is a snare with a coordination cover story—extraction riding on a function that does not require it. If inseparable, the constraint is genuinely tangled: reducing extraction would destroy the coordination.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(coordination_extraction_separability, empirical, 'Whether the coordination and extraction components can be structurally decoupled.').

omega_variable(
    intersex_erasure_mechanism,
    'Does the binary biological standard erase intersex variation by design (to simplify administration) or by accident (intersex people are edge cases the framers did not consider)?',
    'Historical analysis of the legal standards'' drafting: did framers explicitly choose to collapse intersex variation into the binary, or did they assume binary biology is universal? Legislative and case-law record on how intersex classification disputes are resolved.',
    'If by design, the intersex-erasure extraction is intentional—beneficiaries prioritized administrative simplicity over intersex recognition. If by accident, the extraction is a side effect that could be mitigated without altering the core reading (e.g., adding an explicit intersex category). The former supports snare-classification for intersex people; the latter supports repair via the accommodation reading.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(intersex_erasure_mechanism, conceptual, 'Whether intersex erasure is structural or incidental to the biological-boundary reading.').

omega_variable(
    sibling_reading_coexistence,
    'Can the biological reading and the identity reading coexist in adjacent jurisdictions without structural contamination, or does one reading''s adoption pressure the other into retreat?',
    'Observing cross-border dynamics: do jurisdictions with self-ID laws face pressure to restrict access (via residency requirements, medical gatekeeping) when neighboring jurisdictions use biological standards? Do biological-standard jurisdictions face legal challenges citing human-rights obligations when self-ID jurisdictions provide refuge?',
    'If the readings coexist stably, the kernel is a genuine conceptual disagreement without winner-take-all dynamics—both remain live options. If adoption of one reading pressures the other, the kernel is a contested resource with feedback loops that will resolve toward one reading over time.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(sibling_reading_coexistence, empirical, 'Whether sibling readings of the woman-category kernel can coexist or whether one must displace the other.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(woman_category__sex_biology_reading, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(woma_tr_t0, woman_category__sex_biology_reading, theater_ratio, 0, 0.28).
narrative_ontology:measurement(woma_tr_t5, woman_category__sex_biology_reading, theater_ratio, 5, 0.31).
narrative_ontology:measurement(woma_tr_t10, woman_category__sex_biology_reading, theater_ratio, 10, 0.34).
narrative_ontology:measurement(woma_tr_t15, woman_category__sex_biology_reading, theater_ratio, 15, 0.37).
narrative_ontology:measurement(woma_tr_t20, woman_category__sex_biology_reading, theater_ratio, 20, 0.39).
narrative_ontology:measurement(woma_tr_t25, woman_category__sex_biology_reading, theater_ratio, 25, 0.41).

% Extraction over time
narrative_ontology:measurement(woma_be_t0, woman_category__sex_biology_reading, base_extractiveness, 0, 0.52).
narrative_ontology:measurement(woma_be_t5, woman_category__sex_biology_reading, base_extractiveness, 5, 0.56).
narrative_ontology:measurement(woma_be_t10, woman_category__sex_biology_reading, base_extractiveness, 10, 0.61).
narrative_ontology:measurement(woma_be_t15, woman_category__sex_biology_reading, base_extractiveness, 15, 0.64).
narrative_ontology:measurement(woma_be_t20, woman_category__sex_biology_reading, base_extractiveness, 20, 0.66).
narrative_ontology:measurement(woma_be_t25, woman_category__sex_biology_reading, base_extractiveness, 25, 0.68).

% Suppression requirement over time
narrative_ontology:measurement(woma_su_t0, woman_category__sex_biology_reading, suppression_requirement, 0, 0.58).
narrative_ontology:measurement(woma_su_t5, woman_category__sex_biology_reading, suppression_requirement, 5, 0.62).
narrative_ontology:measurement(woma_su_t10, woman_category__sex_biology_reading, suppression_requirement, 10, 0.66).
narrative_ontology:measurement(woma_su_t15, woman_category__sex_biology_reading, suppression_requirement, 15, 0.69).
narrative_ontology:measurement(woma_su_t20, woman_category__sex_biology_reading, suppression_requirement, 20, 0.71).
narrative_ontology:measurement(woma_su_t25, woman_category__sex_biology_reading, suppression_requirement, 25, 0.72).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(woman_category__sex_biology_reading, identity_coordination).
narrative_ontology:affects_constraint(woman_category__sex_biology_reading, woman_category__gender_identity_reading).
narrative_ontology:affects_constraint(woman_category__sex_biology_reading, woman_category__intersex_accommodation_reading).
narrative_ontology:affects_constraint(woman_category__sex_biology_reading, single_sex_facility_access_policies).
narrative_ontology:affects_constraint(woman_category__sex_biology_reading, sex_segregated_sports_eligibility_standards).
narrative_ontology:affects_constraint(woman_category__sex_biology_reading, legal_sex_marker_assignment_procedures).

% DUAL FORMULATION NOTE:
% The woman-category kernel decomposes into three constraint stories with different ε values and victim sets. The biological reading (this file) has high ε in domains where transgender women are categorically excluded (sports, legal sex markers, violence shelters); the identity reading has high ε where self-ID is rejected or gatekept; the intersex-accommodation reading addresses a distinct victim set (intersex people erased by the binary). These are not observer-relative perspectives on one constraint—they are competing definitions that produce different legal and social outcomes. Network links connect all three readings and the downstream access/eligibility policies they generate.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
