% ============================================================================
% CONSTRAINT STORY: woman_category__gender_identity_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2024-01-15
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_woman_category__gender_identity_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: woman_category__gender_identity_reading
 *   human_readable: Gender Identity Reading of Woman Category
 *   domain: political_philosophy/law/social_policy/bioethics
 *
 * SUMMARY:
 *   This constraint is the gender-identity reading of the contested 'woman'
 *   category kernel. It defines category membership by internal gender
 *   identity rather than biological sex, granting legal recognition and
 *   institutional access to anyone who identifies as a woman. The reading
 *   coordinates inclusion for transgender women while extracting from women
 *   whose safety, privacy, and competitive fairness claims rest on sex-based
 *   boundaries. The extraction is highest in contexts where physical
 *   dimorphism matters (sports, intimate spaces) and moderate in
 *   administrative contexts (identity documents). The constraint operates as
 *   tangled rope: genuine coordination function (legal recognition, reduced
 *   gatekeeping) combined with asymmetric extraction (women lose sex-based
 *   protections without consent, athletes face physiological disadvantage)
 *   requiring active enforcement to suppress dissent.
 *
 * KEY AGENTS:
 *   - transgender_women: Primary beneficiary (organized/identity_locked) — gain legal recognition and category access
 *   - gender_identity_advocacy_orgs: Agenda setter (organized/mobile) — draft policy, set interpretation
 *   - sex_based_protected_space_users: Payer (moderate/constrained) — lose exclusive access to single-sex spaces
 *   - competitive_female_athletes: Payer (moderate/trapped) — face physiological disadvantage in competition
 *   - safeguarding_advocates: Excluded (moderate/constrained) — concerns framed as discriminatory
 *   - legal_scholars: Observer (analytical/analytical) — map the rights collision
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(woman_category__gender_identity_reading, 0.68).
domain_priors:suppression_score(woman_category__gender_identity_reading, 0.72).
domain_priors:theater_ratio(woman_category__gender_identity_reading, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, extractiveness, 0.68).
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, suppression_requirement, 0.72).
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, resistance, 0.78).

% --- Constraint claim ---
narrative_ontology:constraint_claim(woman_category__gender_identity_reading, tangled_rope).
narrative_ontology:human_readable(woman_category__gender_identity_reading, "Gender Identity Reading of Woman Category").
narrative_ontology:topic_domain(woman_category__gender_identity_reading, "political_philosophy/law/social_policy/bioethics").

domain_priors:requires_active_enforcement(woman_category__gender_identity_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(woman_category__gender_identity_reading, 'aa7551a1-2fe3-4042-a8f4-355b3a1894d8').
narrative_ontology:cs_kernel_codification('aa7551a1-2fe3-4042-a8f4-355b3a1894d8', distributed).
narrative_ontology:cs_authority_grounding('aa7551a1-2fe3-4042-a8f4-355b3a1894d8', distributed).
narrative_ontology:cs_reading_relation('aa7551a1-2fe3-4042-a8f4-355b3a1894d8', woman_category__sex_biology_reading, coexists_with).
narrative_ontology:cs_reading_relation('aa7551a1-2fe3-4042-a8f4-355b3a1894d8', woman_category__intersex_accommodation_reading, influences).
narrative_ontology:cs_axiom('aa7551a1-2fe3-4042-a8f4-355b3a1894d8', foundational, gender_identity_as_ontological_primacy).
narrative_ontology:cs_axiom_status(gender_identity_as_ontological_primacy, holdable).
narrative_ontology:cs_axiom_grounding('aa7551a1-2fe3-4042-a8f4-355b3a1894d8', gender_identity_as_ontological_primacy, deontological).
narrative_ontology:cs_axiom('aa7551a1-2fe3-4042-a8f4-355b3a1894d8', secondary, sex_based_boundaries_as_discriminatory).
narrative_ontology:cs_axiom_status(sex_based_boundaries_as_discriminatory, holdable).
narrative_ontology:cs_axiom_grounding('aa7551a1-2fe3-4042-a8f4-355b3a1894d8', sex_based_boundaries_as_discriminatory, conventional).
narrative_ontology:cs_reference_frame('aa7551a1-2fe3-4042-a8f4-355b3a1894d8', gender_identity_self_determination_framework).
narrative_ontology:cs_drift_state('aa7551a1-2fe3-4042-a8f4-355b3a1894d8', contemporary_rights_collision_era, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('aa7551a1-2fe3-4042-a8f4-355b3a1894d8', '').
narrative_ontology:cs_kernel_id(woman_category__gender_identity_reading, woman_category).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(woman_category__gender_identity_reading, transgender_women).
narrative_ontology:constraint_beneficiary(woman_category__gender_identity_reading, gender_identity_advocacy_orgs).
narrative_ontology:constraint_beneficiary(woman_category__gender_identity_reading, identity_documentation_administrators).
narrative_ontology:constraint_victim(woman_category__gender_identity_reading, sex_based_protected_space_users).
narrative_ontology:constraint_victim(woman_category__gender_identity_reading, competitive_female_athletes).
narrative_ontology:constraint_victim(woman_category__gender_identity_reading, safeguarding_advocates).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Gain legal recognition as women via self-identification, accessing identity documents, sex-segregated spaces, and institutional categories that affirm their gender identity. Exit would mean denial of their self-concept and social legibility; the identity fusion makes departure unthinkable within their framework.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, transgender_women, beneficiary,
    organized, biographical, identity_locked, national).

% Shape policy frameworks, draft model legislation, provide legal representation, and conduct public education campaigns establishing gender identity as the sole criterion for category membership. They set the interpretive standards and enforcement priorities.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, gender_identity_advocacy_orgs, agenda_setter,
    organized, generational, mobile, national).

% Implement self-identification protocols that reduce verification burden and litigation risk. The rule simplifies administration by removing biological verification requirements, though it transfers the cost of category boundary disputes to downstream contexts.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, identity_documentation_administrators, beneficiary,
    institutional, biographical, constrained, national).
narrative_ontology:stakeholder_secondary_role(woman_category__gender_identity_reading, identity_documentation_administrators, agenda_setter).

% Women who use sex-segregated facilities (changing rooms, shelters, prisons) on the basis of shared female biology. Under this reading, they lose the ability to exclude people with male anatomy from those spaces, bearing privacy and safety costs they did not consent to.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, sex_based_protected_space_users, payer,
    moderate, biographical, constrained, local).

% Athletes who compete in female sports categories. When the category admits anyone who identifies as a woman regardless of physiology, they face competitors with retained male-typical physical advantages. Their exit option is abandoning competitive sport entirely.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, competitive_female_athletes, payer,
    moderate, biographical, trapped, regional).

% Organizations focused on protecting women and children from male violence. They argue that self-identification removes safeguarding mechanisms and that bad actors can exploit the framework. Their concerns are typically excluded from policy discourse as discriminatory.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, safeguarding_advocates, excluded,
    moderate, biographical, constrained, national).

% Clinicians who formerly assessed gender dysphoria before authorizing transition interventions or legal recognition. Under self-identification frameworks, their gatekeeping role is eliminated or minimized, which this reading treats as removing an illegitimate barrier.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, medical_gatekeepers, excluded,
    institutional, biographical, constrained, national).

% Analyze the collision between gender-identity rights and sex-based rights in law. They document how the same policy framework coordinates inclusion for one group while extracting from another, and map the trade-offs the legal system must adjudicate.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, legal_scholars, observer,
    analytical, generational, analytical, national).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a clear, administratively simple rule for legal recognition that affirms transgender women's self-concept and grants them access to gendered institutional categories without requiring medical gatekeeping or biological verification.
% TRANSFER_FUNCTION: Transfers access rights to sex-segregated spaces, competitive categories, and legal protections from a sex-biology basis to a gender-identity basis. Women whose claims rest on female biology lose exclusive access; transgender women gain inclusive access.
% ABSENT_VOICES: Safeguarding advocates and women who view sex-based boundaries as necessary are structurally excluded from policy formation; their objections are framed as discriminatory rather than as legitimate competing rights claims. Medical gatekeepers who formerly assessed dysphoria are also sidelined.
% DISAPPEARANCE_RATIONALE: If this reading vanished overnight, transgender women would lose legal recognition and institutional access, advocacy organizations would restructure around alternative frameworks, sports governing bodies and facility administrators would revert to sex-based criteria, and the legal landscape around single-sex spaces and competitive fairness would reorganize entirely.
% FOUNDING_PROBLEM: Transgender women were denied legal recognition as women, excluded from female spaces and categories, required to undergo medical gatekeeping for identity documents, and subjected to discrimination and violence due to non-recognition.
% FOUNDING_PROBLEM_CORROBORATION: Transgender advocacy organizations and transgender individuals attest the problem is live, citing ongoing discrimination and access barriers. Legal scholars and human rights bodies outside the immediate beneficiary set corroborate that legal non-recognition creates documented harms including employment discrimination, healthcare barriers, and violence risk. The contested element is whether self-identification is the only remedy or whether it creates new harms.
narrative_ontology:disappearance_verdict(woman_category__gender_identity_reading, world_rearranges).
narrative_ontology:founding_problem_status(woman_category__gender_identity_reading, live).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(woman_category__gender_identity_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(woman_category__gender_identity_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(woman_category__gender_identity_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(woman_category__gender_identity_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(woman_category__gender_identity_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is substantial (0.68) because the coordination benefit to transgender women comes at the direct cost of women who lose sex-based protections — the framework treats their competing claims as illegitimate rather than as a genuine rights collision to adjudicate. Suppression is high (0.72) because the constraint's persistence depends on actively suppressing dissent: objections are treated as discriminatory hate speech rather than as legitimate safeguarding or fairness concerns. Theater is moderate-low (0.28): the legal recognition function is real, but a growing share of enforcement activity defends the framework from scrutiny rather than solving the original problem. Resistance is very high (0.78): women's sports governing bodies, safeguarding organizations, and large segments of the public actively resist the framework. Accessibility collapse is low (0.48): the alternative reading (sex-based categories) remains conceptually available and is actively defended by organized groups.
 *
 * PERSPECTIVAL GAP:
 *   From the transgender women and advocacy organization seats, this is coordination — removing an illegitimate barrier and affirming identity. From the sex-based protected space users and athlete seats, the same structure operates as extraction — their rights are subordinated without adjudication, and dissent is suppressed. The legal scholar seat sees both: genuine coordination for one group, genuine extraction from another, and active enforcement preventing the trade-off from being acknowledged.
 *
 * DIRECTIONALITY LOGIC:
 *   Transgender women are structural beneficiaries with identity-locked exit — the constraint affirms their self-concept and grants institutional legibility; departure would mean denial of identity. Gender identity advocacy organizations are agenda setters with mobile exit — they set policy but could pivot to alternative frameworks. Sex-based protected space users and competitive female athletes are payers with constrained or trapped exit — they bear privacy, safety, and fairness costs without consenting to the trade-off, and their exit options are avoiding the spaces entirely or abandoning competition. Safeguarding advocates are excluded rather than coordinated — their concerns are suppressed as the price of maintaining the framework.
 *
 * MANDATROPHY ANALYSIS:
 *   This is not mandatrophy — the founding problem (legal non-recognition of transgender people) is live, and the constraint does solve it for its beneficiaries. The contested element is whether the solution must extract from women's sex-based rights or whether alternative frameworks (tiered access, case-by-case adjudication, third categories) could coordinate both sets of claims. The extraction is the price of solving one problem by subordinating the competing problem, not the persistence of a dead function.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    rights_collision_vs_pure_inclusion,
    'Is this constraint a pure inclusion mechanism (removing an illegitimate barrier) or a rights collision (coordinating one group''s claims while extracting from another''s)?',
    'Legal adjudication in cases where gender-identity access and sex-based protection claims conflict directly (prison placement, competitive sports, intimate care settings). If courts consistently rule that one right subordinates the other, that establishes extraction; if courts require case-by-case balancing, that establishes collision requiring trade-offs.',
    'If pure inclusion, resistance is illegitimate discrimination and suppression is justified. If rights collision, suppression is extractive and the framework should accommodate both sets of claims rather than subordinating one.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(rights_collision_vs_pure_inclusion, conceptual, 'Whether competing claims are illegitimate discrimination or genuine rights collision').

omega_variable(
    physiological_advantage_magnitude,
    'What is the magnitude and persistence of male-typical physiological advantage in transgender women athletes after transition interventions?',
    'Longitudinal performance data on transgender athletes pre- and post-transition, controlled studies of strength/endurance/bone density retention, and competitive outcome analysis in sports where transgender women have competed.',
    'Large retained advantage would establish the sports application as extractive (competitive fairness sacrificed for inclusion). Negligible advantage would support the framework as pure coordination. Moderate advantage would require sport-specific adjudication.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(physiological_advantage_magnitude, empirical, 'Whether sports inclusion extracts from competitive fairness or coordinates without cost').

omega_variable(
    self_id_safeguarding_tradeoff,
    'Does removing gatekeeping and allowing self-identification create exploitable safeguarding vulnerabilities in single-sex spaces?',
    'Incident data from jurisdictions with self-identification laws: rates of access abuse in prisons, shelters, changing rooms. Compare to baseline rates in sex-verification jurisdictions. Control for reporting bias and moral panic amplification.',
    'If vulnerability is empirically negligible, safeguarding objections are moral panic and suppression is justified. If vulnerability is measurable, the framework extracts safety from one group to coordinate inclusion for another, and alternative mechanisms (tiered access, case-by-case assessment) may be warranted.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(self_id_safeguarding_tradeoff, empirical, 'Whether self-identification creates safeguarding costs or is exploitation-neutral').

omega_variable(
    alternative_reading_under_determination,
    'This constraint is one reading of the woman_category kernel. Are the sibling readings (sex_biology_reading, intersex_accommodation_reading) genuine alternatives that could coordinate both sets of claims, or do they fail to solve the founding problem?',
    'Legal and policy analysis of jurisdictions using tiered frameworks (gender identity for some purposes, sex for others) or third-category approaches. Assess whether transgender women achieve legal recognition and protection under those frameworks.',
    'If sibling readings solve the founding problem while avoiding extraction, this reading''s suppression of alternatives is unjustified. If sibling readings recreate the original harm, this reading''s extraction may be unavoidable.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(alternative_reading_under_determination, conceptual, 'Whether alternative framings of the kernel avoid the extraction this reading produces').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(woman_category__gender_identity_reading, 0, 20).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(woma_tr_t0, woman_category__gender_identity_reading, theater_ratio, 0, 0.15).
narrative_ontology:measurement(woma_tr_t4, woman_category__gender_identity_reading, theater_ratio, 4, 0.18).
narrative_ontology:measurement(woma_tr_t8, woman_category__gender_identity_reading, theater_ratio, 8, 0.21).
narrative_ontology:measurement(woma_tr_t12, woman_category__gender_identity_reading, theater_ratio, 12, 0.24).
narrative_ontology:measurement(woma_tr_t16, woman_category__gender_identity_reading, theater_ratio, 16, 0.26).
narrative_ontology:measurement(woma_tr_t20, woman_category__gender_identity_reading, theater_ratio, 20, 0.28).

% Extraction over time
narrative_ontology:measurement(woma_be_t0, woman_category__gender_identity_reading, base_extractiveness, 0, 0.42).
narrative_ontology:measurement(woma_be_t4, woman_category__gender_identity_reading, base_extractiveness, 4, 0.49).
narrative_ontology:measurement(woma_be_t8, woman_category__gender_identity_reading, base_extractiveness, 8, 0.56).
narrative_ontology:measurement(woma_be_t12, woman_category__gender_identity_reading, base_extractiveness, 12, 0.61).
narrative_ontology:measurement(woma_be_t16, woman_category__gender_identity_reading, base_extractiveness, 16, 0.65).
narrative_ontology:measurement(woma_be_t20, woman_category__gender_identity_reading, base_extractiveness, 20, 0.68).

% Suppression requirement over time
narrative_ontology:measurement(woma_su_t0, woman_category__gender_identity_reading, suppression_requirement, 0, 0.48).
narrative_ontology:measurement(woma_su_t4, woman_category__gender_identity_reading, suppression_requirement, 4, 0.54).
narrative_ontology:measurement(woma_su_t8, woman_category__gender_identity_reading, suppression_requirement, 8, 0.6).
narrative_ontology:measurement(woma_su_t12, woman_category__gender_identity_reading, suppression_requirement, 12, 0.65).
narrative_ontology:measurement(woma_su_t16, woman_category__gender_identity_reading, suppression_requirement, 16, 0.69).
narrative_ontology:measurement(woma_su_t20, woman_category__gender_identity_reading, suppression_requirement, 20, 0.72).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(woman_category__gender_identity_reading, identity_coordination).
narrative_ontology:boltzmann_floor_override(woman_category__gender_identity_reading, 0.08).
narrative_ontology:affects_constraint(woman_category__gender_identity_reading, woman_category__sex_biology_reading).
narrative_ontology:affects_constraint(woman_category__gender_identity_reading, woman_category__intersex_accommodation_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the woman_category kernel. The kernel contest is: what determines membership in the legal/social category 'woman'? This reading (gender_identity_reading) uses internal identity as the criterion. The sex_biology_reading uses chromosomal/anatomical facts. The intersex_accommodation_reading treats biological sex as a spectrum and includes intersex variations. Each reading produces different beneficiary/victim structures and different ε values depending on the application context (identity documents vs sports vs intimate spaces). They are linked via network.affects_constraints because they compete for institutional adoption and because adopting one reading forecloses or constrains the alternatives.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
