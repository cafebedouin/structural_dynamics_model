% ============================================================================
% CONSTRAINT STORY: westphalia_sovereignty__graded_sovereignty
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_westphalia_sovereignty__graded_sovereignty, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: westphalia_sovereignty__graded_sovereignty
 *   human_readable: Graded Sovereignty: Intervention Legitimacy Scaled to State Capacity
 *   domain: international_law/political_theory
 *
 * SUMMARY:
 *   The graded sovereignty reading emerged in post-Cold War international law
 *   as a middle position between absolute non-intervention and unlimited
 *   humanitarian intervention. It treats sovereignty not as categorical
 *   status but as scalar capacity—states with high governance capacity
 *   receive full territorial inviolability, while states with measured
 *   deficits face legitimated external oversight proportional to their
 *   weakness. This reading institutionalizes through state fragility indices,
 *   conditional lending frameworks, and peacekeeping mandates calibrated to
 *   capacity metrics. The claim/metric divergence is deliberate: the
 *   constraint is CLAIMED as tangled_rope (genuine coordination function with
 *   asymmetric costs) while the metrics describe substantial extraction and
 *   rising theater—the engine measures whether the coordination justification
 *   holds under the recorded operation.
 *
 * KEY AGENTS:
 *   - capacity_evaluation_authorities: Institutional agenda-setters (institutional/arbitrage) — design and administer the indices that convert state weakness into intervention legitimacy
 *   - intervening_states: Institutional beneficiaries (institutional/mobile) — gain graduated justification frameworks unavailable under categorical sovereignty
 *   - weak_capacity_states: Organized targets (organized/trapped) — experience sovereignty as conditional credential dependent on external evaluation
 *   - populations_under_paternalistic_oversight: Powerless targets (powerless/trapped) — bear costs of subordinate sovereignty without voice in evaluation design
 *   - global_south_coalitions: Organized excluded voices (organized/constrained) — structurally disadvantaged in evaluation apparatus
 *   - international_law_scholars: Analytical observers — document migration from exception to routine
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(westphalia_sovereignty__graded_sovereignty, 0.68).
domain_priors:suppression_score(westphalia_sovereignty__graded_sovereignty, 0.71).
domain_priors:theater_ratio(westphalia_sovereignty__graded_sovereignty, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, extractiveness, 0.68).
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, suppression_requirement, 0.71).
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, accessibility_collapse, 0.58).
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, resistance, 0.64).

% --- Constraint claim ---
narrative_ontology:constraint_claim(westphalia_sovereignty__graded_sovereignty, tangled_rope).
narrative_ontology:human_readable(westphalia_sovereignty__graded_sovereignty, "Graded Sovereignty: Intervention Legitimacy Scaled to State Capacity").
narrative_ontology:topic_domain(westphalia_sovereignty__graded_sovereignty, "international_law/political_theory").

domain_priors:requires_active_enforcement(westphalia_sovereignty__graded_sovereignty).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(westphalia_sovereignty__graded_sovereignty, 'a6e036a3-91c5-4def-ad34-d58da8d38e0e').
narrative_ontology:cs_kernel_codification('a6e036a3-91c5-4def-ad34-d58da8d38e0e', distributed).
narrative_ontology:cs_authority_grounding('a6e036a3-91c5-4def-ad34-d58da8d38e0e', distributed).
narrative_ontology:cs_reading_relation('a6e036a3-91c5-4def-ad34-d58da8d38e0e', westphalia_sovereignty__absolute_non_intervention, influences).
narrative_ontology:cs_reading_relation('a6e036a3-91c5-4def-ad34-d58da8d38e0e', westphalia_sovereignty__conditional_responsibility, coexists_with).
narrative_ontology:cs_axiom('a6e036a3-91c5-4def-ad34-d58da8d38e0e', foundational, sovereignty_as_earned_capacity).
narrative_ontology:cs_axiom_status(sovereignty_as_earned_capacity, holdable).
narrative_ontology:cs_axiom_grounding('a6e036a3-91c5-4def-ad34-d58da8d38e0e', sovereignty_as_earned_capacity, instrumental).
narrative_ontology:cs_axiom('a6e036a3-91c5-4def-ad34-d58da8d38e0e', foundational, intervention_legitimacy_proportional_to_deficit).
narrative_ontology:cs_axiom_status(intervention_legitimacy_proportional_to_deficit, holdable).
narrative_ontology:cs_axiom_grounding('a6e036a3-91c5-4def-ad34-d58da8d38e0e', intervention_legitimacy_proportional_to_deficit, instrumental).
narrative_ontology:cs_reference_frame('a6e036a3-91c5-4def-ad34-d58da8d38e0e', westphalian_equality_presumption).
narrative_ontology:cs_drift_state('a6e036a3-91c5-4def-ad34-d58da8d38e0e', post_cold_war_fragility_era, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('a6e036a3-91c5-4def-ad34-d58da8d38e0e', '').
narrative_ontology:cs_kernel_id(westphalia_sovereignty__graded_sovereignty, westphalia_sovereignty).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, capacity_evaluation_authorities).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, intervening_states).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, international_development_institutions).
narrative_ontology:constraint_victim(westphalia_sovereignty__graded_sovereignty, weak_capacity_states).
narrative_ontology:constraint_victim(westphalia_sovereignty__graded_sovereignty, populations_under_paternalistic_oversight).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, high_capacity_states).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Develop and administer state capacity indices, fragile state frameworks, and governance metrics that calibrate intervention thresholds. Produce rankings that determine which states receive full sovereignty recognition versus enhanced oversight. Control the definitional apparatus that translates capacity deficits into legitimacy gradients.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, capacity_evaluation_authorities, agenda_setter,
    institutional, generational, arbitrage, global).

% Gain legitimacy frameworks for actions that would violate absolute sovereignty norms—humanitarian intervention, peacekeeping mandates, conditional aid architecture, governance capacity-building missions. The scalar framework provides graduated justification mechanisms unavailable under categorical non-intervention.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, intervening_states, beneficiary,
    institutional, generational, mobile, global).

% Expand operational mandate through capacity-building missions tied to sovereignty deficits. Administer conditional lending tied to governance reforms. The framework converts state weakness into institutional jurisdiction—more fragile the state, broader the mandate.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, international_development_institutions, beneficiary,
    institutional, generational, mobile, global).
narrative_ontology:stakeholder_secondary_role(westphalia_sovereignty__graded_sovereignty, international_development_institutions, agenda_setter).

% Experience sovereignty as conditional status dependent on external evaluation. Face intervention legitimacy inversely proportional to measured capacity. Cannot exit the evaluation framework—participation in international system requires submitting to capacity assessment. Capacity deficits become justification for the very oversight that perpetuates subordinate status.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, weak_capacity_states, payer,
    organized, generational, trapped, national).

% Subject to interventions and governance structures designed by external authorities under capacity-deficit justifications. Experience international system's dual standards—actions that would be domestic sovereignty violations in high-capacity states become legitimate oversight in theirs. Bear costs of subordinate sovereignty: conditioned aid, externally mandated reforms, intervention without consent.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, populations_under_paternalistic_oversight, payer,
    powerless, biographical, trapped, local).

% Occupy top tier of the graduated system. Their domestic arrangements remain categorically inviolable while they participate in evaluating and intervening in lower-tier states. The framework operationalizes a hierarchy that insulates their sovereignty while relativizing others'.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, high_capacity_states, beneficiary,
    institutional, generational, arbitrage, global).

% Argue the capacity metrics encode Western institutional preferences as universal standards. Challenge the framework as neo-colonial hierarchy dressed in technocratic language. Structurally disadvantaged in evaluation mechanisms—their governance models register as deficits regardless of local legitimacy or function.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, global_south_coalitions, excluded,
    organized, generational, constrained, global).

% Analyze whether the graded framework preserves Westphalian equality or abandons it. Some read it as pragmatic adaptation to state diversity; others as formalization of imperial hierarchy. Document how capacity-deficit language migrates from technical assessment to intervention justification.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, international_law_scholars, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a graduated framework for international intervention in contexts where categorical non-intervention produces humanitarian catastrophe but absolute intervention violates sovereignty principles. Calibrates external action to state incapacity, theoretically matching oversight intensity to need.
% TRANSFER_FUNCTION: Moves decision authority over domestic arrangements from weak-capacity states to capacity-evaluation authorities and intervening actors. Transfers sovereignty recognition itself—from categorical status to scalar credential dependent on external assessment.
% ABSENT_VOICES: States classified as weak-capacity have minimal input into the capacity metrics that determine their sovereignty status. The evaluation apparatus is designed and administered by high-capacity states and international institutions, creating a self-reinforcing hierarchy where the evaluated have no voice in evaluation design.
% DISAPPEARANCE_RATIONALE: If the graded sovereignty framework disappeared, international law would revert to categorical sovereignty contests between absolute non-intervention and ad hoc exception claims. The current architecture of conditional lending, peacekeeping mandates, and governance interventions depends structurally on capacity-deficit justifications. Weak states would regain categorical inviolability but lose the legitimacy framework that sometimes constrains arbitrary intervention.
% FOUNDING_PROBLEM: Post-Cold War state failures (Somalia, Rwanda, Yugoslavia) revealed that categorical non-intervention could enable mass atrocities while absolute intervention license risked imperial overreach. The scalar framework emerged to provide graduated legitimacy mechanisms matching intervention to demonstrated incapacity.
% FOUNDING_PROBLEM_CORROBORATION: Intervening states and international institutions attest the founding problem remains live, citing ongoing state fragility and humanitarian crises. Weak-capacity states and Global South coalitions attest the problem has shifted—the framework itself now perpetuates the hierarchy it claimed to regulate. Independent legal scholarship documents how capacity-deficit language has migrated from exception to routine, supporting the shifted-function reading.
narrative_ontology:disappearance_verdict(westphalia_sovereignty__graded_sovereignty, world_rearranges).
narrative_ontology:founding_problem_status(westphalia_sovereignty__graded_sovereignty, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(westphalia_sovereignty__graded_sovereignty, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(westphalia_sovereignty__graded_sovereignty, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(westphalia_sovereignty__graded_sovereignty_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(westphalia_sovereignty__graded_sovereignty, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(westphalia_sovereignty__graded_sovereignty_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is substantial (0.68 at interval end) because the framework converts state weakness into persistent subordination—capacity deficits justify the very oversight that perpetuates weak-state status in a self-reinforcing hierarchy. Suppression is high (0.71) because weak-capacity states cannot exit evaluation without exiting the international system itself; participation requires submitting to scalar assessment. Theater rises moderately (0.42) as capacity-building rhetoric increasingly covers arrangements that concentrate decision authority in evaluating institutions. The measurements track gradual drift from humanitarian exception to institutionalized hierarchy. Accessibility_collapse is moderate (0.58)—weak states have theoretical alternatives (strengthen capacity, form coalitions) but practical exit is blocked by systemic integration. Resistance is substantial (0.64)—Global South coalitions actively contest the framework as neo-colonial, though they cannot withdraw from it.
 *
 * PERSPECTIVAL GAP:
 *   From the capacity-evaluation seat, the framework is pragmatic calibration of international response to genuine state incapacity—matching oversight to need. From the weak-capacity seat, the same structure operates as institutionalized hierarchy where capacity deficits become permanent justification for subordinate status. The engine computes this divergence from the structural data: institutional/arbitrage beneficiaries versus organized/trapped targets with no voice in metric design.
 *
 * DIRECTIONALITY LOGIC:
 *   Capacity-evaluation authorities and intervening states are structural beneficiaries—they gain jurisdiction, legitimacy frameworks, and decision authority through the scalar structure (d near beneficiary end, low/negative χ). Weak-capacity states and their populations are targets—they experience sovereignty loss and paternalistic oversight proportional to measured weakness (d near target end, high χ). High-capacity states benefit through insulated sovereignty while participating in others' evaluation. The dual benefit structure (intervening states gain legitimacy, evaluating institutions gain mandate) distinguishes this reading from conditional_responsibility, where intervention is exceptional rather than graduated.
 *
 * MANDATROPHY ANALYSIS:
 *   The founding problem (state failure enabling atrocities under categorical non-intervention) was real; the coordination function (graduated response framework) is genuine. But the asymmetric structure—evaluating authorities come from the high-capacity tier, evaluated states have no voice in metric design, capacity deficits justify perpetual oversight—makes this extractive coordination, not pure rope. The tangled_rope classification captures both: real coordination need AND structural extraction through one-way evaluation architecture.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    capacity_metric_encoding,
    'Do the capacity indices measure universal state function or encode Western institutional preferences as universal standards?',
    'Cross-cultural validation of governance metrics; analysis of whether non-Western governance models systematically register as deficits regardless of local legitimacy or effectiveness.',
    'If metrics encode institutional preferences, the framework is imperial hierarchy dressed in technocratic language rather than pragmatic adaptation. If metrics track universal function, the graduated approach has empirical grounding.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(capacity_metric_encoding, empirical, 'Whether capacity assessment is neutral measurement or preference imposition.').

omega_variable(
    oversight_perpetuation,
    'Does external oversight under capacity-deficit justifications strengthen state capacity or perpetuate the weakness that justifies continued oversight?',
    'Longitudinal analysis of capacity trajectories under different oversight intensities; natural experiments from states that rejected conditional frameworks.',
    'If oversight strengthens capacity and terminates itself, the framework is transitional coordination. If oversight perpetuates dependency, it is extraction dressed as capacity-building.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(oversight_perpetuation, empirical, 'Whether the intervention architecture is self-limiting or self-perpetuating.').

omega_variable(
    hierarchy_formalization,
    'Is this reading a pragmatic adaptation to state diversity or the formalization of a two-tier international system where sovereignty is categorical for some and conditional for others?',
    'Comparative analysis of how capacity frameworks apply to high-capacity state failures versus low-capacity state failures; test whether governance deficits in powerful states trigger equivalent oversight.',
    'If the framework applies symmetrically, it is coordination with universal rules. If it applies asymmetrically (deficits in weak states justify intervention, deficits in powerful states remain domestic), it is institutionalized hierarchy.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(hierarchy_formalization, conceptual, 'Whether the scalar framework preserves sovereignty equality or abandons it.').

omega_variable(
    committer_frame_ambiguity,
    'Is the graded_sovereignty reading a descriptive account of existing international practice or a normative claim that sovereignty SHOULD be scalar?',
    'Analysis of whether proponents cite the framework as empirical reality (states already operate on capacity gradients) or as normative ideal (sovereignty should be earned through capacity). The ambiguity allows the reading to slip between descriptive and prescriptive modes.',
    'If descriptive, the reading documents power asymmetries without endorsing them. If normative, it legitimates hierarchy as proper structure rather than regrettable fact.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(committer_frame_ambiguity, conceptual, 'Whether the scalar framework is claimed as fact or advocated as norm.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(westphalia_sovereignty__graded_sovereignty, 0, 30).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(west_tr_t0, westphalia_sovereignty__graded_sovereignty, theater_ratio, 0, 0.28).
narrative_ontology:measurement(west_tr_t6, westphalia_sovereignty__graded_sovereignty, theater_ratio, 6, 0.31).
narrative_ontology:measurement(west_tr_t12, westphalia_sovereignty__graded_sovereignty, theater_ratio, 12, 0.35).
narrative_ontology:measurement(west_tr_t18, westphalia_sovereignty__graded_sovereignty, theater_ratio, 18, 0.38).
narrative_ontology:measurement(west_tr_t24, westphalia_sovereignty__graded_sovereignty, theater_ratio, 24, 0.4).
narrative_ontology:measurement(west_tr_t30, westphalia_sovereignty__graded_sovereignty, theater_ratio, 30, 0.42).

% Extraction over time
narrative_ontology:measurement(west_be_t0, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 0, 0.48).
narrative_ontology:measurement(west_be_t6, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 6, 0.53).
narrative_ontology:measurement(west_be_t12, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 12, 0.58).
narrative_ontology:measurement(west_be_t18, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 18, 0.62).
narrative_ontology:measurement(west_be_t24, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 24, 0.65).
narrative_ontology:measurement(west_be_t30, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 30, 0.68).

% Suppression requirement over time
narrative_ontology:measurement(west_su_t0, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 0, 0.52).
narrative_ontology:measurement(west_su_t6, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 6, 0.57).
narrative_ontology:measurement(west_su_t12, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 12, 0.62).
narrative_ontology:measurement(west_su_t18, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 18, 0.66).
narrative_ontology:measurement(west_su_t24, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 24, 0.69).
narrative_ontology:measurement(west_su_t30, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 30, 0.71).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:affects_constraint(westphalia_sovereignty__graded_sovereignty, westphalia_sovereignty__absolute_non_intervention).
narrative_ontology:affects_constraint(westphalia_sovereignty__graded_sovereignty, westphalia_sovereignty__conditional_responsibility).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the westphalia_sovereignty kernel. All three readings (absolute_non_intervention, conditional_responsibility, graded_sovereignty) address territorial inviolability but differ structurally on what makes intervention legitimate. The graded reading creates graduated legitimacy proportional to capacity deficits; the absolute reading makes intervention categorically illegitimate; the conditional reading makes intervention legitimate only at atrocity thresholds. Network edges link all three as the constraint family decomposing contested Westphalian sovereignty.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
