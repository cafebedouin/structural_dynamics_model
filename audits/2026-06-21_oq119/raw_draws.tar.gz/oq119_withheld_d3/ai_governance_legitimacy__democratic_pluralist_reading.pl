% ============================================================================
% CONSTRAINT STORY: ai_governance_legitimacy__democratic_pluralist_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2024-01-09
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_ai_governance_legitimacy__democratic_pluralist_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: ai_governance_legitimacy__democratic_pluralist_reading
 *   human_readable: Democratic Pluralist AI Governance Reading
 *   domain: theological_ethics/technology_governance/political_theology
 *
 * SUMMARY:
 *   This constraint instantiates a democratic pluralist reading of AI
 *   governance legitimacy that centers popular sovereignty and inclusive
 *   public reason. It denies interpretive monopoly to any single
 *   tradition—whether Catholic Social Doctrine or technocratic
 *   optimization—and instead grounds authority in transparent deliberative
 *   processes accountable to diverse constituencies. The encyclical's dignity
 *   framework enters as one voice among many rather than as binding doctrine.
 *   The constraint is transitional (scaffold) because it builds participatory
 *   infrastructure intended to mature into self-sustaining democratic norms.
 *   KEY AGENTS (by structural relationship): - Democratic institutions
 *   (institutional/constrained): Administer deliberative processes; benefit
 *   from expanded legitimacy but bear infrastructure costs - Civil society
 *   organizations (organized/mobile): Gain formal voice through mandated
 *   consultation; primary beneficiaries of participatory structures -
 *   Minority rights holders (organized/constrained): Protected through
 *   explicit balancing mechanisms and judicial review - Populations under
 *   authoritarian regimes (powerless/trapped): Subject to AI governance
 *   without consent; constraint exists only as aspiration in their context -
 *   Systematically excluded communities (powerless/identity_locked):
 *   Nominally included but structurally marginalized by barriers to effective
 *   participation - Magisterial authorities (institutional/mobile, excluded):
 *   Denied unique interpretive authority; participate as one voice rather
 *   than authoritative arbiter
 *
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(ai_governance_legitimacy__democratic_pluralist_reading, 0.4).
domain_priors:suppression_score(ai_governance_legitimacy__democratic_pluralist_reading, 0.35).
domain_priors:theater_ratio(ai_governance_legitimacy__democratic_pluralist_reading, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, extractiveness, 0.4).
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 0.35).
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, accessibility_collapse, 0.45).
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, resistance, 0.5).

% --- Constraint claim ---
narrative_ontology:constraint_claim(ai_governance_legitimacy__democratic_pluralist_reading, scaffold).
narrative_ontology:human_readable(ai_governance_legitimacy__democratic_pluralist_reading, "Democratic Pluralist AI Governance Reading").
narrative_ontology:topic_domain(ai_governance_legitimacy__democratic_pluralist_reading, "theological_ethics/technology_governance/political_theology").

domain_priors:requires_active_enforcement(ai_governance_legitimacy__democratic_pluralist_reading).
narrative_ontology:has_sunset_clause(ai_governance_legitimacy__democratic_pluralist_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(ai_governance_legitimacy__democratic_pluralist_reading, '6635bfb1-d1d7-4811-b20f-92694444b390').
narrative_ontology:cs_kernel_codification('6635bfb1-d1d7-4811-b20f-92694444b390', distributed).
narrative_ontology:cs_authority_grounding('6635bfb1-d1d7-4811-b20f-92694444b390', practice).
narrative_ontology:cs_interpretation_layer_present('6635bfb1-d1d7-4811-b20f-92694444b390').
narrative_ontology:cs_reading_relation('6635bfb1-d1d7-4811-b20f-92694444b390', ai_governance_legitimacy__magisterial_subsidiarity_reading, coexists_with).
narrative_ontology:cs_reading_relation('6635bfb1-d1d7-4811-b20f-92694444b390', ai_governance_legitimacy__market_libertarian_reading, influences).
narrative_ontology:cs_reading_relation('6635bfb1-d1d7-4811-b20f-92694444b390', ai_governance_legitimacy__technocratic_optimization_reading, influences).
narrative_ontology:cs_axiom('6635bfb1-d1d7-4811-b20f-92694444b390', foundational, no_tradition_holds_interpretive_monopoly).
narrative_ontology:cs_axiom_status(no_tradition_holds_interpretive_monopoly, holdable).
narrative_ontology:cs_axiom_grounding('6635bfb1-d1d7-4811-b20f-92694444b390', no_tradition_holds_interpretive_monopoly, deontological).
narrative_ontology:cs_axiom('6635bfb1-d1d7-4811-b20f-92694444b390', foundational, legitimacy_derives_from_inclusive_consent).
narrative_ontology:cs_axiom_status(legitimacy_derives_from_inclusive_consent, holdable).
narrative_ontology:cs_axiom_grounding('6635bfb1-d1d7-4811-b20f-92694444b390', legitimacy_derives_from_inclusive_consent, conventional).
narrative_ontology:cs_axiom('6635bfb1-d1d7-4811-b20f-92694444b390', secondary, principles_emerge_from_deliberation_not_doctrine).
narrative_ontology:cs_axiom_status(principles_emerge_from_deliberation_not_doctrine, holdable).
narrative_ontology:cs_axiom_grounding('6635bfb1-d1d7-4811-b20f-92694444b390', principles_emerge_from_deliberation_not_doctrine, conventional).
narrative_ontology:cs_reference_frame('6635bfb1-d1d7-4811-b20f-92694444b390', inclusive_public_reason_framework).
narrative_ontology:cs_drift_state('6635bfb1-d1d7-4811-b20f-92694444b390', contemporary_implementation, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('6635bfb1-d1d7-4811-b20f-92694444b390', '').
narrative_ontology:cs_kernel_id(ai_governance_legitimacy__democratic_pluralist_reading, ai_governance_legitimacy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__democratic_pluralist_reading, civil_society_organizations).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__democratic_pluralist_reading, democratic_institutions).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__democratic_pluralist_reading, minority_rights_holders).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__democratic_pluralist_reading, participatory_governance_advocates).
narrative_ontology:constraint_victim(ai_governance_legitimacy__democratic_pluralist_reading, populations_under_authoritarian_regimes).
narrative_ontology:constraint_victim(ai_governance_legitimacy__democratic_pluralist_reading, systematically_excluded_communities).
narrative_ontology:constraint_victim(ai_governance_legitimacy__democratic_pluralist_reading, deliberatively_disenfranchised_groups).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Gain formal voice in AI governance processes through mandated consultation mechanisms. Access transparency requirements and participatory structures that elevate their input from advisory to constitutive. The constraint creates institutional channels where their advocacy becomes part of the deliberative architecture rather than external pressure.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, civil_society_organizations, beneficiary,
    organized, generational, mobile, global).

% Administer the deliberative processes and enforce transparency requirements. Benefit from expanded legitimacy by grounding AI governance in public consent rather than technocratic or religious authority. Bear the cost of building and maintaining inclusive consultation infrastructure across diverse constituencies.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, democratic_institutions, agenda_setter,
    institutional, generational, constrained, national).
narrative_ontology:stakeholder_secondary_role(ai_governance_legitimacy__democratic_pluralist_reading, democratic_institutions, beneficiary).

% Protected through explicit balancing mechanisms that prevent majoritarian overrides of fundamental rights in AI deployment. The constraint requires their inclusion in deliberative processes and judicial review of governance decisions that affect their interests. Exit is constrained by jurisdictional boundaries but voice is institutionally guaranteed.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, minority_rights_holders, beneficiary,
    organized, biographical, constrained, national).

% Subject to AI systems governed without their consent or participation. The constraint's legitimacy framework exists in their jurisdiction only as theoretical aspiration; they bear the costs of surveillance, social credit systems, and algorithmic control with no deliberative recourse or exit.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, populations_under_authoritarian_regimes, payer,
    powerless, biographical, trapped, national).

% Nominally included in deliberative processes but structurally excluded by language barriers, digital divides, or procedural complexity. The constraint's promise of inclusive participation extracts legitimacy from their theoretical inclusion while their actual influence remains minimal. Identity-locked because their marginalization is constitutive of their social position.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, systematically_excluded_communities, payer,
    powerless, biographical, identity_locked, local).

% Have formal participation rights but lack resources or institutional knowledge to engage effectively. The time cost and expertise required to participate in technical AI governance debates extracts from their capacity while legitimizing decisions they could not meaningfully shape.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, deliberatively_disenfranchised_groups, payer,
    moderate, biographical, constrained, regional).

% The constraint instantiates their normative commitments in institutional form. They gain resources, visibility, and authority as the framework expands. Their exit options are high because the deliberative infrastructure they advocate for is globally portable across democratic contexts.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, participatory_governance_advocates, beneficiary,
    organized, generational, mobile, global).

% The constraint denies them unique interpretive authority over dignity and common good claims in AI governance. They participate as one voice among many rather than as authoritative arbiters. This reading treats their encyclical contributions as valuable input to public reason, not binding doctrine.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, magisterial_authorities, excluded,
    institutional, civilizational, mobile, global).

% The constraint subordinates efficiency and innovation metrics to democratic legitimacy requirements. They advocate for minimal procedural constraints on technical development but must navigate deliberative approval processes. High exit via jurisdiction shopping to governance regimes that prioritize optimization over participation.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, technocratic_optimization_advocates, excluded,
    powerful, biographical, arbitrage, global).

% Study how the constraint's participatory requirements interact with different democratic traditions and constitutional structures. Measure whether inclusive deliberation produces more legitimate AI governance or whether the procedural costs exceed the gains in consent.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, comparative_political_theorists, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Coordinates diverse value commitments across pluralistic societies by creating structured deliberative processes where competing claims about AI ethics can be transparently contested and provisionally resolved through democratic procedures rather than imposed by any single authority.
% TRANSFER_FUNCTION: Transfers interpretive authority over AI governance principles from specialized elites (religious or technocratic) to representative democratic institutions and participatory processes. Transfers time and expertise from marginalized communities into consultation infrastructure as the price of legitimacy.
% ABSENT_VOICES: Populations in authoritarian regimes who have no meaningful participation rights, and systematically marginalized communities within democracies whose formal inclusion masks structural barriers to effective voice. They would testify that deliberative ideals do not reach them.
% DISAPPEARANCE_RATIONALE: Democratic pluralists argue AI governance would devolve into technocratic or corporate capture without deliberative accountability. Critics argue the constraint imposes procedural costs that slow beneficial innovation while still excluding those without resources to participate effectively. The rearrangement depends on whether the participatory infrastructure genuinely distributes power or merely legitimizes pre-determined outcomes.
narrative_ontology:disappearance_verdict(ai_governance_legitimacy__democratic_pluralist_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(ai_governance_legitimacy__democratic_pluralist_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(ai_governance_legitimacy__democratic_pluralist_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(ai_governance_legitimacy__democratic_pluralist_reading_tests).
:- end_tests(ai_governance_legitimacy__democratic_pluralist_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is moderate (0.40) because the constraint genuinely coordinates diverse value commitments through structured processes, but imposes real costs on marginalized communities whose participation is extracted to legitimize outcomes they may not meaningfully shape. The extraction accumulates slowly as the procedural requirements mature and the gap between nominal and effective inclusion becomes visible. Suppression is relatively low (0.35) because the constraint operates through electoral accountability and judicial review rather than force, though it does suppress alternative authority claims (magisterial or technocratic). Theater ratio rises modestly (0.15 to 0.28) as consultation processes proliferate but their actual influence on technical decisions remains contested. Accessibility collapse is moderate (0.45) because alternative governance frameworks remain conceptually and practically available, though this reading has substantial institutional momentum in established democracies. Resistance is significant (0.50) from both excluded traditions and from those who bear the costs of deliberative complexity without gaining proportional influence.
 *
 * PERSPECTIVAL GAP:
 *   From the agenda-setter seat (democratic institutions), the constraint operates as genuine coordination building legitimate governance through inclusive deliberation. From the beneficiary seats (civil society, participatory advocates), it instantiates their normative vision and expands their institutional power. From the victim seats, the same structure extracts legitimacy through nominal inclusion while leaving substantive power asymmetries intact—authoritarian populations have no recourse, marginalized communities face barriers the constraint does not address, and resource-poor groups cannot participate effectively. The engine should compute scaffold from the beneficiary/agenda-setter seats and extract more heavily from the victim seats where identity-lock and resource constraints concentrate costs.
 *
 * DIRECTIONALITY LOGIC:
 *   Civil society organizations and participatory governance advocates are structural beneficiaries—the constraint instantiates their normative commitments and creates institutional channels for their influence, placing them near the beneficiary end (d near 0.0). Democratic institutions occupy a mixed position: they gain legitimacy but bear administrative costs (d near 0.3). Minority rights holders benefit from explicit protections (d near 0.2). Victims sit at higher d values: populations under authoritarian regimes experience pure extraction with no participation rights (d near 0.95), systematically excluded communities face identity-locked extraction where nominal inclusion masks structural barriers (d near 0.85), and deliberatively disenfranchised groups bear time/expertise costs without proportional influence (d near 0.65). Excluded seats (magisterial authorities, technocratic advocates) are not targets of extraction but rather parties denied authority they claim under alternative readings.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint is transitional by design: it builds participatory infrastructure with the explicit goal of maturing into self-sustaining democratic norms where AI governance emerges from inclusive public reason rather than imposed authority. The sunset condition is reached when deliberative processes become sufficiently institutionalized that the scaffolding requirements can be relaxed without reverting to technocratic or religious monopoly. However, the rising theater ratio and the gap between nominal and effective inclusion raise the mandatrophy question: if the deliberative infrastructure persists but systematically fails to include marginalized voices, it may calcify into a legitimacy-extraction mechanism rather than maturing into genuine pluralism. The omega variables address whether the coordination function remains separable from the extraction or whether the constraint is transitioning toward institutionalized exclusion dressed as inclusion.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    nominal_versus_effective_inclusion,
    'Does the constraint''s deliberative infrastructure produce genuine power-sharing across diverse constituencies, or does it extract legitimacy through nominal inclusion while leaving substantive decision authority with resource-advantaged actors?',
    'Longitudinal measurement of policy outcomes: do AI governance decisions track the preferences of systematically marginalized communities when those preferences diverge from elite consensus, or do deliberative processes consistently produce outcomes that could have been predicted from elite preferences alone?',
    'If deliberation genuinely distributes power, the constraint remains a transitional scaffold building toward pluralistic norms. If inclusion is nominal, the constraint transitions toward a more extractive tangled_rope where participation costs are imposed to legitimize pre-determined outcomes.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(nominal_versus_effective_inclusion, empirical, 'Whether deliberative inclusion produces substantive power-sharing or extracts legitimacy through procedural theater').

omega_variable(
    procedural_versus_substantive_legitimacy,
    'Can democratic pluralism ground AI governance legitimacy purely through inclusive processes, or does legitimacy require substantive conformity to pre-political principles (dignity, rights, common good) that constrain what majorities may decide?',
    'Conceptual analysis and normative theory examining whether procedural legitimacy is sufficient or whether it presupposes substantive commitments that themselves require grounding beyond consent.',
    'If procedural legitimacy is sufficient, this reading holds and alternative authority claims (magisterial, natural law) are appropriately excluded. If substantive principles are required, the reading either collapses into one of its siblings or must specify which substantive commitments constrain the deliberative process and where those commitments derive their authority.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(procedural_versus_substantive_legitimacy, conceptual, 'Whether inclusive deliberation suffices for legitimacy or whether substantive pre-political principles are required').

omega_variable(
    transitional_versus_permanent_structure,
    'Is the constraint genuinely transitional, building capacity that will mature into self-sustaining norms, or is the participatory infrastructure a permanent requirement that extracts ongoing costs without sunset?',
    'Observation over generational timescales: do deliberative requirements decline as democratic AI governance norms internalize, or do procedural costs accumulate as the infrastructure becomes institutionally entrenched?',
    'If transitional, the scaffold classification holds and rising extraction is a measurement of the transition''s slowness. If permanent, the constraint should be reclassified as tangled_rope where coordination and extraction are structurally fused.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(transitional_versus_permanent_structure, empirical, 'Whether the deliberative infrastructure is transitional scaffolding or permanent extraction mechanism').

omega_variable(
    democratic_pluralist_versus_magisterial_framing,
    'This constraint is one reading of the ai_governance_legitimacy kernel. The democratic pluralist reading treats the encyclical as one voice among many; the magisterial_subsidiarity_reading treats Catholic Social Doctrine as authoritative. Which framing captures the constraint''s actual operation in mixed secular-religious polities?',
    'Observation of how AI governance institutions handle conflicts between democratic majorities and magisterial claims: does the Magisterium''s voice carry unique weight beyond its persuasive force in public reason, or is it one participant in pluralistic deliberation?',
    'If magisterial claims receive unique deference, the democratic_pluralist_reading mischaracterizes the constraint and the magisterial reading better captures its structure. If the encyclical enters as contestable input, this reading holds.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(democratic_pluralist_versus_magisterial_framing, conceptual, 'Kernel framing ambiguity between democratic pluralist and magisterial authority readings').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(ai_governance_legitimacy__democratic_pluralist_reading, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(ai_g_tr_t0, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 0, 0.15).
narrative_ontology:measurement(ai_g_tr_t5, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 5, 0.18).
narrative_ontology:measurement(ai_g_tr_t10, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 10, 0.22).
narrative_ontology:measurement(ai_g_tr_t15, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 15, 0.25).
narrative_ontology:measurement(ai_g_tr_t20, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 20, 0.27).
narrative_ontology:measurement(ai_g_tr_t25, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 25, 0.28).

% Extraction over time
narrative_ontology:measurement(ai_g_be_t0, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 0, 0.32).
narrative_ontology:measurement(ai_g_be_t5, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 5, 0.35).
narrative_ontology:measurement(ai_g_be_t10, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 10, 0.38).
narrative_ontology:measurement(ai_g_be_t15, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 15, 0.39).
narrative_ontology:measurement(ai_g_be_t20, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 20, 0.4).
narrative_ontology:measurement(ai_g_be_t25, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 25, 0.4).

% Suppression requirement over time
narrative_ontology:measurement(ai_g_su_t0, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 0, 0.3).
narrative_ontology:measurement(ai_g_su_t5, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 5, 0.32).
narrative_ontology:measurement(ai_g_su_t10, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 10, 0.33).
narrative_ontology:measurement(ai_g_su_t15, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 15, 0.34).
narrative_ontology:measurement(ai_g_su_t20, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 20, 0.35).
narrative_ontology:measurement(ai_g_su_t25, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 25, 0.35).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(ai_governance_legitimacy__democratic_pluralist_reading, identity_coordination).
narrative_ontology:boltzmann_floor_override(ai_governance_legitimacy__democratic_pluralist_reading, 0.12).
narrative_ontology:affects_constraint(ai_governance_legitimacy__democratic_pluralist_reading, ai_governance_legitimacy__magisterial_subsidiarity_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__democratic_pluralist_reading, ai_governance_legitimacy__technocratic_optimization_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__democratic_pluralist_reading, ai_governance_legitimacy__market_libertarian_reading).

% DUAL FORMULATION NOTE:
% This constraint is part of the ai_governance_legitimacy kernel family. All four readings decompose a single contested claim (where does AI governance authority derive from) into structurally distinct constraints with different beneficiary sets, extraction profiles, and enforcement mechanisms. Democratic pluralist reading: authority from inclusive deliberation. Magisterial reading: authority from conformity to Catholic Social Doctrine. Market libertarian reading: authority from voluntary exchange and exit. Technocratic reading: authority from expertise and welfare optimization. The extraction values differ substantially (democratic 0.40, magisterial 0.50, market 0.25, technocratic 0.55), confirming these are distinct constraints per ε-invariance, not measurement angles on one constraint.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
