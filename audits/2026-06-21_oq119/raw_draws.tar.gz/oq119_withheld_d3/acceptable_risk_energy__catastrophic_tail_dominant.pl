% ============================================================================
% CONSTRAINT STORY: acceptable_risk_energy__catastrophic_tail_dominant
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2025-01-09
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_acceptable_risk_energy__catastrophic_tail_dominant, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: acceptable_risk_energy__catastrophic_tail_dominant
 *   human_readable: Catastrophic-Tail-Dominant Acceptable Risk (Energy Policy)
 *   domain: risk_assessment/energy_policy/decision_theory
 *
 * SUMMARY:
 *   This constraint is the catastrophic-tail-dominant reading of the
 *   acceptable_risk_energy kernel. It operationalizes 'acceptable risk'
 *   through extreme avoidance of low-probability catastrophic events (nuclear
 *   accidents), even when this produces higher aggregate mortality through
 *   the retained high-probability distributed harms (fossil fuel air
 *   pollution, climate deaths). The reading is claimed as tangled_rope:
 *   genuine coordination function (society needs shared risk criteria)
 *   co-exists with asymmetric extraction (mortality burden shifts to diffuse
 *   victims, regulatory burden suppresses statistically safer pathways). The
 *   metrics describe substantially extractive operation with rising
 *   enforcement intensity over the interval.
 *
 * KEY AGENTS:
 *   - environmental_advocacy_coalitions: agenda_setter (organized/mobile) — institutionalized the precautionary framing in energy regulation
 *   - fossil_fuel_incumbents: beneficiary (institutional/arbitrage) — structurally benefit from nuclear suppression without direct advocacy
 *   - regulatory_agencies: agenda_setter + beneficiary (institutional/constrained) — administer asymmetric regulatory burdens, benefit from complexity justifying authority
 *   - climate_vulnerable_populations: payer (powerless/trapped) — bear distributed catastrophic climate harm discounted by event-salience bias
 *   - air_quality_affected_communities: payer (powerless/trapped) — experience fossil mortality that doesn't register as 'catastrophic'
 *   - nuclear_sector_workers: payer (moderate/constrained) — lose employment as tail-weighting closes nuclear pathways despite superior safety record
 *   - expected_value_analysts: excluded (analytical/analytical) — their evidence form is inadmissible within the framework
 *   - decision_theorists: observer (analytical/analytical) — study the frame's perverse outcomes
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(acceptable_risk_energy__catastrophic_tail_dominant, 0.68).
domain_priors:suppression_score(acceptable_risk_energy__catastrophic_tail_dominant, 0.82).
domain_priors:theater_ratio(acceptable_risk_energy__catastrophic_tail_dominant, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, extractiveness, 0.68).
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 0.82).
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, accessibility_collapse, 0.61).
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, resistance, 0.58).

% --- Constraint claim ---
narrative_ontology:constraint_claim(acceptable_risk_energy__catastrophic_tail_dominant, tangled_rope).
narrative_ontology:human_readable(acceptable_risk_energy__catastrophic_tail_dominant, "Catastrophic-Tail-Dominant Acceptable Risk (Energy Policy)").
narrative_ontology:topic_domain(acceptable_risk_energy__catastrophic_tail_dominant, "risk_assessment/energy_policy/decision_theory").

domain_priors:requires_active_enforcement(acceptable_risk_energy__catastrophic_tail_dominant).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(acceptable_risk_energy__catastrophic_tail_dominant, 'cb225538-6f53-4a27-93e3-74d6d5f68812').
narrative_ontology:cs_kernel_codification('cb225538-6f53-4a27-93e3-74d6d5f68812', distributed).
narrative_ontology:cs_authority_grounding('cb225538-6f53-4a27-93e3-74d6d5f68812', distributed).
narrative_ontology:cs_reading_relation('cb225538-6f53-4a27-93e3-74d6d5f68812', acceptable_risk_energy__expected_value_dominant, coexists_with).
narrative_ontology:cs_reading_relation('cb225538-6f53-4a27-93e3-74d6d5f68812', acceptable_risk_energy__option_value_preserving, influences).
narrative_ontology:cs_axiom('cb225538-6f53-4a27-93e3-74d6d5f68812', foundational, visible_catastrophe_infinite_disutility).
narrative_ontology:cs_axiom_status(visible_catastrophe_infinite_disutility, holdable).
narrative_ontology:cs_axiom_grounding('cb225538-6f53-4a27-93e3-74d6d5f68812', visible_catastrophe_infinite_disutility, deontological).
narrative_ontology:cs_axiom('cb225538-6f53-4a27-93e3-74d6d5f68812', secondary, distributed_harm_discounting_legitimate).
narrative_ontology:cs_axiom_status(distributed_harm_discounting_legitimate, holdable).
narrative_ontology:cs_axiom_grounding('cb225538-6f53-4a27-93e3-74d6d5f68812', distributed_harm_discounting_legitimate, conventional).
narrative_ontology:cs_reference_frame('cb225538-6f53-4a27-93e3-74d6d5f68812', post_chernobyl_precautionary_institutionalization).
narrative_ontology:cs_drift_state('cb225538-6f53-4a27-93e3-74d6d5f68812', post_climate_evidence_accumulation, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('cb225538-6f53-4a27-93e3-74d6d5f68812', '').
narrative_ontology:cs_kernel_id(acceptable_risk_energy__catastrophic_tail_dominant, acceptable_risk_energy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__catastrophic_tail_dominant, environmental_advocacy_coalitions).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__catastrophic_tail_dominant, fossil_fuel_incumbents).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__catastrophic_tail_dominant, regulatory_agencies).
narrative_ontology:constraint_victim(acceptable_risk_energy__catastrophic_tail_dominant, climate_vulnerable_populations).
narrative_ontology:constraint_victim(acceptable_risk_energy__catastrophic_tail_dominant, air_quality_affected_communities).
narrative_ontology:constraint_victim(acceptable_risk_energy__catastrophic_tail_dominant, nuclear_sector_workers).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__catastrophic_tail_dominant, precautionary_principle_supremacy).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__catastrophic_tail_dominant, visible_harm_salience_doctrine).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Frame acceptable risk through catastrophic-tail avoidance, successfully institutionalizing precautionary principles in energy regulation. Deploy visible nuclear accident narratives to maintain heightened risk perception while distributing fossil fuel mortality across space and time makes it less politically salient. Control key regulatory appointments and legislative language.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, environmental_advocacy_coalitions, agenda_setter,
    organized, generational, mobile, national).

% Benefit from nuclear pathway suppression without directly advocating for it—the catastrophic-tail frame does that work structurally. Their distributed mortality pattern (air pollution, climate impacts) escapes the 'catastrophic' classification while nuclear's concentrated-event profile triggers it, preserving market position through others' risk framing.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, fossil_fuel_incumbents, beneficiary,
    institutional, biographical, arbitrage, global).

% Administer the risk framework, imposing asymmetric regulatory burdens that operationalize the tail-weighting principle. Nuclear requires extensive catastrophic-scenario planning and liability caps; fossil infrastructure faces lighter review because its harms distribute. Regulatory complexity justifies agency budget and authority.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, regulatory_agencies, agenda_setter,
    institutional, generational, constrained, national).
narrative_ontology:stakeholder_secondary_role(acceptable_risk_energy__catastrophic_tail_dominant, regulatory_agencies, beneficiary).

% Bear the accumulated mortality and displacement from climate change—the distributed catastrophic outcome discounted by the framework's event-salience bias. Their harm is structurally invisible in catastrophic-tail accounting because it arrives incrementally rather than as a singular event, despite higher aggregate death toll.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, climate_vulnerable_populations, payer,
    powerless, generational, trapped, global).

% Experience elevated mortality from fossil fuel combustion (particulates, toxics) but their deaths don't register as 'catastrophic' because they're statistically dispersed. The framework treats 10,000 deaths over a decade differently than 100 deaths in one event, systematically underweighting their harm.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, air_quality_affected_communities, payer,
    powerless, biographical, trapped, local).

% Lose employment and professional identity as nuclear pathways close under the regulatory burden the tail-weighting imposes. Their sector's actual safety record (lowest mortality-per-TWh of any major energy source) is structurally irrelevant because the framework gates on theoretical tail risk, not realized outcomes.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, nuclear_sector_workers, payer,
    moderate, biographical, constrained, national).

% Produce mortality-per-TWh comparisons showing nuclear as statistically safest, but this evidence is inadmissible within the tail-dominant framework—mentioning it triggers accusations of ignoring Chernobyl/Fukushima. Their analytic seat is structurally excluded from the policy formation that operationalizes acceptable risk.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, expected_value_analysts, excluded,
    analytical, generational, analytical, global).

% Study how catastrophic-tail framing systematically produces perverse outcomes when tail-events are rare but salient while baseline harms are common but diffuse. Document the frame as extractive when it concentrates regulatory burden on low-mortality pathways while protecting high-mortality incumbents.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, decision_theorists, observer,
    analytical, civilizational, analytical, universal).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes shared risk criteria for energy infrastructure decisions, theoretically coordinating societal choices about which hazards to accept and which to avoid through precautionary tail-risk weighting.
% TRANSFER_FUNCTION: Transfers mortality burden from hypothetical future nuclear accident victims (small probability × large consequence) to actual present-day fossil fuel mortality victims (high probability × individually small but cumulatively massive consequence), while transferring regulatory compliance costs from fossil incumbents to nuclear sector.
% ABSENT_VOICES: Expected-value decision theorists and climate-vulnerable populations from the Global South are structurally excluded—the former because their evidence form is inadmissible, the latter because their distributed catastrophic harm (climate displacement, heat mortality) doesn't trigger the event-salience mechanism the framework uses to define 'catastrophic.'
% DISAPPEARANCE_RATIONALE: If the catastrophic-tail-dominant risk framework vanished overnight, energy policy would reorganize around aggregate mortality metrics. Nuclear would face lower regulatory burdens (its actual mortality record is superior), fossil fuel projects would require catastrophic-climate-scenario planning (distributed harm would become salient), and investment flows would redirect toward the statistically safest pathways rather than the most emotionally available ones.
% FOUNDING_PROBLEM: Post-Chernobyl need to institutionalize societal control over technologies capable of producing singular catastrophic events, ensuring such events could never recur regardless of statistical likelihood.
% FOUNDING_PROBLEM_CORROBORATION: Environmental coalitions and regulatory agencies attest the problem remains live, citing ongoing nuclear risk. Decision theorists, energy economists, and public health researchers from outside the benefiting coalitions attest the founding problem has been solved (modern reactor designs, improved safety culture) but the framework persists, now protecting fossil incumbents from distributed-harm accounting that would reveal their mortality burden as the larger catastrophe.
narrative_ontology:disappearance_verdict(acceptable_risk_energy__catastrophic_tail_dominant, world_rearranges).
narrative_ontology:founding_problem_status(acceptable_risk_energy__catastrophic_tail_dominant, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(acceptable_risk_energy__catastrophic_tail_dominant, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(acceptable_risk_energy__catastrophic_tail_dominant, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(acceptable_risk_energy__catastrophic_tail_dominant_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(acceptable_risk_energy__catastrophic_tail_dominant, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(acceptable_risk_energy__catastrophic_tail_dominant_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction (0.68) reflects the mortality transfer: preventing rare nuclear deaths by accepting common fossil deaths produces net harm increase measured in lives. Suppression (0.82) is high because the framework must actively exclude expected-value evidence and suppress nuclear pathways—its persistence depends on keeping mortality-per-TWh comparisons out of policy discourse. Theater ratio (0.42) captures the gap between stated goal (minimize catastrophic risk) and actual function (protect incumbent energy sources): elaborate nuclear safety theater while fossil mortality remains unaccounted. The measurement trajectory shows extraction and enforcement both intensifying as climate evidence accumulated but remained structurally invisible to the tail-dominant frame.
 *
 * PERSPECTIVAL GAP:
 *   From the agenda_setter seats (coalitions, agencies), the framework is legitimate precautionary risk governance coordinating societal choices about technology. From the powerless payer seats (climate/air-quality victims), the same structure operates as enforced mortality transfer—they die from the 'acceptable' distributed risk while visible catastrophic risk is avoided. From the analytical excluded seat, the framework is a category error weaponized: treating event-salience as risk-magnitude systematically protects high-mortality pathways. The engine should compute these seats as experiencing different constraint types from the same structural arrangement.
 *
 * DIRECTIONALITY LOGIC:
 *   Environmental coalitions and regulatory agencies are structural beneficiaries—they set the agenda and collect authority/legitimacy from administering the framework (d → beneficiary end). Fossil incumbents are secondary beneficiaries receiving structural protection without direct advocacy (d → beneficiary end, though their institutional power gives them arbitrage exit). Climate-vulnerable and air-quality-affected populations are pure targets—trapped, powerless, bearing the mortality transfer (d → target end, high χ). Nuclear workers are constrained targets with some mobility but losing professional pathways (d → target end, moderate χ). Expected-value analysts are excluded rather than coordinated; their exclusion is the enforcement object itself.
 *
 * MANDATROPHY ANALYSIS:
 *   The founding problem (prevent another Chernobyl-scale event) has been structurally solved through improved reactor design and safety culture, yet the framework persists with intensifying enforcement. This is classic mandatrophy: the coordination function (shared risk criteria) remains live, but the specific tail-weighting has outlived its precipitating crisis and now extracts more (in aggregate lives) than it protects. The asymmetry—nuclear held to theoretical tail risk while fossil escapes distributed-harm accounting—reveals extraction riding on coordination rather than pure coordination or pure extraction.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    catastrophic_definition_boundary,
    'Is ''catastrophic'' an event-property (single incident with visible victims) or an outcome-property (aggregate harm regardless of temporal/spatial distribution)?',
    'Comparison of regulatory treatment for equal-mortality scenarios delivered as singular events vs. distributed over time. If distributed mortality triggers precautionary response once reframed as ''slow catastrophe,'' the distinction is conceptual framing, not empirical threshold.',
    'If catastrophic = outcome-property, fossil fuel''s distributed mortality and climate displacement become catastrophic, flipping the framework''s beneficiary/victim structure. If event-property, the current asymmetry is internally consistent and the extraction is a feature, not a bug.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(catastrophic_definition_boundary, conceptual, 'Whether catastrophic-ness is defined by event-form or aggregate outcome.').

omega_variable(
    tail_probability_vs_baseline_mortality,
    'What is the actual mortality-per-TWh comparison between nuclear (including tail-risk weighting) and fossil fuels (including climate impacts), and at what tail-event probability does precautionary avoidance produce net mortality increase?',
    'Meta-analysis of energy mortality databases with explicit tail-risk probability distributions for nuclear vs. climate/air-quality impact distributions for fossil, calculating break-even tail probabilities.',
    'If nuclear mortality (including weighted tail risk) remains lower than fossil at any realistic tail probability, the framework''s mortality transfer is empirically net-harmful. If fossil mortality requires implausibly low nuclear tail probabilities to justify avoidance, the precautionary principle as operationalized produces perverse outcomes.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(tail_probability_vs_baseline_mortality, empirical, 'Empirical break-even point where tail-avoidance becomes net-harmful.').

omega_variable(
    coordination_extraction_separation,
    'Is the precautionary principle separable from the event-salience bias, or does precautionary risk governance inherently weight visible catastrophes over distributed harms?',
    'Natural experiment from jurisdictions that apply precautionary principles to distributed harms (climate policy treating cumulative emissions as catastrophic risk). If precaution can operate without event-salience, the functions are separable.',
    'If separable, the tail-weighting is extraction riding on genuine coordination (shared risk criteria) and alternative framings remain available. If inseparable, the event-salience bias is inherent to precautionary coordination and the measured extraction is structural cost, not asymmetric rent.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(coordination_extraction_separation, conceptual, 'Whether precautionary coordination requires event-salience framing.').

omega_variable(
    committer_frame_alternative_kernel,
    'Is the acceptable_risk_energy kernel itself under-determined—could ''acceptable risk'' be instantiated through entirely different readings beyond the three declared (tail/expected-value/option-value)?',
    'Discovery of energy policy frameworks that operationalize acceptable risk through principles orthogonal to probability×consequence calculus (e.g., autonomy-maximizing risk allocation, reversibility-weighted decisions).',
    'If alternative readings exist, the current kernel declaration is incomplete and the committer-axis contest is broader than documented. The three declared readings may represent one sub-family within a larger kernel space.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(committer_frame_alternative_kernel, conceptual, 'Whether the declared kernel exhausts the reading space.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(acceptable_risk_energy__catastrophic_tail_dominant, 0, 35).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(acce_tr_t0, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 0, 0.22).
narrative_ontology:measurement_basis(acce_tr_t0, observed).
narrative_ontology:measurement(acce_tr_t7, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 7, 0.28).
narrative_ontology:measurement_basis(acce_tr_t7, observed).
narrative_ontology:measurement(acce_tr_t14, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 14, 0.33).
narrative_ontology:measurement_basis(acce_tr_t14, observed).
narrative_ontology:measurement(acce_tr_t21, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 21, 0.37).
narrative_ontology:measurement_basis(acce_tr_t21, observed).
narrative_ontology:measurement(acce_tr_t28, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 28, 0.4).
narrative_ontology:measurement_basis(acce_tr_t28, observed).
narrative_ontology:measurement(acce_tr_t35, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 35, 0.42).
narrative_ontology:measurement_basis(acce_tr_t35, observed).

% Extraction over time
narrative_ontology:measurement(acce_be_t0, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 0, 0.48).
narrative_ontology:measurement_basis(acce_be_t0, observed).
narrative_ontology:measurement(acce_be_t7, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 7, 0.54).
narrative_ontology:measurement_basis(acce_be_t7, observed).
narrative_ontology:measurement(acce_be_t14, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 14, 0.61).
narrative_ontology:measurement_basis(acce_be_t14, observed).
narrative_ontology:measurement(acce_be_t21, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 21, 0.65).
narrative_ontology:measurement_basis(acce_be_t21, observed).
narrative_ontology:measurement(acce_be_t28, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 28, 0.67).
narrative_ontology:measurement_basis(acce_be_t28, observed).
narrative_ontology:measurement(acce_be_t35, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 35, 0.68).
narrative_ontology:measurement_basis(acce_be_t35, observed).

% Suppression requirement over time
narrative_ontology:measurement(acce_su_t0, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 0, 0.58).
narrative_ontology:measurement_basis(acce_su_t0, observed).
narrative_ontology:measurement(acce_su_t7, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 7, 0.65).
narrative_ontology:measurement_basis(acce_su_t7, observed).
narrative_ontology:measurement(acce_su_t14, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 14, 0.72).
narrative_ontology:measurement_basis(acce_su_t14, observed).
narrative_ontology:measurement(acce_su_t21, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 21, 0.77).
narrative_ontology:measurement_basis(acce_su_t21, observed).
narrative_ontology:measurement(acce_su_t28, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 28, 0.8).
narrative_ontology:measurement_basis(acce_su_t28, observed).
narrative_ontology:measurement(acce_su_t35, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 35, 0.82).
narrative_ontology:measurement_basis(acce_su_t35, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(acceptable_risk_energy__catastrophic_tail_dominant, resource_allocation).
narrative_ontology:affects_constraint(acceptable_risk_energy__catastrophic_tail_dominant, acceptable_risk_energy__expected_value_dominant).
narrative_ontology:affects_constraint(acceptable_risk_energy__catastrophic_tail_dominant, acceptable_risk_energy__option_value_preserving).

% DUAL FORMULATION NOTE:
% This constraint is one of three readings of the acceptable_risk_energy kernel. The catastrophic_tail_dominant reading operationalizes acceptable risk through extreme avoidance of low-probability visible events. The expected_value_dominant reading operationalizes it through mortality-per-TWh minimization. The option_value_preserving reading operationalizes it through maintaining pathway diversity. These are not perspectives on one constraint—they are distinct constraints with different victim sets and different ε values, linked because they emerge from contested interpretations of the same commitment kernel.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
