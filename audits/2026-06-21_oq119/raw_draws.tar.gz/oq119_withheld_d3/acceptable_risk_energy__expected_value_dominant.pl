% ============================================================================
% CONSTRAINT STORY: acceptable_risk_energy__expected_value_dominant
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_acceptable_risk_energy__expected_value_dominant, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: acceptable_risk_energy__expected_value_dominant
 *   human_readable: Expected-Value Energy Risk Calculus
 *   domain: risk_assessment/energy_policy
 *
 * SUMMARY:
 *   This constraint instantiates one reading of the contested kernel
 *   'acceptable risk in energy systems': the expected-value-dominant reading,
 *   which treats mortality-per-TWh as the master metric and discounts
 *   low-probability catastrophic outcomes by their probability. Under this
 *   framework, fossil fuel deaths from air pollution and mining enter the
 *   victim set at full weight because they are statistically certain, while
 *   nuclear accidents are probability-discounted into near-irrelevance
 *   despite civilization-scale consequences. The sibling
 *   readings—catastrophic tail dominance and option value preservation—are
 *   other constraint stories, not perspectives within this one. The claim
 *   (tangled_rope) and metrics (substantially extractive, high suppression)
 *   are independent: the claim states what I believe is structurally true;
 *   the metrics describe the constraint's actual operation. The engine
 *   measures their divergence.
 *
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(acceptable_risk_energy__expected_value_dominant, 0.68).
domain_priors:suppression_score(acceptable_risk_energy__expected_value_dominant, 0.79).
domain_priors:theater_ratio(acceptable_risk_energy__expected_value_dominant, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, extractiveness, 0.68).
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, suppression_requirement, 0.79).
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, accessibility_collapse, 0.52).
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, resistance, 0.71).

% --- Constraint claim ---
narrative_ontology:constraint_claim(acceptable_risk_energy__expected_value_dominant, tangled_rope).
narrative_ontology:human_readable(acceptable_risk_energy__expected_value_dominant, "Expected-Value Energy Risk Calculus").
narrative_ontology:topic_domain(acceptable_risk_energy__expected_value_dominant, "risk_assessment/energy_policy").

domain_priors:requires_active_enforcement(acceptable_risk_energy__expected_value_dominant).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(acceptable_risk_energy__expected_value_dominant, '659cca4e-c56d-4f4f-9b52-defc5796327a').
narrative_ontology:cs_kernel_codification('659cca4e-c56d-4f4f-9b52-defc5796327a', formalized).
narrative_ontology:cs_authority_grounding('659cca4e-c56d-4f4f-9b52-defc5796327a', expertise).
narrative_ontology:cs_interpretation_layer_present('659cca4e-c56d-4f4f-9b52-defc5796327a').
narrative_ontology:cs_reading_relation('659cca4e-c56d-4f4f-9b52-defc5796327a', acceptable_risk_energy__catastrophic_tail_dominant, coexists_with).
narrative_ontology:cs_reading_relation('659cca4e-c56d-4f4f-9b52-defc5796327a', acceptable_risk_energy__option_value_preserving, coexists_with).
narrative_ontology:cs_axiom('659cca4e-c56d-4f4f-9b52-defc5796327a', foundational, probability_weighted_fungibility).
narrative_ontology:cs_axiom_status(probability_weighted_fungibility, holdable).
narrative_ontology:cs_axiom_grounding('659cca4e-c56d-4f4f-9b52-defc5796327a', probability_weighted_fungibility, empirically_contingent).
narrative_ontology:cs_axiom('659cca4e-c56d-4f4f-9b52-defc5796327a', foundational, tail_risk_discountability).
narrative_ontology:cs_axiom_status(tail_risk_discountability, holdable).
narrative_ontology:cs_axiom_grounding('659cca4e-c56d-4f4f-9b52-defc5796327a', tail_risk_discountability, instrumental).
narrative_ontology:cs_reference_frame('659cca4e-c56d-4f4f-9b52-defc5796327a', mid_century_risk_commensuration).
narrative_ontology:cs_drift_state('659cca4e-c56d-4f4f-9b52-defc5796327a', post_fukushima_contemporary, gap(axiom_overriding, substantial, false)).
narrative_ontology:cs_created_at('659cca4e-c56d-4f4f-9b52-defc5796327a', '').
narrative_ontology:cs_kernel_id(acceptable_risk_energy__expected_value_dominant, acceptable_risk_energy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__expected_value_dominant, nuclear_energy_sector).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__expected_value_dominant, centralized_grid_operators).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__expected_value_dominant, probabilistic_risk_analysts).
narrative_ontology:constraint_victim(acceptable_risk_energy__expected_value_dominant, fossil_fuel_adjacent_populations).
narrative_ontology:constraint_victim(acceptable_risk_energy__expected_value_dominant, mining_communities).
narrative_ontology:constraint_victim(acceptable_risk_energy__expected_value_dominant, tail_risk_averse_communities).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__expected_value_dominant, expected_utility_sufficiency).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__expected_value_dominant, probabilistic_discounting_legitimacy).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Benefit structurally from a risk framework that discounts low-probability catastrophic events by their probability, making nuclear's mortality-per-TWh profile appear highly favorable relative to fossil fuels. The expected-value framing renders Chernobyl and Fukushima as small statistical perturbations rather than civilization-scale warnings, enabling continued operation and investment.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, nuclear_energy_sector, beneficiary,
    institutional, generational, constrained, national).

% Set policy frameworks using mortality-per-TWh as the standard risk metric, defending it as the most rigorous available approach. Coordinate large-scale energy planning around expected-value optimization, treating distributed harm and concentrated catastrophe as fungible when probability-weighted. Control what counts as evidence in regulatory proceedings.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, centralized_grid_operators, agenda_setter,
    institutional, generational, mobile, national).

% Professional community whose methods are vindicated by this framework. Provide the technical infrastructure—fault trees, event probability calculations, consequence modeling—that makes expected-value comparison legible. Their epistemic authority is sustained by treating risk as a calculable quantity amenable to expected-value optimization.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, probabilistic_risk_analysts, beneficiary,
    organized, biographical, mobile, global).

% Bear the actual mortality burden from coal particulates, gas extraction toxicity, and mining accidents—deaths that enter the expected-value calculation at full weight with probability near unity. Live with continuous low-level harm that aggregates to high mortality-per-TWh but never produces a single event large enough to shift policy attention.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, fossil_fuel_adjacent_populations, payer,
    powerless, biographical, trapped, local).

% Experience occupational mortality and environmental degradation across all extraction pathways, but especially fossil fuels. Their deaths are statistically certain, widely distributed, and count fully in aggregate harm calculations, yet generate no catastrophe-scale policy response because they arrive one or two at a time.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, mining_communities, payer,
    powerless, biographical, trapped, local).

% Populations near nuclear facilities or in potential contamination zones who weight low-probability catastrophic outcomes more heavily than expected-value calculations suggest they should. Their concerns are systematically discounted by the framework as irrational risk perception, making their voiced preferences structurally inadmissible in policy.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, tail_risk_averse_communities, payer,
    moderate, generational, constrained, regional).

% Argue for energy systems that avoid both continuous fossil harm and catastrophic nuclear tail risk through distributed generation. Excluded from the expected-value frame because their approach does not optimize a single mortality metric but rather seeks to exit the trade-space entirely. The framework's structure forecloses their pathway by design.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, distributed_renewable_advocates, excluded,
    organized, generational, constrained, national).

% Observe that expected-value optimization across energy pathways systematically underweights outcomes that disable adaptation capacity itself—nuclear exclusion zones, long-term contamination, intergenerational burden. Measure how the framework's probability discounting interacts with climate timelines and societal resilience.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, climate_adaptation_planners, observer,
    institutional, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a legible, quantitative basis for comparing mortality risk across fundamentally different energy pathways: probabilistic rare catastrophes versus statistically certain distributed harm. Enables regulatory decision-making by reducing incommensurable risks to a single metric.
% TRANSFER_FUNCTION: Moves policy legitimacy and capital investment toward pathways with favorable probability-weighted aggregate harm (nuclear, centralized systems) and away from pathways with high certain distributed harm (fossil) or non-optimizable characteristics (distributed renewables). Transfers actual mortality burden to populations experiencing continuous low-level harm.
% ABSENT_VOICES: Populations who experience catastrophic risk not as a probability to be discounted but as an existential threat to place-based identity and multigenerational continuity. Communities whose risk aversion is grounded in option value preservation rather than expected utility. Their perspective is structurally inadmissible because the framework treats deviation from expected-value optimization as cognitive bias.
% DISAPPEARANCE_RATIONALE: If this framework vanished, energy policy would fragment into competing incommensurable risk framings: catastrophic tail avoidance, option value preservation, energy sovereignty, intergenerational burden distribution. Nuclear policy would shift immediately as probability-discounted catastrophe became undiscounted threat. Capital allocation would redistribute across pathways no longer fungible under a single metric.
% FOUNDING_PROBLEM: Mid-20th-century energy planning faced genuinely incommensurable risks: how to compare a coal miner's certain death this year against a probabilistic reactor meltdown affecting millions in an unknown future year. Expected-value calculation offered a technical resolution that made planning tractable.
% FOUNDING_PROBLEM_CORROBORATION: Nuclear sector and probabilistic risk analysis community attest the problem remains live and the expected-value solution is the only rigorous approach. Climate adaptation planners, option-value economists, and tail-risk scholars from outside the energy beneficiary set attest the founding problem has shifted: the question now is not 'which pathway has lowest expected harm' but 'which pathway preserves civilizational continuity under deep uncertainty'—a framing expected-value calculation cannot address.
narrative_ontology:disappearance_verdict(acceptable_risk_energy__expected_value_dominant, world_rearranges).
narrative_ontology:founding_problem_status(acceptable_risk_energy__expected_value_dominant, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(acceptable_risk_energy__expected_value_dominant, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(acceptable_risk_energy__expected_value_dominant, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(acceptable_risk_energy__expected_value_dominant_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(acceptable_risk_energy__expected_value_dominant, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(acceptable_risk_energy__expected_value_dominant_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is substantial (0.68) because the framework systematically transfers mortality burden to populations experiencing continuous distributed harm while protecting pathways with favorable probability-weighted profiles, regardless of catastrophic potential. Suppression is higher (0.79) because the constraint's persistence depends on actively excluding alternative risk framings—tail-risk aversion as rational, option value as calculable, incommensurable risks as non-fungible—and treating them as cognitive bias. Theater ratio rises (0.42 at interval end) as an increasing share of 'risk assessment' activity defends the expected-value frame itself rather than measuring actual safety: probabilistic risk assessments become more sophisticated while systematically underweighting outcomes that disable the calculation itself (contamination rendering regions uninhabitable, intergenerational burden, adaptation capacity destruction). Accessibility collapse is moderate (0.52): alternative frameworks exist (precautionary principle, maximin, option value) but are institutionally marginalized. Resistance is high (0.71): tail-risk-averse communities, option-value economists, and post-Fukushima publics actively contest the framework.
 *
 * PERSPECTIVAL GAP:
 *   From the agenda-setter seat (centralized grid operators, probabilistic risk analysts), this is rigorous quantitative risk management—the only framework that treats all deaths equally regardless of pathway. From the trapped payer seats (fossil-adjacent populations, mining communities), the same structure operates as laundering continuous certain harm into statistical abstraction while protecting catastrophic-potential pathways through probability mathematics. From tail-risk-averse seats, it is systematic suppression of legitimate risk aversion dressed as cognitive bias correction. The engine computes these divergences from exit options and structural position; the authored metrics do not adjudicate between them.
 *
 * DIRECTIONALITY LOGIC:
 *   Nuclear sector and centralized grid operators are structural beneficiaries: the framework's probability discounting makes their preferred pathways appear optimal. Probabilistic risk analysts benefit professionally as their methods are vindicated. Fossil-fuel-adjacent populations and mining communities are primary victims: their statistically certain deaths count fully while catastrophic nuclear harm is discounted. Tail-risk-averse communities are suppressed victims: their risk perception is labeled irrational by the framework itself. Distributed renewable advocates are excluded: their approach is structurally inadmissible because it refuses the expected-value trade-space rather than optimizing within it.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint exhibits mandatrophy characteristics: founded to make incommensurable energy risks comparable during mid-century expansion, it now persists primarily to protect institutional investment in pathways whose legitimacy depends on probability discounting. The rising theater ratio and suppression indicate growing resources devoted to defending the expected-value frame against alternative risk conceptions rather than improving safety. However, it retains genuine coordination function (enabling legible cross-pathway comparison) alongside extraction (systematic discounting of certain distributed harm and catastrophic tail risk), making it tangled_rope rather than pure piton.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    probability_discounting_legitimacy,
    'Is it legitimate to discount civilization-scale catastrophic outcomes by their probability when those outcomes disable the capacity to perform future expected-value calculations?',
    'Conceptual: turns on whether expected utility theory applies to outcomes that destroy the decision-making substrate itself. No empirical resolution, but rival decision theories (maximin, option value, robust satisficing) provide alternative framings.',
    'If probability discounting is illegitimate for substrate-destroying outcomes, nuclear risk cannot be treated as fungible with distributed fossil harm, and the expected-value framework loses its master-metric status. If legitimate, tail-risk aversion is indeed cognitive bias and the framework''s suppression is justified.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(probability_discounting_legitimacy, conceptual, 'Whether expected-value calculation applies to catastrophic outcomes that disable future calculation.').

omega_variable(
    distributed_harm_aggregation,
    'Does aggregating statistically certain individual deaths into mortality-per-TWh metrics preserve or erase morally relevant structure about who bears risk and whether they consent?',
    'Conceptual: depends on whether distributive justice considerations (who is harmed, whether they benefit from the energy system, whether they can exit) are preserved or erased by expected-value aggregation. Alternative frameworks (capabilities approach, rights-based risk assessment) treat distribution as non-fungible.',
    'If distribution is morally relevant and non-fungible, then equal expected harm across two pathways that concentrate risk differently are not equivalent, and the framework systematically misclassifies by erasing distributive structure. If distribution is fungible, the aggregation is legitimate optimization.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(distributed_harm_aggregation, preference, 'Whether risk distribution is fungible under expected-value aggregation.').

omega_variable(
    incommensurability_resolution,
    'Are the risks being compared (continuous distributed fossil harm vs. rare catastrophic nuclear harm vs. material-constraint renewable limits) genuinely commensurable under a single metric, or does expected-value calculation impose false commensurability?',
    'Conceptual: turns on whether fundamentally different types of harm—place-based contamination, respiratory disease, resource bottlenecks—share sufficient structure to be reduced to a common unit. Incommensurability theory (Ruth Chang, Joseph Raz) provides alternative framing treating the trade-space as genuinely plural.',
    'If the risks are incommensurable, expected-value optimization is category error rather than rigorous method, and the framework''s claim to resolve the founding problem is false. If commensurable, the framework successfully reduces complexity to tractable decision-making.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(incommensurability_resolution, conceptual, 'Whether energy pathway risks are commensurable under expected-value calculation.').

omega_variable(
    reading_selection_mechanism,
    'What institutional or epistemic mechanism determines which reading of acceptable risk becomes authoritative in a given regulatory domain?',
    'Empirical: regulatory ethnography, institutional history, analysis of which professional communities control standard-setting. Likely drivers are professional community dominance (probabilistic risk analysts vs. precautionary-principle advocates vs. resilience planners), path dependence from infrastructure investment, and liability regime structure.',
    'If reading selection tracks beneficiary power rather than epistemic warrant, the framework''s authority is extractive rather than coordinative. If selection tracks genuine problem-solving capacity, authority is legitimate even where contested.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(reading_selection_mechanism, empirical, 'How competing risk frameworks gain or lose institutional authority.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(acceptable_risk_energy__expected_value_dominant, 0, 35).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(acce_tr_t0, acceptable_risk_energy__expected_value_dominant, theater_ratio, 0, 0.22).
narrative_ontology:measurement(acce_tr_t7, acceptable_risk_energy__expected_value_dominant, theater_ratio, 7, 0.27).
narrative_ontology:measurement(acce_tr_t14, acceptable_risk_energy__expected_value_dominant, theater_ratio, 14, 0.32).
narrative_ontology:measurement(acce_tr_t21, acceptable_risk_energy__expected_value_dominant, theater_ratio, 21, 0.36).
narrative_ontology:measurement(acce_tr_t28, acceptable_risk_energy__expected_value_dominant, theater_ratio, 28, 0.39).
narrative_ontology:measurement(acce_tr_t35, acceptable_risk_energy__expected_value_dominant, theater_ratio, 35, 0.42).

% Extraction over time
narrative_ontology:measurement(acce_be_t0, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 0, 0.48).
narrative_ontology:measurement(acce_be_t7, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 7, 0.53).
narrative_ontology:measurement(acce_be_t14, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 14, 0.59).
narrative_ontology:measurement(acce_be_t21, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 21, 0.63).
narrative_ontology:measurement(acce_be_t28, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 28, 0.66).
narrative_ontology:measurement(acce_be_t35, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 35, 0.68).

% Suppression requirement over time
narrative_ontology:measurement(acce_su_t0, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 0, 0.58).
narrative_ontology:measurement(acce_su_t7, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 7, 0.63).
narrative_ontology:measurement(acce_su_t14, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 14, 0.68).
narrative_ontology:measurement(acce_su_t21, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 21, 0.73).
narrative_ontology:measurement(acce_su_t28, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 28, 0.76).
narrative_ontology:measurement(acce_su_t35, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 35, 0.79).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(acceptable_risk_energy__expected_value_dominant, resource_allocation).
narrative_ontology:affects_constraint(acceptable_risk_energy__expected_value_dominant, acceptable_risk_energy__catastrophic_tail_dominant).
narrative_ontology:affects_constraint(acceptable_risk_energy__expected_value_dominant, acceptable_risk_energy__option_value_preserving).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the acceptable_risk_energy kernel. The expected-value-dominant reading treats mortality-per-TWh as master metric and probability-discounts catastrophic outcomes. Sibling constraint acceptable_risk_energy__catastrophic_tail_dominant prioritizes tail-risk avoidance even at cost of higher expected harm. Sibling constraint acceptable_risk_energy__option_value_preserving maintains pathway diversity to preserve decision flexibility. These are distinct constraints with different ε values (expected-value frame is substantially more extractive than option-value frame because it systematically discounts certain populations' harm), different beneficiary/victim structures, and different suppression profiles. They are linked because energy policy in practice navigates between readings depending on institutional venue and recent salience of catastrophic events.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
