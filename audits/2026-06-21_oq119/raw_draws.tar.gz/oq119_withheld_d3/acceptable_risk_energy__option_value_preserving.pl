% ============================================================================
% CONSTRAINT STORY: acceptable_risk_energy__option_value_preserving
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_acceptable_risk_energy__option_value_preserving, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: acceptable_risk_energy__option_value_preserving
 *   human_readable: Option-Value Energy Portfolio Risk Framework
 *   domain: risk_assessment/energy_policy/decision_theory
 *
 * SUMMARY:
 *   This constraint instantiates the option-value-preserving reading of
 *   acceptable risk in energy policy: maintaining multiple pathways viable to
 *   preserve decision flexibility under deep technological and geopolitical
 *   uncertainty. The framework justifies slow energy transitions as prudent
 *   hedging against unknown future states. The claim/metric gap is
 *   deliberate: claimed as tangled_rope (real coordination of long-horizon
 *   investment under uncertainty, plus extraction from climate and
 *   air-quality constituencies) while metrics track rising extraction and
 *   theater as renewable cost curves dropped and the founding uncertainty
 *   progressively resolved. The engine measures that divergence; the claim
 *   and metrics are independent authored facts.
 *
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(acceptable_risk_energy__option_value_preserving, 0.58).
domain_priors:suppression_score(acceptable_risk_energy__option_value_preserving, 0.51).
domain_priors:theater_ratio(acceptable_risk_energy__option_value_preserving, 0.44).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, extractiveness, 0.58).
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, suppression_requirement, 0.51).
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, theater_ratio, 0.44).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, accessibility_collapse, 0.47).
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, resistance, 0.62).

% --- Constraint claim ---
narrative_ontology:constraint_claim(acceptable_risk_energy__option_value_preserving, tangled_rope).
narrative_ontology:human_readable(acceptable_risk_energy__option_value_preserving, "Option-Value Energy Portfolio Risk Framework").
narrative_ontology:topic_domain(acceptable_risk_energy__option_value_preserving, "risk_assessment/energy_policy/decision_theory").

domain_priors:requires_active_enforcement(acceptable_risk_energy__option_value_preserving).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(acceptable_risk_energy__option_value_preserving, 'db123bca-dac7-4ad7-9fea-a2790bf94c74').
narrative_ontology:cs_kernel_codification('db123bca-dac7-4ad7-9fea-a2790bf94c74', distributed).
narrative_ontology:cs_authority_grounding('db123bca-dac7-4ad7-9fea-a2790bf94c74', expertise).
narrative_ontology:cs_interpretation_layer_present('db123bca-dac7-4ad7-9fea-a2790bf94c74').
narrative_ontology:cs_reading_relation('db123bca-dac7-4ad7-9fea-a2790bf94c74', acceptable_risk_energy__catastrophic_tail_dominant, coexists_with).
narrative_ontology:cs_reading_relation('db123bca-dac7-4ad7-9fea-a2790bf94c74', acceptable_risk_energy__expected_value_dominant, coexists_with).
narrative_ontology:cs_axiom('db123bca-dac7-4ad7-9fea-a2790bf94c74', foundational, irreversibility_as_primary_risk).
narrative_ontology:cs_axiom_status(irreversibility_as_primary_risk, holdable).
narrative_ontology:cs_axiom_grounding('db123bca-dac7-4ad7-9fea-a2790bf94c74', irreversibility_as_primary_risk, instrumental).
narrative_ontology:cs_axiom('db123bca-dac7-4ad7-9fea-a2790bf94c74', secondary, technological_uncertainty_justifies_delay).
narrative_ontology:cs_axiom_status(technological_uncertainty_justifies_delay, holdable).
narrative_ontology:cs_axiom_grounding('db123bca-dac7-4ad7-9fea-a2790bf94c74', technological_uncertainty_justifies_delay, empirically_contingent).
narrative_ontology:cs_reference_frame('db123bca-dac7-4ad7-9fea-a2790bf94c74', mid_2000s_renewable_uncertainty).
narrative_ontology:cs_drift_state('db123bca-dac7-4ad7-9fea-a2790bf94c74', post_renewable_cost_collapse, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('db123bca-dac7-4ad7-9fea-a2790bf94c74', '').
narrative_ontology:cs_kernel_id(acceptable_risk_energy__option_value_preserving, acceptable_risk_energy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__option_value_preserving, energy_transition_planners).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__option_value_preserving, flexibility_seeking_governments).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__option_value_preserving, incumbent_energy_sectors).
narrative_ontology:constraint_victim(acceptable_risk_energy__option_value_preserving, climate_mitigation_advocates).
narrative_ontology:constraint_victim(acceptable_risk_energy__option_value_preserving, air_quality_communities).
narrative_ontology:constraint_victim(acceptable_risk_energy__option_value_preserving, early_movers_to_renewables).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__option_value_preserving, real_options_theory_in_policy).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__option_value_preserving, irreversibility_as_risk_factor).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Set the acceptable risk framework for national energy policy, explicitly valuing the option to reverse course if technological or geopolitical conditions change. Justify maintaining both fossil and nuclear capacity as hedges against deep uncertainty about renewable scaling, storage breakthroughs, and grid stability. Frame premature closure of pathways as itself a catastrophic risk.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, energy_transition_planners, agenda_setter,
    institutional, generational, constrained, national).

% Benefit from deferring irreversible energy infrastructure commitments while claiming responsible risk management. The framework legitimizes slow transition timelines as prudent hedging rather than regulatory capture, allowing political breathing room on climate commitments without facing accusations of inaction.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, flexibility_seeking_governments, beneficiary,
    institutional, biographical, mobile, national).

% Collect extended operational lifetimes and ongoing investment as their pathways are maintained for option value. The flexibility framing prevents accelerated depreciation of their asset base and sustains their position in energy planning councils as necessary portfolio components rather than legacy liabilities.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, incumbent_energy_sectors, beneficiary,
    powerful, biographical, constrained, global).

% Bear the opportunity cost of delayed emissions reduction as fossil capacity persists longer than aggregate-harm metrics would justify. They argue the framework treats fossil continuity as free option value while externalizing its climate costs, and that the uncertainty framing manufactures decision paralysis where the direction of travel is clear.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, climate_mitigation_advocates, payer,
    organized, generational, constrained, global).

% Continue to experience localized air pollution mortality from fossil plants whose closure is deferred for portfolio reasons. The framework's generational time horizon and national-to-global scope abstract away their immediate health burden, which accumulates during the option-preservation interval.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, air_quality_communities, payer,
    powerless, biographical, trapped, local).

% Face higher stranded-asset risk as their renewable commitments are made in a policy environment that keeps alternatives viable. Jurisdictions that closed pathways early lose the optionality benefit but also lose competitive advantage if the slow-transition equilibrium holds elsewhere, creating first-mover disadvantage where climate leadership was promised.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, early_movers_to_renewables, payer,
    moderate, biographical, constrained, regional).

% Will inherit the compounded climate externalities from extended fossil operation and the locked-in commitments from infrastructure kept viable. They cannot participate in the current option-value calculation but will bear its tail risks if the preserved flexibility is never exercised or exercised too late.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, future_generations, excluded,
    powerless, civilizational, trapped, global).

% Analyze whether the framework's option-value logic is internally consistent or whether it systematically privileges certain forms of reversibility over others. They note the asymmetry: renewable investment is treated as costly irreversibility while fossil lock-in is framed as preserving optionality, though both constrain future choice.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, decision_theorists, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Coordinates long-horizon energy investment under deep technological and geopolitical uncertainty by maintaining multiple pathways viable until key uncertainties resolve, preventing premature closure of options that might prove necessary.
% TRANSFER_FUNCTION: Transfers climate mitigation costs, air quality burden, and stranded-asset risk from incumbent energy sectors and flexibility-seeking governments to climate advocates, air quality communities, and early renewable adopters, as the price of preserving decision flexibility.
% ABSENT_VOICES: Future generations who will inherit the tail consequences of extended fossil operation are structurally excluded from the option-value calculation; their climate-stabilization interests would argue for faster irreversible commitment to low-carbon pathways.
% DISAPPEARANCE_RATIONALE: If the framework vanished and energy policy shifted to either catastrophic-tail avoidance or expected-value minimization, investment patterns would reorganize immediately: either fossil capacity would shut faster under tail-risk weighting, or nuclear would expand faster under mortality-per-TWh logic. The current slow-transition equilibrium is held by the framework, not by technology or economics alone.
% FOUNDING_PROBLEM: Mid-2000s energy policy faced genuine deep uncertainty about renewable scaling potential, storage breakthroughs, nuclear safety post-Fukushima, and climate policy commitment durability across electoral cycles, with high costs to wrong irreversible bets in any direction.
% FOUNDING_PROBLEM_CORROBORATION: Energy planners and real-options economists attest the founding uncertainty remains live, citing continuing storage cost trajectories and nuclear regulatory flux. Climate scientists and renewable-sector analysts attest the direction of travel is now clear and the uncertainty framing has become a legitimization mechanism for delay; IPCC reports and declining renewable costs from outside the incumbent beneficiaries support the shifted-function reading.
narrative_ontology:disappearance_verdict(acceptable_risk_energy__option_value_preserving, world_rearranges).
narrative_ontology:founding_problem_status(acceptable_risk_energy__option_value_preserving, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(acceptable_risk_energy__option_value_preserving, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(acceptable_risk_energy__option_value_preserving, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(acceptable_risk_energy__option_value_preserving_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(acceptable_risk_energy__option_value_preserving, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(acceptable_risk_energy__option_value_preserving_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is moderate-high (0.58 at interval end, rising from 0.42) because the framework transfers climate costs and air-quality burdens to constituencies with less representation in energy planning while preserving incumbent asset values. Suppression is moderate (0.51, rising from 0.38) — the framework dampens both rapid-transition advocacy and fossil-exit demands by framing both as reckless irreversibility, but does not eliminate either position. Theater grows (0.44 from 0.28) as the real-options analysis increasingly serves to justify predetermined slow transition rather than dynamically responding to resolving uncertainties. Resistance is high (0.62) because climate advocates actively contest the framing. Accessibility collapse is moderate (0.47) — alternative risk framings remain conceptually available even as this one dominates policy.
 *
 * PERSPECTIVAL GAP:
 *   From the planner seat the constraint operates as genuine coordination under deep uncertainty; from the payer seats (climate advocates, air quality communities) the same structure operates as legitimized delay that externalizes harm. The engine computes this divergence from the stakeholder surface; the claim does not adjudicate it.
 *
 * DIRECTIONALITY LOGIC:
 *   Energy planners and flexibility-seeking governments are structural beneficiaries (the framework legitimizes their decision deferral and keeps incumbent voices at the table — d near beneficiary end). Incumbent energy sectors are also beneficiaries (extended operational lifetimes, sustained investment). Climate advocates, air quality communities, and early renewable movers are targets (bear the opportunity costs, health burdens, and stranded-asset risks — d near target end). Future generations are excluded entirely from the calculation.
 *
 * MANDATROPHY ANALYSIS:
 *   The founding problem (genuine deep uncertainty about renewable scaling, storage, nuclear safety, and climate policy durability circa mid-2000s) has partially resolved as renewable costs dropped 80%+ and storage scaled faster than central projections. The framework persists not because the uncertainty is as deep as it was but because it coordinates incumbent interests and provides political cover for slow transitions. The option-value logic increasingly functions as cover for path dependence. The R5 mismatch (contested status + world_rearranges verdict) flags this as a capture/zombie candidate.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    option_value_vs_path_dependence,
    'Does the framework dynamically preserve genuine optionality by maintaining reversible pathways, or does it lock in slow-transition equilibrium by treating incumbent infrastructure continuity as costless flexibility while treating renewable commitment as costly irreversibility?',
    'Counterfactual policy analysis: jurisdictions that adopted option-value framing vs those that committed irreversibly to low-carbon paths. If the option-preserving jurisdictions systematically deferred transition without later exercising the option when uncertainties resolved, the framework operated as path-dependence rather than flexibility.',
    'If the framework systematically prevents rather than preserves real decision flexibility, its coordination function is theatrical and its measured extraction understates the full opportunity cost transferred to climate and air-quality constituencies.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(option_value_vs_path_dependence, empirical, 'Whether option-value preservation operates as genuine flexibility or as legitimized lock-in.').

omega_variable(
    asymmetric_irreversibility_weighting,
    'Why does the framework treat renewable investment as costly irreversibility (stranded assets if wrong) but not fossil/nuclear continuity as costly irreversibility (stranded climate stability if wrong)? Is this asymmetry grounded in decision theory or does it privilege certain actors'' reversibility over others''?',
    'Formal decision-theoretic audit: apply symmetric irreversibility weights to all pathways and check if the framework''s recommendation changes. If it does, the asymmetry is not inherent to real-options logic but is a framing choice that benefits incumbents.',
    'If the irreversibility asymmetry is not decision-theoretically justified, the framework''s suppression of rapid-transition advocacy is extraction dressed as coordination, and the victims'' resistance is structurally warranted rather than impatient.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(asymmetric_irreversibility_weighting, conceptual, 'Whether the framework''s irreversibility weighting is symmetric or systematically privileges incumbent continuity.').

omega_variable(
    kernel_reading_contest,
    'Is the option_value_preserving reading of acceptable risk the structurally correct interpretation of the founding kernel, or does it misapply real-options theory to a context where directional uncertainty has substantially resolved?',
    'Cross-reading empirical comparison: track energy transition speed, emissions trajectories, and air-quality outcomes across jurisdictions using the three sibling readings (option-value, expected-value, catastrophic-tail). If option-value jurisdictions systematically underperform on emissions without measurable optionality benefits, the reading is extractive relative to its siblings.',
    'Determines whether this constraint''s extraction is inherent to acceptable-risk logic or specific to the option-value interpretation. A finding that sibling readings deliver lower harm without sacrificing robustness would establish this reading as false summit within the kernel family.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(kernel_reading_contest, empirical, 'Whether the option-value reading is the legitimate interpretation of the kernel or a constructed extraction mechanism within the acceptable-risk family.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(acceptable_risk_energy__option_value_preserving, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(acce_tr_t0, acceptable_risk_energy__option_value_preserving, theater_ratio, 0, 0.28).
narrative_ontology:measurement_basis(acce_tr_t0, observed).
narrative_ontology:measurement(acce_tr_t5, acceptable_risk_energy__option_value_preserving, theater_ratio, 5, 0.32).
narrative_ontology:measurement_basis(acce_tr_t5, observed).
narrative_ontology:measurement(acce_tr_t10, acceptable_risk_energy__option_value_preserving, theater_ratio, 10, 0.36).
narrative_ontology:measurement_basis(acce_tr_t10, observed).
narrative_ontology:measurement(acce_tr_t15, acceptable_risk_energy__option_value_preserving, theater_ratio, 15, 0.39).
narrative_ontology:measurement_basis(acce_tr_t15, observed).
narrative_ontology:measurement(acce_tr_t20, acceptable_risk_energy__option_value_preserving, theater_ratio, 20, 0.42).
narrative_ontology:measurement_basis(acce_tr_t20, observed).
narrative_ontology:measurement(acce_tr_t25, acceptable_risk_energy__option_value_preserving, theater_ratio, 25, 0.44).
narrative_ontology:measurement_basis(acce_tr_t25, projected).

% Extraction over time
narrative_ontology:measurement(acce_be_t0, acceptable_risk_energy__option_value_preserving, base_extractiveness, 0, 0.42).
narrative_ontology:measurement_basis(acce_be_t0, observed).
narrative_ontology:measurement(acce_be_t5, acceptable_risk_energy__option_value_preserving, base_extractiveness, 5, 0.46).
narrative_ontology:measurement_basis(acce_be_t5, observed).
narrative_ontology:measurement(acce_be_t10, acceptable_risk_energy__option_value_preserving, base_extractiveness, 10, 0.51).
narrative_ontology:measurement_basis(acce_be_t10, observed).
narrative_ontology:measurement(acce_be_t15, acceptable_risk_energy__option_value_preserving, base_extractiveness, 15, 0.54).
narrative_ontology:measurement_basis(acce_be_t15, observed).
narrative_ontology:measurement(acce_be_t20, acceptable_risk_energy__option_value_preserving, base_extractiveness, 20, 0.56).
narrative_ontology:measurement_basis(acce_be_t20, observed).
narrative_ontology:measurement(acce_be_t25, acceptable_risk_energy__option_value_preserving, base_extractiveness, 25, 0.58).
narrative_ontology:measurement_basis(acce_be_t25, projected).

% Suppression requirement over time
narrative_ontology:measurement(acce_su_t0, acceptable_risk_energy__option_value_preserving, suppression_requirement, 0, 0.38).
narrative_ontology:measurement_basis(acce_su_t0, observed).
narrative_ontology:measurement(acce_su_t5, acceptable_risk_energy__option_value_preserving, suppression_requirement, 5, 0.41).
narrative_ontology:measurement_basis(acce_su_t5, observed).
narrative_ontology:measurement(acce_su_t10, acceptable_risk_energy__option_value_preserving, suppression_requirement, 10, 0.45).
narrative_ontology:measurement_basis(acce_su_t10, observed).
narrative_ontology:measurement(acce_su_t15, acceptable_risk_energy__option_value_preserving, suppression_requirement, 15, 0.47).
narrative_ontology:measurement_basis(acce_su_t15, observed).
narrative_ontology:measurement(acce_su_t20, acceptable_risk_energy__option_value_preserving, suppression_requirement, 20, 0.49).
narrative_ontology:measurement_basis(acce_su_t20, observed).
narrative_ontology:measurement(acce_su_t25, acceptable_risk_energy__option_value_preserving, suppression_requirement, 25, 0.51).
narrative_ontology:measurement_basis(acce_su_t25, projected).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(acceptable_risk_energy__option_value_preserving, resource_allocation).
narrative_ontology:boltzmann_floor_override(acceptable_risk_energy__option_value_preserving, 0.18).
narrative_ontology:affects_constraint(acceptable_risk_energy__option_value_preserving, acceptable_risk_energy__catastrophic_tail_dominant).
narrative_ontology:affects_constraint(acceptable_risk_energy__option_value_preserving, acceptable_risk_energy__expected_value_dominant).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the acceptable_risk_energy kernel. The kernel phrase 'acceptable risk in energy policy' decomposes into three structurally distinct constraints with different ε values and victim sets: option_value_preserving (this file) maintains pathway flexibility and transfers climate/health costs to advocates and communities; catastrophic_tail_dominant prioritizes avoiding nuclear/climate tails even at higher expected harm; expected_value_dominant minimizes mortality-per-TWh and would accelerate nuclear deployment. All three link via network.affects_constraints. The confusion is in the natural-language label, not in the structure — the framework disambiguates them.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
