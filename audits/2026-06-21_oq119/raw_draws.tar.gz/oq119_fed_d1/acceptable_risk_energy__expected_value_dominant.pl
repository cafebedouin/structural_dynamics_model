% ============================================================================
% CONSTRAINT STORY: acceptable_risk_energy__expected_value_dominant
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-01-15
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_acceptable_risk_energy__expected_value_dominant, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: acceptable_risk_energy__expected_value_dominant
 *   human_readable: Expected Value Dominant Risk Framework for Energy Policy
 *   domain: risk_assessment/energy_policy/decision_theory
 *
 * SUMMARY:
 *   The expected value dominant reading of acceptable risk treats
 *   mortality-per-TWh as the authoritative metric for energy policy
 *   decisions. Under this framework, chronic distributed deaths from fossil
 *   fuel air pollution are counted at face value, while potential deaths from
 *   rare nuclear accidents are probability-discounted, making nuclear energy
 *   appear mathematically superior despite its catastrophic tail risk. The
 *   constraint is CLAIMED as mountain (the advocates present expected utility
 *   maximization as the uniquely rational decision criterion, a feature of
 *   correct reasoning itself), but the metrics describe substantial
 *   extractiveness and active suppression: the framework systematically
 *   benefits nuclear advocacy and marginalizes populations who would bear
 *   concentrated irreversible losses, while suppressing alternative decision
 *   theories that weight tail risks differently. The divergence is the
 *   measurement.
 *
 * KEY AGENTS:
 *   - nuclear_industry_advocates: Primary beneficiary (organized/mobile) — gain legitimacy from probability-discounted catastrophic risk
 *   - expected_utility_theorists: Beneficiary + agenda_setter (powerful/arbitrage) — provide intellectual grounding, set methodological standards
 *   - technocratic_policy_institutions: Agenda setter (institutional/constrained) — implement framework in regulatory action
 *   - fossil_fuel_workers: Payer (organized/constrained) — occupational mortality counted with full weight, no consent mechanism
 *   - communities_near_fossil_infrastructure: Payer (powerless/trapped) — concentrated environmental burdens, no voice in tradeoff
 *   - air_pollution_mortality_populations: Payer (powerless/trapped) — millions of diffuse deaths aggregated as statistical weight
 *   - catastrophic_risk_theorists: Excluded (moderate/constrained) — methodologically excluded by framework's rationality claim
 *   - post_accident_affected_communities: Excluded (powerless/trapped) — future concentrated losses discounted to policy-irrelevance
 *   - academic_risk_analysts: Observer (powerful/analytical) — study how framework encodes contestable values
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(acceptable_risk_energy__expected_value_dominant, 0.72).
domain_priors:suppression_score(acceptable_risk_energy__expected_value_dominant, 0.81).
domain_priors:theater_ratio(acceptable_risk_energy__expected_value_dominant, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, extractiveness, 0.72).
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, suppression_requirement, 0.81).
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, resistance, 0.73).

% --- Constraint claim ---
narrative_ontology:constraint_claim(acceptable_risk_energy__expected_value_dominant, mountain).
narrative_ontology:human_readable(acceptable_risk_energy__expected_value_dominant, "Expected Value Dominant Risk Framework for Energy Policy").
narrative_ontology:topic_domain(acceptable_risk_energy__expected_value_dominant, "risk_assessment/energy_policy/decision_theory").

domain_priors:requires_active_enforcement(acceptable_risk_energy__expected_value_dominant).
domain_priors:emerges_naturally(acceptable_risk_energy__expected_value_dominant).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(acceptable_risk_energy__expected_value_dominant, 'b5713bf4-3a5c-42c3-b762-db71450b5e6e').
narrative_ontology:cs_kernel_codification('b5713bf4-3a5c-42c3-b762-db71450b5e6e', formalized).
narrative_ontology:cs_authority_grounding('b5713bf4-3a5c-42c3-b762-db71450b5e6e', expertise).
narrative_ontology:cs_interpretation_layer_present('b5713bf4-3a5c-42c3-b762-db71450b5e6e').
narrative_ontology:cs_reading_relation('b5713bf4-3a5c-42c3-b762-db71450b5e6e', acceptable_risk_energy__catastrophic_tail_dominant, coexists_with).
narrative_ontology:cs_reading_relation('b5713bf4-3a5c-42c3-b762-db71450b5e6e', acceptable_risk_energy__option_value_preserving, coexists_with).
narrative_ontology:cs_axiom('b5713bf4-3a5c-42c3-b762-db71450b5e6e', foundational, probability_weighted_sum_exhausts_rationality).
narrative_ontology:cs_axiom_status(probability_weighted_sum_exhausts_rationality, holdable).
narrative_ontology:cs_axiom_grounding('b5713bf4-3a5c-42c3-b762-db71450b5e6e', probability_weighted_sum_exhausts_rationality, empirically_contingent).
narrative_ontology:cs_axiom('b5713bf4-3a5c-42c3-b762-db71450b5e6e', foundational, aggregate_optimization_supersedes_individual_consent).
narrative_ontology:cs_axiom_status(aggregate_optimization_supersedes_individual_consent, holdable).
narrative_ontology:cs_axiom_grounding('b5713bf4-3a5c-42c3-b762-db71450b5e6e', aggregate_optimization_supersedes_individual_consent, deontological).
narrative_ontology:cs_reference_frame('b5713bf4-3a5c-42c3-b762-db71450b5e6e', bayesian_expected_utility_orthodoxy).
narrative_ontology:cs_drift_state('b5713bf4-3a5c-42c3-b762-db71450b5e6e', post_fukushima_catastrophic_awareness, gap(axiom_overriding, substantial, false)).
narrative_ontology:cs_created_at('b5713bf4-3a5c-42c3-b762-db71450b5e6e', '').
narrative_ontology:cs_kernel_id(acceptable_risk_energy__expected_value_dominant, acceptable_risk_energy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__expected_value_dominant, nuclear_industry_advocates).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__expected_value_dominant, expected_utility_theorists).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__expected_value_dominant, technocratic_policy_institutions).
narrative_ontology:constraint_victim(acceptable_risk_energy__expected_value_dominant, fossil_fuel_workers).
narrative_ontology:constraint_victim(acceptable_risk_energy__expected_value_dominant, communities_near_fossil_infrastructure).
narrative_ontology:constraint_victim(acceptable_risk_energy__expected_value_dominant, air_pollution_mortality_populations).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__expected_value_dominant, bayesian_rationality_supremacy).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__expected_value_dominant, quantification_completeness_doctrine).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Promote nuclear energy as the rational choice under mortality-per-TWh metrics. They gain legitimacy from the framework's treatment of low-probability catastrophic events as probability-discounted rather than treated with precautionary weight. Their preferred pathway becomes the mathematically justified default when expected harm is the sole optimization target.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, nuclear_industry_advocates, beneficiary,
    organized, generational, mobile, global).

% Provide the intellectual framework grounding acceptable risk decisions in expected utility maximization. They set the methodological standards for what counts as rational policy analysis. The framework vindicates their theoretical commitments and marginalizes alternative decision theories that weight tail risks or irreversible outcomes differently.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, expected_utility_theorists, beneficiary,
    powerful, civilizational, arbitrage, global).
narrative_ontology:stakeholder_secondary_role(acceptable_risk_energy__expected_value_dominant, expected_utility_theorists, agenda_setter).

% Implement energy policy using cost-benefit analysis and mortality-per-TWh comparisons as authoritative inputs. They translate the expected value framework into regulatory action, funding priorities, and infrastructure investment. Their institutional legitimacy depends on quantitative rationality appearing complete and value-neutral.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, technocratic_policy_institutions, agenda_setter,
    institutional, generational, constrained, national).

% Bear occupational mortality and morbidity from mining, extraction, and combustion infrastructure. Under the expected value framework their deaths are counted with full weight and attributed directly to the fossil pathway, which strengthens the case for energy transition but provides no mechanism for their consent or compensation in the comparison.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, fossil_fuel_workers, payer,
    organized, biographical, constrained, national).

% Experience concentrated environmental and health burdens from coal plants, refineries, and extraction sites. The framework counts their elevated mortality and morbidity as deaths attributed to the fossil pathway. They gain visibility in the aggregate calculation but have no voice in whether their suffering should be traded off against systemic risk elsewhere.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, communities_near_fossil_infrastructure, payer,
    powerless, biographical, trapped, local).

% Die from respiratory and cardiovascular disease caused by particulate emissions from fossil combustion. Mortality-per-TWh metrics aggregate millions of these deaths globally. The framework treats them as the dominant harm to minimize, but the populations themselves are diffuse, unorganized, and never consented to being the statistical weight in a risk comparison.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, air_pollution_mortality_populations, payer,
    powerless, biographical, trapped, global).

% Argue that low-probability high-magnitude outcomes require non-expected-value decision criteria because irreversible losses and option value cannot be fully captured in probability-weighted sums. They are methodologically excluded: the framework treats their concerns as irrational discounting of evidence or innumeracy rather than a competing normative position on how to handle deep uncertainty.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, catastrophic_risk_theorists, excluded,
    moderate, civilizational, constrained, global).

% Would bear the concentrated costs of a nuclear accident: displacement, contamination, multi-generational health effects, cultural erasure. The expected value framework discounts their potential future suffering by the probability of the accident occurring, which makes their voice structurally weightless in the aggregate comparison. They have no ability to consent to being the tail of the distribution.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, post_accident_affected_communities, excluded,
    powerless, generational, trapped, local).

% Study how different risk frameworks produce different policy recommendations. They observe that the expected value dominant reading systematically favors technologies with rare catastrophic failure modes over those with distributed chronic harms, and that this weighting encodes contestable value judgments about temporal discounting, irreversibility, and consent.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, academic_risk_analysts, observer,
    powerful, biographical, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a single quantitative metric for comparing disparate energy risks across technologies and scales, enabling policy institutions to make ostensibly objective resource allocation decisions without relitigating foundational values in each case.
% TRANSFER_FUNCTION: Moves epistemic authority from affected populations and catastrophic risk theorists to expected utility theorists and technocratic institutions. Moves policy legitimacy from deliberative consent to quantitative optimization. Moves the evidential burden: chronic distributed harms are counted at face value; catastrophic concentrated harms must overcome a probability discount to register as policy-relevant.
% ABSENT_VOICES: Catastrophic risk theorists who contest expected value maximization as the sole rationality criterion, and post-accident affected communities who would bear concentrated irreversible losses but are discounted to near-zero weight in the aggregate calculation. Both are structurally excluded: the first by methodological fiat, the second by probability weighting that renders their potential future harm negligible in present policy.
% DISAPPEARANCE_RATIONALE: If the expected value framework disappeared, energy policy would lose its claim to value-neutral quantitative rationality. Competing decision criteria would gain standing: maximin, option value preservation, consent-based thresholds for irreversible risk. Nuclear advocacy would lose its mathematical high ground. Policy institutions would have to deliberate openly about incommensurable values rather than optimizing a unified metric. The political economy of energy transitions would reorganize around explicit normative contests instead of purportedly technical calculations.
% FOUNDING_PROBLEM: Mid-20th century energy policy faced legitimacy crisis: competing energy pathways had incommensurable risk profiles, and political debate was deadlocked between apocalyptic narratives and industry apologia with no shared decision criterion.
% FOUNDING_PROBLEM_CORROBORATION: Expected utility theorists and technocratic institutions attest the problem is solved by quantitative risk comparison. Catastrophic risk theorists, environmental justice advocates, and post-Fukushima policy analysts attest the founding problem has been replaced by a new one: the framework itself encodes contestable value weightings while claiming to be descriptive. Independent philosophical analysis from decision theory and science studies supports the shifted-function reading.
narrative_ontology:disappearance_verdict(acceptable_risk_energy__expected_value_dominant, world_rearranges).
narrative_ontology:founding_problem_status(acceptable_risk_energy__expected_value_dominant, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(acceptable_risk_energy__expected_value_dominant, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(acceptable_risk_energy__expected_value_dominant, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(acceptable_risk_energy__expected_value_dominant_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(acceptable_risk_energy__expected_value_dominant, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, ExtMetricName, E),
    domain_priors:suppression_score(acceptable_risk_energy__expected_value_dominant, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(acceptable_risk_energy__expected_value_dominant),
    narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(acceptable_risk_energy__expected_value_dominant_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is high (0.72 at interval end, rising from 0.45 at founding) because the framework systematically transfers epistemic authority and policy weight from affected populations to technocratic optimizers, while treating contestable normative choices about temporal discounting and irreversibility as technical parameters. Suppression is higher still (0.81, rising from 0.58) because maintaining the framework's authority requires actively excluding alternative decision criteria and silencing the voices of those who would bear catastrophic tail risks. Theater is moderate-low (0.28): the quantitative apparatus is genuinely functional for policy coordination, but a growing share of analytical effort defends the framework's claim to value-neutrality rather than improving its empirical inputs. Accessibility collapse is moderate (0.48) because alternative risk frameworks remain intellectually available even as they are institutionally suppressed. Resistance is high (0.73) because populations bearing distributed chronic harm, catastrophic risk theorists, and post-accident communities all contest the framework's legitimacy, though they lack the institutional power to displace it.
 *
 * PERSPECTIVAL GAP:
 *   From the technocratic institutional seat and the expected utility theorist seat, the constraint operates as genuine coordination: it provides a unified metric that makes incommensurable risks commensurable and grounds policy in quantitative rationality. From the payer seats (fossil fuel workers, pollution victims) and the excluded seats (catastrophic risk theorists, potential accident communities), the same structure operates as enforced extraction: their deaths or potential deaths are instrumentalized as weights in an optimization they never consented to, while the framework's value choices are disguised as technical necessity. The engine computes this divergence from the structural data; the authored claim does not adjudicate it.
 *
 * DIRECTIONALITY LOGIC:
 *   Nuclear industry advocates and expected utility theorists are structural beneficiaries: the framework vindicates their preferred technology and their theoretical commitments, respectively. Fossil fuel workers, pollution-affected populations, and near-infrastructure communities are targets: their mortality enters the calculation with full weight while they have no consent mechanism. Post-accident affected communities are probability-discounted into policy irrelevance despite bearing potential civilizational-scale concentrated losses. Catastrophic risk theorists are methodologically excluded: their alternative decision criteria are treated as irrational rather than as competing normative positions.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint exhibits strong mandatrophy dynamics: it was built to solve a legitimacy crisis in energy policy (competing incommensurable narratives with no decision criterion), but it has evolved into a mechanism that systematically advantages technologies with catastrophic tail risk over those with distributed chronic harm, while claiming to be value-neutral. The founding problem (how to compare incommensurable risks) is arguably solved, but the solution encodes contestable normative weightings that now operate as extraction from those on the wrong side of the probability discount. The framework persists not because the legitimacy crisis is ongoing, but because it has created institutional beneficiaries whose authority depends on the quantitative apparatus remaining unchallengeable.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    probability_discount_legitimacy,
    'Is it mathematically and ethically coherent to apply probability discounting to catastrophic irreversible outcomes in the same way it is applied to routine operational risks?',
    'Philosophical analysis of whether expected utility theory can handle outcomes that eliminate the decision-maker or make future calculation impossible. Empirical observation of whether populations accept probability-discounted tail risks in practice when they bear the concentrated losses.',
    'If probability discounting is shown to be incoherent for civilization-scale irreversible losses, the entire expected value framework loses its claim to rationality supremacy and the catastrophic_tail_dominant reading gains standing. If coherent, this reading''s mathematical authority is vindicated.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(probability_discount_legitimacy, conceptual, 'Whether expected utility theory validly handles catastrophic tail risks').

omega_variable(
    aggregation_across_persons,
    'Does summing deaths across individuals to produce mortality-per-TWh metrics require a normative commitment about interpersonal tradeoffs that the framework presents as technical?',
    'Ethical analysis of whether aggregation across persons without consent is a value-neutral mathematical operation or a substantive moral choice. Historical comparison with other contexts where aggregate optimization overrode individual rights claims.',
    'If aggregation-without-consent is revealed as a normative choice rather than mathematical necessity, the framework''s claim to value-neutrality collapses and affected populations gain standing to contest it on legitimacy grounds rather than only on empirical inputs.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(aggregation_across_persons, conceptual, 'Whether cross-person aggregation encodes hidden value weightings').

omega_variable(
    natural_law_vs_institutional_construct,
    'Is expected utility maximization a feature of rationality itself (mountain), or a historically contingent institutional framework that benefits identifiable parties (false summit)?',
    'Historical analysis of when and why expected utility theory became dominant in policy institutions. Cross-cultural comparison of whether societies that use different decision criteria are making ''errors'' or instantiating different values. Examination of which parties benefit from the framework''s institutional authority.',
    'If expected utility dominance is shown to be historically contingent and institutionally constructed, the entire constraint reclassifies from mountain to tangled_rope or snare. The framework''s claim to embody rationality itself would be exposed as a legitimation strategy.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(natural_law_vs_institutional_construct, empirical, 'Whether the constraint is natural law or constructed extraction').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(acceptable_risk_energy__expected_value_dominant, 0, 70).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(acce_tr_t0, acceptable_risk_energy__expected_value_dominant, theater_ratio, 0, 0.15).
narrative_ontology:measurement(acce_tr_t14, acceptable_risk_energy__expected_value_dominant, theater_ratio, 14, 0.18).
narrative_ontology:measurement(acce_tr_t28, acceptable_risk_energy__expected_value_dominant, theater_ratio, 28, 0.21).
narrative_ontology:measurement(acce_tr_t42, acceptable_risk_energy__expected_value_dominant, theater_ratio, 42, 0.24).
narrative_ontology:measurement(acce_tr_t56, acceptable_risk_energy__expected_value_dominant, theater_ratio, 56, 0.26).
narrative_ontology:measurement(acce_tr_t70, acceptable_risk_energy__expected_value_dominant, theater_ratio, 70, 0.28).

% Extraction over time
narrative_ontology:measurement(acce_be_t0, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 0, 0.45).
narrative_ontology:measurement(acce_be_t14, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 14, 0.52).
narrative_ontology:measurement(acce_be_t28, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 28, 0.61).
narrative_ontology:measurement(acce_be_t42, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 42, 0.67).
narrative_ontology:measurement(acce_be_t56, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 56, 0.7).
narrative_ontology:measurement(acce_be_t70, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 70, 0.72).

% Suppression requirement over time
narrative_ontology:measurement(acce_su_t0, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 0, 0.58).
narrative_ontology:measurement(acce_su_t14, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 14, 0.64).
narrative_ontology:measurement(acce_su_t28, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 28, 0.7).
narrative_ontology:measurement(acce_su_t42, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 42, 0.75).
narrative_ontology:measurement(acce_su_t56, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 56, 0.78).
narrative_ontology:measurement(acce_su_t70, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 70, 0.81).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(acceptable_risk_energy__expected_value_dominant, information_standard).
narrative_ontology:affects_constraint(acceptable_risk_energy__expected_value_dominant, acceptable_risk_energy__catastrophic_tail_dominant).
narrative_ontology:affects_constraint(acceptable_risk_energy__expected_value_dominant, acceptable_risk_energy__option_value_preserving).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the acceptable_risk_energy kernel. The expected_value_dominant reading differs structurally from its siblings in victim set (distributed chronic deaths counted fully, concentrated catastrophic deaths probability-discounted), beneficiary structure (nuclear advocates and technocrats benefit from tail-risk discounting), and suppression mechanism (alternative decision criteria methodologically excluded). All three readings share the network relationship because they compete for institutional authority within the same policy domain, but they instantiate different constraints with different ε values: expected_value_dominant is substantially extractive (0.72), catastrophic_tail_dominant likely lower, option_value_preserving likely intermediate.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
