% ============================================================================
% CONSTRAINT STORY: ai_governance_legitimacy__magisterial_subsidiarity_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-14
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_ai_governance_legitimacy__magisterial_subsidiarity_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    constraint_indexing:directionality_override/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_non_agent/2,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: ai_governance_legitimacy__magisterial_subsidiarity_reading
 *   human_readable: Magisterial Subsidiarity Reading of AI Governance Legitimacy
 *   domain: theological_ethics/technology_governance/political_theology
 *
 * SUMMARY:
 *   This constraint is the Magisterial Subsidiarity reading of the contested
 *   kernel 'AI governance legitimacy'. The Catholic Church's teaching
 *   authority (Magisterium) claims that legitimate AI governance must conform
 *   to Catholic Social Doctrine principles—common good, subsidiarity,
 *   solidarity, universal destination of goods—as authoritatively interpreted
 *   by ecclesial tradition. The constraint operates through encyclicals,
 *   apostolic documents, civil society advocacy, and moral suasion rather
 *   than state enforcement. It benefits workers, Global South populations,
 *   families, and marginalized communities by centering their dignity claims
 *   against technocratic and market logics. It imposes costs on tech
 *   monopolies, military-industrial actors, and extractive finance by
 *   demanding subordination of efficiency and profit to human dignity
 *   principles. The constraint is CLAIMED as mountain (natural law accessible
 *   to reason, grounded in reality of human dignity) while the metrics show
 *   moderate extraction, substantial suppression of alternative frameworks,
 *   and rising enforcement requirement as the reading gains institutional
 *   influence.
 *
 * KEY AGENTS:
 *   - Magisterium (institutional/analytical): Authoritative interpreter claiming competence to bind conscience through natural law reasoning
 *   - Workers (organized/constrained): Labor protected by subsidiarity and solidarity principles against algorithmic exploitation
 *   - Global South populations (powerless/trapped): Populations centered by universal destination of goods principle, bearing disproportionate AI development costs
 *   - Private tech monopolies (institutional/mobile): Corporations required to subordinate surveillance capitalism and algorithmic manipulation to common good
 *   - Secular governance institutions (institutional/analytical): Democratic and international bodies observing constraint as one input, not bound by magisterial authority
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(ai_governance_legitimacy__magisterial_subsidiarity_reading, 0.5).
domain_priors:suppression_score(ai_governance_legitimacy__magisterial_subsidiarity_reading, 0.68).
domain_priors:theater_ratio(ai_governance_legitimacy__magisterial_subsidiarity_reading, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__magisterial_subsidiarity_reading, extractiveness, 0.5).
narrative_ontology:constraint_metric(ai_governance_legitimacy__magisterial_subsidiarity_reading, suppression_requirement, 0.68).
narrative_ontology:constraint_metric(ai_governance_legitimacy__magisterial_subsidiarity_reading, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__magisterial_subsidiarity_reading, accessibility_collapse, 0.42).
narrative_ontology:constraint_metric(ai_governance_legitimacy__magisterial_subsidiarity_reading, resistance, 0.71).

% --- Constraint claim ---
narrative_ontology:constraint_claim(ai_governance_legitimacy__magisterial_subsidiarity_reading, mountain).
narrative_ontology:human_readable(ai_governance_legitimacy__magisterial_subsidiarity_reading, "Magisterial Subsidiarity Reading of AI Governance Legitimacy").
narrative_ontology:topic_domain(ai_governance_legitimacy__magisterial_subsidiarity_reading, "theological_ethics/technology_governance/political_theology").

domain_priors:requires_active_enforcement(ai_governance_legitimacy__magisterial_subsidiarity_reading).
domain_priors:emerges_naturally(ai_governance_legitimacy__magisterial_subsidiarity_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(ai_governance_legitimacy__magisterial_subsidiarity_reading, '6992b0de-6c99-4803-a150-af8a2f356191').
narrative_ontology:cs_kernel_codification('6992b0de-6c99-4803-a150-af8a2f356191', formalized).
narrative_ontology:cs_authority_grounding('6992b0de-6c99-4803-a150-af8a2f356191', lineage).
narrative_ontology:cs_interpretation_layer_present('6992b0de-6c99-4803-a150-af8a2f356191').
narrative_ontology:cs_reading_relation('6992b0de-6c99-4803-a150-af8a2f356191', ai_governance_legitimacy__technocratic_optimization_reading, forecloses).
narrative_ontology:cs_reading_relation('6992b0de-6c99-4803-a150-af8a2f356191', ai_governance_legitimacy__democratic_pluralist_reading, influences).
narrative_ontology:cs_reading_relation('6992b0de-6c99-4803-a150-af8a2f356191', ai_governance_legitimacy__market_libertarian_reading, forecloses).
narrative_ontology:cs_axiom('6992b0de-6c99-4803-a150-af8a2f356191', foundational, human_dignity_prior_to_utility).
narrative_ontology:cs_axiom_status(human_dignity_prior_to_utility, holdable).
narrative_ontology:cs_axiom_grounding('6992b0de-6c99-4803-a150-af8a2f356191', human_dignity_prior_to_utility, deontological).
narrative_ontology:cs_axiom('6992b0de-6c99-4803-a150-af8a2f356191', foundational, magisterial_competence_over_technology_ethics).
narrative_ontology:cs_axiom_status(magisterial_competence_over_technology_ethics, holdable).
narrative_ontology:cs_axiom_grounding('6992b0de-6c99-4803-a150-af8a2f356191', magisterial_competence_over_technology_ethics, conventional).
narrative_ontology:cs_axiom('6992b0de-6c99-4803-a150-af8a2f356191', secondary, universal_destination_of_goods_constrains_property).
narrative_ontology:cs_axiom_status(universal_destination_of_goods_constrains_property, holdable).
narrative_ontology:cs_axiom_grounding('6992b0de-6c99-4803-a150-af8a2f356191', universal_destination_of_goods_constrains_property, deontological).
narrative_ontology:cs_reference_frame('6992b0de-6c99-4803-a150-af8a2f356191', apostolic_natural_law_tradition).
narrative_ontology:cs_drift_state('6992b0de-6c99-4803-a150-af8a2f356191', post_vatican_ii_technological_era, gap(practice_drift, substantial, true)).
narrative_ontology:cs_created_at('6992b0de-6c99-4803-a150-af8a2f356191', '').
narrative_ontology:cs_kernel_id(ai_governance_legitimacy__magisterial_subsidiarity_reading, ai_governance_legitimacy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__magisterial_subsidiarity_reading, workers).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__magisterial_subsidiarity_reading, global_south_populations).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__magisterial_subsidiarity_reading, families).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__magisterial_subsidiarity_reading, marginalized_communities).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__magisterial_subsidiarity_reading, catholic_social_teaching_advocates).
narrative_ontology:constraint_victim(ai_governance_legitimacy__magisterial_subsidiarity_reading, private_tech_monopolies).
narrative_ontology:constraint_victim(ai_governance_legitimacy__magisterial_subsidiarity_reading, military_industrial_complex).
narrative_ontology:constraint_victim(ai_governance_legitimacy__magisterial_subsidiarity_reading, extractive_finance_sector).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% The teaching authority of the Catholic Church authoritatively interprets natural law and Catholic Social Doctrine. Issues encyclicals, apostolic exhortations, and doctrinal statements establishing normative principles for technology governance. Claims competence to bind conscience of Catholics and offer moral guidance to all people of goodwill. Does not wield direct enforcement power but exercises moral suasion through global ecclesial network and civil society influence.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, magisterium, agenda_setter,
    institutional, civilizational, analytical, global).

% Labor whose dignity and agency the constraint seeks to protect against algorithmic displacement, surveillance, and exploitation. Benefit from subsidiarity principle requiring decision-making at most local competent level and solidarity principle demanding protection of the vulnerable. Constrained exit because alternative governance regimes offer less structural protection of labor rights against technological disruption.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, workers, beneficiary,
    organized, biographical, constrained, global).

% Populations bearing disproportionate costs of AI development (data extraction, environmental burden, exclusion from benefits) while excluded from governance deliberation. The constraint's universal destination of goods principle explicitly centers their claims. Trapped exit because they lack political power to shape alternative regimes and face highest stakes from unregulated AI deployment.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, global_south_populations, beneficiary,
    powerless, generational, trapped, global).

% Social units the constraint identifies as fundamental to human flourishing, requiring protection from technological disruption of formation, education, and relationships. Benefit from subsidiarity principle limiting centralized interference and solidarity principle ensuring material conditions for family stability. Constrained exit because family structure itself is non-negotiable within this framework.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, families, beneficiary,
    moderate, generational, constrained, local).

% Groups facing algorithmic discrimination, surveillance targeting, or exclusion from AI benefits (racial minorities, disabled persons, religious minorities, indigenous peoples). The constraint's preferential option for the poor explicitly prioritizes their protection. Trapped exit because they lack market or political power to secure alternative protections.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, marginalized_communities, beneficiary,
    powerless, biographical, trapped, regional).

% Civil society organizations, theologians, and activists implementing the constraint's principles through advocacy, policy work, and institutional reform. Their professional identity and institutional mission are constituted through this framework. Identity-locked exit because their vocation is defined by this interpretive tradition; adopting an alternative framework would require reconstituting professional self-understanding.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, catholic_social_teaching_advocates, beneficiary,
    organized, civilizational, identity_locked, global).

% Corporations whose business models the constraint identifies as incompatible with human dignity: surveillance capitalism, algorithmic manipulation, labor exploitation, monopolistic extraction. Required to subordinate profit to common good through transparency, accountability, and worker participation in governance. Mobile exit through jurisdictional arbitrage and political capture of secular regulatory regimes.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, private_tech_monopolies, payer,
    institutional, biographical, mobile, global).

% Defense contractors and national security apparatus deploying autonomous weapons and surveillance systems. The constraint demands human control, proportionality, and prohibition of indiscriminate harm—principles incompatible with many military AI applications. Bear cost of foregone strategic advantage and operational efficiency. Mobile exit through national security exemptions and classified programs insulated from civil society oversight.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, military_industrial_complex, payer,
    institutional, generational, mobile, global).

% Financial institutions using algorithmic trading, credit scoring, and risk assessment in ways the constraint identifies as serving capital accumulation over universal destination of goods. Required to prioritize equitable access to capital and protection of debtors over profit maximization. Arbitrage exit through regulatory capture, offshore operations, and reframing extractive practices as fiduciary duties.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, extractive_finance_sector, payer,
    institutional, immediate, arbitrage, global).

% Democratic governments, international organizations, and regulatory bodies observing the constraint as one input among many. Some incorporate Catholic Social Teaching principles into policy; others reject theological grounding while adopting similar substantive norms. Analytical exit because they adjudicate legitimacy claims through their own constitutional and deliberative processes rather than accepting magisterial authority.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, secular_governance_institutions, observer,
    institutional, generational, analytical, national).

% Rival comprehensive doctrines (secular humanism, other religious traditions, philosophical schools) offering competing accounts of human dignity, justice, and legitimate authority. The constraint treats its principles as grounded in natural law accessible to reason, but claims magisterial interpretive authority that structurally excludes non-Catholic voices from authoritative determination of meaning. Listed for completeness as the class of frameworks the reading's authority claim marginalizes.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, alternative_ethical_frameworks, excluded,
    analytical, civilizational, analytical, universal).
narrative_ontology:stakeholder_non_agent(ai_governance_legitimacy__magisterial_subsidiarity_reading, alternative_ethical_frameworks).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a systematic ethical framework for technology governance rooted in two millennia of moral theology, offering determinate answers to otherwise contested questions about human dignity, distributive justice, and legitimate authority through magisterial interpretation.
% TRANSFER_FUNCTION: Moves authority to define AI governance legitimacy from democratic deliberation, technical expertise, or market mechanisms to ecclesial interpretive tradition. Transfers decision-making power over technology deployment from private and state actors to governance structures accountable to subsidiarity and solidarity principles.
% ABSENT_VOICES: Non-Catholic religious traditions, secular philosophical frameworks, and indigenous knowledge systems that reject magisterial authority while holding substantive positions on technology ethics. They are structurally excluded from authoritative interpretation while their adherents are subject to the constraint's normative claims through civil society advocacy and international law.
% DISAPPEARANCE_RATIONALE: If this interpretive authority vanished, AI governance debates would lose a major institutional voice claiming comprehensive answers grounded in natural law. Catholic hospitals, universities, and advocacy organizations would require alternative ethical frameworks for technology policy. Global South civil society movements relying on CST language would need different conceptual tools. Tech firms and military actors would face one fewer source of moral suasion constraining deployment.
% FOUNDING_PROBLEM: The problem of technological development outpacing ethical deliberation, with no shared moral language to adjudicate conflicts between efficiency, innovation, human dignity, and justice. Particularly acute in AI where decisions affect billions while concentrated in hands of unaccountable private and state actors.
% FOUNDING_PROBLEM_CORROBORATION: The founding problem is corroborated by secular technology ethicists, democratic theorists, and international governance scholars who independently identify coordination failure in AI governance even while rejecting magisterial authority. UNESCO, EU AI Act deliberations, and academic literature on AI alignment document the legitimacy crisis. The constraint's SOLUTION (magisterial authority) is contested while the PROBLEM it addresses is widely acknowledged outside the benefiting institution.
narrative_ontology:disappearance_verdict(ai_governance_legitimacy__magisterial_subsidiarity_reading, world_rearranges).
narrative_ontology:founding_problem_status(ai_governance_legitimacy__magisterial_subsidiarity_reading, live).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(ai_governance_legitimacy__magisterial_subsidiarity_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(ai_governance_legitimacy__magisterial_subsidiarity_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(ai_governance_legitimacy__magisterial_subsidiarity_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(ai_governance_legitimacy__magisterial_subsidiarity_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__magisterial_subsidiarity_reading, ExtMetricName, E),
    domain_priors:suppression_score(ai_governance_legitimacy__magisterial_subsidiarity_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(ai_governance_legitimacy__magisterial_subsidiarity_reading),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__magisterial_subsidiarity_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__magisterial_subsidiarity_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(ai_governance_legitimacy__magisterial_subsidiarity_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is moderate-high (0.50) because the constraint transfers interpretive authority over contested ethical questions from democratic deliberation and technical expertise to ecclesial tradition, foreclosing pluralist resolution. The extraction is real even though substantive principles (dignity, solidarity) have broad appeal—what is extracted is the authority to define and apply these principles outside magisterial interpretation. Suppression is higher (0.68) because the constraint's authority claim structurally excludes non-Catholic comprehensive doctrines from authoritative voice while claiming its principles bind all people through natural law. Theater ratio is moderate-low (0.28) because the coordination function is genuine—Catholic Social Teaching provides systematic ethical framework and mobilizes civil society—but growing enforcement effort goes to defending magisterial authority against secular and pluralist challenges rather than elaborating principles. Accessibility collapse is moderate (0.42) because alternative frameworks remain intellectually available and institutionally viable outside Catholic contexts. Resistance is high (0.71) because secular democratic theorists, other religious traditions, and market advocates actively contest the authority claim even when they share concern for dignity and justice.
 *
 * PERSPECTIVAL GAP:
 *   From the Magisterium's seat, this constraint is a mountain: natural law reasoning makes human dignity and its requirements accessible to reason independent of revelation; the Church merely articulates what is objectively true about technology's proper ordering to human ends. From powerless beneficiary seats (Global South, marginalized communities), the constraint appears as tangled rope: it offers real protection against technocratic and market exploitation but does so through an authority structure that excludes their voices from shaping interpretation. From institutional payer seats (tech monopolies, military), it appears as snare: moral suasion backed by civil society pressure and regulatory advocacy that constrains profitable deployment without democratic legitimation. From secular governance seats, it appears as one comprehensive doctrine among many claiming special interpretive privilege. The engine computes these divergent classifications from the structural data—the claim/metric independence preserves this measurement rather than reconciling it away.
 *
 * DIRECTIONALITY LOGIC:
 *   The Magisterium sits at the beneficiary end (d ≈ 0.20): it collects interpretive authority and institutional influence from the constraint's operation while bearing minimal cost. Workers, Global South populations, families, and marginalized communities are positioned as beneficiaries (d ≈ 0.25-0.35) insofar as their dignity claims are centered, but they are also constrained by the framework's exclusion of their own voices from authoritative interpretation—they receive protection but not agency. Catholic Social Teaching advocates are identity-locked beneficiaries (d ≈ 0.30). Tech monopolies, military-industrial complex, and extractive finance are institutional payers (d ≈ 0.75-0.80) whose business models the constraint identifies as dignity-violating, but their mobile/arbitrage exit options dampen effective extraction. Secular governance institutions and alternative ethical frameworks experience the constraint as suppressive (d ≈ 0.60-0.70) of pluralist deliberation without being subordinated to it—they resist the authority claim while sometimes incorporating substantive principles.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint exhibits classic mandatrophy structure: it was built to solve a genuine coordination problem (ethical framework for technology governance amid legitimacy crisis) and offers real benefits (systematic principles, civil society mobilization, centering of vulnerable populations). But the solution entails concentrated interpretive authority that persists through institutional inertia beyond what the coordination function requires. A pluralist framework offering similar substantive principles (dignity, solidarity, subsidiarity) without magisterial gatekeeping could coordinate as effectively while extracting less. The rising suppression requirement over the interval reflects not that the principles have become less true but that defending magisterial exclusivity against democratic and pluralist challenges requires increasing institutional effort. The measurement trajectory shows extraction and enforcement climbing as the reading gains influence—suggesting the mandate has outlived the coordination efficiency and is sustained by ecclesial institutional interest.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    natural_law_vs_ecclesial_authority,
    'Are the constraint''s principles genuinely accessible to reason independent of revelation (natural law claim), or is their content and application inseparable from Catholic theological tradition such that magisterial authority is required for determinate answers?',
    'Historical analysis of whether non-Catholic traditions and secular frameworks converge on similar substantive principles when reasoning about technology ethics. If convergence occurs without magisterial input, the natural law claim is stronger. If substantive principles remain contested across traditions, the constraint''s claim to natural law grounding is weaker and it functions more as one comprehensive doctrine among others.',
    'If natural law accessible-to-reason, the constraint is closer to mountain (genuine coordination around objective moral facts). If ecclesial authority required, it is tangled rope or snare (extraction of interpretive monopoly from pluralist deliberation).',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(natural_law_vs_ecclesial_authority, conceptual, 'Whether magisterial authority is epistemically necessary or institutionally contingent for applying dignity principles to AI governance.').

omega_variable(
    beneficiary_agency_vs_protection,
    'Do the constraint''s beneficiaries (workers, Global South, marginalized communities) gain agency to shape AI governance through this framework, or only protection within an interpretive structure that excludes their authoritative voice?',
    'Empirical study of Catholic Social Teaching-based advocacy: does it amplify marginalized voices in governance deliberation, or does it substitute ecclesial voice for direct participation? Comparative analysis with movements using indigenous, feminist, or democratic frameworks.',
    'If beneficiaries gain agency, the coordination function is robust and extraction is lower. If they gain only protection without voice, the constraint operates more extractively—collecting authority from those it claims to serve.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(beneficiary_agency_vs_protection, empirical, 'Whether the constraint empowers or ventriloquizes its claimed beneficiaries.').

omega_variable(
    subsidiarity_vs_magisterial_centralization,
    'Does the constraint''s subsidiarity principle (decisions at most local competent level) apply reflexively to its own interpretive authority, or does magisterial centralization of ethical interpretation violate the principle it proclaims?',
    'Theological analysis of whether ecclesial teaching authority is exempt from subsidiarity constraints, or whether local churches, national conferences, and lay faithful should hold interpretive authority over technology ethics within their contexts. Test cases: when local bishops or Catholic ethicists diverge from Vatican positions on AI, whose interpretation governs?',
    'If subsidiarity applies reflexively, the constraint''s authority structure is internally contradictory and extraction is higher (claiming a principle it violates). If magisterial authority is legitimately exempt, internal coherence is stronger but the constraint remains exclusionary of non-Catholic frameworks.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(subsidiarity_vs_magisterial_centralization, conceptual, 'Whether the constraint''s subsidiarity principle undermines its own centralized interpretive authority.').

omega_variable(
    moral_suasion_vs_coercive_enforcement,
    'As the constraint gains influence through civil society advocacy and international law, does enforcement remain non-coercive moral suasion or does it harden into legal and regulatory requirements that bind non-consenting parties?',
    'Track trajectory of Catholic Social Teaching principles from encyclicals to EU regulation, UN frameworks, and national law. If principles become legally binding on non-Catholic actors and institutions without their consent, suppression increases. If they remain voluntary guidance, suppression stays lower.',
    'If enforcement remains moral suasion, the constraint is closer to its claimed voluntary coordination. If it hardens into law, it operates more coercively and extraction/suppression rise to match institutional power wielded.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(moral_suasion_vs_coercive_enforcement, empirical, 'Whether the constraint''s enforcement trajectory moves from voluntary to coercive as institutional influence grows.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(ai_governance_legitimacy__magisterial_subsidiarity_reading, 0, 30).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(ai_g_tr_t0, ai_governance_legitimacy__magisterial_subsidiarity_reading, theater_ratio, 0, 0.2).
narrative_ontology:measurement(ai_g_tr_t6, ai_governance_legitimacy__magisterial_subsidiarity_reading, theater_ratio, 6, 0.22).
narrative_ontology:measurement(ai_g_tr_t12, ai_governance_legitimacy__magisterial_subsidiarity_reading, theater_ratio, 12, 0.24).
narrative_ontology:measurement(ai_g_tr_t18, ai_governance_legitimacy__magisterial_subsidiarity_reading, theater_ratio, 18, 0.26).
narrative_ontology:measurement(ai_g_tr_t24, ai_governance_legitimacy__magisterial_subsidiarity_reading, theater_ratio, 24, 0.27).
narrative_ontology:measurement(ai_g_tr_t30, ai_governance_legitimacy__magisterial_subsidiarity_reading, theater_ratio, 30, 0.28).

% Extraction over time
narrative_ontology:measurement(ai_g_be_t0, ai_governance_legitimacy__magisterial_subsidiarity_reading, base_extractiveness, 0, 0.42).
narrative_ontology:measurement(ai_g_be_t6, ai_governance_legitimacy__magisterial_subsidiarity_reading, base_extractiveness, 6, 0.44).
narrative_ontology:measurement(ai_g_be_t12, ai_governance_legitimacy__magisterial_subsidiarity_reading, base_extractiveness, 12, 0.46).
narrative_ontology:measurement(ai_g_be_t18, ai_governance_legitimacy__magisterial_subsidiarity_reading, base_extractiveness, 18, 0.48).
narrative_ontology:measurement(ai_g_be_t24, ai_governance_legitimacy__magisterial_subsidiarity_reading, base_extractiveness, 24, 0.49).
narrative_ontology:measurement(ai_g_be_t30, ai_governance_legitimacy__magisterial_subsidiarity_reading, base_extractiveness, 30, 0.5).

% Suppression requirement over time
narrative_ontology:measurement(ai_g_su_t0, ai_governance_legitimacy__magisterial_subsidiarity_reading, suppression_requirement, 0, 0.58).
narrative_ontology:measurement(ai_g_su_t6, ai_governance_legitimacy__magisterial_subsidiarity_reading, suppression_requirement, 6, 0.61).
narrative_ontology:measurement(ai_g_su_t12, ai_governance_legitimacy__magisterial_subsidiarity_reading, suppression_requirement, 12, 0.63).
narrative_ontology:measurement(ai_g_su_t18, ai_governance_legitimacy__magisterial_subsidiarity_reading, suppression_requirement, 18, 0.65).
narrative_ontology:measurement(ai_g_su_t24, ai_governance_legitimacy__magisterial_subsidiarity_reading, suppression_requirement, 24, 0.67).
narrative_ontology:measurement(ai_g_su_t30, ai_governance_legitimacy__magisterial_subsidiarity_reading, suppression_requirement, 30, 0.68).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(ai_governance_legitimacy__magisterial_subsidiarity_reading, identity_coordination).
narrative_ontology:boltzmann_floor_override(ai_governance_legitimacy__magisterial_subsidiarity_reading, 0.12).
narrative_ontology:affects_constraint(ai_governance_legitimacy__magisterial_subsidiarity_reading, ai_governance_legitimacy__technocratic_optimization_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__magisterial_subsidiarity_reading, ai_governance_legitimacy__democratic_pluralist_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__magisterial_subsidiarity_reading, ai_governance_legitimacy__market_libertarian_reading).

% DUAL FORMULATION NOTE:
% This constraint is one of four readings of the ai_governance_legitimacy kernel. Each reading instantiates a different institutional solution to the same coordination problem (legitimate authority over AI governance amid value pluralism). The readings differ in epsilon (extractiveness) because they differ in whose authority they concentrate and whom they exclude. Network edges connect all four readings bidirectionally because they compete for the same institutional space—civil society advocacy, regulatory frameworks, international law—and each reading's success constrains the others' influence. The kernel decomposition follows epsilon-invariance: measuring all four readings separately reveals the range of institutional arrangements the natural-language concept 'AI governance legitimacy' can instantiate, each with different beneficiary structures and extraction profiles.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

constraint_indexing:directionality_override(ai_governance_legitimacy__magisterial_subsidiarity_reading, institutional, 0.25).

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
