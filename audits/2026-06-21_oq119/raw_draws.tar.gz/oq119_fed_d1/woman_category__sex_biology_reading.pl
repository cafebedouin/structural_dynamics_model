% ============================================================================
% CONSTRAINT STORY: woman_category__sex_biology_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_woman_category__sex_biology_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: woman_category__sex_biology_reading
 *   human_readable: Woman Category: Sex Biology Reading
 *   domain: political_philosophy/law/social_policy/bioethics
 *
 * SUMMARY:
 *   This constraint is the sex-biology reading of the contested 'woman'
 *   category kernel. It defines 'woman' by chromosomal and anatomical
 *   criteria: XX chromosomes, female reproductive anatomy, typical female
 *   endocrinology. The reading is institutionalized in sports eligibility
 *   rules, legal definitions of sex, medical protocols, and access to
 *   sex-segregated spaces. Proponents frame it as recognizing biological
 *   reality; opponents frame it as naturalizing a contested policy choice
 *   that excludes transgender women and treats intersex variation as
 *   aberration. The reading COEXISTS WITH two sibling readings
 *   (gender-identity and intersex-accommodation) across different
 *   jurisdictions and institutions; it does not logically foreclose them, but
 *   it creates structural pressure (administrative simplicity, legal
 *   precedent, medical infrastructure) that makes alternative readings
 *   costlier to implement.
 *
 * KEY AGENTS:
 *   - sex_based_rights_advocates: agenda_setter (organized/mobile) — set policy agendas and draft legislation preserving sex-based definitions
 *   - sports_governing_bodies: beneficiary (institutional/constrained) — gain administrative simplicity from bright-line eligibility rules
 *   - medical_professionals: beneficiary (institutional/mobile) — preserve established clinical protocols built on sex-based data
 *   - people_with_female_biology: beneficiary (organized/constrained) — access sex-segregated protections
 *   - transgender_women: payer (moderate/identity_locked) — excluded from category membership and associated protections
 *   - intersex_people: payer (powerless/trapped) — ambiguously positioned, subjected to medical intervention or categorical misrecognition
 *   - gender_identity_advocates: excluded (organized/mobile) — position structurally subordinated under this reading
 *   - legal_scholars: observer (institutional/analytical) — analyze the constraint's historical and constitutional dynamics
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(woman_category__sex_biology_reading, 0.68).
domain_priors:suppression_score(woman_category__sex_biology_reading, 0.72).
domain_priors:theater_ratio(woman_category__sex_biology_reading, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, extractiveness, 0.68).
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, suppression_requirement, 0.72).
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, accessibility_collapse, 0.71).
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, resistance, 0.76).

% --- Constraint claim ---
narrative_ontology:constraint_claim(woman_category__sex_biology_reading, mountain).
narrative_ontology:human_readable(woman_category__sex_biology_reading, "Woman Category: Sex Biology Reading").
narrative_ontology:topic_domain(woman_category__sex_biology_reading, "political_philosophy/law/social_policy/bioethics").

domain_priors:requires_active_enforcement(woman_category__sex_biology_reading).
domain_priors:emerges_naturally(woman_category__sex_biology_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(woman_category__sex_biology_reading, '9071e6c0-3bba-4fe9-820f-a67888ea0376').
narrative_ontology:cs_kernel_codification('9071e6c0-3bba-4fe9-820f-a67888ea0376', formalized).
narrative_ontology:cs_authority_grounding('9071e6c0-3bba-4fe9-820f-a67888ea0376', lineage).
narrative_ontology:cs_interpretation_layer_present('9071e6c0-3bba-4fe9-820f-a67888ea0376').
narrative_ontology:cs_reading_relation('9071e6c0-3bba-4fe9-820f-a67888ea0376', woman_category__gender_identity_reading, coexists_with).
narrative_ontology:cs_reading_relation('9071e6c0-3bba-4fe9-820f-a67888ea0376', woman_category__intersex_accommodation_reading, influences).
narrative_ontology:cs_axiom('9071e6c0-3bba-4fe9-820f-a67888ea0376', foundational, chromosomal_sex_determines_category_membership).
narrative_ontology:cs_axiom_status(chromosomal_sex_determines_category_membership, holdable).
narrative_ontology:cs_axiom_grounding('9071e6c0-3bba-4fe9-820f-a67888ea0376', chromosomal_sex_determines_category_membership, empirically_contingent).
narrative_ontology:cs_axiom('9071e6c0-3bba-4fe9-820f-a67888ea0376', foundational, biological_sex_is_binary_and_immutable).
narrative_ontology:cs_axiom_status(biological_sex_is_binary_and_immutable, holdable).
narrative_ontology:cs_axiom_grounding('9071e6c0-3bba-4fe9-820f-a67888ea0376', biological_sex_is_binary_and_immutable, empirically_contingent).
narrative_ontology:cs_reference_frame('9071e6c0-3bba-4fe9-820f-a67888ea0376', classical_biological_sex_binary).
narrative_ontology:cs_drift_state('9071e6c0-3bba-4fe9-820f-a67888ea0376', contemporary_gender_identity_era, gap(authority_erosion, substantial, false)).
narrative_ontology:cs_created_at('9071e6c0-3bba-4fe9-820f-a67888ea0376', '').
narrative_ontology:cs_kernel_id(woman_category__sex_biology_reading, woman_category).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(woman_category__sex_biology_reading, sex_based_rights_advocates).
narrative_ontology:constraint_beneficiary(woman_category__sex_biology_reading, sports_governing_bodies).
narrative_ontology:constraint_beneficiary(woman_category__sex_biology_reading, medical_professionals).
narrative_ontology:constraint_victim(woman_category__sex_biology_reading, transgender_women).
narrative_ontology:constraint_victim(woman_category__sex_biology_reading, intersex_people).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_beneficiary(woman_category__sex_biology_reading, people_with_female_biology).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Advocate for sex-based legal protections, women's sports eligibility rules, and single-sex spaces. Frame biological sex as the stable, objective basis for category membership and argue that abandoning sex-based classification erodes protections built for female people. They set policy agendas in legislative hearings, draft model legislation, and litigate to preserve sex-based definitions in law.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, sex_based_rights_advocates, agenda_setter,
    organized, generational, mobile, global).

% Implement eligibility rules for women's athletic competition. The sex-biology reading provides a bright-line standard (chromosomal sex, testosterone thresholds, reproductive anatomy) that is administratively simple to apply and defensible as grounded in physical performance differences. Alternative readings complicate eligibility and create enforcement costs; this reading simplifies their administrative burden.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, sports_governing_bodies, beneficiary,
    institutional, biographical, constrained, global).

% Use chromosomal and anatomical sex as the primary clinical variable for sex-specific disease risk, drug metabolism, and reproductive health. The sex-biology reading aligns with established diagnostic protocols and epidemiological data collection. Shifting to identity-based categories would require rebuilding clinical databases and risk stratification models; preserving sex-based categories protects existing infrastructure.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, medical_professionals, beneficiary,
    institutional, generational, mobile, global).

% Access sex-segregated spaces (prisons, shelters, changing rooms), sports categories, and legal protections built on the recognition of sex-based vulnerability and physical difference. The sex-biology reading preserves their access to these protections by maintaining a stable boundary. Contestation of the boundary creates uncertainty about who has legitimate access.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, people_with_female_biology, beneficiary,
    organized, generational, constrained, global).

% Excluded from women's sports, single-sex spaces, and legal protections tied to the 'woman' category under this reading. The exclusion is grounded in chromosomal and anatomical criteria that do not change with gender transition. Their access to safety, legal recognition, and participation depends on policies that either carve out exceptions or adopt alternative definitions; under this reading they are categorically ineligible.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, transgender_women, payer,
    moderate, biographical, identity_locked, global).

% Ambiguously positioned: the 'typical case' framing excludes intersex variations from the core definition, but enforcement mechanisms treat ambiguous cases inconsistently. In athletics, intersex women with high endogenous testosterone are subjected to hormone suppression requirements or outright exclusion; in legal contexts, intersex people are often administratively assigned to male or female categories without recognition of biological variation. The constraint imposes costs (medical intervention, categorical misrecognition) without providing the protections it offers to typical-case women.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, intersex_people, payer,
    powerless, biographical, trapped, global).

% Advocate for self-identified gender as the basis for category membership and legal recognition. Under this reading, their position is structurally excluded: chromosomal sex is treated as the governing criterion, and identity claims are subordinated to biological facts. They would argue that the sex-biology reading imposes a reductive, essentialist framework that denies the lived reality of transgender people.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, gender_identity_advocates, excluded,
    organized, generational, mobile, global).

% Analyze the constraint's interaction with equality law, human rights frameworks, and constitutional protections. They trace how sex-based classification has historically been used both to protect women (Title IX, Violence Against Women Act) and to subordinate them (coverture, employment discrimination). The sex-biology reading's claim to naturalism is contested within this scholarship: some scholars argue it reflects biological reality; others argue it naturalizes a contested policy choice.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, legal_scholars, observer,
    institutional, generational, analytical, national).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a stable, legible, administratively simple basis for sex-segregated legal protections, medical protocols, and athletic competition: one criterion (chromosomal/anatomical sex) determines category membership without requiring individualized assessment of identity claims.
% TRANSFER_FUNCTION: Moves access to sex-segregated spaces, sports participation, legal protections, and social recognition from people without female biology (transgender women) to people with female biology, as the price of maintaining a bright-line boundary.
% ABSENT_VOICES: Gender identity advocates and intersex rights advocates are structurally excluded from the definitional apparatus: the reading treats chromosomal sex as governing and subordinates identity and biological variation to that standard.
% DISAPPEARANCE_RATIONALE: If the sex-biology reading vanished overnight, women's sports would reorganize around alternative eligibility criteria (identity, testosterone levels, or case-by-case assessment), single-sex spaces would adopt new access policies, legal frameworks would shift to gender-identity-based protections, and medical protocols would require rebuilding around new classification schemes. The social world is organized around this definition.
% FOUNDING_PROBLEM: Sex-based oppression and vulnerability (reproductive coercion, sexual violence, economic subordination) required legal recognition of women as a protected class; biological sex provided the stable, objective, legible criterion for that recognition.
% FOUNDING_PROBLEM_CORROBORATION: Sex-based rights advocates attest the founding problem remains live, citing ongoing sex-based violence and the need for stable legal categories. Gender identity advocates and intersex rights scholars attest the founding problem has been solved in ways that no longer require chromosomal essentialism: legal protections can be grounded in gender identity or non-binary sex frameworks. Independent legal scholars and human rights bodies (UN Women, Council of Europe) document that both sex-based and gender-identity-based frameworks are live policy options across jurisdictions, supporting the contested status.
narrative_ontology:disappearance_verdict(woman_category__sex_biology_reading, world_rearranges).
narrative_ontology:founding_problem_status(woman_category__sex_biology_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(woman_category__sex_biology_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(woman_category__sex_biology_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(woman_category__sex_biology_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(woman_category__sex_biology_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(woman_category__sex_biology_reading, ExtMetricName, E),
    domain_priors:suppression_score(woman_category__sex_biology_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(woman_category__sex_biology_reading),
    narrative_ontology:constraint_metric(woman_category__sex_biology_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(woman_category__sex_biology_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(woman_category__sex_biology_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is high (0.68) because the constraint transfers access to protections, spaces, and recognition from transgender women to people with female biology, not as a coordination necessity but as a definitional choice among contested alternatives. The cost borne by transgender women (categorical exclusion, denial of legal recognition, foreclosed access to safety) is substantial and not compensated by benefits they receive under this reading. Suppression is high (0.72) because enforcement requires active institutional machinery: sports bodies test chromosomes and hormone levels, legal systems adjudicate disputes over birth certificates and identity documents, prisons and shelters enforce access policies, and alternative definitions are litigated and legislatively opposed. Theater ratio is moderate-low (0.28): the administrative simplicity and clinical utility are real, but a growing share of enforcement activity defends the definitional boundary itself rather than solving coordination problems. Accessibility collapse is high (0.71) because once chromosomal sex is treated as the governing criterion, alternative bases for category membership (identity, social role, legal recognition) are subordinated; but it is not near-total because sibling readings remain institutionalized in other jurisdictions. Resistance is high (0.76) because the reading meets sustained opposition from gender identity advocates, intersex rights organizations, and legal scholars who contest its naturalism claim.
 *
 * PERSPECTIVAL GAP:
 *   From the sex-based rights advocates' seat, the constraint is genuine coordination grounded in biological reality: it recognizes an objective category and protects women as a class. From the transgender women's seat, the same structure is enforced extraction: it denies their lived identity, forecloses legal recognition, and transfers protections they need to a group defined to exclude them. The engine computes this divergence from the structural data. The claimed type (mountain) reflects the proponents' framing; the metrics describe the operation as substantially extractive and actively enforced.
 *
 * DIRECTIONALITY LOGIC:
 *   Sex-based rights advocates and sports governing bodies are structural beneficiaries: the reading simplifies administration, provides legal defensibility, and preserves protections they value (d near beneficiary end). People with female biology are also beneficiaries: they retain access to sex-segregated spaces and sports. Transgender women are structural targets: excluded from category membership, they bear the full cost of the boundary (d near target end, identity-locked exit). Intersex people are ambiguous targets: not clearly included or excluded, they face enforcement costs without receiving the protections offered to typical-case women (d mid-to-high, trapped exit). Medical professionals are beneficiaries in that the reading preserves existing infrastructure, but their position is complicated by clinical cases where chromosomal sex does not predict treatment response (d slightly below symmetric). Gender identity advocates are excluded rather than coordinated.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint's founding problem (sex-based oppression requiring legal recognition of women as a protected class) is contested: sex-based rights advocates attest it remains live; gender identity advocates attest it has been solved in ways that no longer require chromosomal essentialism. The disappearance verdict is world_rearranges: social arrangements (sports, law, medicine) are organized around this definition. The mismatch consumer will flag founding_problem_status=contested + disappearance_verdict=world_rearranges as evidence of ongoing coordination function, not obsolescence. This is NOT a zombie constraint: the world's dependence on it is real, even if the necessity of THIS particular reading is disputed.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    biological_essentialism_vs_social_construction,
    'Is the sex-biology reading a description of natural biological categories, or is it a constructed policy choice that naturalizes one framework among contested alternatives?',
    'Cross-jurisdictional comparison: if legal and medical systems can function with gender-identity or intersex-inclusive definitions without collapsing coordination (as observed in jurisdictions that have adopted those frameworks), the sex-biology reading is a policy choice, not a natural necessity. If those systems exhibit coordination failures traceable to definitional ambiguity, the essentialism claim gains support.',
    'If the reading is a policy choice naturalizing one framework, the mountain claim is false and the constraint reclassifies toward tangled_rope or snare. If it describes irreducible biological categories, the mountain claim holds and extraction is the unavoidable cost of recognizing reality.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(biological_essentialism_vs_social_construction, conceptual, 'Whether the constraint reflects biological necessity or contested policy framing.').

omega_variable(
    intersex_inclusion_ambiguity,
    'Does the ''typical case'' framing of female biology include or exclude intersex people, and is that inclusion/exclusion stable or enforcement-dependent?',
    'Systematic review of sports eligibility rulings, legal adjudications, and medical protocols: if intersex people are included without additional requirements, the reading is genuinely inclusive; if they are subjected to hormone suppression, surgery, or categorical exclusion, the reading excludes them despite rhetorical inclusion.',
    'If intersex people are systematically excluded or subjected to coercive intervention, the victim set expands and extractiveness increases. If they are included without cost, the coordination function claim strengthens.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(intersex_inclusion_ambiguity, empirical, 'Whether intersex people are genuinely included or subjected to enforcement costs.').

omega_variable(
    administrative_simplicity_vs_essentialist_ontology,
    'Is the sex-biology reading defended for its administrative simplicity (a pragmatic coordination argument) or for its essentialist ontology (a claim about the nature of sex categories)?',
    'Discourse analysis of legislative hearings, policy documents, and advocacy materials: if proponents emphasize bright-line rules and enforcement costs, the defense is pragmatic; if they emphasize immutable biological reality and conceptual necessity, the defense is essentialist. Track whether proponents accept alternative frameworks in contexts where administrative simplicity is less critical (private spaces, social recognition).',
    'If the defense is pragmatic, the constraint is better understood as enforced coordination (tangled_rope) where administrative cost is weighed against exclusionary harm. If the defense is essentialist, the mountain framing is sincere but the beneficiary structure and resistance levels undermine naturalism certification.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(administrative_simplicity_vs_essentialist_ontology, conceptual, 'Whether the constraint''s justification is pragmatic coordination or essentialist ontology.').

omega_variable(
    kernel_contest_resolution_path,
    'Is the woman_category kernel resolvable by empirical evidence (measuring coordination outcomes under alternative readings), or is it irreducibly normative (a values dispute about which framework ought to govern)?',
    'Meta-analysis of jurisdictions that have adopted each reading: if one reading produces systematically better coordination outcomes (fewer disputes, lower enforcement costs, broader consensus) without imposing greater harm on excluded groups, the kernel is empirically resolvable. If each reading produces trade-offs that different constituencies weight differently, the kernel is normatively irreducible.',
    'If empirically resolvable, future evidence could adjudicate between readings and reclassify the kernel. If normatively irreducible, the kernel remains contested indefinitely and the reading competition is a permanent feature of the policy landscape.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(kernel_contest_resolution_path, preference, 'Whether the kernel contest is empirically resolvable or normatively irreducible.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(woman_category__sex_biology_reading, 0, 30).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(woma_tr_t0, woman_category__sex_biology_reading, theater_ratio, 0, 0.15).
narrative_ontology:measurement_basis(woma_tr_t0, observed).
narrative_ontology:measurement(woma_tr_t6, woman_category__sex_biology_reading, theater_ratio, 6, 0.18).
narrative_ontology:measurement_basis(woma_tr_t6, observed).
narrative_ontology:measurement(woma_tr_t12, woman_category__sex_biology_reading, theater_ratio, 12, 0.21).
narrative_ontology:measurement_basis(woma_tr_t12, observed).
narrative_ontology:measurement(woma_tr_t18, woman_category__sex_biology_reading, theater_ratio, 18, 0.24).
narrative_ontology:measurement_basis(woma_tr_t18, observed).
narrative_ontology:measurement(woma_tr_t24, woman_category__sex_biology_reading, theater_ratio, 24, 0.26).
narrative_ontology:measurement_basis(woma_tr_t24, observed).
narrative_ontology:measurement(woma_tr_t30, woman_category__sex_biology_reading, theater_ratio, 30, 0.28).
narrative_ontology:measurement_basis(woma_tr_t30, observed).

% Extraction over time
narrative_ontology:measurement(woma_be_t0, woman_category__sex_biology_reading, base_extractiveness, 0, 0.52).
narrative_ontology:measurement_basis(woma_be_t0, observed).
narrative_ontology:measurement(woma_be_t6, woman_category__sex_biology_reading, base_extractiveness, 6, 0.56).
narrative_ontology:measurement_basis(woma_be_t6, observed).
narrative_ontology:measurement(woma_be_t12, woman_category__sex_biology_reading, base_extractiveness, 12, 0.61).
narrative_ontology:measurement_basis(woma_be_t12, observed).
narrative_ontology:measurement(woma_be_t18, woman_category__sex_biology_reading, base_extractiveness, 18, 0.64).
narrative_ontology:measurement_basis(woma_be_t18, observed).
narrative_ontology:measurement(woma_be_t24, woman_category__sex_biology_reading, base_extractiveness, 24, 0.66).
narrative_ontology:measurement_basis(woma_be_t24, observed).
narrative_ontology:measurement(woma_be_t30, woman_category__sex_biology_reading, base_extractiveness, 30, 0.68).
narrative_ontology:measurement_basis(woma_be_t30, observed).

% Suppression requirement over time
narrative_ontology:measurement(woma_su_t0, woman_category__sex_biology_reading, suppression_requirement, 0, 0.58).
narrative_ontology:measurement_basis(woma_su_t0, observed).
narrative_ontology:measurement(woma_su_t6, woman_category__sex_biology_reading, suppression_requirement, 6, 0.62).
narrative_ontology:measurement_basis(woma_su_t6, observed).
narrative_ontology:measurement(woma_su_t12, woman_category__sex_biology_reading, suppression_requirement, 12, 0.66).
narrative_ontology:measurement_basis(woma_su_t12, observed).
narrative_ontology:measurement(woma_su_t18, woman_category__sex_biology_reading, suppression_requirement, 18, 0.69).
narrative_ontology:measurement_basis(woma_su_t18, observed).
narrative_ontology:measurement(woma_su_t24, woman_category__sex_biology_reading, suppression_requirement, 24, 0.71).
narrative_ontology:measurement_basis(woma_su_t24, observed).
narrative_ontology:measurement(woma_su_t30, woman_category__sex_biology_reading, suppression_requirement, 30, 0.72).
narrative_ontology:measurement_basis(woma_su_t30, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(woman_category__sex_biology_reading, identity_coordination).
narrative_ontology:affects_constraint(woman_category__sex_biology_reading, woman_category__gender_identity_reading).
narrative_ontology:affects_constraint(woman_category__sex_biology_reading, woman_category__intersex_accommodation_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the woman_category kernel. The sex-biology reading and gender-identity reading have different victim sets, different enforcement mechanisms, and different extractiveness profiles; they are linked via network.affects_constraints but are distinct constraints. The sex-biology reading INFLUENCES the gender-identity reading by creating legal and administrative precedent that makes identity-based frameworks costlier to adopt.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
