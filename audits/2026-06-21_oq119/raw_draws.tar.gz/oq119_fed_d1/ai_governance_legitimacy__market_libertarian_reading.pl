% ============================================================================
% CONSTRAINT STORY: ai_governance_legitimacy__market_libertarian_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_ai_governance_legitimacy__market_libertarian_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: ai_governance_legitimacy__market_libertarian_reading
 *   human_readable: Market Libertarian Reading of AI Governance Legitimacy
 *   domain: theological_ethics/technology_governance/political_theology
 *
 * SUMMARY:
 *   This constraint story instantiates the market libertarian reading of AI
 *   governance legitimacy from the contested kernel around Aliquid Novi's
 *   encyclical. The reading asserts that legitimate governance authority
 *   derives from voluntary exchange and property rights, treating these as
 *   pre-political foundations rather than constructed institutional
 *   arrangements. It accepts the encyclical's subsidiarity principle
 *   (governance at lowest effective level) while rejecting solidarity demands
 *   as illegitimate coercion. The reading is claimed as mountain—a discovered
 *   feature of moral and economic reality—while the metrics capture modest
 *   extraction from those lacking market power and exit options. The
 *   divergence between claim and metrics is the measurement: does
 *   property-rights authority operate as natural law or as constructed
 *   protection of incumbent advantages?
 *
 * KEY AGENTS:
 *   - entrepreneurs: Primary beneficiaries (powerful/arbitrage) — operate under minimal regulatory burden, protected innovation returns
 *   - investors: Primary beneficiaries (powerful/arbitrage) — capital allocation unconstrained by solidarity-based redistribution
 *   - high_autonomy_individuals: Beneficiaries (moderate/mobile) — exercise dignity through exit and choice in competitive markets
 *   - workers_in_monopsony_markets: Primary targets (powerless/trapped) — face concentrated employer power, no collective remedy
 *   - communities_facing_coordination_failures: Targets (organized/identity_locked) — experience externalities without legitimated political response
 *   - individuals_lacking_market_power: Targets (powerless/constrained) — formal exit rights without substantive capacity
 *   - magisterial_authority: Excluded (institutional/analytical) — interpretive authority explicitly rejected by the reading
 *   - democratic_publics: Excluded (organized/constrained) — collective mandates delegitimated as coercion
 *   - political_economists: Observers (analytical/analytical) — test empirical premises about exit options and market structure
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(ai_governance_legitimacy__market_libertarian_reading, 0.25).
domain_priors:suppression_score(ai_governance_legitimacy__market_libertarian_reading, 0.18).
domain_priors:theater_ratio(ai_governance_legitimacy__market_libertarian_reading, 0.12).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, extractiveness, 0.25).
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 0.18).
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 0.12).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, accessibility_collapse, 0.78).
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, resistance, 0.42).

% --- Constraint claim ---
narrative_ontology:constraint_claim(ai_governance_legitimacy__market_libertarian_reading, mountain).
narrative_ontology:human_readable(ai_governance_legitimacy__market_libertarian_reading, "Market Libertarian Reading of AI Governance Legitimacy").
narrative_ontology:topic_domain(ai_governance_legitimacy__market_libertarian_reading, "theological_ethics/technology_governance/political_theology").

domain_priors:emerges_naturally(ai_governance_legitimacy__market_libertarian_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(ai_governance_legitimacy__market_libertarian_reading, '3432bcef-e498-42e1-808a-e03dc039b594').
narrative_ontology:cs_kernel_codification('3432bcef-e498-42e1-808a-e03dc039b594', distributed).
narrative_ontology:cs_authority_grounding('3432bcef-e498-42e1-808a-e03dc039b594', practice).
narrative_ontology:cs_interpretation_layer_present('3432bcef-e498-42e1-808a-e03dc039b594').
narrative_ontology:cs_reading_relation('3432bcef-e498-42e1-808a-e03dc039b594', ai_governance_legitimacy__magisterial_subsidiarity_reading, forecloses).
narrative_ontology:cs_reading_relation('3432bcef-e498-42e1-808a-e03dc039b594', ai_governance_legitimacy__technocratic_optimization_reading, coexists_with).
narrative_ontology:cs_reading_relation('3432bcef-e498-42e1-808a-e03dc039b594', ai_governance_legitimacy__democratic_pluralist_reading, forecloses).
narrative_ontology:cs_axiom('3432bcef-e498-42e1-808a-e03dc039b594', foundational, property_rights_pre_political).
narrative_ontology:cs_axiom_status(property_rights_pre_political, holdable).
narrative_ontology:cs_axiom_grounding('3432bcef-e498-42e1-808a-e03dc039b594', property_rights_pre_political, deontological).
narrative_ontology:cs_axiom('3432bcef-e498-42e1-808a-e03dc039b594', foundational, solidarity_demands_illegitimate_coercion).
narrative_ontology:cs_axiom_status(solidarity_demands_illegitimate_coercion, holdable).
narrative_ontology:cs_axiom_grounding('3432bcef-e498-42e1-808a-e03dc039b594', solidarity_demands_illegitimate_coercion, deontological).
narrative_ontology:cs_axiom('3432bcef-e498-42e1-808a-e03dc039b594', secondary, exit_constitutes_dignity_protection).
narrative_ontology:cs_axiom_status(exit_constitutes_dignity_protection, holdable).
narrative_ontology:cs_axiom_grounding('3432bcef-e498-42e1-808a-e03dc039b594', exit_constitutes_dignity_protection, instrumental).
narrative_ontology:cs_reference_frame('3432bcef-e498-42e1-808a-e03dc039b594', lockean_natural_rights_framework).
narrative_ontology:cs_drift_state('3432bcef-e498-42e1-808a-e03dc039b594', ai_era_market_concentration, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('3432bcef-e498-42e1-808a-e03dc039b594', '').
narrative_ontology:cs_kernel_id(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__market_libertarian_reading, entrepreneurs).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__market_libertarian_reading, investors).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__market_libertarian_reading, high_autonomy_individuals).
narrative_ontology:constraint_victim(ai_governance_legitimacy__market_libertarian_reading, workers_in_monopsony_markets).
narrative_ontology:constraint_victim(ai_governance_legitimacy__market_libertarian_reading, communities_facing_coordination_failures).
narrative_ontology:constraint_victim(ai_governance_legitimacy__market_libertarian_reading, individuals_lacking_market_power).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Operate AI ventures under minimal regulatory burden. Build and deploy systems according to market demand signals rather than collective mandates. Exit to favorable jurisdictions when local regulation tightens. The constraint protects their freedom to innovate by treating regulatory intervention as presumptively illegitimate unless grounded in property rights or voluntary contract.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, entrepreneurs, beneficiary,
    powerful, biographical, arbitrage, global).

% Allocate capital to AI ventures with confidence that returns will not be expropriated through retrospective regulation or solidarity-based redistribution. The constraint's property-rights foundation protects accumulated gains and limits claims that collective welfare overrides contractual rights. Can exit to jurisdictions with stronger property protections.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, investors, beneficiary,
    powerful, biographical, arbitrage, global).

% Possess marketable skills, financial reserves, and social capital enabling navigation between competing AI systems and jurisdictions. Exercise dignity through exit and voice in competitive markets. Benefit from innovation unconstrained by collective mandates, bearing costs through choice rather than imposed solidarity.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, high_autonomy_individuals, beneficiary,
    moderate, biographical, mobile, national).

% Face concentrated employer power in AI-transformed labor markets with limited alternatives. Cannot credibly exit when algorithmic management intensifies or wages compress. The constraint treats their situation as a voluntary exchange outcome rather than a coordination failure requiring collective remedy, leaving them dependent on employer forbearance rather than political protection.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, workers_in_monopsony_markets, payer,
    powerless, immediate, trapped, local).

% Experience AI deployment's negative externalities—surveillance infrastructure, algorithmic discrimination, labor displacement—without mechanisms for collective response. The constraint delegitimates political coordination to address shared harms, framing solidarity-based interventions as coercion. Cannot exit their geographic or cultural community to escape impacts.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, communities_facing_coordination_failures, payer,
    organized, generational, identity_locked, local).

% Lack resources to exit harmful AI systems or negotiate favorable terms. Experience algorithmic systems as unavoidable infrastructure (credit scoring, employment screening, benefits administration) while the constraint denies political authority to impose transparency or accountability requirements. Dignity protection through exit is formal rather than substantive.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, individuals_lacking_market_power, payer,
    powerless, biographical, constrained, national).

% Claims interpretive authority over technology's moral implications through Catholic Social Doctrine. The constraint explicitly rejects this authority by treating property rights as pre-political and solidarity demands as illegitimate. Would assert that economic freedom must be subordinated to common good as defined through tradition and authoritative interpretation.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, magisterial_authority, excluded,
    institutional, civilizational, analytical, global).

% Seek to impose collective standards on AI development through legislative process. The constraint treats such mandates as presumptively illegitimate coercion unless they protect property rights or enforce voluntary contracts. Their voice is excluded from the legitimacy framework itself, which locates authority in market exchange rather than democratic deliberation.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, democratic_publics, excluded,
    organized, generational, constrained, national).

% Analyze whether the constraint's empirical premises hold: whether exit options remain meaningful under AI-era market concentration, whether property rights assignments are pre-political or constructed, whether coordination failures justify collective intervention. Provide evidence on monopsony power, externalities, and distributional outcomes that test the reading's foundational claims.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, political_economists, observer,
    analytical, biographical, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Coordinates investment and innovation by establishing property rights in AI systems and their outputs as the authoritative allocation mechanism, solving disputes through contract law and private arbitration rather than political processes.
% TRANSFER_FUNCTION: Transfers authority over AI governance from democratic publics and religious/ethical traditions to individual property holders and market participants. Blocks redistribution of AI-generated gains through solidarity-based claims.
% ABSENT_VOICES: Magisterial authority interpreting Catholic Social Doctrine and democratic publics seeking collective AI governance standards are structurally excluded. They would assert that property rights are not pre-political and that solidarity is not coercion but rather fulfillment of human dignity in community.
% DISAPPEARANCE_RATIONALE: The reading's defenders would argue that without property-rights foundations, AI innovation would collapse under political rent-seeking and no stable investment framework would exist (world_rearranges toward stagnation). Critics would argue that property rights themselves are political constructs and the reading merely defends existing distributions; alternative governance frameworks would emerge through democratic or magisterial processes (world_rearranges toward different allocations). The magisterial reading explicitly contests the pre-political status claim.
% FOUNDING_PROBLEM: In the reading's account: preventing political expropriation of innovation gains and protecting innovators from retrospective collective mandates. The subsidiarity principle is invoked to support decentralization while rejecting solidarity-based redistribution as coercion.
% FOUNDING_PROBLEM_CORROBORATION: Entrepreneurs and investors attest the problem remains live, citing regulatory uncertainty and political demands for algorithmic accountability. Political economists and magisterial commentators attest that the framing inverts the actual problem: coordination failures and power asymmetries require collective response, not protection from it. The contested status reflects the kernel's central dispute over whether property rights are discovered or constructed.
narrative_ontology:disappearance_verdict(ai_governance_legitimacy__market_libertarian_reading, contested).
narrative_ontology:founding_problem_status(ai_governance_legitimacy__market_libertarian_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(ai_governance_legitimacy__market_libertarian_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(ai_governance_legitimacy__market_libertarian_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(ai_governance_legitimacy__market_libertarian_reading_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, ExtMetricName, E),
    domain_priors:suppression_score(ai_governance_legitimacy__market_libertarian_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(ai_governance_legitimacy__market_libertarian_reading),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(ai_governance_legitimacy__market_libertarian_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is low (0.25) because the reading operates primarily through enabling rather than directly extracting—it protects gains accruing to market winners but does not itself collect rents. Modest extraction appears in blocked alternatives: communities and workers bearing externalities cannot invoke collective remedy, and political processes are delegitimated. Suppression is minimal (0.18) because the constraint relies on philosophical authority and contract enforcement rather than active coercion—those with market power experience it as enabling freedom, while those without experience it as naturalized disadvantage. Theater ratio is low (0.12) because the reading's ideological work is genuine rather than performative—it authentically asserts property rights as pre-political. Accessibility collapse is high (0.78) for those who accept property rights as foundational but moderate overall because sibling readings remain live. Resistance is substantial (0.42) from magisterial and democratic traditions contesting the pre-political claim. The measurement series shows gradual extraction accumulation as market concentration grows and exit options narrow under AI-era dynamics.
 *
 * PERSPECTIVAL GAP:
 *   The beneficiary seats (entrepreneurs, investors, high-autonomy individuals) should experience this as genuine coordination—property rights enabling innovation and voluntary exchange. The target seats (trapped workers, coordination-failure communities, powerless individuals) should experience extraction—blocked alternatives and naturalized disadvantage. The excluded seats (magisterial authority, democratic publics) contest the framework's legitimacy itself rather than their position within it. The observer seat tests whether the reading's empirical premises hold under AI-era market concentration. The engine computes these divergences from the structural data; the claimed mountain status versus measured modest extraction is exactly the gap false-summit detection exists to flag.
 *
 * DIRECTIONALITY LOGIC:
 *   Entrepreneurs and investors are structural beneficiaries with arbitrage-grade exit—low directionality toward subsidy/protection. High-autonomy individuals benefit from unconstrained innovation with mobile exit—slightly higher directionality but still beneficiary-side. Workers in monopsony markets are full targets: powerless, trapped, bearing costs without remedy—high directionality toward extraction. Communities facing coordination failures are targets with identity-locked exit—the constraint treats their situation as legitimate market outcome rather than collective problem. Individuals lacking market power are targets with constrained exit—formal rights without substantive capacity. The divergence in effective extraction by seat reflects how property-rights framing advantages those with existing market position while naturalizing disadvantages of those without.
 *
 * MANDATROPHY ANALYSIS:
 *   The founding problem as stated—preventing political expropriation of innovation—frames collective governance as threat rather than coordination. This inverts standard mandatrophy: the coordination function claimed is protection from solidarity, treating market outcomes as pre-political. The contested founding_problem_status reflects the kernel's central dispute: whether property rights are discovered moral facts or constructed institutional arrangements. If constructed, the reading operates as protection of incumbent advantages (tangled_rope or snare) rather than discovered law (mountain). The measurement trajectory shows extraction accumulating as market concentration grows—exactly the pattern where protection-from-solidarity increasingly serves concentration-of-power.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    property_rights_pre_political_status,
    'Are property rights in AI systems pre-political moral facts discovered through reason, or constructed institutional arrangements requiring ongoing political justification?',
    'Philosophical analysis of whether any allocation of entitlements can be derived from non-political premises, combined with historical evidence on how property regimes actually emerge and are maintained through political processes.',
    'If property rights are constructed rather than discovered, the reading operates as protection of incumbent advantages rather than natural law—reclassifies from mountain to tangled_rope or snare. The beneficiary/victim structure becomes a political outcome rather than a neutral coordination mechanism.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(property_rights_pre_political_status, conceptual, 'Whether the constraint''s mountain claim is coherent or category error.').

omega_variable(
    exit_options_substantive_vs_formal,
    'Under AI-era market concentration, do exit options remain substantively available to workers and consumers, or only formally available while practically foreclosed?',
    'Empirical analysis of labor market concentration, switching costs in AI systems, and geographic mobility under algorithmic infrastructure. Natural experiments from jurisdictions with different antitrust enforcement.',
    'If exit is formal but not substantive, the reading''s dignity-protection claim fails and extraction from trapped parties is substantially higher than measured. Would support reclassification toward snare for powerless seats even if mountain holds for powerful seats.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(exit_options_substantive_vs_formal, empirical, 'Whether the constraint''s enabling function operates equitably across power differentials.').

omega_variable(
    coordination_failure_legitimacy_boundary,
    'What boundary distinguishes legitimate collective response to coordination failures from illegitimate coercion, and who has authority to draw that boundary?',
    'Comparison of how different readings handle canonical coordination failures (externalities, public goods, information asymmetries). Analysis of whether the boundary is discovered through reason or negotiated through political process.',
    'If no principled boundary exists and the reading simply privileges existing distributions, it operates as constructed protection rather than discovered principle. Affects whether solidarity demands are actually coercive or whether the reading''s anti-solidarity stance itself extracts from communities.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(coordination_failure_legitimacy_boundary, conceptual, 'Whether the reading''s core distinction between coordination and coercion is coherent.').

omega_variable(
    false_summit_beneficiary_structure,
    'The reading claims mountain status while declaring beneficiaries (entrepreneurs, investors, high-autonomy individuals). Is this a genuine natural law that happens to benefit some parties, or a constructed constraint using natural-law rhetoric to protect incumbent advantages?',
    'Cross-kernel comparison: do other readings of the same kernel with different beneficiary structures also claim mountain status? Historical analysis: did the property-rights framework emerge from philosophical discovery or from political settlements among powerful actors?',
    'False summit detection: a mountain with identifiable beneficiaries whose advantages depend on the constraint''s enforcement is the signature of naturalized extraction. If mountain certification fails on FSM grounds, reclassifies to tangled_rope (coordination + asymmetric extraction) with beneficiaries as partial captors.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(false_summit_beneficiary_structure, conceptual, 'Whether beneficiary presence on a claimed mountain indicates false summit.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(ai_governance_legitimacy__market_libertarian_reading, 0, 20).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(ai_g_tr_t0, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 0, 0.08).
narrative_ontology:measurement(ai_g_tr_t5, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 5, 0.09).
narrative_ontology:measurement(ai_g_tr_t10, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 10, 0.1).
narrative_ontology:measurement(ai_g_tr_t15, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 15, 0.11).
narrative_ontology:measurement(ai_g_tr_t20, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 20, 0.12).

% Extraction over time
narrative_ontology:measurement(ai_g_be_t0, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 0, 0.18).
narrative_ontology:measurement(ai_g_be_t5, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 5, 0.2).
narrative_ontology:measurement(ai_g_be_t10, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 10, 0.22).
narrative_ontology:measurement(ai_g_be_t15, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 15, 0.24).
narrative_ontology:measurement(ai_g_be_t20, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 20, 0.25).

% Suppression requirement over time
narrative_ontology:measurement(ai_g_su_t0, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 0, 0.12).
narrative_ontology:measurement(ai_g_su_t5, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 5, 0.14).
narrative_ontology:measurement(ai_g_su_t10, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 10, 0.16).
narrative_ontology:measurement(ai_g_su_t15, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 15, 0.17).
narrative_ontology:measurement(ai_g_su_t20, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 20, 0.18).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:affects_constraint(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy__magisterial_subsidiarity_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy__technocratic_optimization_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy__democratic_pluralist_reading).

% DUAL FORMULATION NOTE:
% Part of the ai_governance_legitimacy constraint family. This reading treats property rights as pre-political and solidarity as coercion, producing low measured extraction because it operates through enabling rather than direct collection. The magisterial_subsidiarity_reading treats the same AI governance question through Catholic Social Doctrine with moderate extraction from solidarity enforcement. The technocratic_optimization_reading subordinates ethical constraints to efficiency with higher extraction from optimization pressure. The democratic_pluralist_reading grounds legitimacy in deliberative consent rather than property rights or tradition. All four readings address the same governance domain with substantially different epsilon values and beneficiary/victim structures, linked through network.affects_constraints.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
