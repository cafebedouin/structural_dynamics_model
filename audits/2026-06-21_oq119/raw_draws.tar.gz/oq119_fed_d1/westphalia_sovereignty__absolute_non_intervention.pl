% ============================================================================
% CONSTRAINT STORY: westphalia_sovereignty__absolute_non_intervention
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-01-15
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_westphalia_sovereignty__absolute_non_intervention, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: westphalia_sovereignty__absolute_non_intervention
 *   human_readable: Westphalian Sovereignty: Absolute Non-Intervention Principle
 *   domain: international_law/political_theory
 *
 * SUMMARY:
 *   The Westphalian principle of absolute territorial sovereignty emerged
 *   from the 1648 Peace of Westphalia, establishing non-intervention in
 *   domestic affairs as foundational rule of international order. This
 *   reading treats sovereignty as categorical inviolability—a state's
 *   territorial authority is complete and interference is per se illegitimate
 *   regardless of internal conduct. Regime actors invoke it as natural
 *   principle of statehood; human rights advocates and intervention-capable
 *   democracies increasingly contest it as constructed shield for atrocity.
 *   The constraint is CLAIMED as mountain (the regime framing: sovereignty
 *   simply is inviolability, discovered not constructed) while the metrics
 *   describe substantially extractive operation with identifiable
 *   beneficiaries and victims—the engine measures that divergence.
 *
 * KEY AGENTS:
 *   - authoritarian_state_elites: Primary beneficiary (institutional/constrained) — exercise unaccountable domestic control under sovereignty shield
 *   - regime_security_apparatus: Agenda-setter + beneficiary (institutional/constrained) — enforce internal order with diplomatic protection from external accountability
 *   - sovereignty_doctrine_scholars: Secondary beneficiary (moderate/mobile) — provide legitimating theoretical framework
 *   - populations_under_authoritarian_rule: Primary victim (powerless/trapped) — bear costs of unaccountable governance, categorically excluded from international protection
 *   - ethnic_minorities_facing_persecution: Primary victim (powerless/trapped) — experience violence bounded as internal matter
 *   - democratic_states_with_intervention_capacity: Excluded actor (institutional/mobile) — possess capacity but face legitimacy barrier
 *   - international_human_rights_monitors: Observer (moderate/mobile) — document atrocities without structural remedy
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(westphalia_sovereignty__absolute_non_intervention, 0.68).
domain_priors:suppression_score(westphalia_sovereignty__absolute_non_intervention, 0.79).
domain_priors:theater_ratio(westphalia_sovereignty__absolute_non_intervention, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, extractiveness, 0.68).
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 0.79).
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, accessibility_collapse, 0.71).
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, resistance, 0.64).

% --- Constraint claim ---
narrative_ontology:constraint_claim(westphalia_sovereignty__absolute_non_intervention, mountain).
narrative_ontology:human_readable(westphalia_sovereignty__absolute_non_intervention, "Westphalian Sovereignty: Absolute Non-Intervention Principle").
narrative_ontology:topic_domain(westphalia_sovereignty__absolute_non_intervention, "international_law/political_theory").

domain_priors:requires_active_enforcement(westphalia_sovereignty__absolute_non_intervention).
domain_priors:emerges_naturally(westphalia_sovereignty__absolute_non_intervention).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(westphalia_sovereignty__absolute_non_intervention, 'e73612fd-b227-4a7d-a3a8-72d0929dc1b7').
narrative_ontology:cs_kernel_codification('e73612fd-b227-4a7d-a3a8-72d0929dc1b7', formalized).
narrative_ontology:cs_authority_grounding('e73612fd-b227-4a7d-a3a8-72d0929dc1b7', lineage).
narrative_ontology:cs_interpretation_layer_present('e73612fd-b227-4a7d-a3a8-72d0929dc1b7').
narrative_ontology:cs_reading_relation('e73612fd-b227-4a7d-a3a8-72d0929dc1b7', westphalia_sovereignty__conditional_responsibility, coexists_with).
narrative_ontology:cs_reading_relation('e73612fd-b227-4a7d-a3a8-72d0929dc1b7', westphalia_sovereignty__graded_sovereignty, coexists_with).
narrative_ontology:cs_axiom('e73612fd-b227-4a7d-a3a8-72d0929dc1b7', foundational, territorial_authority_categorical_inviolability).
narrative_ontology:cs_axiom_status(territorial_authority_categorical_inviolability, holdable).
narrative_ontology:cs_axiom_grounding('e73612fd-b227-4a7d-a3a8-72d0929dc1b7', territorial_authority_categorical_inviolability, conventional).
narrative_ontology:cs_axiom('e73612fd-b227-4a7d-a3a8-72d0929dc1b7', foundational, internal_affairs_absolute_immunity).
narrative_ontology:cs_axiom_status(internal_affairs_absolute_immunity, holdable).
narrative_ontology:cs_axiom_grounding('e73612fd-b227-4a7d-a3a8-72d0929dc1b7', internal_affairs_absolute_immunity, conventional).
narrative_ontology:cs_reference_frame('e73612fd-b227-4a7d-a3a8-72d0929dc1b7', westphalian_settlement_1648).
narrative_ontology:cs_drift_state('e73612fd-b227-4a7d-a3a8-72d0929dc1b7', post_humanitarian_intervention_era, gap(axiom_overriding, substantial, false)).
narrative_ontology:cs_created_at('e73612fd-b227-4a7d-a3a8-72d0929dc1b7', '').
narrative_ontology:cs_kernel_id(westphalia_sovereignty__absolute_non_intervention, westphalia_sovereignty).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__absolute_non_intervention, authoritarian_state_elites).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__absolute_non_intervention, regime_security_apparatus).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__absolute_non_intervention, sovereignty_doctrine_scholars).
narrative_ontology:constraint_victim(westphalia_sovereignty__absolute_non_intervention, populations_under_authoritarian_rule).
narrative_ontology:constraint_victim(westphalia_sovereignty__absolute_non_intervention, ethnic_minorities_facing_persecution).
narrative_ontology:constraint_victim(westphalia_sovereignty__absolute_non_intervention, internally_displaced_populations).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__absolute_non_intervention, territorial_integrity_doctrine).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__absolute_non_intervention, state_consent_requirement_for_intervention).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Exercise domestic control without external accountability. The categorical non-intervention principle shields internal repression from international scrutiny or sanction. They invoke sovereignty as natural law while depending on active diplomatic defense of the principle in international forums. Their authority persists only so long as external powers accept the inviolability frame.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, authoritarian_state_elites, beneficiary,
    institutional, biographical, constrained, national).

% Enforce domestic order and suppress dissent, operating under the protective umbrella of territorial inviolability. They frame security operations as internal matters categorically exempt from external judgment. Their operational latitude depends on the diplomatic apparatus maintaining the sovereignty shield at international level.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, regime_security_apparatus, agenda_setter,
    institutional, biographical, constrained, national).
narrative_ontology:stakeholder_secondary_role(westphalia_sovereignty__absolute_non_intervention, regime_security_apparatus, beneficiary).

% Advance legal-theoretical frameworks treating sovereignty as foundational principle of international order. Their scholarly authority and institutional positions benefit from framing non-intervention as structural necessity rather than contested political choice. They provide legitimating vocabulary that regime actors deploy.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, sovereignty_doctrine_scholars, beneficiary,
    moderate, generational, mobile, global).

% Bear the direct costs of unaccountable domestic governance. The categorical sovereignty barrier prevents external assistance or intervention even when facing systematic repression. Their appeals for international protection are categorized as interference in internal affairs. Exit is typically criminalized or physically impossible.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, populations_under_authoritarian_rule, payer,
    powerless, biographical, trapped, national).

% Experience targeted violence that the sovereignty principle classifies as domestic concern. Their persecution is jurisdictionally bounded—neighboring states that might intervene are deterred by the inviolability norm. They exist in a sovereignty-created vacuum where internal violence meets external non-responsibility.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, ethnic_minorities_facing_persecution, payer,
    powerless, biographical, trapped, local).

% Flee internal violence but remain within territorial boundaries where the sovereign retains categorical authority. International humanitarian access is subject to state consent, which the sovereignty principle treats as absolute. Their displacement is internally contained by the same barrier that blocks external intervention.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, internally_displaced_populations, payer,
    powerless, immediate, trapped, regional).

% Possess military and diplomatic capacity to intervene in humanitarian crises but are constrained by the categorical sovereignty norm. They face a legitimacy dilemma: intervention violates foundational international law principle even when addressing mass atrocities. Some navigate through Security Council authorization, but categorical non-intervention reading treats even that as conceptual violation.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, democratic_states_with_intervention_capacity, excluded,
    institutional, generational, mobile, global).

% Document internal atrocities and issue reports, but lack enforcement capacity under categorical sovereignty framework. They witness the sovereignty principle operating as shield for regime violence. Their reporting creates diplomatic pressure but no structural remedy—categorical inviolability blocks translation of documentation into accountability.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, international_human_rights_monitors, observer,
    moderate, generational, mobile, global).

% Argue for conditional sovereignty framework where protection failures trigger international responsibility. Under the categorical non-intervention reading, their entire project is conceptually foreclosed—sovereignty simply is inviolability, not a status earned through responsible governance. They operate as external critics with no purchase on the principle itself.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, responsibility_to_protect_advocates, excluded,
    moderate, generational, mobile, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes predictable boundaries between state jurisdictions in an anarchic international system, preventing cascade of interventions and stabilizing territorial order through mutual recognition of exclusive domestic authority.
% TRANSFER_FUNCTION: Transfers unconstrained governance authority to state elites while transferring costs of unaccountable rule to domestic populations who cannot appeal beyond territorial boundaries. Moves diplomatic protection from vulnerable populations to regime stability.
% ABSENT_VOICES: Populations facing state-sponsored violence, ethnic cleansing, or systematic repression have no voice in the sovereignty framework that categorizes their situation as internal matter. Democratic states contemplating humanitarian intervention are excluded from legitimacy discourse by the categorical principle. Post-colonial states that experienced sovereignty violations historically but now wield it as shield are present but their historical position as victims is structurally erased.
% DISAPPEARANCE_RATIONALE: If categorical non-intervention vanished overnight, humanitarian interventions would proceed in ongoing atrocity situations, regime security apparatuses would lose diplomatic shield and face external accountability mechanisms, internally trapped populations would gain access to international protection, and the international legal order would reorganize around conditional or graded sovereignty frameworks already present as competing readings.
% FOUNDING_PROBLEM: The post-Thirty Years War European state system faced catastrophic instability from religious and dynastic intervention wars. Mutual recognition of territorial inviolability was constructed as solution to intervention cascade and confessional warfare—each sovereign determines domestic religious settlement without external interference.
% FOUNDING_PROBLEM_CORROBORATION: The founding problem of religious-confessional intervention wars has been structurally resolved for centuries—modern interventions concern humanitarian crises and regime stability, not competing dynastic or religious claims. Historical consensus from outside beneficiary states confirms the Westphalian settlement addressed early modern Europe's specific state formation crisis. Contemporary international relations scholars across ideological positions attest that religious warfare is not the live threat categorical sovereignty claims to prevent. The principle persists while its founding justification is historically extinguished.
narrative_ontology:disappearance_verdict(westphalia_sovereignty__absolute_non_intervention, world_rearranges).
narrative_ontology:founding_problem_status(westphalia_sovereignty__absolute_non_intervention, dead).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(westphalia_sovereignty__absolute_non_intervention, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(westphalia_sovereignty__absolute_non_intervention, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(westphalia_sovereignty__absolute_non_intervention_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(westphalia_sovereignty__absolute_non_intervention, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, ExtMetricName, E),
    domain_priors:suppression_score(westphalia_sovereignty__absolute_non_intervention, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(westphalia_sovereignty__absolute_non_intervention),
    narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(westphalia_sovereignty__absolute_non_intervention_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is high (0.68 at interval end) because the principle shields regime violence from accountability while transferring governance costs to trapped populations. Suppression is higher still (0.79) because maintaining categorical inviolability requires active diplomatic defense against humanitarian intervention norms—the principle does not self-enforce but depends on regime coordination in international forums. Theater ratio is moderate (0.42): sovereignty rhetoric about preventing intervention cascade has real coordination function in some contexts, but growing share of invocations defend atrocity from scrutiny rather than prevent destabilizing wars. The founding problem (religious intervention wars) is historically dead but the principle persists, suggesting extraction has detached from coordination. Accessibility collapse is high (0.71) because once framed as foundational principle of international order, alternatives appear systemically disruptive. Resistance is substantial (0.64) from human rights networks, intervention advocates, and populations experiencing the protection gap—the principle is defended, not passively accepted.
 *
 * PERSPECTIVAL GAP:
 *   The beneficiary and victim seats should compute radically different types from the same structural data. From the authoritarian elite position (low d, collects authority) the constraint appears as coordination—mutual non-intervention prevents destabilizing intervention cascade and they genuinely benefit from the stability. From the trapped population position (high d, bears violence with no exit) the identical structure operates as snare—sovereignty is the enforcement mechanism that blocks international protection. The observer seats (human rights monitors, democratic states) see the extraction but face suppression in challenging it. The engine computes this seat divergence; the authored mountain claim reflects the regime framing, not adjudication.
 *
 * DIRECTIONALITY LOGIC:
 *   Authoritarian elites and security apparatus are structural beneficiaries (collect unaccountable domestic authority, shield from external costs—d near beneficiary end, low χ). Populations under authoritarian rule, ethnic minorities, and displaced populations are primary targets (bear violence costs, categorically trapped by sovereignty barrier—d at target end, high χ). Sovereignty scholars are indirect beneficiaries (professional authority from naturalizing the principle—moderate d). Democratic intervention-capable states sit between excluded and constrained: they have capacity but face legitimacy costs under categorical sovereignty (moderate-high d). The divergence is structural: from the regime seat sovereignty operates as genuine coordination; from the trapped population seat the same principle operates as enforced extraction preventing exit or appeal.
 *
 * MANDATROPHY ANALYSIS:
 *   This is candidate mandatrophy: the founding problem (preventing religious intervention wars in early modern Europe) is dead, but the principle persists as shield for contemporary authoritarian governance. The coordination function was real at founding—mutual recognition of territorial boundaries solved genuine intervention cascade problem. That function has substantially shifted: modern sovereignty invocations primarily defend regime prerogatives rather than prevent confessional warfare. The shift is masked by treating sovereignty as timeless natural principle rather than historically contingent institutional arrangement. Classification distinguishes genuine coordination (preventing intervention cascade where it remains risk) from extraction (blocking accountability for internal atrocities). The R5 mismatch is diagnostic: founding_problem_status is dead while disappearance_verdict is world_rearranges—the constraint's persistence requires active diplomatic defense, not passive natural-law acceptance.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    natural_law_vs_regime_construction,
    'Is categorical non-intervention a natural principle of international order (regime framing), or a constructed norm that benefits authoritarian elites by blocking accountability (human rights framing)?',
    'Historical-genealogical analysis showing sovereignty principle emerged from specific state formation crisis and was contested throughout, plus cross-national analysis of which actors invoke categorical sovereignty and under what circumstances. If invocation correlates with authoritarian governance and atrocity-shielding rather than with genuine intervention-cascade prevention, constructedness is established.',
    'If natural law, the mountain classification holds and victims'' costs are unfortunate necessity of international order. If constructed norm benefiting identifiable actors, classification shifts toward tangled_rope or snare depending on whether coordination function remains genuine. The omega documents the core ambiguity the FSM machinery exists to measure.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(natural_law_vs_regime_construction, conceptual, 'Whether categorical sovereignty is discovered natural principle or constructed regime shield').

omega_variable(
    coordination_extraction_separability,
    'Is the coordination function (preventing intervention cascade) structurally separable from the extraction function (shielding regime atrocity), or does maintaining international stability require accepting unaccountable domestic governance?',
    'Natural experiment from emergence of responsibility-to-protect norm and humanitarian interventions: if international order remains stable while interventions proceed in atrocity cases, the functions are separable. If every intervention attempt destabilizes broader state system, they are coupled.',
    'If separable, the sovereignty principle is tangled_rope (genuine coordination + asymmetric extraction). If inseparable, some measured extraction is inherent cost of coordination and classification remains contested between rope and mountain.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(coordination_extraction_separability, empirical, 'Whether stability-coordination requires atrocity-shielding or functions are separable').

omega_variable(
    intervention_cascade_live_vs_theoretical,
    'Is intervention cascade a live structural risk in contemporary international system, or a theoretical concern invoked to justify sovereignty barrier after the founding problem became historically extinct?',
    'Analysis of actual intervention patterns post-Cold War: do humanitarian interventions trigger reciprocal interventions and destabilize regional order, or do they remain bounded? Track whether sovereignty-invoking states face genuine intervention threat or deploy principle strategically to block accountability.',
    'If cascade risk is live, categorical sovereignty retains genuine coordination function. If cascade is theoretical while actual pattern is selective intervention in atrocity cases, the founding function is dead and principle persists as extraction. Determines whether mandatrophy condition is met.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(intervention_cascade_live_vs_theoretical, empirical, 'Whether intervention cascade remains live risk or is extinct founding problem').

omega_variable(
    committer_frame_kernel_disambiguation,
    'Does ''Westphalian sovereignty'' denote one constraint measured from different angles, or three distinct constraints (absolute, conditional, graded) that different parties instantiate from contested kernel?',
    'Structural analysis per ε-invariance principle: if ε is stable across observational methods, one constraint; if different sovereignty readings yield different beneficiary/victim structures and different extraction levels, multiple constraints. The beneficiary structure here (regime elites shielded from accountability) differs fundamentally from conditional_responsibility reading (populations gain protection, regimes lose shield), confirming distinct constraints.',
    'Confirms decomposition into constraint family was structurally necessary, not arbitrary framing choice. Each reading gets its own story with its own ε because they instantiate different arrangements with different parties. Links the readings via network.affects_constraints for contamination analysis.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(committer_frame_kernel_disambiguation, conceptual, 'Whether sovereignty kernel decomposes into distinct constraints or is single constraint with observer variation').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(westphalia_sovereignty__absolute_non_intervention, 0, 40).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(west_tr_t0, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 0, 0.25).
narrative_ontology:measurement(west_tr_t8, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 8, 0.29).
narrative_ontology:measurement(west_tr_t16, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 16, 0.34).
narrative_ontology:measurement(west_tr_t24, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 24, 0.38).
narrative_ontology:measurement(west_tr_t32, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 32, 0.4).
narrative_ontology:measurement(west_tr_t40, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 40, 0.42).

% Extraction over time
narrative_ontology:measurement(west_be_t0, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 0, 0.48).
narrative_ontology:measurement(west_be_t8, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 8, 0.53).
narrative_ontology:measurement(west_be_t16, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 16, 0.59).
narrative_ontology:measurement(west_be_t24, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 24, 0.64).
narrative_ontology:measurement(west_be_t32, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 32, 0.66).
narrative_ontology:measurement(west_be_t40, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 40, 0.68).

% Suppression requirement over time
narrative_ontology:measurement(west_su_t0, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 0, 0.58).
narrative_ontology:measurement(west_su_t8, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 8, 0.64).
narrative_ontology:measurement(west_su_t16, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 16, 0.69).
narrative_ontology:measurement(west_su_t24, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 24, 0.73).
narrative_ontology:measurement(west_su_t32, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 32, 0.76).
narrative_ontology:measurement(west_su_t40, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 40, 0.79).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(westphalia_sovereignty__absolute_non_intervention, global_infrastructure).
narrative_ontology:affects_constraint(westphalia_sovereignty__absolute_non_intervention, westphalia_sovereignty__conditional_responsibility).
narrative_ontology:affects_constraint(westphalia_sovereignty__absolute_non_intervention, westphalia_sovereignty__graded_sovereignty).

% DUAL FORMULATION NOTE:
% This story is the absolute_non_intervention reading of the westphalia_sovereignty kernel. The kernel decomposes into three constraints because the readings have fundamentally different ε values and beneficiary/victim structures. This reading treats sovereignty as categorical (ε ~0.68, benefits regime elites, blocks accountability); conditional_responsibility reading treats sovereignty as earned through protection (lower ε, shifts benefits toward populations); graded_sovereignty reading treats authority as scalar capacity (ε varies by state capacity level). The decomposition follows ε-invariance principle: changing from absolute to conditional sovereignty reading changes who benefits and who pays, not merely how we measure the same constraint. All three stories link via affects_constraints for family analysis.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
