% ============================================================================
% CONSTRAINT STORY: woman_category__intersex_accommodation_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_woman_category__intersex_accommodation_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: woman_category__intersex_accommodation_reading
 *   human_readable: Woman Category as Non-Binary Biological Spectrum (Intersex Accommodation Reading)
 *   domain: political_philosophy/law/social_policy/bioethics
 *
 * SUMMARY:
 *   This constraint is the INTERSEX ACCOMMODATION READING of the contested
 *   'woman category' kernel. It holds that biological sex exists on a
 *   spectrum rather than as a binary, and that the category 'woman' must
 *   include people with typical female biology plus intersex variations that
 *   do not cleanly fit the male category. The reading is framed as a
 *   mountain: biological variation is presented as a natural fact, and
 *   accommodating that fact in policy is treated as alignment with reality
 *   rather than social construction. The constraint's victims are intersex
 *   people facing binary gatekeeping in sports eligibility, identity
 *   documents, and sex-segregated institutional spaces. Beneficiaries include
 *   intersex advocacy organizations (whose core empirical claim is
 *   vindicated) and medical researchers studying sex variation (whose work
 *   gains legitimacy). The claim/metric gap is deliberate: the constraint is
 *   CLAIMED as mountain (a natural accommodation of biological reality) while
 *   the metrics describe moderate extraction and suppression because binary
 *   enforcement machinery must be actively dismantled and intersex people
 *   still face gatekeeping in practice.
 *
 * KEY AGENTS:
 *   - intersex_athletes_in_binary_categories: Primary target (powerless/identity_locked) — face eligibility testing, hormone suppression, or categorical exclusion under binary sports rules
 *   - people_with_ambiguous_biology_facing_administrative_gatekeeping: Primary target (powerless/identity_locked) — navigate bureaucratic friction in identity documents, medical systems, and sex-segregated spaces
 *   - intersex_advocacy_organizations: Primary beneficiary (organized/mobile) — this reading vindicates their empirical claim and strengthens their policy leverage
 *   - medical_researchers_studying_sex_variation: Secondary beneficiary (institutional/mobile) — their research gains legitimacy when policy treats sex as spectrum
 *   - binary_category_administrators: Excluded (institutional/constrained) — operational frameworks depend on binary simplicity; this reading subordinates that need to biological fact
 *   - bioethicists_and_philosophers_of_science: Analytical observer — evaluate whether the reading accurately represents biology and what trade-offs it creates
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(woman_category__intersex_accommodation_reading, 0.28).
domain_priors:suppression_score(woman_category__intersex_accommodation_reading, 0.42).
domain_priors:theater_ratio(woman_category__intersex_accommodation_reading, 0.15).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, extractiveness, 0.28).
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, suppression_requirement, 0.42).
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, theater_ratio, 0.15).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, accessibility_collapse, 0.72).
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, resistance, 0.58).

% --- Constraint claim ---
narrative_ontology:constraint_claim(woman_category__intersex_accommodation_reading, mountain).
narrative_ontology:human_readable(woman_category__intersex_accommodation_reading, "Woman Category as Non-Binary Biological Spectrum (Intersex Accommodation Reading)").
narrative_ontology:topic_domain(woman_category__intersex_accommodation_reading, "political_philosophy/law/social_policy/bioethics").

domain_priors:emerges_naturally(woman_category__intersex_accommodation_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(woman_category__intersex_accommodation_reading, '2eb2f1ea-e101-4197-88b3-2a3d8245161c').
narrative_ontology:cs_kernel_codification('2eb2f1ea-e101-4197-88b3-2a3d8245161c', distributed).
narrative_ontology:cs_authority_grounding('2eb2f1ea-e101-4197-88b3-2a3d8245161c', expertise).
narrative_ontology:cs_interpretation_layer_present('2eb2f1ea-e101-4197-88b3-2a3d8245161c').
narrative_ontology:cs_reading_relation('2eb2f1ea-e101-4197-88b3-2a3d8245161c', woman_category__sex_biology_reading, influences).
narrative_ontology:cs_reading_relation('2eb2f1ea-e101-4197-88b3-2a3d8245161c', woman_category__gender_identity_reading, coexists_with).
narrative_ontology:cs_axiom('2eb2f1ea-e101-4197-88b3-2a3d8245161c', foundational, biological_sex_exists_on_measurable_spectrum).
narrative_ontology:cs_axiom_status(biological_sex_exists_on_measurable_spectrum, holdable).
narrative_ontology:cs_axiom_grounding('2eb2f1ea-e101-4197-88b3-2a3d8245161c', biological_sex_exists_on_measurable_spectrum, empirically_contingent).
narrative_ontology:cs_axiom('2eb2f1ea-e101-4197-88b3-2a3d8245161c', foundational, category_membership_must_accommodate_biological_reality).
narrative_ontology:cs_axiom_status(category_membership_must_accommodate_biological_reality, holdable).
narrative_ontology:cs_axiom_grounding('2eb2f1ea-e101-4197-88b3-2a3d8245161c', category_membership_must_accommodate_biological_reality, deontological).
narrative_ontology:cs_reference_frame('2eb2f1ea-e101-4197-88b3-2a3d8245161c', binary_administrative_default).
narrative_ontology:cs_drift_state('2eb2f1ea-e101-4197-88b3-2a3d8245161c', post_medical_consensus_on_sex_variation, gap(axiom_overriding, substantial, false)).
narrative_ontology:cs_created_at('2eb2f1ea-e101-4197-88b3-2a3d8245161c', '').
narrative_ontology:cs_kernel_id(woman_category__intersex_accommodation_reading, woman_category).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(woman_category__intersex_accommodation_reading, intersex_advocacy_organizations).
narrative_ontology:constraint_beneficiary(woman_category__intersex_accommodation_reading, medical_researchers_studying_sex_variation).
narrative_ontology:constraint_victim(woman_category__intersex_accommodation_reading, intersex_athletes_in_binary_categories).
narrative_ontology:constraint_victim(woman_category__intersex_accommodation_reading, people_with_ambiguous_biology_facing_administrative_gatekeeping).
narrative_ontology:constraint_vindicates(woman_category__intersex_accommodation_reading, biological_sex_exists_on_spectrum).
narrative_ontology:constraint_vindicates(woman_category__intersex_accommodation_reading, binary_categories_require_arbitrary_thresholds).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Athletes with intersex variations (elevated testosterone, ambiguous chromosomal patterns, or atypical reproductive anatomy) who compete in elite women's sports face eligibility challenges under rules that treat biological sex as binary. They must undergo invasive medical testing, hormone suppression therapy, or categorical exclusion to continue competing. Exit means abandoning their sport or competing in a category that does not match their lived identity and physical development.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, intersex_athletes_in_binary_categories, payer,
    powerless, biographical, identity_locked, global).

% People with intersex variations navigating identity documents, medical systems, and institutional sex-segregated spaces (prisons, bathrooms, shelters) where binary sex categories are administratively enforced. They face bureaucratic friction, demands for medical documentation, forced categorization that does not match their biology or identity, and sometimes exclusion from services. Their biology does not fit the binary; the constraint forces them into one box or the other anyway.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, people_with_ambiguous_biology_facing_administrative_gatekeeping, payer,
    powerless, biographical, identity_locked, global).

% Organizations advocating for legal recognition of intersex variations, medical ethics reform (ending non-consensual infant surgeries), and policy frameworks that acknowledge biological sex diversity. This reading vindicates their core claim: sex is not binary, and policy must accommodate the spectrum. They gain rhetorical and epistemic leverage when institutions adopt this framing.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, intersex_advocacy_organizations, beneficiary,
    organized, generational, mobile, global).

% Researchers in endocrinology, genetics, and developmental biology whose work documents the empirical reality of sex variation (chromosomal mosaicism, androgen insensitivity, congenital adrenal hyperplasia, 5-alpha reductase deficiency). This reading treats their findings as foundational rather than exceptional. Adoption of this framing increases funding, institutional support, and public legitimacy for their research programs.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, medical_researchers_studying_sex_variation, beneficiary,
    institutional, generational, mobile, global).

% Sports governing bodies, prison systems, and administrative agencies that rely on binary sex categories for operational simplicity, fairness adjudication, or safety protocols. This reading forces them to either adopt complex eligibility criteria (testing, thresholds, case-by-case review) or abandon binary enforcement altogether. They are structurally excluded from the conversation because the reading treats their operational need for binary simplicity as secondary to biological reality.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, binary_category_administrators, excluded,
    institutional, biographical, constrained, global).

% Scholars analyzing category construction, the relationship between biological fact and social policy, and the ethical implications of forced categorization. They evaluate whether this reading accurately represents biological reality, whether it resolves the coordination problems the other readings address, and what trade-offs it creates for policy and institutional design.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, bioethicists_and_philosophers_of_science, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a category definition that aligns with observed biological variation: acknowledges that some people have anatomy, chromosomes, or hormone profiles that do not fit the male/female binary, and includes them in the 'woman' category when their biology is closer to typical female or explicitly non-male.
% TRANSFER_FUNCTION: Shifts epistemic authority from binary administrative convenience to biological reality as documented by medical science. Moves institutional legitimacy toward frameworks that accommodate spectrum rather than forcing binary classification. Transfers the burden of complexity from individuals (who must fit themselves into ill-fitting boxes) to institutions (who must design accommodating criteria).
% ABSENT_VOICES: Binary category administrators (sports bodies, correctional institutions, administrative agencies) whose operational frameworks depend on binary simplicity are structurally excluded: this reading treats their need for clean boundaries as subordinate to biological fact. People with unambiguous binary biology who experience competitive disadvantage from inclusion of intersex athletes are also not centered in this framing.
% DISAPPEARANCE_RATIONALE: Advocates of this reading would say the world rearranges: without acknowledgment of biological spectrum, intersex people face ongoing coerced categorization, medical gatekeeping, and competitive exclusion. Critics would say the underlying biological variation remains whether or not policy acknowledges it; the constraint is not a natural fact but a social choice about how to categorize that variation.
% FOUNDING_PROBLEM: Binary sex categories in law, sports, and administration systematically misclassify people whose biology does not fit the male/female divide, forcing them into invasive testing, medical intervention, or exclusion despite having bodies that developed in non-binary ways.
% FOUNDING_PROBLEM_CORROBORATION: Medical researchers studying Differences of Sex Development (DSD) document the empirical existence of intersex variations and the harms of binary enforcement. Bioethicists outside the intersex advocacy community attest that binary categorization creates real administrative and ethical problems for people with atypical biology. The International Olympic Committee and World Athletics policy revisions (2019–2023) acknowledge the problem and attempt solutions, though the solutions remain contested.
narrative_ontology:disappearance_verdict(woman_category__intersex_accommodation_reading, contested).
narrative_ontology:founding_problem_status(woman_category__intersex_accommodation_reading, live).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(woman_category__intersex_accommodation_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(woman_category__intersex_accommodation_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(woman_category__intersex_accommodation_reading_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, ExtMetricName, E),
    domain_priors:suppression_score(woman_category__intersex_accommodation_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(woman_category__intersex_accommodation_reading),
    narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(woman_category__intersex_accommodation_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is moderate (0.28 at interval end) because the constraint imposes real costs on binary category administrators (must adopt complex eligibility criteria or abandon binary enforcement) and on intersex people themselves (invasive testing, gatekeeping, and forced medical documentation persist even under accommodating frameworks). The extraction is rising slightly over time as administrative machinery resists spectrum-based frameworks. Suppression is moderate (0.42) because binary enforcement actively excludes people whose biology does not fit, and accommodating frameworks still require medical verification (a different suppression mechanism than outright exclusion but still coercive). Theater is low (0.15): the biological variation this reading names is empirically real, and most policy activity around it is functional rather than performative, though some institutional rhetoric about 'inclusion' operates as cover for continued binary gatekeeping. Accessibility collapse is high (0.72): once intersex variations are understood as biologically real, treating sex as strictly binary becomes harder to defend empirically, though policy resistance remains. Resistance is moderate-high (0.58): binary frameworks push back because accommodating spectrum increases operational complexity.
 *
 * PERSPECTIVAL GAP:
 *   The beneficiary seats (advocacy organizations, researchers) experience this constraint as genuine coordination with biological reality: acknowledging spectrum reduces harm and aligns policy with empirical fact. The victim seats (intersex individuals facing gatekeeping) experience it as ongoing extraction: even under accommodating frameworks, they must undergo invasive testing and forced categorization. The excluded seat (binary administrators) experiences it as imposed complexity that disrupts operational simplicity. The engine computes this divergence from the structural data; the authored claim does not adjudicate it.
 *
 * DIRECTIONALITY LOGIC:
 *   Intersex athletes and people with ambiguous biology are structural targets (identity_locked exit, powerless, facing active gatekeeping — d toward the target end). Intersex advocacy organizations are beneficiaries (the reading vindicates their core claim — d toward the beneficiary end). Medical researchers are secondary beneficiaries (legitimacy and funding increase under spectrum-acknowledging frameworks — d toward beneficiary end). Binary category administrators are excluded rather than coordinated (their operational need is subordinated; they would experience this as extractive). The engine should compute divergent seat classifications: from the intersex advocacy and research seats, this operates as coordination (acknowledging reality); from the intersex individual and binary administrator seats, it operates as extractive enforcement or exclusion.
 *
 * MANDATROPHY ANALYSIS:
 *   The Mandatrophy question: is this a natural accommodation of biological fact (mountain), or is the 'spectrum' framing itself a contested social construction that benefits some actors over others (tangled rope or snare)? The intersex accommodation reading treats biological sex variation as empirically real and binary categorization as the constructed overlay. Critics of this reading argue that 'spectrum' conflates distinct intersex conditions with different etiologies and that the policy accommodation is driven by ideological commitments rather than biological necessity. The constraint is claimed as mountain because the reading holds that sex variation is a fact of nature; the metrics describe moderate extraction because the policy frameworks built on this claim still impose costs and because resistance from binary enforcement machinery is substantial.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    natural_law_vs_ideological_construction,
    'Is the ''biological sex as spectrum'' framing an accurate representation of natural variation, or is it a contested ideological construction that benefits intersex advocacy organizations and their epistemic allies?',
    'Longitudinal analysis of medical research consensus on sex variation (do endocrinologists and geneticists converge on spectrum language or maintain distinct categorical descriptions of specific conditions?); cross-jurisdictional policy outcomes (do accommodating frameworks reduce measurable harm to intersex people, or do they introduce new gatekeeping mechanisms?); analysis of which actors gain institutional leverage when spectrum language is adopted.',
    'If the spectrum framing is empirically accurate and reducibly represents natural variation, the constraint is a genuine mountain and resistance to it is motivated reasoning. If the framing is contested or conflates distinct conditions for rhetorical effect, the constraint is a tangled rope or snare where intersex advocacy organizations extract epistemic rents by claiming natural-law status for a particular social construction.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(natural_law_vs_ideological_construction, empirical, 'Whether ''sex as spectrum'' is natural fact or contested framing.').

omega_variable(
    kernel_reading_disambiguation,
    'This constraint is the intersex_accommodation_reading of the woman_category kernel. The sex_biology_reading treats woman as binary (XX chromosomes, female reproductive anatomy); the gender_identity_reading treats woman as self-identification regardless of biology. What structural elements would change under the sibling readings?',
    'Under sex_biology_reading: intersex people with ambiguous biology are excluded from the woman category entirely or forced into the male category (different victim set, higher suppression). Under gender_identity_reading: intersex variations become irrelevant to category membership; anyone who identifies as a woman is included regardless of chromosomes or anatomy (different coordination function, possibly lower extraction for intersex people who identify as women but higher contestation from those who prioritize biological boundaries).',
    'The sibling readings produce different victim sets, different beneficiary structures, and different extractiveness profiles. This reading sits between the siblings: it acknowledges biological reality (like sex_biology_reading) but rejects strict binary enforcement (like gender_identity_reading). The disagreement location is: what grounds category membership — chromosomes and anatomy (sex_biology), internal identity (gender_identity), or spectrum of biological variation (this reading).',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(kernel_reading_disambiguation, conceptual, 'Sibling reading disambiguation for the woman_category kernel.').

omega_variable(
    elite_sports_performance_boundary,
    'In elite sports, intersex athletes with elevated testosterone or atypical hormone profiles may have performance advantages over athletes with typical female biology. Is excluding or hormonally suppressing these athletes a legitimate fairness mechanism (extraction justified by coordination need) or discriminatory gatekeeping (extraction without genuine coordination function)?',
    'Longitudinal performance data analysis comparing intersex athletes to typical female athletes across multiple sports; bioethical analysis of whether ''fairness'' in sports requires normalizing all competitors to typical female hormone profiles or whether natural variation (including intersex variation) is part of competitive diversity; legal analysis of human rights obligations versus sports governing body autonomy.',
    'If performance advantages are empirically substantial and fairness requires normalization, then eligibility restrictions are coordination (though costly to intersex athletes). If advantages are overstated or if natural variation is treated as legitimate in other contexts (height, muscle fiber distribution), then restrictions are pure extraction. This omega is specific to the elite sports domain; in most other policy domains (identity documents, healthcare, sex-segregated spaces), the performance-advantage question does not arise and extraction is lower.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(elite_sports_performance_boundary, empirical, 'Whether elite sports eligibility restrictions on intersex athletes are coordination or extraction.').

omega_variable(
    administrative_spectrum_operationalization,
    'If policy frameworks adopt this reading, how do institutions operationalize ''spectrum'' without creating new gatekeeping mechanisms? Does acknowledging spectrum reduce extraction on intersex people, or does it shift extraction from binary exclusion to invasive medical verification?',
    'Policy implementation analysis in jurisdictions that have adopted spectrum-acknowledging frameworks (Germany''s third gender marker, some U.S. states'' non-binary ID options): measure bureaucratic friction, medical documentation requirements, and subjective reports from intersex people navigating these systems. Compare to binary-enforcement jurisdictions and to self-identification frameworks.',
    'If spectrum-acknowledging frameworks reduce gatekeeping and allow intersex people to navigate institutions with less friction, the constraint is closer to genuine coordination. If they replace binary exclusion with medical verification requirements (proving intersex status to access the accommodating category), extraction persists at similar levels but shifts mechanism. This determines whether the constraint''s moderate extractiveness is transitional (legacy of binary enforcement) or intrinsic to spectrum-based frameworks.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(administrative_spectrum_operationalization, empirical, 'Whether operationalizing spectrum reduces or shifts extraction.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(woman_category__intersex_accommodation_reading, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(woma_tr_t0, woman_category__intersex_accommodation_reading, theater_ratio, 0, 0.1).
narrative_ontology:measurement(woma_tr_t5, woman_category__intersex_accommodation_reading, theater_ratio, 5, 0.11).
narrative_ontology:measurement(woma_tr_t10, woman_category__intersex_accommodation_reading, theater_ratio, 10, 0.12).
narrative_ontology:measurement(woma_tr_t15, woman_category__intersex_accommodation_reading, theater_ratio, 15, 0.13).
narrative_ontology:measurement(woma_tr_t20, woman_category__intersex_accommodation_reading, theater_ratio, 20, 0.14).
narrative_ontology:measurement(woma_tr_t25, woman_category__intersex_accommodation_reading, theater_ratio, 25, 0.15).

% Extraction over time
narrative_ontology:measurement(woma_be_t0, woman_category__intersex_accommodation_reading, base_extractiveness, 0, 0.18).
narrative_ontology:measurement(woma_be_t5, woman_category__intersex_accommodation_reading, base_extractiveness, 5, 0.21).
narrative_ontology:measurement(woma_be_t10, woman_category__intersex_accommodation_reading, base_extractiveness, 10, 0.23).
narrative_ontology:measurement(woma_be_t15, woman_category__intersex_accommodation_reading, base_extractiveness, 15, 0.25).
narrative_ontology:measurement(woma_be_t20, woman_category__intersex_accommodation_reading, base_extractiveness, 20, 0.27).
narrative_ontology:measurement(woma_be_t25, woman_category__intersex_accommodation_reading, base_extractiveness, 25, 0.28).

% Suppression requirement over time
narrative_ontology:measurement(woma_su_t0, woman_category__intersex_accommodation_reading, suppression_requirement, 0, 0.32).
narrative_ontology:measurement(woma_su_t5, woman_category__intersex_accommodation_reading, suppression_requirement, 5, 0.35).
narrative_ontology:measurement(woma_su_t10, woman_category__intersex_accommodation_reading, suppression_requirement, 10, 0.37).
narrative_ontology:measurement(woma_su_t15, woman_category__intersex_accommodation_reading, suppression_requirement, 15, 0.39).
narrative_ontology:measurement(woma_su_t20, woman_category__intersex_accommodation_reading, suppression_requirement, 20, 0.41).
narrative_ontology:measurement(woma_su_t25, woman_category__intersex_accommodation_reading, suppression_requirement, 25, 0.42).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(woman_category__intersex_accommodation_reading, identity_coordination).
narrative_ontology:affects_constraint(woman_category__intersex_accommodation_reading, woman_category__sex_biology_reading).
narrative_ontology:affects_constraint(woman_category__intersex_accommodation_reading, woman_category__gender_identity_reading).

% DUAL FORMULATION NOTE:
% This constraint is the intersex_accommodation_reading of the woman_category kernel. It sits in a three-way constraint family with sex_biology_reading (binary chromosomal definition) and gender_identity_reading (self-identification regardless of biology). All three readings address the same coordination problem (how to define category membership for legal, administrative, and institutional purposes) but produce different victim sets, beneficiary structures, and extractiveness profiles. The ε values differ substantially: sex_biology_reading has low ε in most domains but high ε for trans women and some intersex people who are excluded; gender_identity_reading has low ε for people whose identity matches their biology but higher ε for institutions required to accommodate self-identification; this reading (intersex_accommodation) has low ε in most policy domains (small population affected) but high ε in elite sports (performance-advantage boundary cases). Each reading is linked via network.affects_constraints to acknowledge the constraint family structure.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
