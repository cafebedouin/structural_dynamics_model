% ============================================================================
% CONSTRAINT STORY: waitangi_sovereignty_allocation__crown_sovereignty_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_waitangi_sovereignty_allocation__crown_sovereignty_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: waitangi_sovereignty_allocation__crown_sovereignty_reading
 *   human_readable: Crown Sovereignty Reading of Treaty of Waitangi Article I
 *   domain: constitutional_law/indigenous_rights/post_colonial_governance
 *
 * SUMMARY:
 *   The Treaty of Waitangi (1840) exists in two textual versions with
 *   materially different sovereignty allocations. The English Article I
 *   states Māori chiefs ceded 'absolutely and without reservation all the
 *   rights and powers of Sovereignty' to the Crown. This reading treats the
 *   English text as authoritative and the Māori text as non-binding
 *   translation, establishing Westminster parliamentary supremacy as
 *   constitutional foundation. The CLAIMED type is mountain (asserted as
 *   foundational constitutional reality), while the AUTHORED metrics describe
 *   substantially extractive, actively enforced operation with identified
 *   beneficiaries — the engine measures this divergence as potential false
 *   summit. The measurement interval spans 1840-2024 (184 years).
 *
 * KEY AGENTS:
 *   - crown_parliament: Agenda-setter (institutional/arbitrage) — exercises plenary legislative authority under sovereignty claim
 *   - settler_colonial_establishment: Beneficiary (powerful/mobile) — receives property security and political dominance
 *   - extractive_resource_industries: Beneficiary (powerful/mobile) — operates under Crown licenses over contested lands
 *   - iwi_hapu_collectives: Payer (organized/identity_locked) — bear land alienation and subordination costs
 *   - individual_maori_landholders: Payer (powerless/identity_locked) — face compulsory acquisition and jurisdictional loss
 *   - waitangi_tribunal: Observer (institutional/constrained) — investigates breaches within Crown framework
 *   - constitutional_law_scholars: Observer (analytical/analytical) — analyze textual contestability
 *   - international_human_rights_bodies: Excluded (institutional/constrained) — alternative legitimacy framework systematically excluded
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(waitangi_sovereignty_allocation__crown_sovereignty_reading, 0.78).
domain_priors:suppression_score(waitangi_sovereignty_allocation__crown_sovereignty_reading, 0.82).
domain_priors:theater_ratio(waitangi_sovereignty_allocation__crown_sovereignty_reading, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, extractiveness, 0.78).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 0.82).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, accessibility_collapse, 0.71).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, resistance, 0.74).

% --- Constraint claim ---
narrative_ontology:constraint_claim(waitangi_sovereignty_allocation__crown_sovereignty_reading, mountain).
narrative_ontology:human_readable(waitangi_sovereignty_allocation__crown_sovereignty_reading, "Crown Sovereignty Reading of Treaty of Waitangi Article I").
narrative_ontology:topic_domain(waitangi_sovereignty_allocation__crown_sovereignty_reading, "constitutional_law/indigenous_rights/post_colonial_governance").

domain_priors:requires_active_enforcement(waitangi_sovereignty_allocation__crown_sovereignty_reading).
domain_priors:emerges_naturally(waitangi_sovereignty_allocation__crown_sovereignty_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(waitangi_sovereignty_allocation__crown_sovereignty_reading, '40a47fb6-839b-4714-9ff9-e36f8e593813').
narrative_ontology:cs_kernel_codification('40a47fb6-839b-4714-9ff9-e36f8e593813', fixed_text).
narrative_ontology:cs_authority_grounding('40a47fb6-839b-4714-9ff9-e36f8e593813', extraction).
narrative_ontology:cs_interpretation_layer_present('40a47fb6-839b-4714-9ff9-e36f8e593813').
narrative_ontology:cs_reading_relation('40a47fb6-839b-4714-9ff9-e36f8e593813', waitangi_sovereignty_allocation__partnership_reading, coexists_with).
narrative_ontology:cs_reading_relation('40a47fb6-839b-4714-9ff9-e36f8e593813', waitangi_sovereignty_allocation__rangatiratanga_reading, forecloses).
narrative_ontology:cs_axiom('40a47fb6-839b-4714-9ff9-e36f8e593813', foundational, english_text_exclusive_authority).
narrative_ontology:cs_axiom_status(english_text_exclusive_authority, holdable).
narrative_ontology:cs_axiom_grounding('40a47fb6-839b-4714-9ff9-e36f8e593813', english_text_exclusive_authority, conventional).
narrative_ontology:cs_axiom('40a47fb6-839b-4714-9ff9-e36f8e593813', foundational, sovereignty_indivisible_unitary).
narrative_ontology:cs_axiom_status(sovereignty_indivisible_unitary, holdable).
narrative_ontology:cs_axiom_grounding('40a47fb6-839b-4714-9ff9-e36f8e593813', sovereignty_indivisible_unitary, deontological).
narrative_ontology:cs_axiom('40a47fb6-839b-4714-9ff9-e36f8e593813', secondary, parliamentary_supremacy_absolute).
narrative_ontology:cs_axiom_status(parliamentary_supremacy_absolute, holdable).
narrative_ontology:cs_axiom_grounding('40a47fb6-839b-4714-9ff9-e36f8e593813', parliamentary_supremacy_absolute, conventional).
narrative_ontology:cs_reference_frame('40a47fb6-839b-4714-9ff9-e36f8e593813', english_text_complete_cession).
narrative_ontology:cs_drift_state('40a47fb6-839b-4714-9ff9-e36f8e593813', post_waitangi_tribunal_era, gap(authority_erosion, substantial, false)).
narrative_ontology:cs_created_at('40a47fb6-839b-4714-9ff9-e36f8e593813', '').
narrative_ontology:cs_kernel_id(waitangi_sovereignty_allocation__crown_sovereignty_reading, waitangi_sovereignty_allocation).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__crown_sovereignty_reading, crown_parliament).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__crown_sovereignty_reading, settler_colonial_establishment).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__crown_sovereignty_reading, extractive_resource_industries).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__crown_sovereignty_reading, iwi_hapu_collectives).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__crown_sovereignty_reading, individual_maori_landholders).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__crown_sovereignty_reading, parliamentary_supremacy_doctrine).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__crown_sovereignty_reading, unified_sovereignty_principle).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__crown_sovereignty_reading, discovery_doctrine).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Exercises plenary legislative authority over all New Zealand territory and subjects under this reading. Claims English Article I text as legal foundation for unilateral resource allocation, constitutional amendment, and sovereignty enforcement. Enacts legislation affecting Māori interests without consent requirement. Views Treaty as historical founding document now superseded by Westminster constitutional conventions.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, crown_parliament, agenda_setter,
    institutional, generational, arbitrage, national).

% Receives secure property rights, investment certainty, and political dominance through Crown sovereignty framework. Benefits from land alienation mechanisms enabled by unilateral parliamentary authority. Economic and political institutions organized around certainty of Crown title and legislative supremacy over competing claims.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, settler_colonial_establishment, beneficiary,
    powerful, generational, mobile, national).

% Operates under parliamentary licenses for resource extraction on lands with contested ownership. Crown sovereignty reading provides legal foundation for granting extraction rights over Māori objections. Alternative readings would require consent mechanisms that materially constrain operation.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, extractive_resource_industries, beneficiary,
    powerful, biographical, mobile, national).

% Bear costs of land alienation, resource extraction, and legislative subordination under this reading. Assert Māori text retained rangatiratanga making this reading a unilateral Crown imposition. Exit means abandoning territorial and cultural claims that constitute collective identity. Coalition power through pan-Māori organizing and Waitangi Tribunal proceedings provides partial structural leverage but operates within Crown legal framework.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, iwi_hapu_collectives, payer,
    organized, generational, identity_locked, regional).

% Face compulsory acquisition, resource loss, and jurisdictional subordination as individual rights-bearers under Crown sovereignty regime. Māori Land Court operates under parliamentary statute; no customary law remedy exists outside Crown framework. Identity fusion through whakapapa and whenua means exit from territorial relationship is psychologically and culturally devastating, not merely costly.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, individual_maori_landholders, payer,
    powerless, biographical, identity_locked, local).

% Investigates Crown breaches of Treaty principles under statutory mandate. Produces non-binding recommendations requiring parliamentary implementation. Recognizes contestability of sovereignty allocation but operates within constitutional framework that grants it no power to alter parliamentary supremacy itself.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, waitangi_tribunal, observer,
    institutional, generational, constrained, national).

% Analyze textual divergence between English and Māori Treaty versions, comparative post-colonial jurisprudence, and legitimacy of unilateral sovereignty claims. Document structural asymmetry where one party's language version becomes binding while other party's version is treated as non-authoritative translation.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, constitutional_law_scholars, observer,
    analytical, generational, analytical, global).

% UN Declaration on Rights of Indigenous Peoples and related mechanisms recognize indigenous sovereignty and self-determination claims. Would provide alternative legitimacy framework undermining Crown sovereignty reading but systematically excluded from domestic constitutional adjudication by parliamentary supremacy doctrine itself.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, international_human_rights_bodies, excluded,
    institutional, generational, constrained, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes unified sovereign authority for territory-wide governance, legal certainty for property rights, and single legislative framework for resource allocation and dispute resolution.
% TRANSFER_FUNCTION: Transfers plenary legislative authority from contested dual-sovereignty arrangement to Crown Parliament, moving territorial control, resource allocation power, and jurisdictional supremacy from Māori collectives to settler-colonial state apparatus.
% ABSENT_VOICES: International indigenous rights frameworks and alternative constitutional traditions recognizing indigenous sovereignty are structurally excluded from domestic adjudication by the sovereignty allocation this reading establishes. The sibling readings' proponents within Māori communities are present but subordinated within Crown legal framework.
% DISAPPEARANCE_RATIONALE: If Crown sovereignty reading vanished overnight, constitutional authority would immediately become contested between competing sovereignty claims. Resource allocation would require negotiated consent mechanisms. Property rights regime and parliamentary legislative power over Māori affairs would lose legal foundation. State apparatus would face legitimacy crisis requiring constitutional reconstitution.
% FOUNDING_PROBLEM: Competing sovereignty claims and absence of unified territorial authority in 1840 created legal uncertainty for land transactions, resource rights, and dispute resolution between Māori and settler populations.
% FOUNDING_PROBLEM_CORROBORATION: Crown institutions and settler establishment attest sovereignty uncertainty was resolved by Treaty cession. Māori collectives, Waitangi Tribunal findings, and post-colonial legal scholars attest sovereignty contest remains unresolved because Māori text demonstrates no cession occurred. Corroboration from outside benefiting parties: comparative indigenous rights jurisprudence and textual analysis by international law scholars supports contested-sovereignty reading over complete-cession claim.
narrative_ontology:disappearance_verdict(waitangi_sovereignty_allocation__crown_sovereignty_reading, world_rearranges).
narrative_ontology:founding_problem_status(waitangi_sovereignty_allocation__crown_sovereignty_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(waitangi_sovereignty_allocation__crown_sovereignty_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(waitangi_sovereignty_allocation__crown_sovereignty_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(waitangi_sovereignty_allocation__crown_sovereignty_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(waitangi_sovereignty_allocation__crown_sovereignty_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, ExtMetricName, E),
    domain_priors:suppression_score(waitangi_sovereignty_allocation__crown_sovereignty_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(waitangi_sovereignty_allocation__crown_sovereignty_reading),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(waitangi_sovereignty_allocation__crown_sovereignty_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is high (0.78 at interval end) because sovereignty allocation transfers plenary territorial control and resource authority from one party to another party's unilateral legislative discretion. Suppression is higher (0.82) because persistence requires active enforcement against competing sovereignty claims and exits from Crown jurisdiction. Theater ratio rises over interval (0.05 to 0.28) as Treaty commemoration and partnership rhetoric increase while underlying sovereignty allocation remains unchanged. Accessibility collapse (0.71) reflects that within Crown legal framework no remedy exists outside parliamentary supremacy, though resistance (0.74) remains substantial through Waitangi Tribunal, iwi organizing, and international human rights advocacy. Measurements track 184-year trajectory showing extraction accumulation as land alienation mechanisms matured and suppression intensification as competing sovereignty claims were progressively foreclosed within domestic law.
 *
 * PERSPECTIVAL GAP:
 *   From Crown Parliament seat, this arrangement is constitutional bedrock — the foundational sovereignty allocation that enables all subsequent governance. From iwi/hapū collective seat, the same structure operates as imposed extraction riding on textual manipulation where one party's language version was treated as authoritative over the other's. The gap is not reconcilable through metric adjustment because it reflects genuine structural position divergence. Engine computes per-seat classifications from these structural relationships; the mountain claim documents Crown institutional framing while metrics document operation as experienced by subordinated parties.
 *
 * DIRECTIONALITY LOGIC:
 *   Crown Parliament is structural beneficiary (receives sovereignty, sets all rules, d→0.15). Settler establishment and extractive industries are downstream beneficiaries (receive certainty and access under Crown framework, d→0.25-0.35). Iwi and hapū collectives are primary targets with identity-locked exit (bear extraction, cannot exit territorial relationship that constitutes identity, d→0.85). Individual Māori landholders are powerless identity-locked targets (d→0.95). Observers sit outside extraction flow at analytical positions.
 *
 * MANDATROPHY ANALYSIS:
 *   The founding problem (competing sovereignty claims creating legal uncertainty) was genuine in 1840 contact context. The Crown sovereignty solution established unified authority but did so through unilateral textual interpretation that subordinated Māori sovereignty claims rather than resolving them through negotiated arrangement. Status is contested because Māori collectives attest sovereignty was never ceded in their authoritative text version, supported by linguistic analysis showing 'kawanatanga' (governorship over settlers) differs materially from 'sovereignty' (plenary territorial authority). The mandate-function gap appears where coordination need (unified governance framework) is met through extraction mechanism (unilateral sovereignty allocation) that systematically advantages one party. Alternative coordination paths (genuine power-sharing, federated authority, negotiated jurisdiction) were foreclosed by treating one textual version as binding.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    textual_authority_allocation,
    'When two contractual versions in different languages contain materially different sovereignty allocations, on what principle is one version treated as authoritative and the other as non-binding translation?',
    'Comparative treaty law analysis of how bilateral agreements with textual divergence are adjudicated internationally. Examination of whether authority allocation itself was negotiated or unilaterally asserted post-signing.',
    'If authority allocation principle is ''stronger party chooses'' rather than ''both versions binding'', the sovereignty claim rests on power assertion rather than contractual agreement, supporting snare classification over mountain. If treaty law principle is ''contra proferentem'' (ambiguity construed against drafter), Māori text would be authoritative.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(textual_authority_allocation, conceptual, 'Whether treating English text as authoritative over Māori text is grounded in legal principle or power assertion.').

omega_variable(
    cession_vs_governance_distinction,
    'Does Māori text ''kawanatanga'' (governorship) constitute same sovereignty transfer as English ''sovereignty'', or does linguistic evidence establish material distinction between governance-over-settlers and plenary-territorial-authority?',
    'Linguistic analysis of 1840s Māori usage of ''kawanatanga'' in other contexts, comparative analysis of how other Polynesian languages distinguish governance from sovereignty, examination of what Māori signatories understood they were agreeing to based on missionary explanations in Māori.',
    'If ''kawanatanga'' demonstrably means governance-over-settlers rather than territorial sovereignty, complete cession claim loses textual foundation in the version signed by Māori chiefs, and sovereignty allocation becomes contested rather than foundational. Supports reclassification from mountain to tangled_rope or snare.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(cession_vs_governance_distinction, empirical, 'Whether linguistic evidence supports complete sovereignty cession or more limited governance transfer in Māori text.').

omega_variable(
    naturalization_vs_construction,
    'Is Westminster parliamentary supremacy a natural feature of constitutional order that the Treaty discovered/recognized, or a constructed allocation that benefited identifiable parties and required active enforcement against competing claims?',
    'Historical analysis of whether sovereignty allocation could have been otherwise (federated authority, power-sharing, reserved Māori jurisdiction), examination of whose interests were served by unilateral allocation, and assessment of enforcement mechanisms required to suppress alternative sovereignty claims.',
    'If Crown sovereignty required identifying beneficiaries (settler property security, extraction industries, parliamentary power) and active suppression of alternatives rather than emerging naturally, the mountain claim is false summit. The omega itself is the FSM trigger — a mountain with declared beneficiaries that required enforcement to establish.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(naturalization_vs_construction, conceptual, 'Whether Crown sovereignty is discovered natural law or constructed arrangement benefiting identifiable parties.').

omega_variable(
    coalition_power_threshold,
    'At what threshold of pan-Māori organizing, Tribunal findings, and international human rights pressure does organized coalition power of iwi/hapū collectives shift from ''organized/identity_locked'' to higher structural leverage?',
    'Observable shifts in Crown legislative responses to Māori sovereignty claims, treaty settlement outcomes, and constitutional reform proposals. Measurement of whether collective organizing produces actual jurisdictional concessions or only compensatory mechanisms within unchanged sovereignty framework.',
    'If coalition power reaches threshold where Crown must negotiate rather than legislate unilaterally, suppression requirement decreases and classification shifts from extraction-heavy to contested-coordination. Current power classification at ''organized'' acknowledges coalition formation but notes identity-lock and subordination within Crown framework limit exit credibility.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(coalition_power_threshold, empirical, 'Whether Māori collective organizing has reached structural threshold to alter sovereignty allocation or operates within unchanged Crown supremacy framework.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(waitangi_sovereignty_allocation__crown_sovereignty_reading, 0, 184).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(wait_tr_t0, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 0, 0.05).
narrative_ontology:measurement_basis(wait_tr_t0, observed).
narrative_ontology:measurement(wait_tr_t30, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 30, 0.08).
narrative_ontology:measurement_basis(wait_tr_t30, observed).
narrative_ontology:measurement(wait_tr_t61, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 61, 0.12).
narrative_ontology:measurement_basis(wait_tr_t61, observed).
narrative_ontology:measurement(wait_tr_t92, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 92, 0.17).
narrative_ontology:measurement_basis(wait_tr_t92, observed).
narrative_ontology:measurement(wait_tr_t123, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 123, 0.22).
narrative_ontology:measurement_basis(wait_tr_t123, observed).
narrative_ontology:measurement(wait_tr_t154, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 154, 0.26).
narrative_ontology:measurement_basis(wait_tr_t154, observed).
narrative_ontology:measurement(wait_tr_t184, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 184, 0.28).
narrative_ontology:measurement_basis(wait_tr_t184, observed).

% Extraction over time
narrative_ontology:measurement(wait_be_t0, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 0, 0.45).
narrative_ontology:measurement_basis(wait_be_t0, observed).
narrative_ontology:measurement(wait_be_t30, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 30, 0.58).
narrative_ontology:measurement_basis(wait_be_t30, observed).
narrative_ontology:measurement(wait_be_t61, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 61, 0.69).
narrative_ontology:measurement_basis(wait_be_t61, observed).
narrative_ontology:measurement(wait_be_t92, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 92, 0.74).
narrative_ontology:measurement_basis(wait_be_t92, observed).
narrative_ontology:measurement(wait_be_t123, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 123, 0.76).
narrative_ontology:measurement_basis(wait_be_t123, observed).
narrative_ontology:measurement(wait_be_t154, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 154, 0.77).
narrative_ontology:measurement_basis(wait_be_t154, observed).
narrative_ontology:measurement(wait_be_t184, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 184, 0.78).
narrative_ontology:measurement_basis(wait_be_t184, observed).

% Suppression requirement over time
narrative_ontology:measurement(wait_su_t0, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 0, 0.55).
narrative_ontology:measurement_basis(wait_su_t0, observed).
narrative_ontology:measurement(wait_su_t30, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 30, 0.64).
narrative_ontology:measurement_basis(wait_su_t30, observed).
narrative_ontology:measurement(wait_su_t61, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 61, 0.71).
narrative_ontology:measurement_basis(wait_su_t61, observed).
narrative_ontology:measurement(wait_su_t92, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 92, 0.76).
narrative_ontology:measurement_basis(wait_su_t92, observed).
narrative_ontology:measurement(wait_su_t123, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 123, 0.79).
narrative_ontology:measurement_basis(wait_su_t123, observed).
narrative_ontology:measurement(wait_su_t154, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 154, 0.81).
narrative_ontology:measurement_basis(wait_su_t154, observed).
narrative_ontology:measurement(wait_su_t184, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 184, 0.82).
narrative_ontology:measurement_basis(wait_su_t184, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(waitangi_sovereignty_allocation__crown_sovereignty_reading, enforcement_mechanism).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__crown_sovereignty_reading, waitangi_sovereignty_allocation__partnership_reading).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__crown_sovereignty_reading, waitangi_sovereignty_allocation__rangatiratanga_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the waitangi_sovereignty_allocation kernel. The kernel decomposes into three readings with different sovereignty allocations and materially different ε values. crown_sovereignty_reading (this constraint): high extraction, English text authoritative, plenary Crown authority. partnership_reading: moderate extraction, ongoing consultation obligations, Treaty principles as constitutional constraint. rangatiratanga_reading: low extraction, Māori text authoritative, retained indigenous sovereignty with limited Crown governance over settlers. Decomposition follows ε-invariance principle: readings have different beneficiary/victim structures, different enforcement requirements, and different accessibility collapse profiles.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
