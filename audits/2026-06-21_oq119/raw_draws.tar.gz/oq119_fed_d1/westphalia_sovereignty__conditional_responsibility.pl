% ============================================================================
% CONSTRAINT STORY: westphalia_sovereignty__conditional_responsibility
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-13
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_westphalia_sovereignty__conditional_responsibility, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: westphalia_sovereignty__conditional_responsibility
 *   human_readable: Responsibility to Protect (R2P) Conditional Sovereignty
 *   domain: international_law/political_theory/state_systems
 *
 * SUMMARY:
 *   The Responsibility to Protect doctrine emerged after 1990s atrocities to
 *   establish that sovereignty is conditional on protecting populations from
 *   mass violence. This reading of Westphalian sovereignty holds that states
 *   forfeit territorial inviolability when they fail to prevent genocide,
 *   ethnic cleansing, war crimes, or crimes against humanity. The constraint
 *   is claimed as a natural moral principle (mountain)—that human rights
 *   obligations transcend state borders—but operates with identifiable
 *   beneficiaries who gain authority and geopolitical leverage from its
 *   enforcement. The claim/metric divergence is deliberate: the doctrine is
 *   presented as universal moral law while the metrics describe substantially
 *   extractive, selectively enforced operation.
 *
 * KEY AGENTS:
 *   - humanitarian_intervention_coalitions: Institutional agenda-setters (institutional/arbitrage) — invoke R2P to authorize military action, gain geopolitical footholds
 *   - un_security_council_permanent_members: Institutional beneficiaries (institutional/arbitrage) — control adjudication while remaining exempt from obligations
 *   - populations_under_atrocity_regimes: Powerless dual-role (powerless/trapped) — framed as beneficiaries but pay intervention costs
 *   - targeted_sovereign_states: Organized payers (organized/trapped) — lose sovereignty and face regime change
 *   - regional_powers_outside_coalitions: Institutional payers (institutional/constrained) — lose regional influence, face precedent erosion
 *   - international_law_scholars: Analytical observers — document selective enforcement asymmetries
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(westphalia_sovereignty__conditional_responsibility, 0.68).
domain_priors:suppression_score(westphalia_sovereignty__conditional_responsibility, 0.71).
domain_priors:theater_ratio(westphalia_sovereignty__conditional_responsibility, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, extractiveness, 0.68).
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, suppression_requirement, 0.71).
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, accessibility_collapse, 0.58).
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, resistance, 0.74).

% --- Constraint claim ---
narrative_ontology:constraint_claim(westphalia_sovereignty__conditional_responsibility, mountain).
narrative_ontology:human_readable(westphalia_sovereignty__conditional_responsibility, "Responsibility to Protect (R2P) Conditional Sovereignty").
narrative_ontology:topic_domain(westphalia_sovereignty__conditional_responsibility, "international_law/political_theory/state_systems").

domain_priors:requires_active_enforcement(westphalia_sovereignty__conditional_responsibility).
domain_priors:emerges_naturally(westphalia_sovereignty__conditional_responsibility).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(westphalia_sovereignty__conditional_responsibility, 'd472eda5-f238-4a37-a087-6cd82e974fe1').
narrative_ontology:cs_kernel_codification('d472eda5-f238-4a37-a087-6cd82e974fe1', distributed).
narrative_ontology:cs_authority_grounding('d472eda5-f238-4a37-a087-6cd82e974fe1', distributed).
narrative_ontology:cs_reading_relation('d472eda5-f238-4a37-a087-6cd82e974fe1', westphalia_sovereignty__absolute_non_intervention, forecloses).
narrative_ontology:cs_reading_relation('d472eda5-f238-4a37-a087-6cd82e974fe1', westphalia_sovereignty__graded_sovereignty, coexists_with).
narrative_ontology:cs_axiom('d472eda5-f238-4a37-a087-6cd82e974fe1', foundational, sovereignty_contingent_on_population_protection).
narrative_ontology:cs_axiom_status(sovereignty_contingent_on_population_protection, holdable).
narrative_ontology:cs_axiom_grounding('d472eda5-f238-4a37-a087-6cd82e974fe1', sovereignty_contingent_on_population_protection, deontological).
narrative_ontology:cs_axiom('d472eda5-f238-4a37-a087-6cd82e974fe1', secondary, international_community_humanitarian_authority).
narrative_ontology:cs_axiom_status(international_community_humanitarian_authority, holdable).
narrative_ontology:cs_axiom_grounding('d472eda5-f238-4a37-a087-6cd82e974fe1', international_community_humanitarian_authority, conventional).
narrative_ontology:cs_reference_frame('d472eda5-f238-4a37-a087-6cd82e974fe1', post_westphalian_human_rights_order).
narrative_ontology:cs_drift_state('d472eda5-f238-4a37-a087-6cd82e974fe1', contemporary_selective_enforcement_era, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('d472eda5-f238-4a37-a087-6cd82e974fe1', '').
narrative_ontology:cs_kernel_id(westphalia_sovereignty__conditional_responsibility, westphalia_sovereignty).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, humanitarian_intervention_coalitions).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, international_criminal_court).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, global_governance_institutions).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, un_security_council_permanent_members).
narrative_ontology:constraint_victim(westphalia_sovereignty__conditional_responsibility, populations_under_atrocity_regimes).
narrative_ontology:constraint_victim(westphalia_sovereignty__conditional_responsibility, targeted_sovereign_states).
narrative_ontology:constraint_victim(westphalia_sovereignty__conditional_responsibility, regional_powers_outside_intervention_coalitions).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, populations_under_atrocity_regimes).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__conditional_responsibility, universal_human_rights_doctrine).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__conditional_responsibility, international_community_authority).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% NATO-led or coalition forces that invoke R2P doctrine to authorize military intervention without Security Council approval when atrocities are underway. They frame intervention as enforcement of universal norms, gain geopolitical leverage in target regions, and expand the precedent for future action. Their structural position allows selective application—intervening where strategic interests align while declining intervention where they don't.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, humanitarian_intervention_coalitions, agenda_setter,
    institutional, generational, arbitrage, global).
narrative_ontology:stakeholder_secondary_role(westphalia_sovereignty__conditional_responsibility, humanitarian_intervention_coalitions, beneficiary).

% Prosecutes leaders of targeted states for atrocity crimes, treating R2P violations as justiciable offenses. The doctrine expands ICC jurisdiction by establishing that sovereignty failure creates accountability to international law. The court depends on intervention coalitions for enforcement but gains institutional authority from each successful prosecution.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, international_criminal_court, agenda_setter,
    institutional, generational, constrained, global).

% UN agencies, regional bodies, and multilateral organizations that gain mandate and resources when R2P is invoked. The doctrine expands their authority to operate inside sovereign borders during crises, building institutional capacity and precedent for governance functions that transcend state consent.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, global_governance_institutions, beneficiary,
    institutional, civilizational, mobile, global).

% Hold veto power over authorized R2P interventions while remaining exempt from R2P obligations themselves. The conditional sovereignty doctrine applies asymmetrically—P5 states invoke it against rivals while their own conduct (Chechnya, Xinjiang, Yemen support) remains insulated from intervention. They control the adjudicative machinery without being subject to it.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, un_security_council_permanent_members, beneficiary,
    institutional, generational, arbitrage, global).
narrative_ontology:stakeholder_secondary_role(westphalia_sovereignty__conditional_responsibility, un_security_council_permanent_members, agenda_setter).

% Civilians facing mass violence—genocide, ethnic cleansing, crimes against humanity. R2P doctrine frames them as the ultimate beneficiaries: intervention supposedly protects them when their own state fails to. They also pay the costs: interventions often intensify violence in the short term, impose regime change with unpredictable outcomes, and leave behind destabilized states. Their voices are structurally absent from the decision to intervene.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, populations_under_atrocity_regimes, beneficiary,
    powerless, immediate, trapped, national).
narrative_ontology:stakeholder_secondary_role(westphalia_sovereignty__conditional_responsibility, populations_under_atrocity_regimes, payer).

% States deemed to have forfeited sovereignty by failing R2P obligations. They face military intervention, regime change, ICC prosecutions, and long-term loss of territorial control. The assessment that they 'failed' their obligations is made by external actors with strategic interests. Their attempts to invoke Westphalian non-intervention norms are dismissed as cover for atrocities.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, targeted_sovereign_states, payer,
    organized, biographical, trapped, national).

% States like China, Russia, India, Brazil that oppose R2P doctrine as Western imperialism in humanitarian language. They lose regional influence when coalition interventions establish new client governments, face precedent erosion for their own sovereignty claims, and bear costs of instability from nearby interventions. Their resistance is systematically overridden in international legal fora.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, regional_powers_outside_intervention_coalitions, payer,
    institutional, generational, constrained, regional).

% States committed to absolute non-intervention norms who are structurally excluded from the new legitimacy framework. Their principle that sovereignty is categorical regardless of internal conduct has been displaced; their objections are treated as defending atrocities rather than defending a coherent legal order.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, traditional_westphalian_states, excluded,
    organized, generational, constrained, national).

% Analyze whether R2P represents customary international law evolution or selective enforcement masking geopolitical interests. They document the asymmetry: intervention coalitions never face R2P obligations, and atrocity determinations correlate with strategic interests rather than civilian death tolls. Their analysis feeds legitimacy contests but rarely alters intervention decisions.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, international_law_scholars, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes a transnational legal mechanism for responding to mass atrocities when state structures collapse or turn predatory. Solves the coordination problem of who has authority to act when domestic governance fails catastrophically and populations face extermination.
% TRANSFER_FUNCTION: Transfers sovereign authority from targeted states to intervention coalitions and international institutions. Moves military, jurisdictional, and governance capacity from domestic control to external actors. Populations under atrocity regimes receive protection (sometimes) but lose self-determination; intervening coalitions gain geopolitical footholds and precedent for future action.
% ABSENT_VOICES: Populations under atrocity regimes have no vote on whether intervention occurs or what form it takes. Regional powers outside the intervention coalition are excluded from adjudication. Traditional Westphalian states defending absolute non-intervention are treated as defending atrocities rather than a coherent legal principle.
% DISAPPEARANCE_RATIONALE: If R2P doctrine vanished, humanitarian intervention would revert to requiring Security Council authorization or being treated as aggression. States facing internal atrocities would no longer forfeit sovereignty claims. Coalition interventions would lose their legitimacy framework, ICC prosecutions of state leaders would face jurisdictional challenges, and the balance between territorial inviolability and human rights protection would reset toward the Westphalian baseline.
% FOUNDING_PROBLEM: The Rwanda genocide and Srebrenica massacre demonstrated that strict Westphalian non-intervention norms allowed mass atrocities to proceed while the international community watched. State sovereignty was protecting regimes committing genocide against their own populations.
% FOUNDING_PROBLEM_CORROBORATION: Humanitarian intervention advocates and global governance institutions attest the problem remains live—atrocities continue and sovereignty must remain conditional. Regional powers outside intervention coalitions, international law scholars critical of selective enforcement, and traditional Westphalian states attest the doctrine has become a legitimacy cover for geopolitical intervention: atrocity determinations correlate with strategic interests, intervention coalitions never face R2P obligations themselves, and comparable atrocities in allied states go unaddressed. Independent analysis shows intervention decisions correlate more strongly with intervener strategic interests than with civilian death tolls.
narrative_ontology:disappearance_verdict(westphalia_sovereignty__conditional_responsibility, world_rearranges).
narrative_ontology:founding_problem_status(westphalia_sovereignty__conditional_responsibility, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(westphalia_sovereignty__conditional_responsibility, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(westphalia_sovereignty__conditional_responsibility, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(westphalia_sovereignty__conditional_responsibility_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(westphalia_sovereignty__conditional_responsibility, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, ExtMetricName, E),
    domain_priors:suppression_score(westphalia_sovereignty__conditional_responsibility, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(westphalia_sovereignty__conditional_responsibility),
    narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(westphalia_sovereignty__conditional_responsibility_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Base extractiveness rises from 0.48 to 0.68 over the interval as selective application becomes evident: intervention coalitions never face R2P obligations, atrocity determinations correlate with strategic interests rather than death tolls, and comparable violence in allied states goes unaddressed. Suppression requirement increases from 0.51 to 0.71 as the doctrine requires actively overriding regional powers' objections and traditional Westphalian states' sovereignty claims. Theater ratio rises from 0.22 to 0.42: the humanitarian justification remains but grows performative as geopolitical patterns emerge. Accessibility collapse is moderate (0.58) because alternative sovereignty frameworks persist—absolute non-intervention and graded sovereignty remain live positions. Resistance is high (0.74) from regional powers, targeted states, and sovereignty traditionalists who see the doctrine as imperialism in humanitarian language.
 *
 * PERSPECTIVAL GAP:
 *   From the intervention coalition seat, this constraint is universal moral law enforcing human rights obligations. From the targeted state seat, it is selective geopolitical intervention dressed in humanitarian language. From the powerless population seat, it is ambiguous—sometimes genuine protection, sometimes violence intensification with no say in the decision. The engine computes these divergent classifications from the structural asymmetries in power, exit options, and benefit flows.
 *
 * DIRECTIONALITY LOGIC:
 *   Intervention coalitions are primary beneficiaries (collect authority and geopolitical leverage—d near 0.15). UN Security Council P5 members are beneficiaries (control adjudication asymmetrically—d ~0.20). Global governance institutions benefit from expanded mandate (d ~0.25). Populations under atrocity regimes occupy a dual position: framed as beneficiaries but structurally powerless and bearing intervention costs (d ~0.45). Targeted sovereign states are primary targets (lose sovereignty, face regime change—d ~0.90). Regional powers outside coalitions are secondary targets (precedent erosion, regional instability—d ~0.75).
 *
 * MANDATROPHY ANALYSIS:
 *   The founding problem (Rwanda, Srebrenica) was genuine—strict non-intervention allowed genocide. But mandatrophy analysis asks whether the current doctrine still primarily solves that problem or has shifted to other functions. Evidence for shift: (1) Atrocity determinations correlate more strongly with intervener strategic interests than civilian death tolls. (2) Intervention coalitions never face R2P obligations for their own conduct or allies' conduct. (3) Theater ratio rising as humanitarian justification persists while enforcement patterns follow geopolitical logic. (4) The doctrine persists even as selective application undermines its legitimacy with regional powers—suggesting the geopolitical benefits to intervening coalitions sustain it independent of humanitarian function.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    natural_law_vs_geopolitical_construction,
    'Is conditional sovereignty a natural moral principle (states genuinely forfeit legitimacy through atrocities) or a constructed doctrine serving intervention coalitions'' geopolitical interests?',
    'Longitudinal analysis of intervention decisions versus atrocity severity across all cases. If intervention probability correlates more strongly with intervener strategic interests than with civilian death tolls, the doctrine is constructed. If intervention occurs consistently when atrocities reach threshold severity regardless of strategic context, it is closer to natural law.',
    'If natural law, the constraint is a mountain with extraction as necessary enforcement cost. If constructed, it is a snare using humanitarian language to legitimize selective geopolitical intervention—beneficiaries are intervention coalitions, victims are targeted states and regional powers.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(natural_law_vs_geopolitical_construction, empirical, 'Whether R2P is universal moral principle or selective geopolitical tool').

omega_variable(
    asymmetric_application_mechanism,
    'Is the asymmetry (intervention coalitions exempt from R2P obligations) a temporary implementation failure or a structural feature enabling selective enforcement?',
    'Test whether intervention coalitions ever face R2P obligations for their own conduct or allies'' conduct. If the doctrine evolves to hold P5 states accountable for atrocities in Xinjiang, Yemen, Chechnya, etc., asymmetry is implementation failure. If exemption persists across cases, it is structural.',
    'If structural exemption, extraction flows systematically from non-coalition states to coalition states—classic tangled rope or snare pattern. If implementation failure being corrected, extraction is lower and coordination function dominates.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(asymmetric_application_mechanism, empirical, 'Whether coalition exemption is bug or feature').

omega_variable(
    protection_versus_destabilization,
    'Do populations under atrocity regimes experience net benefit from R2P interventions, or do interventions intensify violence and destabilization more than they prevent atrocities?',
    'Systematic outcome analysis of R2P interventions: casualty trajectories, state stability, refugee flows, post-intervention governance quality. Compare intervened cases to comparable non-intervened atrocities.',
    'If populations experience net benefit, they are genuine beneficiaries and the constraint has real coordination function. If interventions systematically worsen outcomes, populations are victims rather than beneficiaries—the humanitarian framing is cover for extraction that harms the nominal beneficiaries.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(protection_versus_destabilization, empirical, 'Whether R2P interventions actually protect populations').

omega_variable(
    sovereignty_threshold_under_determination,
    'What atrocity threshold triggers sovereignty forfeiture? Is there an objective standard or does the threshold shift based on who is being judged?',
    'Comparative analysis of atrocity severity across intervened and non-intervened cases. If threshold is stable across cases, it is closer to objective law. If threshold systematically differs between allied and rival states, it is under-determined and serves as a flexibility mechanism for selective enforcement.',
    'Threshold under-determination means the constraint''s scope is controlled by intervening coalitions, enabling extraction through selective application. An objective threshold would constrain coalition discretion and increase coordination/protection function.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(sovereignty_threshold_under_determination, conceptual, 'Whether atrocity threshold is objective or politically determined').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(westphalia_sovereignty__conditional_responsibility, 0, 28).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(west_tr_t0, westphalia_sovereignty__conditional_responsibility, theater_ratio, 0, 0.22).
narrative_ontology:measurement_basis(west_tr_t0, observed).
narrative_ontology:measurement(west_tr_t7, westphalia_sovereignty__conditional_responsibility, theater_ratio, 7, 0.28).
narrative_ontology:measurement_basis(west_tr_t7, observed).
narrative_ontology:measurement(west_tr_t14, westphalia_sovereignty__conditional_responsibility, theater_ratio, 14, 0.34).
narrative_ontology:measurement_basis(west_tr_t14, observed).
narrative_ontology:measurement(west_tr_t21, westphalia_sovereignty__conditional_responsibility, theater_ratio, 21, 0.39).
narrative_ontology:measurement_basis(west_tr_t21, observed).
narrative_ontology:measurement(west_tr_t28, westphalia_sovereignty__conditional_responsibility, theater_ratio, 28, 0.42).
narrative_ontology:measurement_basis(west_tr_t28, observed).

% Extraction over time
narrative_ontology:measurement(west_be_t0, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 0, 0.48).
narrative_ontology:measurement_basis(west_be_t0, observed).
narrative_ontology:measurement(west_be_t7, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 7, 0.54).
narrative_ontology:measurement_basis(west_be_t7, observed).
narrative_ontology:measurement(west_be_t14, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 14, 0.61).
narrative_ontology:measurement_basis(west_be_t14, observed).
narrative_ontology:measurement(west_be_t21, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 21, 0.66).
narrative_ontology:measurement_basis(west_be_t21, observed).
narrative_ontology:measurement(west_be_t28, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 28, 0.68).
narrative_ontology:measurement_basis(west_be_t28, observed).

% Suppression requirement over time
narrative_ontology:measurement(west_su_t0, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 0, 0.51).
narrative_ontology:measurement_basis(west_su_t0, observed).
narrative_ontology:measurement(west_su_t7, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 7, 0.58).
narrative_ontology:measurement_basis(west_su_t7, observed).
narrative_ontology:measurement(west_su_t14, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 14, 0.64).
narrative_ontology:measurement_basis(west_su_t14, observed).
narrative_ontology:measurement(west_su_t21, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 21, 0.68).
narrative_ontology:measurement_basis(west_su_t21, observed).
narrative_ontology:measurement(west_su_t28, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 28, 0.71).
narrative_ontology:measurement_basis(west_su_t28, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(westphalia_sovereignty__conditional_responsibility, enforcement_mechanism).
narrative_ontology:affects_constraint(westphalia_sovereignty__conditional_responsibility, westphalia_sovereignty__absolute_non_intervention).
narrative_ontology:affects_constraint(westphalia_sovereignty__conditional_responsibility, westphalia_sovereignty__graded_sovereignty).
narrative_ontology:affects_constraint(westphalia_sovereignty__conditional_responsibility, international_criminal_court_jurisdiction).
narrative_ontology:affects_constraint(westphalia_sovereignty__conditional_responsibility, humanitarian_intervention_doctrine).
narrative_ontology:affects_constraint(westphalia_sovereignty__conditional_responsibility, security_council_chapter_seven_authority).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the westphalia_sovereignty kernel. The kernel decomposes into three structurally distinct readings with different beneficiary/victim sets and different ε values. The absolute_non_intervention reading has negligible extraction (sovereignty is categorical). The graded_sovereignty reading has moderate extraction (differential treatment by capacity tier). This conditional_responsibility reading has substantial extraction (selective enforcement against non-coalition states). They are linked as alternative readings of the same fundamental question about territorial authority.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
