% ============================================================================
% CONSTRAINT STORY: waitangi_sovereignty_allocation__partnership_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_waitangi_sovereignty_allocation__partnership_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:stakeholder_gain_flow/2,
    narrative_ontology:fixing_cost_class/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: waitangi_sovereignty_allocation__partnership_reading
 *   human_readable: Treaty of Waitangi Partnership Doctrine
 *   domain: constitutional/indigenous_rights/post_colonial_governance
 *
 * SUMMARY:
 *   The Treaty of Waitangi partnership doctrine emerged through judicial and
 *   political interpretation of the 1840 Treaty's ambiguous sovereignty
 *   provisions. The English and Māori texts differed substantively: English
 *   version appeared to cede sovereignty, Māori version retained tino
 *   rangatiratanga while granting only kāwanatanga over settlers. By mid-20th
 *   century, partnership interpretation provided framework for managing this
 *   foundational ambiguity without resolving underlying sovereignty contest.
 *   Courts elaborated principles doctrine requiring Crown good faith, active
 *   protection of Māori interests, and consultation. Settlement process
 *   emerged to address historical grievances. Partnership reading CLAIMS
 *   mountain status as natural resolution of textual ambiguity and basis of
 *   constitutional order, while empirical operation shows moderate extraction
 *   (legitimacy transfer to Crown), declining but real theatrical performance
 *   (consultation that proves procedural), and genuine coordination function
 *   coexisting with asymmetric outcomes.
 *
 * KEY AGENTS:
 *   - crown_state_apparatus: Primary beneficiary (institutional/arbitrage) — maintains sovereignty while gaining legitimacy through partnership narrative
 *   - maori_communities: Dual-positioned (organized/constrained) — gain consultation rights and settlements while bearing costs of partnership framework channeling sovereignty claims into juridical process
 *   - treaty_settlement_negotiators: Beneficiary (organized/mobile) — professional class mediating relations through settlements apparatus
 *   - dispossessed_iwi: Victim (powerless/identity_locked) — endure historical dispossession addressed through delayed settlements at quantum below loss
 *   - unrecognized_claimants: Victim (powerless/trapped) — excluded from partnership benefits by recognition criteria
 *   - parliamentary_legislators: Agenda-setter (institutional/mobile) — exercise formally unlimited authority within political constraints of principles doctrine
 *   - waitangi_tribunal: Observer and beneficiary (institutional/constrained) — elaborate principles without enforcement power
 *   - constitutional_scholars: Analytical observer — document gap between rhetoric and power-sharing
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(waitangi_sovereignty_allocation__partnership_reading, 0.42).
domain_priors:suppression_score(waitangi_sovereignty_allocation__partnership_reading, 0.38).
domain_priors:theater_ratio(waitangi_sovereignty_allocation__partnership_reading, 0.29).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, extractiveness, 0.42).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 0.38).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 0.29).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, accessibility_collapse, 0.51).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, resistance, 0.58).

% --- Constraint claim ---
narrative_ontology:constraint_claim(waitangi_sovereignty_allocation__partnership_reading, mountain).
narrative_ontology:human_readable(waitangi_sovereignty_allocation__partnership_reading, "Treaty of Waitangi Partnership Doctrine").
narrative_ontology:topic_domain(waitangi_sovereignty_allocation__partnership_reading, "constitutional/indigenous_rights/post_colonial_governance").

domain_priors:requires_active_enforcement(waitangi_sovereignty_allocation__partnership_reading).
domain_priors:emerges_naturally(waitangi_sovereignty_allocation__partnership_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(waitangi_sovereignty_allocation__partnership_reading, 'f74b0908-14db-4ed3-8b88-6bb842875870').
narrative_ontology:cs_kernel_codification('f74b0908-14db-4ed3-8b88-6bb842875870', fixed_text).
narrative_ontology:cs_authority_grounding('f74b0908-14db-4ed3-8b88-6bb842875870', lineage).
narrative_ontology:cs_interpretation_layer_present('f74b0908-14db-4ed3-8b88-6bb842875870').
narrative_ontology:cs_reading_relation('f74b0908-14db-4ed3-8b88-6bb842875870', waitangi_sovereignty_allocation__crown_sovereignty_reading, coexists_with).
narrative_ontology:cs_reading_relation('f74b0908-14db-4ed3-8b88-6bb842875870', waitangi_sovereignty_allocation__rangatiratanga_reading, coexists_with).
narrative_ontology:cs_axiom('f74b0908-14db-4ed3-8b88-6bb842875870', foundational, treaty_partnership_as_constitutional_foundation).
narrative_ontology:cs_axiom_status(treaty_partnership_as_constitutional_foundation, holdable).
narrative_ontology:cs_axiom_grounding('f74b0908-14db-4ed3-8b88-6bb842875870', treaty_partnership_as_constitutional_foundation, conventional).
narrative_ontology:cs_axiom('f74b0908-14db-4ed3-8b88-6bb842875870', secondary, good_faith_consultation_requirement).
narrative_ontology:cs_axiom_status(good_faith_consultation_requirement, holdable).
narrative_ontology:cs_axiom_grounding('f74b0908-14db-4ed3-8b88-6bb842875870', good_faith_consultation_requirement, deontological).
narrative_ontology:cs_reference_frame('f74b0908-14db-4ed3-8b88-6bb842875870', treaty_partnership_constitutional_settlement).
narrative_ontology:cs_drift_state('f74b0908-14db-4ed3-8b88-6bb842875870', contemporary_sovereignty_pressure, gap(authority_erosion, substantial, false)).
narrative_ontology:cs_created_at('f74b0908-14db-4ed3-8b88-6bb842875870', '').
narrative_ontology:cs_kernel_id(waitangi_sovereignty_allocation__partnership_reading, waitangi_sovereignty_allocation).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__partnership_reading, crown_state_apparatus).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__partnership_reading, maori_communities).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__partnership_reading, treaty_settlement_negotiators).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__partnership_reading, dispossessed_iwi).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__partnership_reading, unrecognized_claimants).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__partnership_reading, waitangi_tribunal).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__partnership_reading, maori_communities).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__partnership_reading, partnership_constitutionalism).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__partnership_reading, principles_doctrine_legitimacy).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Maintains parliamentary sovereignty while operating under judicially-elaborated Treaty principles that constrain policy options. Sets consultation requirements, determines settlement negotiation frameworks, and interprets good faith obligations. Benefits from legitimacy conferred by partnership narrative while retaining ultimate legislative authority.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, crown_state_apparatus, agenda_setter,
    institutional, generational, arbitrage, national).
narrative_ontology:stakeholder_secondary_role(waitangi_sovereignty_allocation__partnership_reading, crown_state_apparatus, beneficiary).

% Gain consultation rights, settlement processes, and cultural recognition through principles doctrine. Bear costs where consultation proves merely procedural rather than substantive, where settlement quantum falls short of loss, and where partnership rhetoric masks continued Crown unilateralism on core sovereignty questions.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, maori_communities, beneficiary,
    organized, generational, constrained, national).
narrative_ontology:stakeholder_secondary_role(waitangi_sovereignty_allocation__partnership_reading, maori_communities, payer).

% Constitute professional class mediating Crown-Māori relations through settlements process. Benefit from ongoing demand for negotiation services, expertise in principles jurisprudence, and institutional position between the other seats. Their continued role depends on partnership framework persisting as settlement mechanism.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, treaty_settlement_negotiators, beneficiary,
    organized, biographical, mobile, national).

% Endure historical dispossession that partnership doctrine addresses through settlements decades or centuries late, at quantum substantially below loss. Identity-locked to place and kinship structures that were disrupted by Crown action the partnership narrative now characterizes as historical breach rather than ongoing structural extraction. Settlements close claims without restoring sovereignty or economic position.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, dispossessed_iwi, payer,
    powerless, generational, identity_locked, regional).

% Groups whose claims fall outside Crown's recognition criteria or settlement frameworks. Excluded from partnership benefits because their dispossession does not fit the process's evidentiary or temporal requirements. Cannot exit their structural position but also cannot access the remedial apparatus the partnership doctrine established.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, unrecognized_claimants, payer,
    powerless, generational, trapped, local).

% Exercise formally unlimited legislative authority while navigating political and juridical expectations of Treaty compliance. Can legislate contrary to principles but face legitimacy costs and judicial review. The partnership doctrine frames their authority as constrained while leaving override capacity intact.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, parliamentary_legislators, agenda_setter,
    institutional, biographical, mobile, national).

% Adjudicates Treaty breach claims and elaborates principles doctrine through non-binding recommendations. Benefits institutionally from partnership framework that empowers its interpretive function. Constrained by lack of enforcement power and Parliament's ability to legislate around its findings.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, waitangi_tribunal, observer,
    institutional, generational, constrained, national).
narrative_ontology:stakeholder_secondary_role(waitangi_sovereignty_allocation__partnership_reading, waitangi_tribunal, beneficiary).

% Analyze the partnership doctrine's operation, document the gap between consultation rhetoric and substantive power-sharing, track settlement outcomes. See full structure including how principles jurisprudence enables both meaningful constraint and strategic legitimation of Crown authority.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, constitutional_scholars, observer,
    analytical, generational, analytical, national).

% --- OQ-92 receipt surface: who RECEIVES the extraction (capture half).
% 'diffuse' = authored no-capture (piton-side); a seat name = capturer.
% ABSENT field = not authored, fail-closed. Never synthesized. ---
narrative_ontology:stakeholder_gain_flow(waitangi_sovereignty_allocation__partnership_reading, crown_state_apparatus).
narrative_ontology:fixing_cost_class(waitangi_sovereignty_allocation__partnership_reading, prohibitive).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes framework for ongoing Crown-Māori relations in post-colonial state: consultation protocols, settlement mechanisms, cultural recognition processes, and principles-based constraint on government action solve coordination problem of governing divided society with contested founding authority.
% TRANSFER_FUNCTION: Moves legitimacy to Crown governance through partnership narrative; moves limited financial settlements and consultation rights to recognized Māori groups; moves structural sovereignty questions out of political contestation into juridical interpretation where Crown retains override capacity.
% ABSENT_VOICES: Unrecognized claimants whose dispossession falls outside settlement frameworks; sovereignty advocates who reject partnership as adequate response to rangatiratanga claims; critics who see principles doctrine as legitimation device rather than meaningful constraint.
% DISAPPEARANCE_RATIONALE: If partnership doctrine vanished, Crown would face direct legitimacy crisis requiring either explicit return to Crown sovereignty reading or substantive power-sharing under rangatiratanga reading. Māori communities would lose consultation rights and settlement processes but could pursue sovereignty claims without partnership framework's channeling effect. Settlement negotiators' professional apparatus would collapse. Current constitutional arrangement depends on partnership doctrine mediating between incompatible sovereignty assertions.
% FOUNDING_PROBLEM: 1840 Treaty text ambiguity and Māori-English version divergence created ongoing sovereignty contest threatening colonial state legitimacy and Māori dispossession claims with no resolution mechanism.
% FOUNDING_PROBLEM_CORROBORATION: Constitutional scholars, Waitangi Tribunal jurisprudence, and historical analysis from outside benefiting parties confirm textual ambiguity persists and sovereignty question remains unresolved. Partnership doctrine addresses symptoms through process rather than resolving foundational sovereignty contest.
narrative_ontology:disappearance_verdict(waitangi_sovereignty_allocation__partnership_reading, world_rearranges).
narrative_ontology:founding_problem_status(waitangi_sovereignty_allocation__partnership_reading, live).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(waitangi_sovereignty_allocation__partnership_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(waitangi_sovereignty_allocation__partnership_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(waitangi_sovereignty_allocation__partnership_reading_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, ExtMetricName, E),
    domain_priors:suppression_score(waitangi_sovereignty_allocation__partnership_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(waitangi_sovereignty_allocation__partnership_reading),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(waitangi_sovereignty_allocation__partnership_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness 0.42 reflects legitimacy transfer to Crown and channeling of sovereignty claims into process that preserves Crown ultimate authority, offset by real settlements and consultation rights. Declining from 0.55 as genuine redress mechanisms matured. Suppression 0.38 reflects active but not maximal constraint: partnership framework requires maintaining appearance of good faith while preserving override capacity. Theater 0.29 captures gap between consultation rhetoric and substantive outcomes, declining as process institutionalized. Accessibility collapse 0.51 reflects that alternative sovereignty framings remain conceptually available but politically marginalized by partnership's institutional dominance. Resistance 0.58 reflects ongoing contestation from sovereignty advocates and settlement critics. CLAIMED as mountain because partnership doctrine presents itself as natural resolution of textual ambiguity and constitutional necessity; metrics show moderate extraction and enforcement, making divergence between claim and computed type the measurement.
 *
 * PERSPECTIVAL GAP:
 *   From Crown position, partnership doctrine is constitutional bedrock enabling legitimate bicultural governance — genuine mountain. From organized Māori communities, it operates as tangled rope: real coordination through consultation and settlements coexisting with extraction through sovereignty claim channeling. From dispossessed powerless iwi, framework operates as snare: identity-locked to claims process that delivers inadequate redress decades late while foreclosing sovereignty challenge. From sovereignty advocates excluded from process, entire partnership apparatus is extractive theater legitimating Crown authority. Engine computes each seat's type from these structural positions; claim/metric divergence measures false summit signature.
 *
 * DIRECTIONALITY LOGIC:
 *   Crown apparatus is structural beneficiary collecting legitimacy while retaining sovereignty (d toward beneficiary end, low χ despite institutional power). Māori communities are dual-positioned: coordination benefits from consultation and settlements, extraction costs from sovereignty channeling and procedural consultation (d near symmetric, moderate χ). Dispossessed iwi are victims with identity-locked exit receiving delayed inadequate settlements (d toward target end, amplified χ from powerless + identity_locked). Unrecognized claimants fully trapped with no access to benefits (d = 1.0, maximum χ). Settlement negotiators are beneficiaries whose professional role depends on framework persisting (d toward beneficiary, negative χ).
 *
 * MANDATROPHY ANALYSIS:
 *   Partnership doctrine carries both coordination function (managing bicultural governance) and extraction function (channeling sovereignty claims, legitimating Crown authority). Prevents misclassification as pure mountain by documenting beneficiaries and victims. Prevents pure snare classification by evidencing real coordination through consultation requirements and settlement processes. Mandatrophy resolution requires recognizing both functions operating simultaneously with different intensities across power positions.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    partnership_as_natural_constitutional_fact,
    'Is partnership doctrine genuinely emergent from Treaty text''s inherent ambiguity (mountain), or is it constructed judicial interpretation that benefits Crown by channeling sovereignty claims into manageable process (tangled rope or snare)?',
    'Comparative constitutional analysis: do other post-colonial states with ambiguous founding texts develop similar partnership doctrines, or is this specific to contexts where settler state apparatus benefits from legitimation device? Historical analysis: does partnership interpretation emerge from Treaty text itself or from Crown''s legitimacy needs in face of Māori resistance?',
    'If genuinely emergent from textual ambiguity, partnership''s moderate extraction is inherent coordination cost. If constructed for Crown benefit, extraction represents rent collection through constitutional narrative. Reclassification from claimed mountain to tangled rope would acknowledge both coordination function and asymmetric extraction serving Crown interests.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(partnership_as_natural_constitutional_fact, conceptual, 'Whether partnership doctrine is natural resolution of textual ambiguity or constructed legitimation device').

omega_variable(
    consultation_substantive_vs_procedural,
    'Do consultation requirements impose genuine constraint on Crown action (reducing extraction), or do they operate primarily as procedural legitimation (increasing theater ratio)?',
    'Systematic analysis of consultation outcomes: proportion where Crown modifies policy based on Māori input vs. proportion where consultation occurs but Crown proceeds with original plan. Comparison of consultation rhetoric in official statements vs. actual policy outcomes.',
    'If consultation proves substantive, coordination function dominates and extraction measures should be revised downward. If primarily procedural, theater ratio should be higher and constraint operates more as legitimation device than genuine power-sharing. Current 0.29 theater ratio may understate performative component.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(consultation_substantive_vs_procedural, empirical, 'Whether consultation requirements provide substantive constraint or procedural legitimation').

omega_variable(
    settlement_quantum_adequacy,
    'Do Treaty settlements provide adequate compensation for dispossession (genuine redress reducing victim extraction), or do they systematically undervalue claims while providing Crown with political closure (extraction through inadequate settlement)?',
    'Economic analysis comparing settlement quantum to estimated value of land and resources lost, accounting for time value and opportunity cost. Analysis of settlement negotiation power dynamics and Crown''s ability to constrain settlement amounts through budget allocation and negotiation frameworks it controls.',
    'If settlements systematically undervalue claims, extractiveness from dispossessed iwi perspective is higher than cross-seat average suggests. If settlements approximate losses, coordination function through redress mechanism is stronger than extraction function. Affects whether framework operates as genuine resolution mechanism or as managed closure process.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(settlement_quantum_adequacy, empirical, 'Whether settlement quantum adequately compensates dispossession or systematically undervalues claims').

omega_variable(
    framing_under_determination,
    'Is partnership the correct constitutional framing, or does the Treaty''s Māori text establish continuing rangatiratanga that partnership doctrine systematically underweights?',
    'Linguistic and historical analysis of rangatiratanga vs. kāwanatanga terms in 1840s Māori usage. Comparative analysis of Treaty principles jurisprudence vs. alternative constitutional frameworks that take tino rangatiratanga as foundational rather than partnership as compromise.',
    'If rangatiratanga reading is structurally defensible alternative, partnership framework''s classification as coordination mechanism becomes contestable — it may operate to suppress alternative constitutional framing that would distribute sovereignty differently. Alternative framing would show higher extraction from Māori perspective and challenge mountain claim more directly.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(framing_under_determination, conceptual, 'Whether partnership framing or rangatiratanga-centered framing better captures Treaty''s constitutional structure').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(waitangi_sovereignty_allocation__partnership_reading, 0, 50).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(wait_tr_t0, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 0, 0.45).
narrative_ontology:measurement_basis(wait_tr_t0, observed).
narrative_ontology:measurement(wait_tr_t10, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 10, 0.41).
narrative_ontology:measurement_basis(wait_tr_t10, observed).
narrative_ontology:measurement(wait_tr_t20, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 20, 0.37).
narrative_ontology:measurement_basis(wait_tr_t20, observed).
narrative_ontology:measurement(wait_tr_t30, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 30, 0.33).
narrative_ontology:measurement_basis(wait_tr_t30, observed).
narrative_ontology:measurement(wait_tr_t40, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 40, 0.31).
narrative_ontology:measurement_basis(wait_tr_t40, observed).
narrative_ontology:measurement(wait_tr_t50, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 50, 0.29).
narrative_ontology:measurement_basis(wait_tr_t50, observed).

% Extraction over time
narrative_ontology:measurement(wait_be_t0, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 0, 0.55).
narrative_ontology:measurement_basis(wait_be_t0, observed).
narrative_ontology:measurement(wait_be_t10, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 10, 0.52).
narrative_ontology:measurement_basis(wait_be_t10, observed).
narrative_ontology:measurement(wait_be_t20, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 20, 0.48).
narrative_ontology:measurement_basis(wait_be_t20, observed).
narrative_ontology:measurement(wait_be_t30, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 30, 0.45).
narrative_ontology:measurement_basis(wait_be_t30, observed).
narrative_ontology:measurement(wait_be_t40, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 40, 0.43).
narrative_ontology:measurement_basis(wait_be_t40, observed).
narrative_ontology:measurement(wait_be_t50, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 50, 0.42).
narrative_ontology:measurement_basis(wait_be_t50, observed).

% Suppression requirement over time
narrative_ontology:measurement(wait_su_t0, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 0, 0.52).
narrative_ontology:measurement_basis(wait_su_t0, observed).
narrative_ontology:measurement(wait_su_t10, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 10, 0.48).
narrative_ontology:measurement_basis(wait_su_t10, observed).
narrative_ontology:measurement(wait_su_t20, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 20, 0.45).
narrative_ontology:measurement_basis(wait_su_t20, observed).
narrative_ontology:measurement(wait_su_t30, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 30, 0.42).
narrative_ontology:measurement_basis(wait_su_t30, observed).
narrative_ontology:measurement(wait_su_t40, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 40, 0.4).
narrative_ontology:measurement_basis(wait_su_t40, observed).
narrative_ontology:measurement(wait_su_t50, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 50, 0.38).
narrative_ontology:measurement_basis(wait_su_t50, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(waitangi_sovereignty_allocation__partnership_reading, identity_coordination).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__partnership_reading, waitangi_sovereignty_allocation__crown_sovereignty_reading).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__partnership_reading, waitangi_sovereignty_allocation__rangatiratanga_reading).

% DUAL FORMULATION NOTE:
% Partnership reading is one of three constraint stories decomposing the Treaty of Waitangi's sovereignty allocation. Crown sovereignty reading treats English text as ceding complete sovereignty (low ε, settled law). Partnership reading mediates through principles doctrine requiring consultation and good faith (medium ε, coordination with extraction). Rangatiratanga reading treats Māori text as retaining full authority (high ε from Māori perspective, substantial Crown constraint). The three readings form constraint family linked via network.affects_constraints because they represent competing constitutional interpretations of same foundational text with different beneficiary structures and extraction profiles.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
