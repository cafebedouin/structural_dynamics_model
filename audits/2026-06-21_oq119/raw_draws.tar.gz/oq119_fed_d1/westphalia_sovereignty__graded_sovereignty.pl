% ============================================================================
% CONSTRAINT STORY: westphalia_sovereignty__graded_sovereignty
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-01-15
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_westphalia_sovereignty__graded_sovereignty, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: westphalia_sovereignty__graded_sovereignty
 *   human_readable: Graded Sovereignty: Capacity-Based Intervention Legitimacy
 *   domain: international_law/political_theory/state_systems
 *
 * SUMMARY:
 *   The graded sovereignty reading treats state authority as existing on a
 *   continuous spectrum from full to nominal, with intervention legitimacy
 *   calibrated to measured capacity deficits. Emerged in post-Cold War
 *   international relations theory and practice as middle position between
 *   absolute non-intervention and responsibility-to-protect doctrines.
 *   Creates de facto tiering of state system through technocratic capacity
 *   assessment. Claimed as mountain (natural adaptation to state system
 *   heterogeneity) while operating with substantial extraction from
 *   capacity-deficient states and active enforcement against challenges to
 *   the assessment regime. KEY AGENTS (by structural relationship): -
 *   Capacity evaluation authorities (institutional/arbitrage): Primary
 *   agenda-setters defining metrics and thresholds - Intervention-capable
 *   states (institutional/arbitrage): Primary beneficiaries gaining normative
 *   cover for coercion - International governance institutions
 *   (institutional/mobile): Secondary beneficiaries expanding mandate -
 *   Capacity-deficient states (powerless/trapped): Primary targets losing
 *   territorial inviolability - Populations in weak states
 *   (powerless/trapped): Secondary targets bearing intervention consequences
 *   - Anti-colonial movements (organized/constrained): Excluded voices
 *   contesting framework's naturalization of hierarchy - International law
 *   scholars (analytical/analytical): Observers documenting formal equality
 *   versus de facto hierarchy tension
 *
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(westphalia_sovereignty__graded_sovereignty, 0.68).
domain_priors:suppression_score(westphalia_sovereignty__graded_sovereignty, 0.72).
domain_priors:theater_ratio(westphalia_sovereignty__graded_sovereignty, 0.58).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, extractiveness, 0.68).
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, suppression_requirement, 0.72).
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, theater_ratio, 0.58).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, accessibility_collapse, 0.42).
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, resistance, 0.71).

% --- Constraint claim ---
narrative_ontology:constraint_claim(westphalia_sovereignty__graded_sovereignty, mountain).
narrative_ontology:human_readable(westphalia_sovereignty__graded_sovereignty, "Graded Sovereignty: Capacity-Based Intervention Legitimacy").
narrative_ontology:topic_domain(westphalia_sovereignty__graded_sovereignty, "international_law/political_theory/state_systems").

domain_priors:requires_active_enforcement(westphalia_sovereignty__graded_sovereignty).
domain_priors:emerges_naturally(westphalia_sovereignty__graded_sovereignty).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(westphalia_sovereignty__graded_sovereignty, '547933fe-b553-42bb-adf8-5ed30b19d3ef').
narrative_ontology:cs_kernel_codification('547933fe-b553-42bb-adf8-5ed30b19d3ef', formalized).
narrative_ontology:cs_authority_grounding('547933fe-b553-42bb-adf8-5ed30b19d3ef', expertise).
narrative_ontology:cs_interpretation_layer_present('547933fe-b553-42bb-adf8-5ed30b19d3ef').
narrative_ontology:cs_reading_relation('547933fe-b553-42bb-adf8-5ed30b19d3ef', westphalia_sovereignty__absolute_non_intervention, coexists_with).
narrative_ontology:cs_reading_relation('547933fe-b553-42bb-adf8-5ed30b19d3ef', westphalia_sovereignty__conditional_responsibility, influences).
narrative_ontology:cs_axiom('547933fe-b553-42bb-adf8-5ed30b19d3ef', foundational, sovereignty_requires_capacity).
narrative_ontology:cs_axiom_status(sovereignty_requires_capacity, holdable).
narrative_ontology:cs_axiom_grounding('547933fe-b553-42bb-adf8-5ed30b19d3ef', sovereignty_requires_capacity, empirically_contingent).
narrative_ontology:cs_axiom('547933fe-b553-42bb-adf8-5ed30b19d3ef', foundational, intervention_legitimacy_scales_with_deficit).
narrative_ontology:cs_axiom_status(intervention_legitimacy_scales_with_deficit, holdable).
narrative_ontology:cs_axiom_grounding('547933fe-b553-42bb-adf8-5ed30b19d3ef', intervention_legitimacy_scales_with_deficit, instrumental).
narrative_ontology:cs_axiom('547933fe-b553-42bb-adf8-5ed30b19d3ef', secondary, capacity_measurement_is_objective).
narrative_ontology:cs_axiom_status(capacity_measurement_is_objective, holdable).
narrative_ontology:cs_axiom_grounding('547933fe-b553-42bb-adf8-5ed30b19d3ef', capacity_measurement_is_objective, empirically_contingent).
narrative_ontology:cs_reference_frame('547933fe-b553-42bb-adf8-5ed30b19d3ef', westphalian_sovereign_equality).
narrative_ontology:cs_drift_state('547933fe-b553-42bb-adf8-5ed30b19d3ef', post_cold_war_state_failure_era, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('547933fe-b553-42bb-adf8-5ed30b19d3ef', '').
narrative_ontology:cs_kernel_id(westphalia_sovereignty__graded_sovereignty, westphalia_sovereignty).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, capacity_evaluation_authorities).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, intervention_capable_states).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, international_governance_institutions).
narrative_ontology:constraint_victim(westphalia_sovereignty__graded_sovereignty, capacity_deficient_states).
narrative_ontology:constraint_victim(westphalia_sovereignty__graded_sovereignty, populations_in_weak_states).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, populations_in_weak_states).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__graded_sovereignty, hierarchy_reflects_competence).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__graded_sovereignty, paternalism_as_responsibility).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Define and measure state capacity metrics through composite indices tracking governance effectiveness, institutional strength, and service delivery. Set thresholds determining intervention legitimacy. Frame capacity deficits as objective failures rather than structural outcomes of historical extraction or contemporary economic architecture. Their assessment apparatus becomes the authoritative map of which states possess sovereignty and which hold it conditionally.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, capacity_evaluation_authorities, agenda_setter,
    institutional, generational, arbitrage, global).

% Gain normative cover for interventions in capacity-deficient states by framing military or economic coercion as responsibility rather than aggression. The graded sovereignty framework translates their power advantage into moral authority: what was conquest becomes custodianship. Exit options are analytical because they set the rules rather than operate under them.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, intervention_capable_states, beneficiary,
    institutional, generational, arbitrage, global).

% Gain expanded mandate and jurisdiction by administering the capacity-assessment regime and coordinating intervention authorization. The framework justifies their growing role as arbiters of legitimate statehood. They benefit from the constraint's operation without being its primary architects.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, international_governance_institutions, beneficiary,
    institutional, generational, mobile, global).
narrative_ontology:stakeholder_secondary_role(westphalia_sovereignty__graded_sovereignty, international_governance_institutions, agenda_setter).

% Bear loss of territorial inviolability calibrated to their measured capacity deficit. Face legitimized external interference in domestic affairs, conditionality on aid and recognition, and erosion of negotiating position in international forums. Their capacity deficits are often downstream of historical colonization or contemporary debt structures, but the framework treats low capacity as intrinsic failure rather than relational outcome. Exit requires building capacity under the same international architecture that extracts from weakness.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, capacity_deficient_states, payer,
    powerless, generational, trapped, national).

% Subjected to interventions justified by their state's measured incapacity, with outcomes ranging from humanitarian protection to resource extraction dressed as stabilization. The framework treats them as objects of responsibility rather than agents with claims. They may receive genuine protection in some cases but lose voice in determining what protection means or who provides it. Geographic and economic constraints leave them unable to exit their state's capacity tier.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, populations_in_weak_states, payer,
    powerless, biographical, trapped, local).
narrative_ontology:stakeholder_secondary_role(westphalia_sovereignty__graded_sovereignty, populations_in_weak_states, beneficiary).

% Argue that capacity deficits reflect historical extraction and ongoing structural violence, not intrinsic state failure. They contest the framework's naturalization of hierarchy and its erasure of causation. They are systematically excluded from capacity-evaluation bodies and intervention-authorization processes. Their reading—that graded sovereignty recreates colonial administration under technocratic cover—is treated as ideological rather than analytical.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, anti_colonial_movements, excluded,
    organized, generational, constrained, global).

% Document the tension between the Charter's formal equality principle and the graded sovereignty regime's de facto hierarchy. Some read the capacity framework as pragmatic adaptation to state system heterogeneity; others read it as power's legitimation apparatus. They analyze intervention precedents and track which capacity metrics correlate with actual intervention versus rhetorical justification.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, international_law_scholars, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a stability mechanism for managing state system heterogeneity without formal abandonment of sovereign equality doctrine. Offers intervention-capable states a rule-governed framework for addressing state failure, humanitarian crises, and regional instability without claiming openly hierarchical authority.
% TRANSFER_FUNCTION: Transfers decision rights over territorial sovereignty from capacity-deficient states to capacity-evaluation authorities and intervention-capable states. Moves normative authority to define legitimate statehood from the state system's formal equality principle to technocratic assessment bodies.
% ABSENT_VOICES: Anti-colonial movements and scholars who trace capacity deficits to extraction histories are structurally excluded from capacity-evaluation bodies. Populations in capacity-deficient states have no seat in determining assessment criteria or intervention authorization. Their absence ensures the framework treats capacity as intrinsic rather than relational.
% DISAPPEARANCE_RATIONALE: If the graded sovereignty framework vanished overnight, intervention-capable states would lose legitimation cover for coercive action in weak states, international institutions would lose jurisdictional expansion justification, and capacity-deficient states would gain stronger non-intervention claims under Charter equality principles. The international legal order would revert to sharper tension between formal equality and de facto power asymmetry.
% FOUNDING_PROBLEM: Post-Cold War state failures and humanitarian crises created tension between the Westphalian non-intervention norm and the manifest inability of some states to provide basic security or services. The framework emerged to reconcile intervention practice with sovereignty doctrine.
% FOUNDING_PROBLEM_CORROBORATION: Intervention-capable states and international institutions attest the problem remains live and the framework is necessary adaptation. Anti-colonial scholars and international law critics from the Global South attest the founding problem was constructed to justify intervention rather than discovered as a natural tension, citing selective application of capacity metrics that correlates with resource access and geopolitical alignment rather than humanitarian need. Independent analysis from legal scholars outside Western institutions documents the correlation.
narrative_ontology:disappearance_verdict(westphalia_sovereignty__graded_sovereignty, world_rearranges).
narrative_ontology:founding_problem_status(westphalia_sovereignty__graded_sovereignty, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(westphalia_sovereignty__graded_sovereignty, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(westphalia_sovereignty__graded_sovereignty, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(westphalia_sovereignty__graded_sovereignty_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(westphalia_sovereignty__graded_sovereignty, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, ExtMetricName, E),
    domain_priors:suppression_score(westphalia_sovereignty__graded_sovereignty, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(westphalia_sovereignty__graded_sovereignty),
    narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(westphalia_sovereignty__graded_sovereignty_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness scores 0.68 because the constraint transfers decision rights over sovereignty from weak states to assessment authorities and intervention-capable states, with transfer magnitude calibrated to measured deficits. This is substantial extraction even when interventions serve humanitarian goals, because it removes weak states' authority to define their own institutional trajectories. Suppression is 0.72 because the framework requires active enforcement against alternative readings that treat capacity deficits as relational rather than intrinsic—challenges to the assessment regime are suppressed as ideological interference with objective measurement. Theater ratio reaches 0.58 by interval end as the humanitarian justification increasingly covers resource-access interventions and the assessment apparatus devotes growing resources to legitimation performance rather than genuine capacity measurement. Accessibility collapse is moderate (0.42) because alternative sovereignty frameworks remain conceptually available even as they are institutionally marginalized. Resistance is high (0.71) because capacity-deficient states and anti-colonial movements actively contest the framework despite power asymmetry.
 *
 * PERSPECTIVAL GAP:
 *   From the capacity-evaluation seat, the framework is pragmatic adaptation to real state system heterogeneity—natural recognition that sovereignty requires capacity and intervention prevents humanitarian catastrophe. From the capacity-deficient state seat, the same structure is extraction apparatus naturalizing historical power asymmetries—what presents as objective measurement is power's self-justification. From the analytical seat, the constraint's operation reveals the tension: capacity metrics show suspicious correlation with resource access and geopolitical alignment, suggesting the framework serves legitimation more than coordination. The engine computes these divergent classifications from the structural asymmetries in power, exit options, and capture of assessment authority.
 *
 * DIRECTIONALITY LOGIC:
 *   Capacity evaluation authorities and intervention-capable states are structural beneficiaries (d near 0.15-0.25): they gain normative authority and intervention legitimacy from the framework's operation. International governance institutions sit slightly higher (d near 0.30): they benefit from expanded mandate but do not control the assessment criteria. Capacity-deficient states are primary targets (d near 0.85-0.90): they lose territorial inviolability with no exit path that does not require accepting the capacity framework's authority. Populations in weak states have high but slightly lower d (near 0.75-0.80) because they receive genuine protection in some intervention cases even as they lose voice. Anti-colonial movements sit near 0.60—they are excluded from authority but not primary extraction targets.
 *
 * MANDATROPHY ANALYSIS:
 *   The graded sovereignty framework navigates mandatrophy tension by claiming to coordinate response to genuine state failure while operating as extraction mechanism benefiting intervention-capable states and assessment authorities. The coordination function is real—some interventions prevent mass atrocities and the framework provides rule-governed process rather than naked power politics. But the extraction is also real and substantial—the apparatus transfers sovereignty rights from weak to strong states, with capacity deficits treated as intrinsic failures rather than outcomes of relational structures the strong states constructed. The constraint is claimed as mountain (natural adaptation to state system heterogeneity) while showing high extraction, rising theater ratio, and active suppression of alternative causal framings. This is textbook false summit: a constructed hierarchy presented as natural order, with identifiable beneficiaries collecting rents from the naturalization.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    capacity_intrinsic_vs_relational,
    'Are the capacity deficits that justify intervention intrinsic state failures or outcomes of relational structures (historical extraction, contemporary debt architecture, resource curse mechanics) that intervention-capable states constructed or maintain?',
    'Longitudinal analysis correlating capacity metrics with historical colonization, contemporary debt servicing ratios, and resource extraction patterns. If capacity deficits track these relational variables more strongly than governance choices, the intrinsic-failure framing is falsified.',
    'If capacity deficits are relational outcomes, the graded sovereignty framework is extraction apparatus naturalizing power asymmetries rather than pragmatic adaptation to heterogeneity. Intervention becomes mechanism for reproducing the structures that created the deficits.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(capacity_intrinsic_vs_relational, empirical, 'Whether capacity deficits are intrinsic failures or relational outcomes of extraction structures').

omega_variable(
    assessment_objectivity,
    'Do capacity assessment metrics measure actual governance effectiveness or do they correlate primarily with geopolitical alignment and resource access?',
    'Statistical analysis of intervention authorization decisions against capacity metrics versus strategic interest proxies (military basing, resource deposits, great power rivalry zones). If intervention correlates more strongly with strategic proxies than capacity scores, the objectivity claim is falsified.',
    'If assessment is geopolitically driven, the graded sovereignty framework provides legitimation cover for power politics rather than rule-governed intervention process. The technocratic apparatus would be theater masking strategic extraction.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(assessment_objectivity, empirical, 'Whether capacity assessment tracks governance effectiveness or geopolitical interests').

omega_variable(
    mountain_versus_constructed_hierarchy,
    'Is the graded sovereignty framework a natural adaptation to state system heterogeneity (mountain), or a constructed hierarchy that benefits intervention-capable states by naturalizing their authority?',
    'Cross-kernel comparison of how alternative sovereignty readings would allocate intervention legitimacy and decision rights. If beneficiaries strongly resist alternative framings despite their logical coherence, the natural-adaptation claim is weakened.',
    'If constructed rather than natural, the constraint is false summit—extraction apparatus presenting as natural law. The substantial extraction from capacity-deficient states, rising theater ratio, and active suppression of relational causation framings support the constructed reading.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(mountain_versus_constructed_hierarchy, conceptual, 'Whether graded sovereignty is natural adaptation or constructed hierarchy serving beneficiaries').

omega_variable(
    coordination_separability,
    'Is the genuine coordination function (preventing humanitarian catastrophe, managing state failure spillovers) separable from the extraction function (transferring sovereignty rights to intervention-capable states)?',
    'Analysis of intervention cases where humanitarian protection occurred without sovereignty transfer versus cases where sovereignty transfer occurred without humanitarian protection. If the functions regularly separate in practice, they are structurally separable.',
    'If separable, the current framework bundles necessary coordination with unnecessary extraction. Alternative designs could preserve the humanitarian function without the hierarchy-naturalizing apparatus.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(coordination_separability, conceptual, 'Whether humanitarian coordination requires sovereignty hierarchy or can be separated').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(westphalia_sovereignty__graded_sovereignty, 0, 35).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(west_tr_t0, westphalia_sovereignty__graded_sovereignty, theater_ratio, 0, 0.32).
narrative_ontology:measurement_basis(west_tr_t0, observed).
narrative_ontology:measurement(west_tr_t7, westphalia_sovereignty__graded_sovereignty, theater_ratio, 7, 0.38).
narrative_ontology:measurement_basis(west_tr_t7, observed).
narrative_ontology:measurement(west_tr_t14, westphalia_sovereignty__graded_sovereignty, theater_ratio, 14, 0.44).
narrative_ontology:measurement_basis(west_tr_t14, observed).
narrative_ontology:measurement(west_tr_t21, westphalia_sovereignty__graded_sovereignty, theater_ratio, 21, 0.49).
narrative_ontology:measurement_basis(west_tr_t21, observed).
narrative_ontology:measurement(west_tr_t28, westphalia_sovereignty__graded_sovereignty, theater_ratio, 28, 0.54).
narrative_ontology:measurement_basis(west_tr_t28, observed).
narrative_ontology:measurement(west_tr_t35, westphalia_sovereignty__graded_sovereignty, theater_ratio, 35, 0.58).
narrative_ontology:measurement_basis(west_tr_t35, observed).

% Extraction over time
narrative_ontology:measurement(west_be_t0, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 0, 0.48).
narrative_ontology:measurement_basis(west_be_t0, observed).
narrative_ontology:measurement(west_be_t7, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 7, 0.54).
narrative_ontology:measurement_basis(west_be_t7, observed).
narrative_ontology:measurement(west_be_t14, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 14, 0.59).
narrative_ontology:measurement_basis(west_be_t14, observed).
narrative_ontology:measurement(west_be_t21, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 21, 0.63).
narrative_ontology:measurement_basis(west_be_t21, observed).
narrative_ontology:measurement(west_be_t28, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 28, 0.66).
narrative_ontology:measurement_basis(west_be_t28, observed).
narrative_ontology:measurement(west_be_t35, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 35, 0.68).
narrative_ontology:measurement_basis(west_be_t35, observed).

% Suppression requirement over time
narrative_ontology:measurement(west_su_t0, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 0, 0.52).
narrative_ontology:measurement_basis(west_su_t0, observed).
narrative_ontology:measurement(west_su_t7, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 7, 0.58).
narrative_ontology:measurement_basis(west_su_t7, observed).
narrative_ontology:measurement(west_su_t14, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 14, 0.63).
narrative_ontology:measurement_basis(west_su_t14, observed).
narrative_ontology:measurement(west_su_t21, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 21, 0.67).
narrative_ontology:measurement_basis(west_su_t21, observed).
narrative_ontology:measurement(west_su_t28, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 28, 0.7).
narrative_ontology:measurement_basis(west_su_t28, observed).
narrative_ontology:measurement(west_su_t35, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 35, 0.72).
narrative_ontology:measurement_basis(west_su_t35, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(westphalia_sovereignty__graded_sovereignty, global_infrastructure).
narrative_ontology:boltzmann_floor_override(westphalia_sovereignty__graded_sovereignty, 0.22).
narrative_ontology:affects_constraint(westphalia_sovereignty__graded_sovereignty, westphalia_sovereignty__absolute_non_intervention).
narrative_ontology:affects_constraint(westphalia_sovereignty__graded_sovereignty, westphalia_sovereignty__conditional_responsibility).
narrative_ontology:affects_constraint(westphalia_sovereignty__graded_sovereignty, humanitarian_intervention_doctrine).
narrative_ontology:affects_constraint(westphalia_sovereignty__graded_sovereignty, un_security_council_authorization).

% DUAL FORMULATION NOTE:
% This constraint is one of three readings of the Westphalian sovereignty kernel. The absolute_non_intervention reading treats sovereignty as categorical and inviolable. The conditional_responsibility reading treats it as earned through protecting populations. This graded_sovereignty reading treats it as scalar capacity. All three readings share the same kernel (territorial state authority) but instantiate different constraints with different beneficiary structures and different extraction profiles.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
