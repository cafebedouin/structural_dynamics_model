% ============================================================================
% CONSTRAINT STORY: waitangi_sovereignty_allocation__rangatiratanga_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_waitangi_sovereignty_allocation__rangatiratanga_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: waitangi_sovereignty_allocation__rangatiratanga_reading
 *   human_readable: Waitangi Sovereignty Allocation (Rangatiratanga Reading)
 *   domain: constitutional_law/indigenous_rights/post_colonial_governance
 *
 * SUMMARY:
 *   The Treaty of Waitangi was signed in 1840 in both English and Māori
 *   versions with materially different sovereignty allocations. The
 *   rangatiratanga reading holds that the Māori text—the version signed by
 *   Māori chiefs who could not read English—is the authoritative account of
 *   what was agreed. Under that text, Article II guaranteed tino
 *   rangatiratanga (full authority/chieftainship) over lands, forests,
 *   fisheries, and taonga, while Article I granted the Crown only kāwanatanga
 *   (governorship) over British settlers. The reading treats this as a
 *   foundational constitutional allocation grounded in the treaty text
 *   itself, not a policy preference. The Crown sovereignty reading, by
 *   contrast, relies on the English text claiming complete sovereignty
 *   cession. This constraint models the rangatiratanga reading's structural
 *   claims and their constitutional implications. KEY AGENTS: maori_iwi_hapu
 *   (organized/identity_locked) hold inherent rangatiratanga;
 *   crown_administrative_apparatus (institutional/constrained) possesses
 *   limited kāwanatanga; settler_colonial_interests (powerful/mobile) built
 *   property claims on Crown sovereignty doctrine now contested;
 *   indigenous_sovereignty_movements (organized/identity_locked) benefit from
 *   precedent value; treaty_tribunal_judiciary (institutional/analytical)
 *   adjudicates between readings; constitutional_scholars
 *   (analytical/analytical) document textual divergence.
 *
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(waitangi_sovereignty_allocation__rangatiratanga_reading, 0.23).
domain_priors:suppression_score(waitangi_sovereignty_allocation__rangatiratanga_reading, 0.41).
domain_priors:theater_ratio(waitangi_sovereignty_allocation__rangatiratanga_reading, 0.18).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, extractiveness, 0.23).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 0.41).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 0.18).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, accessibility_collapse, 0.71).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, resistance, 0.67).

% --- Constraint claim ---
narrative_ontology:constraint_claim(waitangi_sovereignty_allocation__rangatiratanga_reading, mountain).
narrative_ontology:human_readable(waitangi_sovereignty_allocation__rangatiratanga_reading, "Waitangi Sovereignty Allocation (Rangatiratanga Reading)").
narrative_ontology:topic_domain(waitangi_sovereignty_allocation__rangatiratanga_reading, "constitutional_law/indigenous_rights/post_colonial_governance").

domain_priors:emerges_naturally(waitangi_sovereignty_allocation__rangatiratanga_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(waitangi_sovereignty_allocation__rangatiratanga_reading, '13ad2424-cb97-4d7a-98e1-e691c68f2110').
narrative_ontology:cs_kernel_codification('13ad2424-cb97-4d7a-98e1-e691c68f2110', fixed_text).
narrative_ontology:cs_authority_grounding('13ad2424-cb97-4d7a-98e1-e691c68f2110', lineage).
narrative_ontology:cs_interpretation_layer_present('13ad2424-cb97-4d7a-98e1-e691c68f2110').
narrative_ontology:cs_reading_relation('13ad2424-cb97-4d7a-98e1-e691c68f2110', waitangi_sovereignty_allocation__crown_sovereignty_reading, forecloses).
narrative_ontology:cs_reading_relation('13ad2424-cb97-4d7a-98e1-e691c68f2110', waitangi_sovereignty_allocation__partnership_reading, influences).
narrative_ontology:cs_axiom('13ad2424-cb97-4d7a-98e1-e691c68f2110', foundational, maori_text_constitutional_authority).
narrative_ontology:cs_axiom_status(maori_text_constitutional_authority, holdable).
narrative_ontology:cs_axiom_grounding('13ad2424-cb97-4d7a-98e1-e691c68f2110', maori_text_constitutional_authority, conventional).
narrative_ontology:cs_axiom('13ad2424-cb97-4d7a-98e1-e691c68f2110', foundational, sovereignty_retained_not_ceded).
narrative_ontology:cs_axiom_status(sovereignty_retained_not_ceded, holdable).
narrative_ontology:cs_axiom_grounding('13ad2424-cb97-4d7a-98e1-e691c68f2110', sovereignty_retained_not_ceded, deontological).
narrative_ontology:cs_axiom('13ad2424-cb97-4d7a-98e1-e691c68f2110', secondary, rangatiratanga_crown_coequal_authority).
narrative_ontology:cs_axiom_status(rangatiratanga_crown_coequal_authority, holdable).
narrative_ontology:cs_axiom_grounding('13ad2424-cb97-4d7a-98e1-e691c68f2110', rangatiratanga_crown_coequal_authority, conventional).
narrative_ontology:cs_reference_frame('13ad2424-cb97-4d7a-98e1-e691c68f2110', treaty_text_as_signed_maori_version).
narrative_ontology:cs_drift_state('13ad2424-cb97-4d7a-98e1-e691c68f2110', contemporary_crown_sovereignty_doctrine, gap(practice_drift, severe, false)).
narrative_ontology:cs_created_at('13ad2424-cb97-4d7a-98e1-e691c68f2110', '').
narrative_ontology:cs_kernel_id(waitangi_sovereignty_allocation__rangatiratanga_reading, waitangi_sovereignty_allocation).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__rangatiratanga_reading, maori_iwi_hapu).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__rangatiratanga_reading, indigenous_sovereignty_movements).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__rangatiratanga_reading, crown_administrative_apparatus).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__rangatiratanga_reading, settler_colonial_interests).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Hold tino rangatiratanga (full authority) over ancestral lands, resources, and taonga under Article II of the Māori text. Their authority is not delegated from the Crown but inherent and retained. Exit would require abandoning claims to territories and resources that constitute their identity as tangata whenua. The reading vindicates their assertion that they never ceded sovereignty and that co-governance or independent governance structures are treaty obligations, not concessions.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, maori_iwi_hapu, beneficiary,
    organized, generational, identity_locked, national).

% Under this reading, possesses only kāwanatanga (governorship over settlers), not sovereignty over Māori or their territories. Must negotiate with iwi and hapū as co-equal authorities rather than exercise unilateral legislative supremacy. The constraint limits Crown jurisdiction to non-Māori populations and requires structural power-sharing arrangements. The Crown's exit option is constrained because abandoning governance functions would destabilize state legitimacy, but continuing under Westminster supremacy doctrine contradicts the treaty text this reading holds authoritative.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, crown_administrative_apparatus, payer,
    institutional, generational, constrained, national).

% Property rights and resource access claims rest on Crown sovereignty doctrine; under this reading those claims would require renegotiation with iwi and hapū holding rangatiratanga. Face potential restrictions on land use, resource extraction, and development where Māori authority is recognized. Exit is geographically mobile but economically costly where investment is sunk in contested territories.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, settler_colonial_interests, payer,
    powerful, biographical, mobile, national).

% The rangatiratanga reading provides doctrinal support for indigenous self-determination claims globally by demonstrating that treaty language can be read to retain rather than cede sovereignty. They benefit from the precedent value without direct jurisdiction over New Zealand governance.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, indigenous_sovereignty_movements, beneficiary,
    organized, generational, identity_locked, global).

% Adjudicates competing treaty interpretations and determines which reading governs specific disputes. Can recognize rangatiratanga in particular contexts without fully displacing Crown sovereignty doctrine. The tribunal operates within Crown-established legal structures while examining claims that challenge those structures' legitimacy.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, treaty_tribunal_judiciary, observer,
    institutional, generational, analytical, national).

% Analyze the textual and structural evidence for competing readings. Document that the Māori and English treaty texts contain materially different sovereignty allocations, that tino rangatiratanga and kāwanatanga are not synonyms, and that treating the English text as authoritative when signed by Māori chiefs reading the Māori text raises foundational legitimacy questions.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, constitutional_scholars, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes the foundational allocation of authority between Crown and Māori under the Treaty of Waitangi, solving the coordination problem of defining legitimate jurisdiction over territories, resources, and peoples.
% TRANSFER_FUNCTION: Under this reading, no sovereignty transfer occurred; Māori retained tino rangatiratanga while granting only limited kāwanatanga over settlers. The contested transfer is the Crown's subsequent assumption of full sovereignty, which this reading treats as unauthorized rather than treaty-based.
% ABSENT_VOICES: Iwi and hapū who signed the Māori text understanding they retained rangatiratanga were structurally excluded from the English-text interpretation that became Crown constitutional doctrine. Their understanding of what they signed was overridden by a text version they did not authorize.
% DISAPPEARANCE_RATIONALE: If this reading's authority allocation were suddenly recognized as legally operative, New Zealand's constitutional structure would fundamentally reorganize: Parliament's legislative supremacy over Māori territories would dissolve, co-governance institutions would become mandatory rather than discretionary, resource management frameworks would require iwi and hapū consent, and the Crown would govern only non-Māori populations unless explicitly authorized otherwise. The entire post-colonial state apparatus rests on rejecting this reading.
% FOUNDING_PROBLEM: Pre-treaty, no agreed framework existed for Crown-Māori relations or settler governance, creating jurisdictional uncertainty and potential for violent conflict over land and authority. The treaty was negotiated to establish legitimate governance structures.
% FOUNDING_PROBLEM_CORROBORATION: Historical record from outside benefiting parties: missionary witnesses documented that Māori chiefs were assured they retained mana and authority over their lands when signing; linguistic analysis by scholars not affiliated with either Crown or iwi demonstrates tino rangatiratanga and sovereignty are not equivalent terms; international legal scholars examining treaty documents identify the textual divergence as a foundational unresolved contest over what was actually agreed. Crown and settler interests claim the founding problem is resolved by Crown sovereignty doctrine; Māori and indigenous rights advocates claim it remains live because the Māori text's terms were never implemented.
narrative_ontology:disappearance_verdict(waitangi_sovereignty_allocation__rangatiratanga_reading, world_rearranges).
narrative_ontology:founding_problem_status(waitangi_sovereignty_allocation__rangatiratanga_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(waitangi_sovereignty_allocation__rangatiratanga_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(waitangi_sovereignty_allocation__rangatiratanga_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(waitangi_sovereignty_allocation__rangatiratanga_reading_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, ExtMetricName, E),
    domain_priors:suppression_score(waitangi_sovereignty_allocation__rangatiratanga_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(waitangi_sovereignty_allocation__rangatiratanga_reading),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(waitangi_sovereignty_allocation__rangatiratanga_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is low (0.23) because this reading describes a constitutional allocation, not a rent-collection mechanism—the constraint establishes who holds what authority, and while the Crown's assumption of unilateral sovereignty extracted authority from Māori, the reading itself is the treaty text's allocation rather than the extraction. Suppression is moderate (0.41) because maintaining Crown sovereignty doctrine against this reading requires active legal and institutional work to treat the English text as authoritative despite Māori signatories not reading English. Theater is low (0.18) because the constitutional machinery operates functionally even while contested—courts adjudicate, Parliament legislates—but growing acknowledgment of the textual divergence creates performative gestures toward partnership without structural power-sharing. Accessibility collapse is high (0.71) because once the textual evidence is examined, the fact that two different sovereignty allocations exist in the two treaty versions is not interpretively escapable, though which text should govern remains contested. Resistance is high (0.67) because the Crown and settler interests actively resist full recognition of rangatiratanga through constitutional doctrine, legislative supremacy, and institutional inertia. The measurements track slow accumulation of extractiveness and suppression as the gap between treaty text and constitutional practice becomes harder to maintain.
 *
 * PERSPECTIVAL GAP:
 *   From the Māori beneficiary seat, this reading is the treaty's plain text and the foundation of legitimate authority—a constitutional fact that Crown institutions refuse to implement. From the Crown institutional seat, recognizing this reading would dissolve parliamentary supremacy and destabilize governance structures built over 180 years—the same text appears as an existential threat to constitutional order. From the settler seat, the reading threatens property security. From the analytical seat, the textual divergence is a documented historical fact and the contest over which text governs is the unresolved founding problem of New Zealand's constitutional legitimacy. The engine should compute these seats differently because the structural relationships to the constraint diverge sharply despite all parties reading the same treaty texts.
 *
 * DIRECTIONALITY LOGIC:
 *   Māori iwi and hapū are structural beneficiaries under this reading—it vindicates their never-ceded sovereignty and grounds claims to co-governance and resource authority. Their exit is identity-locked because abandoning the claim means accepting dispossession as legitimate. Crown administrative apparatus and settler colonial interests are structural payers—the reading constrains Crown jurisdiction and destabilizes property rights grounded in sovereignty doctrine. Their extraction comes from authority they claim but that this reading treats as unauthorized. Indigenous sovereignty movements benefit globally from precedent without bearing costs. Observers (tribunal, scholars) analyze from analytical seats.
 *
 * MANDATROPHY ANALYSIS:
 *   This is not mandatrophy—the founding problem (establishing legitimate governance framework) remains live because the treaty's actual terms were never implemented as the Māori text specified. The rangatiratanga reading does not describe a function that outlived its purpose; it describes a constitutional allocation that was textually agreed but institutionally overridden. The Crown sovereignty reading, by contrast, would treat the founding problem as resolved, making contestation over which reading governs the mandatrophy question itself—whether the treaty established what it says it established, or whether subsequent Crown practice superseded it.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    textual_authority_ambiguity,
    'When a treaty exists in two languages with materially different sovereignty allocations, and the indigenous signatories signed the version in their language, which text governs?',
    'International law principles (contra proferentem, indigenous interpretation preference) would favor the Māori text; domestic constitutional doctrine has favored the English text. Resolution requires either judicial/legislative recognition of Māori text authority or international tribunal ruling.',
    'If the Māori text governs, the rangatiratanga reading becomes the authoritative constitutional allocation and Crown sovereignty doctrine loses its treaty foundation. If the English text governs despite Māori signatories not reading it, the treaty''s consent basis is undermined but existing constitutional structures persist.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(textual_authority_ambiguity, conceptual, 'Which treaty text has constitutional authority when they differ materially.').

omega_variable(
    natural_law_vs_constructed_authority,
    'Is the rangatiratanga allocation a natural/inherent feature of indigenous sovereignty that the treaty recognized, or a constructed allocation that the treaty created and that subsequent practice can revise?',
    'Depends on whether indigenous sovereignty is treated as pre-existing and inalienable (natural law reading) or as treaty-dependent (legal positivist reading). The rangatiratanga reading itself treats Māori authority as inherent and retained, not granted.',
    'If inherent, Māori authority exists independently of Crown recognition and the treaty merely acknowledged it—making Crown sovereignty assertion unauthorized. If treaty-created, then treaty interpretation or subsequent practice can modify the allocation—making the sovereignty contest a legal rather than natural-law question.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(natural_law_vs_constructed_authority, conceptual, 'Whether the constraint describes inherent indigenous authority or treaty-constructed allocation.').

omega_variable(
    rangatiratanga_institutional_form,
    'What institutional structures would operationalize tino rangatiratanga under contemporary conditions—full independent sovereignty, co-governance arrangements, or iwi/hapū autonomy within Crown jurisdiction?',
    'Negotiation between Crown and iwi/hapū, guided by treaty tribunal recommendations and international indigenous rights precedents. The rangatiratanga reading itself does not specify modern institutional form, only the authority allocation principle.',
    'Different institutional interpretations of rangatiratanga would have vastly different constitutional implications: full independence would dissolve the New Zealand state''s claim over Māori territories; co-governance would require constitutional restructuring; autonomy arrangements would preserve Crown sovereignty while recognizing Māori authority. All three claim grounding in the same treaty text.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(rangatiratanga_institutional_form, preference, 'What institutional form tino rangatiratanga takes in a contemporary constitutional framework.').

omega_variable(
    beneficiary_identification_mountain,
    'If the rangatiratanga allocation is a foundational constitutional fact (mountain), why does it have clearly identifiable beneficiaries and victims rather than applying neutrally to all parties?',
    'FSM evaluation: the constraint is claimed as mountain (foundational treaty text allocation) but shows structural beneficiary/victim asymmetry. Resolution depends on whether constitutional allocations can be mountains when they distribute authority asymmetrically, or whether beneficiary presence always indicates constructed rather than natural constraint.',
    'If foundational constitutional allocations are mountains despite beneficiary asymmetry, the rangatiratanga reading is a genuine mountain vindicating Māori authority claims. If beneficiary presence indicates construction, the reading is better understood as tangled_rope or scaffold—a contested allocation serving identifiable interests. The FSM signature will test this.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(beneficiary_identification_mountain, conceptual, 'Whether a constitutional allocation claimed as foundational can be a mountain when it benefits identifiable parties.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(waitangi_sovereignty_allocation__rangatiratanga_reading, 0, 30).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(wait_tr_t0, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 0, 0.12).
narrative_ontology:measurement_basis(wait_tr_t0, observed).
narrative_ontology:measurement(wait_tr_t6, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 6, 0.13).
narrative_ontology:measurement_basis(wait_tr_t6, observed).
narrative_ontology:measurement(wait_tr_t12, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 12, 0.15).
narrative_ontology:measurement_basis(wait_tr_t12, observed).
narrative_ontology:measurement(wait_tr_t18, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 18, 0.16).
narrative_ontology:measurement_basis(wait_tr_t18, observed).
narrative_ontology:measurement(wait_tr_t24, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 24, 0.17).
narrative_ontology:measurement_basis(wait_tr_t24, observed).
narrative_ontology:measurement(wait_tr_t30, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 30, 0.18).
narrative_ontology:measurement_basis(wait_tr_t30, observed).

% Extraction over time
narrative_ontology:measurement(wait_be_t0, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 0, 0.18).
narrative_ontology:measurement_basis(wait_be_t0, observed).
narrative_ontology:measurement(wait_be_t6, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 6, 0.19).
narrative_ontology:measurement_basis(wait_be_t6, observed).
narrative_ontology:measurement(wait_be_t12, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 12, 0.2).
narrative_ontology:measurement_basis(wait_be_t12, observed).
narrative_ontology:measurement(wait_be_t18, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 18, 0.21).
narrative_ontology:measurement_basis(wait_be_t18, observed).
narrative_ontology:measurement(wait_be_t24, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 24, 0.22).
narrative_ontology:measurement_basis(wait_be_t24, observed).
narrative_ontology:measurement(wait_be_t30, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 30, 0.23).
narrative_ontology:measurement_basis(wait_be_t30, observed).

% Suppression requirement over time
narrative_ontology:measurement(wait_su_t0, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 0, 0.32).
narrative_ontology:measurement_basis(wait_su_t0, observed).
narrative_ontology:measurement(wait_su_t6, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 6, 0.35).
narrative_ontology:measurement_basis(wait_su_t6, observed).
narrative_ontology:measurement(wait_su_t12, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 12, 0.37).
narrative_ontology:measurement_basis(wait_su_t12, observed).
narrative_ontology:measurement(wait_su_t18, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 18, 0.38).
narrative_ontology:measurement_basis(wait_su_t18, observed).
narrative_ontology:measurement(wait_su_t24, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 24, 0.4).
narrative_ontology:measurement_basis(wait_su_t24, observed).
narrative_ontology:measurement(wait_su_t30, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 30, 0.41).
narrative_ontology:measurement_basis(wait_su_t30, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(waitangi_sovereignty_allocation__rangatiratanga_reading, enforcement_mechanism).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__rangatiratanga_reading, waitangi_sovereignty_allocation__crown_sovereignty_reading).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__rangatiratanga_reading, waitangi_sovereignty_allocation__partnership_reading).

% DUAL FORMULATION NOTE:
% This constraint is one of three readings of the waitangi_sovereignty_allocation kernel. The rangatiratanga reading holds the Māori treaty text retained full Māori authority while granting Crown only limited governorship over settlers. The crown_sovereignty reading holds the English text ceded complete sovereignty to Crown. The partnership reading holds the treaty established ongoing partnership despite textual ambiguity. All three readings claim grounding in the same 1840 treaty signing but produce different constitutional implications because the English and Māori texts allocated sovereignty differently. The readings are linked as a constraint family because they address the same founding document's authority allocation, but each instantiates a distinct constraint with different beneficiary/victim structures and different ε values. The network edges model that the rangatiratanga reading influences both siblings by providing textual evidence that contests their claims, though all three coexist as live constitutional interpretations held by different institutional and community actors.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
