% ============================================================================
% CONSTRAINT STORY: woman_category__gender_identity_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-12
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_woman_category__gender_identity_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: woman_category__gender_identity_reading
 *   human_readable: Woman Category Membership via Gender Identity Reading
 *   domain: political_philosophy/law/social_policy/bioethics
 *
 * SUMMARY:
 *   This constraint instantiates the gender identity reading of
 *   woman-category membership: 'woman' means anyone who identifies as a
 *   woman, regardless of sex assigned at birth. It is one of three
 *   structurally distinct readings of the same contested kernel. The sex
 *   biology reading (sibling) treats 'woman' as grounded in chromosomal and
 *   reproductive biology; the intersex accommodation reading (sibling)
 *   acknowledges biological sex variation while maintaining sex as the
 *   operative category. This reading displaces biological sex with subjective
 *   identity as the determinative criterion for legal and social
 *   categorization. KEY AGENTS (by structural relationship): -
 *   transgender_women: Primary beneficiaries (organized/identity_locked) —
 *   gain legal recognition and access -
 *   gender_identity_advocacy_organizations: Agenda setters
 *   (institutional/mobile) — draft policy, coordinate adoption -
 *   sex_based_protection_advocates: Payers (organized/constrained) — lose
 *   standing for sex-based accommodations - competitive_female_athletes:
 *   Payers (moderate/constrained) — compete against male-typical physiology -
 *   women_seeking_sex_segregated_services: Payers (powerless/trapped) — lose
 *   access to female-only spaces - medical_and_research_institutions:
 *   Observers (institutional/analytical) — study long-term policy effects
 *
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(woman_category__gender_identity_reading, 0.68).
domain_priors:suppression_score(woman_category__gender_identity_reading, 0.72).
domain_priors:theater_ratio(woman_category__gender_identity_reading, 0.31).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, extractiveness, 0.68).
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, suppression_requirement, 0.72).
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, theater_ratio, 0.31).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, accessibility_collapse, 0.42).
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, resistance, 0.78).

% --- Constraint claim ---
narrative_ontology:constraint_claim(woman_category__gender_identity_reading, mountain).
narrative_ontology:human_readable(woman_category__gender_identity_reading, "Woman Category Membership via Gender Identity Reading").
narrative_ontology:topic_domain(woman_category__gender_identity_reading, "political_philosophy/law/social_policy/bioethics").

domain_priors:requires_active_enforcement(woman_category__gender_identity_reading).
domain_priors:emerges_naturally(woman_category__gender_identity_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(woman_category__gender_identity_reading, 'dc0cc187-dd95-4019-83c2-325fd0a17819').
narrative_ontology:cs_kernel_codification('dc0cc187-dd95-4019-83c2-325fd0a17819', distributed).
narrative_ontology:cs_authority_grounding('dc0cc187-dd95-4019-83c2-325fd0a17819', distributed).
narrative_ontology:cs_reading_relation('dc0cc187-dd95-4019-83c2-325fd0a17819', woman_category__sex_biology_reading, coexists_with).
narrative_ontology:cs_reading_relation('dc0cc187-dd95-4019-83c2-325fd0a17819', woman_category__intersex_accommodation_reading, coexists_with).
narrative_ontology:cs_axiom('dc0cc187-dd95-4019-83c2-325fd0a17819', foundational, identity_determines_category_membership).
narrative_ontology:cs_axiom_status(identity_determines_category_membership, holdable).
narrative_ontology:cs_axiom_grounding('dc0cc187-dd95-4019-83c2-325fd0a17819', identity_determines_category_membership, deontological).
narrative_ontology:cs_axiom('dc0cc187-dd95-4019-83c2-325fd0a17819', secondary, sex_based_exclusion_is_discriminatory).
narrative_ontology:cs_axiom_status(sex_based_exclusion_is_discriminatory, holdable).
narrative_ontology:cs_axiom_grounding('dc0cc187-dd95-4019-83c2-325fd0a17819', sex_based_exclusion_is_discriminatory, deontological).
narrative_ontology:cs_reference_frame('dc0cc187-dd95-4019-83c2-325fd0a17819', binary_sex_category_framework).
narrative_ontology:cs_drift_state('dc0cc187-dd95-4019-83c2-325fd0a17819', contemporary_identity_rights_era, gap(repudiation_pressure, substantial, true)).
narrative_ontology:cs_created_at('dc0cc187-dd95-4019-83c2-325fd0a17819', '').
narrative_ontology:cs_kernel_id(woman_category__gender_identity_reading, woman_category).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(woman_category__gender_identity_reading, transgender_women).
narrative_ontology:constraint_beneficiary(woman_category__gender_identity_reading, gender_identity_advocacy_organizations).
narrative_ontology:constraint_beneficiary(woman_category__gender_identity_reading, legal_equality_framework_proponents).
narrative_ontology:constraint_victim(woman_category__gender_identity_reading, sex_based_protection_advocates).
narrative_ontology:constraint_victim(woman_category__gender_identity_reading, competitive_female_athletes).
narrative_ontology:constraint_victim(woman_category__gender_identity_reading, women_seeking_sex_segregated_services).
narrative_ontology:constraint_vindicates(woman_category__gender_identity_reading, gender_self_identification_doctrine).
narrative_ontology:constraint_vindicates(woman_category__gender_identity_reading, anti_discrimination_via_identity_inclusion).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Gain legal recognition as women, access to women's spaces and services, protection under sex discrimination law when their gender identity is the operative criterion. Identity-locked because their core self-understanding depends on this categorization framework being recognized as legitimate; alternatives that exclude them require denying their own identity.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, transgender_women, beneficiary,
    organized, biographical, identity_locked, national).

% Set policy agendas in legal frameworks, educational institutions, healthcare systems. Draft model legislation treating gender identity as the protected category. Coordinate political pressure for institutional adoption of identity-based definitions. Their institutional funding and political influence depend on this framework prevailing.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, gender_identity_advocacy_organizations, agenda_setter,
    institutional, generational, mobile, national).

% Incorporate gender identity protections into broader anti-discrimination legal architecture. Benefit from coherent equality doctrine that treats identity claims as determinative; this reading resolves doctrinal ambiguity in their favor and expands their jurisdiction over identity-based claims.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, legal_equality_framework_proponents, beneficiary,
    institutional, generational, mobile, national).
narrative_ontology:stakeholder_secondary_role(woman_category__gender_identity_reading, legal_equality_framework_proponents, agenda_setter).

% Lose legal standing for sex-based accommodations when gender identity supplants biological sex as the operative category. Their advocacy for protections grounded in reproductive biology or sexed embodiment is recharacterized as discriminatory exclusion. Constrained exit because they cannot maintain sex-based protections while also accepting identity-based category membership.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, sex_based_protection_advocates, payer,
    organized, generational, constrained, national).

% Compete in female categories now open to athletes with male-typical physiology who identify as women. Argue that sex-linked physical advantages persist regardless of identity and that category membership should track performance-relevant biology. Their complaints are reframed as transphobic exclusion rather than competitive fairness concerns. Exit is constrained because leaving the sport means abandoning their athletic careers.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, competitive_female_athletes, payer,
    moderate, biographical, constrained, national).

% Use services like domestic violence shelters, prisons, changing rooms where sex segregation was historically grounded in vulnerability to male violence or privacy from male-bodied people. Under this reading, requesting a female-only space becomes discriminatory if it excludes transgender women. Trapped because alternative services are scarce or nonexistent and objecting to the policy results in being denied service or labeled bigoted.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, women_seeking_sex_segregated_services, payer,
    powerless, biographical, trapped, local).

% Implement gender identity policies in schools, workplaces, healthcare, prisons. Navigate conflicting access rights: transgender women's claim to inclusion vs natal women's claim to sex-segregated spaces. Constrained because refusing to adopt identity-based policies exposes institutions to legal liability under discrimination law, while adopting them generates resistance from those who experience the policy as imposed.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, institutional_policy_administrators, agenda_setter,
    institutional, biographical, constrained, national).

% Study the relationship between biological sex, gender identity, and health outcomes. Face pressure to adopt identity-based language in research and clinical practice even when biological sex is the relevant variable. Track long-term effects of identity-based categorization policies on population health data quality.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, medical_and_research_institutions, observer,
    institutional, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a single consistent legal and social definition of 'woman' that includes transgender women, enabling coherent anti-discrimination enforcement and identity document administration across institutions.
% TRANSFER_FUNCTION: Moves legal recognition, institutional access, and protected-class status from being allocated by biological sex markers to being allocated by self-identified gender, transferring authority over category boundaries from embodied biology to subjective identity.
% ABSENT_VOICES: Women who experience sex-based oppression grounded in their reproductive biology and who argue that gender identity and biological sex are distinct categories with different policy implications are increasingly excluded from institutional policy discussions as transphobic. Their experiential knowledge of sex-based vulnerability is recharacterized as discriminatory exclusion rather than legitimate material concern.
% DISAPPEARANCE_RATIONALE: If this categorization framework disappeared overnight, transgender women would lose legal recognition in many jurisdictions, identity documents would revert to sex-based markers, access to sex-segregated spaces would reorganize around biological criteria, sports eligibility rules would shift, and anti-discrimination law would fracture over whether gender identity or biological sex is the protected category. Institutions would face immediate policy crises over conflicting access rights.
% FOUNDING_PROBLEM: Transgender individuals faced legal non-recognition, institutional exclusion, and lack of protection under sex discrimination law when their gender identity differed from their sex assigned at birth.
% FOUNDING_PROBLEM_CORROBORATION: Gender identity advocacy organizations attest the problem is ongoing and requires identity-based legal frameworks for resolution. Legal scholars and medical institutions outside the advocacy coalition acknowledge historical discrimination but dispute whether identity-based category membership is the only remedy or whether it creates new conflicts with sex-based rights. Feminist legal theorists and women's sports governing bodies argue that conflating sex and gender identity erases sex-based protections that address materially distinct harms.
narrative_ontology:disappearance_verdict(woman_category__gender_identity_reading, world_rearranges).
narrative_ontology:founding_problem_status(woman_category__gender_identity_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(woman_category__gender_identity_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(woman_category__gender_identity_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(woman_category__gender_identity_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(woman_category__gender_identity_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(woman_category__gender_identity_reading, ExtMetricName, E),
    domain_priors:suppression_score(woman_category__gender_identity_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(woman_category__gender_identity_reading),
    narrative_ontology:constraint_metric(woman_category__gender_identity_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(woman_category__gender_identity_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(woman_category__gender_identity_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is substantial (0.68) because the framework imposes costs on those seeking sex-based protections while concentrating benefits on identity-claimants and advocacy organizations; the costs are not coordination overhead but reallocation of category access rights. Suppression is high (0.72) because dissent from the identity framework is institutionally penalized as discriminatory — objecting to the policy in workplaces, schools, or service settings results in sanctions, not dialogue. Theater ratio is moderate-low (0.31): genuine anti-discrimination work occurs, but a growing share of enforcement activity targets speech and boundary-maintenance rather than material discrimination. Accessibility collapse is moderate (0.42) because alternative frameworks (sex-based categorization, intersex accommodation) remain conceptually coherent and are held by substantial populations, though institutionally suppressed. Resistance is high (0.78) because the framework meets organized opposition from feminists, competitive athletes, religious communities, and parents — resistance that the framework's proponents treat as evidence of bigotry rather than legitimate disagreement. The measurements show accumulating extraction and suppression over the interval as the framework consolidates institutional power.
 *
 * PERSPECTIVAL GAP:
 *   From the beneficiary seats (transgender women, advocacy organizations), this constraint is a civil rights achievement correcting historical exclusion — it is experienced as foundational moral progress, not extraction. From the payer seats (sex-based protection advocates, female athletes, women seeking sex-segregated spaces), the same structure operates as enforced displacement of sex-based protections by a framework that treats their material concerns as illegitimate. The engine computes this divergence from the structural data; the authored mountain claim reflects the beneficiary seat's framing, while the metrics describe the constraint's actual operation across all seats.
 *
 * DIRECTIONALITY LOGIC:
 *   Transgender women are structural beneficiaries with identity-locked exit — their self-understanding depends on this framework being recognized. Gender identity advocacy organizations are agenda setters who benefit institutionally but retain mobile exit. Sex-based protection advocates, competitive female athletes, and women seeking sex-segregated services are targets who bear costs through loss of category boundaries they depended on; their exit options range from constrained (can't maintain prior protections while accepting this framework) to trapped (no alternative services, sanctions for objecting). Institutional policy administrators are caught between conflicting access-rights claims, implementing the policy under legal threat. The directionality computation should produce low d for transgender women (beneficiaries with identity-locked exit), moderate d for advocacy organizations (beneficiaries with mobile exit), and high d for the three payer groups (targets with constrained-to-trapped exit).
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint's mandate (legal recognition and anti-discrimination protection for transgender individuals) has not outlived its function from the beneficiary perspective, but the victim seats argue that the specific mechanism (identity-supplants-sex-as-category-criterion) imposes costs that exceed coordination necessity. Alternative frameworks exist: legal recognition of transgender status as a distinct protected category without collapsing it into the woman category, or third-category accommodations. The framework's persistence in its current form despite these alternatives, and despite substantial resistance, suggests the arrangement benefits those who control category-definition authority more than a pure coordination account would predict.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    natural_category_vs_social_construct,
    'Is gender identity a natural, foundational feature of human psychology that grounds category membership (as the mountain claim asserts), or is it a social construct whose institutional enforcement benefits identifiable parties at others'' expense?',
    'Longitudinal studies of gender identity stability, cross-cultural invariance, and developmental trajectories; analysis of whether institutional adoption tracks evidence of naturalness or political pressure from advocacy organizations; comparison of policy outcomes in jurisdictions that recognize gender identity vs those that maintain sex-based categories.',
    'If gender identity is foundational and invariant, the mountain classification is vindicated and resistance is mere prejudice. If it is socially constructed and its institutional primacy correlates with advocacy organization influence rather than evidence, the constraint is better understood as tangled_rope or snare — coordination (anti-discrimination) layered with extraction (displacement of sex-based protections to benefit identity-claimants and their institutional advocates).',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(natural_category_vs_social_construct, empirical, 'Whether gender identity is a natural category or a politically enforced construct.').

omega_variable(
    sex_vs_identity_separability,
    'Are biological sex and gender identity separable categories with distinct policy implications, or must legal and social recognition collapse them into a single identity-based framework?',
    'Natural experiments from jurisdictions that recognize transgender identity as a protected category without redefining ''woman'' to include all who identify as such; analysis of whether anti-discrimination goals and sex-based protections can coexist or whether one necessarily displaces the other.',
    'If separable, the framework''s conflation of sex and identity is a policy choice benefiting some parties over others, not a logical necessity — the extraction component is removable. If inseparable, the collision between access rights and exclusion rights is inherent to recognition itself, and the constraint''s costs are the unavoidable price of inclusion.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(sex_vs_identity_separability, conceptual, 'Whether sex and identity must be collapsed or can be maintained as distinct categories.').

omega_variable(
    alternative_frameworks_suppression,
    'Are alternative frameworks (sex-based categorization, third-category accommodation, intersex-spectrum models) suppressed because they are incoherent or discriminatory, or because they threaten the institutional authority of gender identity advocacy organizations?',
    'Content analysis of institutional policy discussions: are alternative frameworks engaged substantively or dismissed as inherently bigoted? Comparison of suppression mechanisms (legal penalties, employment sanctions, social ostracism) applied to advocates of alternative frameworks vs advocates of this reading.',
    'If alternatives are suppressed for principled reasons, the high suppression score reflects legitimate boundary enforcement. If alternatives are suppressed to protect institutional authority despite their coherence, the suppression is extractive rather than functional — evidence of snare rather than mountain.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(alternative_frameworks_suppression, empirical, 'Whether suppression of alternative frameworks is principled or extractive.').

omega_variable(
    committer_frame_sex_biology,
    'How would the structural relationship between this reading and the sex_biology_reading be characterized: does this reading foreclose biological sex as a criterion (making them mutually exclusive), coexist with it (different parties holding different readings), or influence it (creating downstream pressure on sex-based frameworks)?',
    'Analysis of institutional implementation: do jurisdictions that adopt identity-based definitions also eliminate sex-based protections, or do both frameworks coexist with jurisdictional boundaries? Does adoption of this reading in one domain (identity documents) create political or legal pressure to extend it to other domains (sports, prisons, healthcare)?',
    'If this reading forecloses sex-based categorization, the omega resolves to structural displacement — one reading''s institutional victory necessarily eliminates the other. If they coexist, the contest is observer-level disagreement across jurisdictions. If this reading influences the sex_biology_reading by eroding its legitimacy or funding without logically eliminating it, the relationship is asymmetric institutional pressure.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(committer_frame_sex_biology, conceptual, 'The structural relationship between identity-based and sex-based readings of the woman category.').

omega_variable(
    committer_frame_intersex_accommodation,
    'How would the structural relationship between this reading and the intersex_accommodation_reading be characterized: does this reading foreclose biological-sex-spectrum models, coexist with them, or influence them?',
    'Examination of whether intersex advocacy and transgender advocacy align or diverge in policy demands; analysis of whether recognizing biological sex variation (intersex spectrum) strengthens or weakens claims for identity-based category membership.',
    'If this reading coexists with intersex accommodation (both recognize non-binary realities but via different mechanisms), the conflict is between two inclusion frameworks and extraction is lower. If this reading forecloses intersex-spectrum models by treating all non-binary experience as gender identity rather than biological variation, it displaces an alternative inclusion path and extraction is higher.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(committer_frame_intersex_accommodation, conceptual, 'The structural relationship between identity-based reading and biological-spectrum reading.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(woman_category__gender_identity_reading, 0, 20).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(woma_tr_t0, woman_category__gender_identity_reading, theater_ratio, 0, 0.12).
narrative_ontology:measurement_basis(woma_tr_t0, observed).
narrative_ontology:measurement(woma_tr_t5, woman_category__gender_identity_reading, theater_ratio, 5, 0.18).
narrative_ontology:measurement_basis(woma_tr_t5, observed).
narrative_ontology:measurement(woma_tr_t10, woman_category__gender_identity_reading, theater_ratio, 10, 0.23).
narrative_ontology:measurement_basis(woma_tr_t10, observed).
narrative_ontology:measurement(woma_tr_t15, woman_category__gender_identity_reading, theater_ratio, 15, 0.28).
narrative_ontology:measurement_basis(woma_tr_t15, observed).
narrative_ontology:measurement(woma_tr_t20, woman_category__gender_identity_reading, theater_ratio, 20, 0.31).
narrative_ontology:measurement_basis(woma_tr_t20, observed).

% Extraction over time
narrative_ontology:measurement(woma_be_t0, woman_category__gender_identity_reading, base_extractiveness, 0, 0.38).
narrative_ontology:measurement_basis(woma_be_t0, observed).
narrative_ontology:measurement(woma_be_t5, woman_category__gender_identity_reading, base_extractiveness, 5, 0.47).
narrative_ontology:measurement_basis(woma_be_t5, observed).
narrative_ontology:measurement(woma_be_t10, woman_category__gender_identity_reading, base_extractiveness, 10, 0.56).
narrative_ontology:measurement_basis(woma_be_t10, observed).
narrative_ontology:measurement(woma_be_t15, woman_category__gender_identity_reading, base_extractiveness, 15, 0.63).
narrative_ontology:measurement_basis(woma_be_t15, observed).
narrative_ontology:measurement(woma_be_t20, woman_category__gender_identity_reading, base_extractiveness, 20, 0.68).
narrative_ontology:measurement_basis(woma_be_t20, observed).

% Suppression requirement over time
narrative_ontology:measurement(woma_su_t0, woman_category__gender_identity_reading, suppression_requirement, 0, 0.45).
narrative_ontology:measurement_basis(woma_su_t0, observed).
narrative_ontology:measurement(woma_su_t5, woman_category__gender_identity_reading, suppression_requirement, 5, 0.54).
narrative_ontology:measurement_basis(woma_su_t5, observed).
narrative_ontology:measurement(woma_su_t10, woman_category__gender_identity_reading, suppression_requirement, 10, 0.62).
narrative_ontology:measurement_basis(woma_su_t10, observed).
narrative_ontology:measurement(woma_su_t15, woman_category__gender_identity_reading, suppression_requirement, 15, 0.68).
narrative_ontology:measurement_basis(woma_su_t15, observed).
narrative_ontology:measurement(woma_su_t20, woman_category__gender_identity_reading, suppression_requirement, 20, 0.72).
narrative_ontology:measurement_basis(woma_su_t20, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(woman_category__gender_identity_reading, identity_coordination).
narrative_ontology:affects_constraint(woman_category__gender_identity_reading, woman_category__sex_biology_reading).
narrative_ontology:affects_constraint(woman_category__gender_identity_reading, woman_category__intersex_accommodation_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the woman_category kernel. The three readings (gender_identity_reading, sex_biology_reading, intersex_accommodation_reading) decompose a single natural-language concept ('woman') into structurally distinct constraints with different ε profiles and victim sets. The gender_identity_reading has moderate ε in administrative domains and high ε in access-rights collision domains; the sex_biology_reading has lower ε in institutional simplicity but higher ε in transgender exclusion; the intersex_accommodation_reading has moderate ε across domains while maintaining biological sex as operative. Network links preserve the constraint family structure per the ε-invariance principle.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
