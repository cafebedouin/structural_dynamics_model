% ============================================================================
% CONSTRAINT STORY: acceptable_risk_energy__catastrophic_tail_dominant
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_acceptable_risk_energy__catastrophic_tail_dominant, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: acceptable_risk_energy__catastrophic_tail_dominant
 *   human_readable: Catastrophic-Tail-Dominant Acceptable Risk Framework
 *   domain: risk_assessment/energy_policy/decision_theory
 *
 * SUMMARY:
 *   The catastrophic-tail-dominant reading of acceptable risk treats
 *   low-probability nuclear accidents as infinitely weighted relative to
 *   higher-probability aggregate harms from fossil fuel combustion. This
 *   reading emerged from 1970s-1980s nuclear opposition movements and became
 *   institutionalized in regulatory frameworks that require demonstrating
 *   nuclear safety to a standard no other energy source must meet. The
 *   constraint is CLAIMED as mountain (a foundational feature of risk
 *   perception under deep uncertainty) while the metrics describe
 *   substantially extractive operation with identifiable beneficiaries—the
 *   divergence is the measurement.
 *
 * KEY AGENTS:
 *   - anti_nuclear_advocacy_coalitions: Primary agenda-setter (organized/mobile) — maintains catastrophic framing through public pressure and regulatory testimony
 *   - fossil_fuel_industry: Structural beneficiary (institutional/constrained) — extends market share through nuclear suppression without directly setting risk framework
 *   - climate_vulnerable_populations: Primary victim (powerless/trapped) — bears aggregate harm from delayed decarbonization
 *   - air_quality_impacted_communities: Secondary victim (powerless/trapped) — ongoing mortality from fossil baseload continuation
 *   - risk_assessment_economists: Excluded voice (moderate/mobile) — expected-value frameworks structurally excluded from acceptable risk determination
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(acceptable_risk_energy__catastrophic_tail_dominant, 0.68).
domain_priors:suppression_score(acceptable_risk_energy__catastrophic_tail_dominant, 0.79).
domain_priors:theater_ratio(acceptable_risk_energy__catastrophic_tail_dominant, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, extractiveness, 0.68).
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 0.79).
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, accessibility_collapse, 0.71).
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, resistance, 0.58).

% --- Constraint claim ---
narrative_ontology:constraint_claim(acceptable_risk_energy__catastrophic_tail_dominant, mountain).
narrative_ontology:human_readable(acceptable_risk_energy__catastrophic_tail_dominant, "Catastrophic-Tail-Dominant Acceptable Risk Framework").
narrative_ontology:topic_domain(acceptable_risk_energy__catastrophic_tail_dominant, "risk_assessment/energy_policy/decision_theory").

domain_priors:requires_active_enforcement(acceptable_risk_energy__catastrophic_tail_dominant).
domain_priors:emerges_naturally(acceptable_risk_energy__catastrophic_tail_dominant).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(acceptable_risk_energy__catastrophic_tail_dominant, '7eef7d3e-09c0-4391-b176-74b45ef04d8b').
narrative_ontology:cs_kernel_codification('7eef7d3e-09c0-4391-b176-74b45ef04d8b', distributed).
narrative_ontology:cs_authority_grounding('7eef7d3e-09c0-4391-b176-74b45ef04d8b', distributed).
narrative_ontology:cs_reading_relation('7eef7d3e-09c0-4391-b176-74b45ef04d8b', acceptable_risk_energy__expected_value_dominant, coexists_with).
narrative_ontology:cs_reading_relation('7eef7d3e-09c0-4391-b176-74b45ef04d8b', acceptable_risk_energy__option_value_preserving, coexists_with).
narrative_ontology:cs_axiom('7eef7d3e-09c0-4391-b176-74b45ef04d8b', foundational, catastrophic_outcomes_infinitely_weighted).
narrative_ontology:cs_axiom_status(catastrophic_outcomes_infinitely_weighted, holdable).
narrative_ontology:cs_axiom_grounding('7eef7d3e-09c0-4391-b176-74b45ef04d8b', catastrophic_outcomes_infinitely_weighted, deontological).
narrative_ontology:cs_axiom('7eef7d3e-09c0-4391-b176-74b45ef04d8b', secondary, aggregate_harm_discountable_when_diffuse).
narrative_ontology:cs_axiom_status(aggregate_harm_discountable_when_diffuse, holdable).
narrative_ontology:cs_axiom_grounding('7eef7d3e-09c0-4391-b176-74b45ef04d8b', aggregate_harm_discountable_when_diffuse, conventional).
narrative_ontology:cs_reference_frame('7eef7d3e-09c0-4391-b176-74b45ef04d8b', post_chernobyl_precautionary_consensus).
narrative_ontology:cs_drift_state('7eef7d3e-09c0-4391-b176-74b45ef04d8b', contemporary_climate_emergency_era, gap(axiom_overriding, substantial, false)).
narrative_ontology:cs_created_at('7eef7d3e-09c0-4391-b176-74b45ef04d8b', '').
narrative_ontology:cs_kernel_id(acceptable_risk_energy__catastrophic_tail_dominant, acceptable_risk_energy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__catastrophic_tail_dominant, anti_nuclear_advocacy_coalitions).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__catastrophic_tail_dominant, fossil_fuel_industry).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__catastrophic_tail_dominant, incumbent_grid_operators).
narrative_ontology:constraint_victim(acceptable_risk_energy__catastrophic_tail_dominant, climate_vulnerable_populations).
narrative_ontology:constraint_victim(acceptable_risk_energy__catastrophic_tail_dominant, air_quality_impacted_communities).
narrative_ontology:constraint_victim(acceptable_risk_energy__catastrophic_tail_dominant, nuclear_technology_workforce).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__catastrophic_tail_dominant, precautionary_principle_supremacy).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__catastrophic_tail_dominant, catastrophic_risk_incommensurability).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Frame acceptable risk as requiring zero-tolerance for catastrophic nuclear accidents regardless of aggregate mortality comparisons. They maintain public pressure through imagery of Chernobyl and Fukushima, testify in regulatory hearings, and mobilize to block new nuclear construction permits. Their organizational continuity depends on sustaining the catastrophic framing.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, anti_nuclear_advocacy_coalitions, agenda_setter,
    organized, generational, mobile, national).

% Benefits structurally from nuclear suppression without actively setting the risk framework. Every year nuclear capacity is delayed or cancelled extends fossil baseload market share. They fund some advocacy indirectly but primarily benefit as the default alternative when nuclear is rejected on catastrophic-risk grounds.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, fossil_fuel_industry, beneficiary,
    institutional, biographical, constrained, global).

% Avoid the capital risk and regulatory complexity of nuclear while maintaining baseload revenue from existing fossil capacity. The catastrophic risk framework provides political cover for choosing the lower-capital-risk fossil pathway even when lifecycle mortality comparisons favor nuclear.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, incumbent_grid_operators, beneficiary,
    institutional, generational, constrained, regional).

% Bear the aggregate harm from delayed decarbonization when low-carbon baseload is suppressed. They experience rising climate impacts while energy policy debates fixate on nuclear accident scenarios. Their deaths are diffuse, statistically projected, and structurally discounted in the catastrophic framing.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, climate_vulnerable_populations, payer,
    powerless, generational, trapped, global).

% Live downwind of coal plants that continue operating because nuclear alternatives are rejected. They experience elevated respiratory disease and premature mortality—quantifiable, ongoing harm that is treated as acceptable background risk rather than catastrophe.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, air_quality_impacted_communities, payer,
    powerless, biographical, trapped, local).

% Trained for careers in a technology pathway that is systematically suppressed. They can transition to other engineering fields but their specialized expertise atrophies when no new plants are built. Their professional identity is constituted through nuclear engineering competence.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, nuclear_technology_workforce, payer,
    moderate, biographical, constrained, national).

% Produce mortality-per-TWh comparisons showing nuclear as safer than fossil in aggregate expected terms. Their analysis is systematically excluded from acceptable risk determinations when the framework assigns infinite weight to catastrophic scenarios. They testify but are not heard.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, risk_assessment_economists, excluded,
    moderate, biographical, mobile, national).

% Apply the catastrophic risk framework in licensing decisions. They receive competing risk assessments but operate under political mandates that encode catastrophic-tail dominance. They can observe the aggregate mortality trade-offs but cannot adjudicate between incommensurable risk framings.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, regulatory_authorities, observer,
    institutional, generational, analytical, national).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a shared framework for comparing energy pathway risks under deep uncertainty about rare catastrophic events, enabling collective decisions when probability distributions are contested.
% TRANSFER_FUNCTION: Moves policy space and capital investment away from nuclear baseload toward fossil incumbents, transferring aggregate mortality from visible catastrophic scenarios to diffuse ongoing harm borne by climate-vulnerable and air-quality-impacted populations.
% ABSENT_VOICES: Future generations who will bear compounding climate harm from delayed decarbonization, and risk-assessment economists whose expected-value frameworks are structurally excluded from the determination of acceptable risk.
% DISAPPEARANCE_RATIONALE: If the catastrophic-tail-dominant framework disappeared, energy policy would shift toward mortality-per-TWh optimization, nuclear licensing would accelerate in jurisdictions currently suppressing it, fossil incumbents would face stranded asset risk, and advocacy coalitions organized around nuclear opposition would lose their animating mandate.
% FOUNDING_PROBLEM: In the 1970s-1980s, societies needed a framework for assessing nuclear technology risks when probability estimates for core melt accidents were deeply uncertain and public trust in technocratic risk assessment was eroding after Three Mile Island.
% FOUNDING_PROBLEM_CORROBORATION: Anti-nuclear coalitions attest the founding problem remains live, citing Fukushima as evidence that catastrophic risk is irreducible. Risk economists and nuclear engineers attest the founding problem is solved—modern reactor designs have demonstrated safety records and probabilistic risk assessment has matured—but the framework persists as political economy. Independent energy system modeling from climate scientists and public health researchers supports the shifted-function reading: the aggregate mortality trade-off now decisively favors nuclear over fossil baseload, but policy remains locked in the catastrophic framing.
narrative_ontology:disappearance_verdict(acceptable_risk_energy__catastrophic_tail_dominant, world_rearranges).
narrative_ontology:founding_problem_status(acceptable_risk_energy__catastrophic_tail_dominant, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(acceptable_risk_energy__catastrophic_tail_dominant, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(acceptable_risk_energy__catastrophic_tail_dominant, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(acceptable_risk_energy__catastrophic_tail_dominant_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(acceptable_risk_energy__catastrophic_tail_dominant, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, ExtMetricName, E),
    domain_priors:suppression_score(acceptable_risk_energy__catastrophic_tail_dominant, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(acceptable_risk_energy__catastrophic_tail_dominant),
    narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(acceptable_risk_energy__catastrophic_tail_dominant_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is high (0.68) because the framework systematically transfers mortality from visible catastrophic scenarios to diffuse ongoing harm, benefiting fossil incumbents and nuclear opposition coalitions at the expense of climate-vulnerable and air-quality-impacted populations. The transfer is obscured by treating nuclear accidents as incommensurable with fossil deaths—a framing move rather than an empirical claim. Suppression is higher (0.79) because maintaining the framework requires actively suppressing nuclear licensing, excluding mortality-per-TWh analysis from policy discourse, and sustaining public catastrophic imagery despite improving safety records. Theater ratio (0.42) reflects the growing gap between the coordination narrative (managing deep uncertainty) and the actual function (defending fossil incumbency). Accessibility collapse (0.71) is substantial because once the catastrophic framing is adopted, alternative risk comparisons become illegible—expected-value arguments are dismissed as technocratic callousness. Resistance (0.58) comes from nuclear engineers, climate scientists, and some economists who maintain mortality-per-TWh analysis, but their resistance is structurally discounted.
 *
 * PERSPECTIVAL GAP:
 *   From the agenda-setter seat, this is a legitimate application of the precautionary principle under deep uncertainty—catastrophic risk genuinely differs from aggregate risk and requires different treatment. From the victim seats (climate-vulnerable, air-quality-impacted), the same framework operates as a transfer mechanism that makes their ongoing deaths invisible by treating them as acceptable background rather than catastrophe. From the excluded seat (risk economists), the framework is a rejection of commensurability that prevents rational comparison. The engine computes these divergent classifications from the structural data—the mountain claim does not adjudicate them.
 *
 * DIRECTIONALITY LOGIC:
 *   Agenda-setters (anti-nuclear coalitions) are positioned as beneficiaries of the framework's persistence—they collect organizational continuity and political influence from maintaining catastrophic focus. Fossil fuel industry and grid operators are structural beneficiaries without directly setting the framework—they gain market extension without bearing the coordination costs. Climate-vulnerable populations and air-quality-impacted communities are the primary victims—they bear the aggregate mortality that is discounted as non-catastrophic. The nuclear workforce is a secondary victim—career pathway suppression. Risk economists are excluded—their analytical frameworks are treated as categorically irrelevant to acceptable risk determination.
 *
 * MANDATROPHY ANALYSIS:
 *   The founding problem—how to assess nuclear risks under deep uncertainty in an era of eroding technocratic trust—was real. The catastrophic-tail-dominant framework initially served a coordination function by enabling collective decision-making when probability estimates were contested. But the framework has outlived its mandate: modern reactor designs have orders-of-magnitude lower accident probabilities, probabilistic risk assessment has matured, and the climate crisis has made the aggregate mortality trade-off between nuclear and fossil empirically decisive. The framework persists not because uncertainty remains irreducible but because it serves identifiable beneficiaries: fossil incumbents avoid stranded assets, grid operators avoid capital risk, advocacy coalitions maintain organizational identity. The measurement trajectory shows extraction accumulating as the gap between founding function and current operation widens.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    natural_vs_constructed_catastrophic_framing,
    'Is the infinite weighting of catastrophic nuclear risk relative to fossil aggregate harm a natural feature of human risk perception under deep uncertainty, or a constructed framing that benefits identifiable actors?',
    'Cross-cultural and cross-temporal comparison of risk frameworks: if catastrophic-tail dominance appears universally when probability estimates are uncertain, it is closer to natural. If it appears selectively in contexts where fossil incumbents have political influence and disappears when empirical safety records improve, it is constructed.',
    'If natural, the constraint is a mountain with unavoidable beneficiaries (fossil industry benefits accidentally from deep human risk aversion). If constructed, it is a tangled rope or snare—coordination narrative layered over systematic extraction.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(natural_vs_constructed_catastrophic_framing, empirical, 'Whether catastrophic-tail dominance is human-universal or context-dependent construction.').

omega_variable(
    incommensurability_vs_incomparability,
    'Is catastrophic risk genuinely incommensurable with aggregate risk (they cannot be placed on the same scale), or merely difficult to compare (society finds the comparison emotionally and politically hard)?',
    'Philosophical analysis and revealed preference: if societies systematically make trade-offs between catastrophic and aggregate risks in other domains (aviation safety, infectious disease policy), then the risks are comparable and energy policy is a special case. If no society ever treats catastrophic and aggregate risks as commensurable, incommensurability is real.',
    'If genuinely incommensurable, expected-value frameworks are categorically inapplicable and the catastrophic reading has foundational grounding. If merely incomparable, the framework is a preference that could be revised by better information or shifting values.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(incommensurability_vs_incomparability, conceptual, 'Whether the catastrophic-aggregate distinction is a limit of rational comparison or a contingent framing choice.').

omega_variable(
    founding_mandate_obsolescence,
    'Has the founding problem (assessing nuclear risk under irreducible uncertainty) been solved by improved reactor designs and mature probabilistic risk assessment, making the catastrophic framework a zombie constraint?',
    'Comparison of accident probability distributions between 1970s-era reactors and modern designs (Gen III+, SMRs): if modern designs achieve demonstrably lower core damage frequencies while policy remains locked in 1970s risk framework, mandate is obsolete.',
    'If obsolete, the constraint''s persistence is evidence of capture—it continues because it benefits fossil incumbents and advocacy coalitions, not because uncertainty remains irreducible. R5 mismatch: founding_problem_status would shift from contested to dead.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(founding_mandate_obsolescence, empirical, 'Whether the uncertainty justifying catastrophic-tail dominance remains empirically live or has been resolved by technology improvement.').

omega_variable(
    cs_framing_alternative_authority,
    'Is the catastrophic-tail-dominant reading the only coherent interpretation of acceptable risk under precautionary norms, or could the same precautionary kernel ground alternative readings (expected-value or option-value) if different actors held interpretive authority?',
    'Examination of jurisdictions where climate scientists or public health authorities (rather than anti-nuclear advocacy coalitions) hold interpretive authority over acceptable risk: if they produce different readings from the same precautionary kernel, authority-grounding rather than kernel content determines the reading.',
    'If alternative authority produces alternative readings, the catastrophic reading is a contingent political-economy outcome, not a necessary interpretation of precaution. The constraint''s classification depends on who controls the interpretive layer.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(cs_framing_alternative_authority, conceptual, 'Whether the reading is determined by the kernel''s content or by who holds authority to interpret it.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(acceptable_risk_energy__catastrophic_tail_dominant, 0, 50).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(acce_tr_t0, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 0, 0.25).
narrative_ontology:measurement_basis(acce_tr_t0, observed).
narrative_ontology:measurement(acce_tr_t10, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 10, 0.29).
narrative_ontology:measurement_basis(acce_tr_t10, observed).
narrative_ontology:measurement(acce_tr_t20, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 20, 0.34).
narrative_ontology:measurement_basis(acce_tr_t20, observed).
narrative_ontology:measurement(acce_tr_t30, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 30, 0.38).
narrative_ontology:measurement_basis(acce_tr_t30, observed).
narrative_ontology:measurement(acce_tr_t40, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 40, 0.41).
narrative_ontology:measurement_basis(acce_tr_t40, observed).
narrative_ontology:measurement(acce_tr_t50, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 50, 0.42).
narrative_ontology:measurement_basis(acce_tr_t50, observed).

% Extraction over time
narrative_ontology:measurement(acce_be_t0, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 0, 0.45).
narrative_ontology:measurement_basis(acce_be_t0, observed).
narrative_ontology:measurement(acce_be_t10, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 10, 0.52).
narrative_ontology:measurement_basis(acce_be_t10, observed).
narrative_ontology:measurement(acce_be_t20, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 20, 0.59).
narrative_ontology:measurement_basis(acce_be_t20, observed).
narrative_ontology:measurement(acce_be_t30, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 30, 0.64).
narrative_ontology:measurement_basis(acce_be_t30, observed).
narrative_ontology:measurement(acce_be_t40, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 40, 0.67).
narrative_ontology:measurement_basis(acce_be_t40, observed).
narrative_ontology:measurement(acce_be_t50, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 50, 0.68).
narrative_ontology:measurement_basis(acce_be_t50, observed).

% Suppression requirement over time
narrative_ontology:measurement(acce_su_t0, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 0, 0.58).
narrative_ontology:measurement_basis(acce_su_t0, observed).
narrative_ontology:measurement(acce_su_t10, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 10, 0.63).
narrative_ontology:measurement_basis(acce_su_t10, observed).
narrative_ontology:measurement(acce_su_t20, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 20, 0.69).
narrative_ontology:measurement_basis(acce_su_t20, observed).
narrative_ontology:measurement(acce_su_t30, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 30, 0.73).
narrative_ontology:measurement_basis(acce_su_t30, observed).
narrative_ontology:measurement(acce_su_t40, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 40, 0.77).
narrative_ontology:measurement_basis(acce_su_t40, observed).
narrative_ontology:measurement(acce_su_t50, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 50, 0.79).
narrative_ontology:measurement_basis(acce_su_t50, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(acceptable_risk_energy__catastrophic_tail_dominant, identity_coordination).
narrative_ontology:affects_constraint(acceptable_risk_energy__catastrophic_tail_dominant, acceptable_risk_energy__expected_value_dominant).
narrative_ontology:affects_constraint(acceptable_risk_energy__catastrophic_tail_dominant, acceptable_risk_energy__option_value_preserving).
narrative_ontology:affects_constraint(acceptable_risk_energy__catastrophic_tail_dominant, nuclear_licensing_framework).
narrative_ontology:affects_constraint(acceptable_risk_energy__catastrophic_tail_dominant, climate_mitigation_baseline_pathway).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the acceptable_risk_energy kernel. All three readings (catastrophic_tail_dominant, expected_value_dominant, option_value_preserving) are live in contemporary energy policy discourse and held by different coalitions. They have different ε values because they produce different victim sets and suppression mechanisms—the catastrophic reading suppresses nuclear licensing and discounts fossil aggregate harm; the expected-value reading would suppress fossil continuation and integrate nuclear accident risk into aggregate mortality; the option-value reading maintains both pathways at higher coordination cost. The kernel decomposes because ε is not stable across the choice of how to weight catastrophic vs. aggregate risk.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
