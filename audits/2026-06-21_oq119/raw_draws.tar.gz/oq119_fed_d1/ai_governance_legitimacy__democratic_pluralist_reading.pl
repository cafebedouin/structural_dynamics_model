% ============================================================================
% CONSTRAINT STORY: ai_governance_legitimacy__democratic_pluralist_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-12
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_ai_governance_legitimacy__democratic_pluralist_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: ai_governance_legitimacy__democratic_pluralist_reading
 *   human_readable: Democratic Pluralist AI Governance Legitimacy
 *   domain: theological_ethics/technology_governance/political_theology
 *
 * SUMMARY:
 *   This reading grounds AI governance legitimacy in democratic deliberation
 *   and inclusive public reason. No single tradition—religious, technocratic,
 *   or market—holds interpretive monopoly. The Catholic encyclical's dignity
 *   claims contribute one voice among many. Principles emerge through
 *   transparent political processes balancing diverse values. The reading
 *   claims to be a foundational feature of legitimate governance (hence
 *   mountain) while simultaneously organizing real beneficiaries and victims
 *   around its operation. The claim/metric divergence is deliberate: the
 *   reading presents itself as natural law while extracting compliance costs
 *   and excluding voices.
 *
 * KEY AGENTS:
 *   - civil_society_organizations: organized/mobile beneficiary—gain voice in deliberation
 *   - democratic_institutions: institutional/constrained agenda_setter—set and enforce framework
 *   - minority_rights_holders: moderate/constrained beneficiary—protected by pluralist commitments
 *   - excluded_populations: powerless/trapped payer—bear costs of failed inclusion
 *   - authoritarian_regime_subjects: powerless/trapped payer—outside deliberative reach
 *   - marginalized_deliberative_voices: powerless/identity_locked payer—nominal inclusion, real exclusion
 *   - corporate_ai_developers: powerful/mobile payer—face compliance costs
 *   - technocratic_experts: powerful/mobile excluded—authority subordinated
 *   - religious_magisteria: institutional/constrained excluded—interpretive monopoly denied
 *   - political_theorists: analytical observer—measure legitimacy gaps
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(ai_governance_legitimacy__democratic_pluralist_reading, 0.4).
domain_priors:suppression_score(ai_governance_legitimacy__democratic_pluralist_reading, 0.35).
domain_priors:theater_ratio(ai_governance_legitimacy__democratic_pluralist_reading, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, extractiveness, 0.4).
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 0.35).
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, accessibility_collapse, 0.42).
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, resistance, 0.55).

% --- Constraint claim ---
narrative_ontology:constraint_claim(ai_governance_legitimacy__democratic_pluralist_reading, mountain).
narrative_ontology:human_readable(ai_governance_legitimacy__democratic_pluralist_reading, "Democratic Pluralist AI Governance Legitimacy").
narrative_ontology:topic_domain(ai_governance_legitimacy__democratic_pluralist_reading, "theological_ethics/technology_governance/political_theology").

domain_priors:requires_active_enforcement(ai_governance_legitimacy__democratic_pluralist_reading).
domain_priors:emerges_naturally(ai_governance_legitimacy__democratic_pluralist_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(ai_governance_legitimacy__democratic_pluralist_reading, 'fe95e990-784b-4d09-b5bf-3f4bd39b8cc2').
narrative_ontology:cs_kernel_codification('fe95e990-784b-4d09-b5bf-3f4bd39b8cc2', distributed).
narrative_ontology:cs_authority_grounding('fe95e990-784b-4d09-b5bf-3f4bd39b8cc2', distributed).
narrative_ontology:cs_reading_relation('fe95e990-784b-4d09-b5bf-3f4bd39b8cc2', ai_governance_legitimacy__magisterial_subsidiarity_reading, coexists_with).
narrative_ontology:cs_reading_relation('fe95e990-784b-4d09-b5bf-3f4bd39b8cc2', ai_governance_legitimacy__market_libertarian_reading, coexists_with).
narrative_ontology:cs_reading_relation('fe95e990-784b-4d09-b5bf-3f4bd39b8cc2', ai_governance_legitimacy__technocratic_optimization_reading, coexists_with).
narrative_ontology:cs_axiom('fe95e990-784b-4d09-b5bf-3f4bd39b8cc2', foundational, no_epistemic_monopoly).
narrative_ontology:cs_axiom_status(no_epistemic_monopoly, holdable).
narrative_ontology:cs_axiom_grounding('fe95e990-784b-4d09-b5bf-3f4bd39b8cc2', no_epistemic_monopoly, deontological).
narrative_ontology:cs_axiom('fe95e990-784b-4d09-b5bf-3f4bd39b8cc2', foundational, legitimacy_through_consent).
narrative_ontology:cs_axiom_status(legitimacy_through_consent, holdable).
narrative_ontology:cs_axiom_grounding('fe95e990-784b-4d09-b5bf-3f4bd39b8cc2', legitimacy_through_consent, conventional).
narrative_ontology:cs_axiom('fe95e990-784b-4d09-b5bf-3f4bd39b8cc2', secondary, inclusive_deliberation_primacy).
narrative_ontology:cs_axiom_status(inclusive_deliberation_primacy, holdable).
narrative_ontology:cs_axiom_grounding('fe95e990-784b-4d09-b5bf-3f4bd39b8cc2', inclusive_deliberation_primacy, instrumental).
narrative_ontology:cs_reference_frame('fe95e990-784b-4d09-b5bf-3f4bd39b8cc2', rawlsian_public_reason_framework).
narrative_ontology:cs_drift_state('fe95e990-784b-4d09-b5bf-3f4bd39b8cc2', contemporary_populist_era, gap(authority_erosion, substantial, true)).
narrative_ontology:cs_created_at('fe95e990-784b-4d09-b5bf-3f4bd39b8cc2', '').
narrative_ontology:cs_kernel_id(ai_governance_legitimacy__democratic_pluralist_reading, ai_governance_legitimacy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__democratic_pluralist_reading, civil_society_organizations).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__democratic_pluralist_reading, democratic_institutions).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__democratic_pluralist_reading, minority_rights_holders).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__democratic_pluralist_reading, participatory_publics).
narrative_ontology:constraint_victim(ai_governance_legitimacy__democratic_pluralist_reading, excluded_populations).
narrative_ontology:constraint_victim(ai_governance_legitimacy__democratic_pluralist_reading, authoritarian_regime_subjects).
narrative_ontology:constraint_victim(ai_governance_legitimacy__democratic_pluralist_reading, marginalized_deliberative_voices).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_victim(ai_governance_legitimacy__democratic_pluralist_reading, corporate_ai_developers).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Gain structured voice in AI governance deliberations through this reading's legitimacy framework. They advocate for transparency, accountability, and human rights safeguards. Their influence depends on maintaining access to democratic processes and resisting capture by concentrated interests.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, civil_society_organizations, beneficiary,
    organized, generational, mobile, global).

% Set the rules for AI governance through legislative processes, regulatory frameworks, and judicial review. This reading legitimizes their authority but also constrains them to maintain inclusive deliberation and transparency. They face pressure from both concentrated corporate interests and diffuse civil society demands.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, democratic_institutions, agenda_setter,
    institutional, generational, constrained, national).
narrative_ontology:stakeholder_secondary_role(ai_governance_legitimacy__democratic_pluralist_reading, democratic_institutions, beneficiary).

% Protected by the reading's emphasis on inclusive public reason and diverse values. They gain standing to contest AI systems that disproportionately harm minority communities. Their protection depends on democratic institutions honoring pluralist commitments rather than majoritarian efficiency.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, minority_rights_holders, beneficiary,
    moderate, biographical, constrained, national).

% Gain voice in AI governance through public consultation processes, citizen assemblies, and democratic input mechanisms. They benefit from transparency requirements and accountability structures. Their actual influence varies with institutional design quality and resistance to capture.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, participatory_publics, beneficiary,
    organized, biographical, mobile, regional).

% Bear the costs when democratic deliberation fails to include them—linguistic barriers, digital divides, geographic isolation, or legal status exclusions. They experience AI governance decisions imposed on them without meaningful participation. The reading claims to protect them but enforcement depends on institutions reaching beyond formal citizenship.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, excluded_populations, payer,
    powerless, immediate, trapped, regional).

% Experience AI surveillance, social credit systems, and algorithmic control without the democratic accountability this reading requires. The constraint does not operate in their jurisdictions; they bear the full cost of ungoverned AI deployment. The reading's legitimacy claims do not reach them.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, authoritarian_regime_subjects, payer,
    powerless, immediate, trapped, national).

% Nominally included in democratic processes but systematically disadvantaged by power asymmetries, epistemic exclusion, or resource constraints. They attend consultations but lack the technical literacy, legal representation, or social capital to shape outcomes. The reading promises inclusion but delivers symbolic participation.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, marginalized_deliberative_voices, payer,
    powerless, biographical, identity_locked, national).

% Face regulatory compliance costs, transparency requirements, and slower deployment cycles under democratic oversight. They prefer lighter-touch self-regulation and argue that deliberative processes impose innovation drag. Their mobility lets them forum-shop across jurisdictions with varying democratic constraints.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, corporate_ai_developers, payer,
    powerful, biographical, mobile, global).

% Their epistemic authority is subordinated to democratic legitimacy in this reading. They provide input but do not control governance outcomes. They argue that complex technical domains require expert-led decision-making and that democratic deliberation produces suboptimal policy.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, technocratic_experts, excluded,
    powerful, biographical, mobile, global).

% Their interpretive authority over human dignity and moral truth is denied unique status in this reading. They contribute as one voice among many but do not adjudicate governance legitimacy. They object that this relativizes foundational moral truths to political contingency.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, religious_magisteria, excluded,
    institutional, civilizational, constrained, global).

% Analyze the legitimacy structures and measure the gap between the reading's inclusive claims and its actual deliberative reach. They document who is systematically excluded, where epistemic authority concentrates despite pluralist commitments, and how the reading's enforcement mechanisms operate across different regime types.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, political_theorists, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Coordinates AI governance legitimacy through democratic deliberation institutions: legislative frameworks, regulatory agencies, judicial review, public consultation processes, and civil liberties protections. Solves the collective-action problem of governing powerful technology without concentrating interpretive authority in any single tradition.
% TRANSFER_FUNCTION: Transfers governance authority from concentrated technical or religious elites to diffuse participatory publics and their democratic representatives. Moves deliberative burden from expert optimization or magisterial doctrine to inclusive public reason. Imposes compliance costs on corporate developers and transparency requirements on institutions.
% ABSENT_VOICES: Populations under authoritarian regimes where democratic deliberation does not operate. Marginalized groups within democracies who lack resources for meaningful participation. Future generations affected by AI decisions but without representation in current deliberation.
% DISAPPEARANCE_RATIONALE: If this reading's legitimacy framework vanished, AI governance would reorganize around alternative authority structures: technocratic expert rule, market self-regulation, religious magisterial authority, or corporate capture. Democratic institutions would lose their constraint on concentrated power. Minority rights protections would depend on majoritarian goodwill or market forces rather than pluralist commitments.
% FOUNDING_PROBLEM: How to govern transformative AI technology when multiple traditions make competing claims about human dignity, legitimate authority, and moral truth. How to prevent concentration of interpretive power while maintaining enough coordination for effective governance.
% FOUNDING_PROBLEM_CORROBORATION: Political theorists, civil society organizations, and democratic institutions attest the founding problem remains live: AI governance disputes continue across religious/secular, expert/public, and national/global boundaries. Independent analysis confirms no single tradition has achieved interpretive monopoly and that pluralist legitimacy claims remain contested.
narrative_ontology:disappearance_verdict(ai_governance_legitimacy__democratic_pluralist_reading, world_rearranges).
narrative_ontology:founding_problem_status(ai_governance_legitimacy__democratic_pluralist_reading, live).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(ai_governance_legitimacy__democratic_pluralist_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(ai_governance_legitimacy__democratic_pluralist_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(ai_governance_legitimacy__democratic_pluralist_reading_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, ExtMetricName, E),
    domain_priors:suppression_score(ai_governance_legitimacy__democratic_pluralist_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(ai_governance_legitimacy__democratic_pluralist_reading),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(ai_governance_legitimacy__democratic_pluralist_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction (0.40) is moderate because the reading imposes real costs—corporate compliance burdens, excluded voices bearing ungoverned AI harms, marginalized groups with symbolic rather than substantive participation. Suppression (0.35) reflects enforcement through democratic accountability mechanisms that are softer than direct coercion but still constrain alternatives. Theater (0.28) captures the gap between inclusive deliberation rhetoric and the systematic exclusion of powerless populations. Accessibility_collapse (0.42) is moderate because genuine alternatives exist—technocratic, market, and religious governance readings remain live. Resistance (0.55) is substantial: corporate interests resist transparency requirements, experts resist epistemic subordination, religious traditions resist relativization, and marginalized groups resist symbolic inclusion. The measurement series tracks gradual extraction accumulation as democratic institutions build participatory infrastructure.
 *
 * PERSPECTIVAL GAP:
 *   The beneficiary seats (civil society, democratic institutions) should compute this as coordination—building participatory infrastructure for legitimate governance. The payer seats (excluded populations, marginalized voices) should compute it as extraction—they are promised inclusion but denied meaningful participation. The excluded seats (religious magisteria, technocratic experts) should compute it as suppression of their authority. The analytical seat sees the structural divergence: a reading claiming foundational status while organizing real asymmetries of voice and power.
 *
 * DIRECTIONALITY LOGIC:
 *   Civil society organizations, democratic institutions, minority rights holders, and participatory publics are structural beneficiaries—they gain voice, protection, and legitimacy under this reading. Excluded populations, authoritarian regime subjects, and marginalized deliberative voices are targets—they bear the costs of failed inclusion or non-reach. Corporate developers and technocratic experts are payers—they face constraints on their preferred governance modes. Religious magisteria are excluded rather than coordinated—their unique authority claim is what the reading exists to deny.
 *
 * MANDATROPHY ANALYSIS:
 *   The reading avoids pure snare classification by maintaining genuine coordination function—democratic deliberation does solve collective-action problems around AI governance. It avoids pure rope classification by acknowledging real victims—populations systematically excluded from deliberative processes. The scaffold designation reflects its transitional character: building participatory infrastructure toward more inclusive governance. The mandatrophy risk is that inclusive deliberation rhetoric persists while institutional capture concentrates authority, leaving the coordination claim as cover for extractive governance.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    foundational_vs_constructed_legitimacy,
    'Is democratic deliberation a foundational feature of legitimate governance (mountain claim) or a historically contingent political construction that benefits specific institutional actors?',
    'Cross-cultural and historical analysis of legitimacy structures. If democratic deliberation emerges independently across diverse contexts as the recognized basis for governing collective technology, the mountain claim holds. If it concentrates in specific political traditions and serves identifiable beneficiaries, it is constructed.',
    'If foundational, the reading''s authority is natural and alternatives are illegitimate. If constructed, it is one governance reading among several, and the beneficiary/victim asymmetries are extractive rather than natural.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(foundational_vs_constructed_legitimacy, conceptual, 'Whether democratic legitimacy is natural law or political construction').

omega_variable(
    inclusion_gap_magnitude,
    'What fraction of affected populations is systematically excluded from meaningful deliberation despite the reading''s inclusive rhetoric?',
    'Empirical measurement of deliberative reach: participation rates across demographic groups, resource requirements for meaningful input, linguistic and technical barriers, legal status exclusions. Survey marginalized groups directly about perceived voice and influence.',
    'A large exclusion gap would elevate extraction and reveal the reading as serving organized interests rather than diffuse publics. A small gap would validate the coordination claim and support scaffold rather than tangled_rope classification.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(inclusion_gap_magnitude, empirical, 'How many are excluded from the deliberation they nominally join').

omega_variable(
    epistemic_authority_distribution,
    'Does the reading genuinely distribute epistemic authority across diverse traditions, or does it concentrate authority in secular liberal institutions while denying pluralism?',
    'Analysis of governance outcomes: whose moral claims shape policy, which traditions'' dignity concepts inform regulation, whose expertise is treated as authoritative. Compare rhetoric of pluralism against institutional practice.',
    'If authority genuinely distributes, the pluralist claim is validated. If authority concentrates in secular liberal frameworks while excluding religious and non-Western traditions, the reading is extractive toward excluded epistemic communities.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(epistemic_authority_distribution, empirical, 'Whether pluralism distributes authority or concentrates it').

omega_variable(
    sibling_reading_committer_frame,
    'How would this constraint''s classification change under a magisterial_subsidiarity_reading (religious authority) or technocratic_optimization_reading (expert authority) framing?',
    'Generate sibling constraint stories with identical base situation but different legitimacy kernels. Compare beneficiary/victim structures and type classifications across readings.',
    'If classifications converge despite different legitimacy claims, the coordination function is real and robust. If they diverge sharply, the legitimacy frame itself is the extraction mechanism and the readings are competing power claims rather than objective governance structures.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(sibling_reading_committer_frame, conceptual, 'Committer-axis reading dependence of classification').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(ai_governance_legitimacy__democratic_pluralist_reading, 0, 30).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(ai_g_tr_t0, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 0, 0.2).
narrative_ontology:measurement(ai_g_tr_t6, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 6, 0.22).
narrative_ontology:measurement(ai_g_tr_t12, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 12, 0.24).
narrative_ontology:measurement(ai_g_tr_t18, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 18, 0.26).
narrative_ontology:measurement(ai_g_tr_t24, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 24, 0.27).
narrative_ontology:measurement(ai_g_tr_t30, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 30, 0.28).

% Extraction over time
narrative_ontology:measurement(ai_g_be_t0, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 0, 0.3).
narrative_ontology:measurement(ai_g_be_t6, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 6, 0.33).
narrative_ontology:measurement(ai_g_be_t12, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 12, 0.36).
narrative_ontology:measurement(ai_g_be_t18, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 18, 0.38).
narrative_ontology:measurement(ai_g_be_t24, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 24, 0.39).
narrative_ontology:measurement(ai_g_be_t30, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 30, 0.4).

% Suppression requirement over time
narrative_ontology:measurement(ai_g_su_t0, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 0, 0.25).
narrative_ontology:measurement(ai_g_su_t6, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 6, 0.28).
narrative_ontology:measurement(ai_g_su_t12, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 12, 0.3).
narrative_ontology:measurement(ai_g_su_t18, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 18, 0.32).
narrative_ontology:measurement(ai_g_su_t24, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 24, 0.34).
narrative_ontology:measurement(ai_g_su_t30, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 30, 0.35).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:affects_constraint(ai_governance_legitimacy__democratic_pluralist_reading, ai_governance_legitimacy__magisterial_subsidiarity_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__democratic_pluralist_reading, ai_governance_legitimacy__market_libertarian_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__democratic_pluralist_reading, ai_governance_legitimacy__technocratic_optimization_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the ai_governance_legitimacy kernel. The kernel decomposes into four distinct constraint stories because different legitimacy sources (democratic consent, magisterial authority, market exchange, expert optimization) produce different beneficiary/victim structures and different ε values. Democratic pluralist reading: moderate extraction from exclusion gaps and compliance costs. Magisterial subsidiarity reading: extraction from epistemic monopoly and secular exclusion. Market libertarian reading: extraction from coercive solidarity demands. Technocratic optimization reading: extraction from subordinating values to efficiency. Each reading is an ε-invariant constraint with its own classification.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
