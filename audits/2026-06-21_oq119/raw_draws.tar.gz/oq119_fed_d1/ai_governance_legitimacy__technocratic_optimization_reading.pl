% ============================================================================
% CONSTRAINT STORY: ai_governance_legitimacy__technocratic_optimization_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-01-15
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_ai_governance_legitimacy__technocratic_optimization_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: ai_governance_legitimacy__technocratic_optimization_reading
 *   human_readable: AI Governance Legitimacy via Technocratic Optimization (Reading)
 *   domain: theological_ethics/technology_governance/political_theology
 *
 * SUMMARY:
 *   This constraint is the technocratic optimization reading of the contested
 *   kernel 'AI governance legitimacy'. It instantiates one structural
 *   position: legitimacy derives from aggregate welfare maximization,
 *   technical expertise, and demonstrated performance. The encyclical's
 *   dignity principles are treated as aspirational values to balance against
 *   feasibility and growth imperatives, not as incommensurable normative
 *   foundations. Sibling readings ground legitimacy in magisterial authority
 *   (subsidiarity/solidarity), democratic deliberation (pluralist consent),
 *   or market voluntarism (libertarian property rights). This reading
 *   coordinates tech firms, investors, and high-skill workers around
 *   efficiency metrics while imposing costs on displaced workers, digitally
 *   excluded communities, and algorithmically profiled populations. The
 *   claim/metric gap is deliberate: the constraint is CLAIMED as mountain
 *   (optimization metrics as natural legitimacy grounds, emerges from
 *   economic rationality) while the metrics describe moderate extraction,
 *   active enforcement through regulatory capture and epistemic gatekeeping,
 *   and organized resistance from excluded seats. The engine measures that
 *   divergence; the author does not reconcile it.
 *
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(ai_governance_legitimacy__technocratic_optimization_reading, 0.36).
domain_priors:suppression_score(ai_governance_legitimacy__technocratic_optimization_reading, 0.42).
domain_priors:theater_ratio(ai_governance_legitimacy__technocratic_optimization_reading, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, extractiveness, 0.36).
narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 0.42).
narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, resistance, 0.55).

% --- Constraint claim ---
narrative_ontology:constraint_claim(ai_governance_legitimacy__technocratic_optimization_reading, mountain).
narrative_ontology:human_readable(ai_governance_legitimacy__technocratic_optimization_reading, "AI Governance Legitimacy via Technocratic Optimization (Reading)").
narrative_ontology:topic_domain(ai_governance_legitimacy__technocratic_optimization_reading, "theological_ethics/technology_governance/political_theology").

domain_priors:requires_active_enforcement(ai_governance_legitimacy__technocratic_optimization_reading).
domain_priors:emerges_naturally(ai_governance_legitimacy__technocratic_optimization_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(ai_governance_legitimacy__technocratic_optimization_reading, '69f8d2dd-1c88-4db1-a6bb-7f9cb1ee3351').
narrative_ontology:cs_kernel_codification('69f8d2dd-1c88-4db1-a6bb-7f9cb1ee3351', distributed).
narrative_ontology:cs_authority_grounding('69f8d2dd-1c88-4db1-a6bb-7f9cb1ee3351', expertise).
narrative_ontology:cs_interpretation_layer_present('69f8d2dd-1c88-4db1-a6bb-7f9cb1ee3351').
narrative_ontology:cs_reading_relation('69f8d2dd-1c88-4db1-a6bb-7f9cb1ee3351', ai_governance_legitimacy__magisterial_subsidiarity_reading, coexists_with).
narrative_ontology:cs_reading_relation('69f8d2dd-1c88-4db1-a6bb-7f9cb1ee3351', ai_governance_legitimacy__democratic_pluralist_reading, coexists_with).
narrative_ontology:cs_reading_relation('69f8d2dd-1c88-4db1-a6bb-7f9cb1ee3351', ai_governance_legitimacy__market_libertarian_reading, influences).
narrative_ontology:cs_axiom('69f8d2dd-1c88-4db1-a6bb-7f9cb1ee3351', foundational, aggregate_welfare_primacy).
narrative_ontology:cs_axiom_status(aggregate_welfare_primacy, holdable).
narrative_ontology:cs_axiom_grounding('69f8d2dd-1c88-4db1-a6bb-7f9cb1ee3351', aggregate_welfare_primacy, empirically_contingent).
narrative_ontology:cs_axiom('69f8d2dd-1c88-4db1-a6bb-7f9cb1ee3351', foundational, epistemic_technocracy_legitimacy).
narrative_ontology:cs_axiom_status(epistemic_technocracy_legitimacy, holdable).
narrative_ontology:cs_axiom_grounding('69f8d2dd-1c88-4db1-a6bb-7f9cb1ee3351', epistemic_technocracy_legitimacy, instrumental).
narrative_ontology:cs_axiom('69f8d2dd-1c88-4db1-a6bb-7f9cb1ee3351', secondary, dignity_as_parameter_constraint).
narrative_ontology:cs_axiom_status(dignity_as_parameter_constraint, holdable).
narrative_ontology:cs_axiom_grounding('69f8d2dd-1c88-4db1-a6bb-7f9cb1ee3351', dignity_as_parameter_constraint, instrumental).
narrative_ontology:cs_reference_frame('69f8d2dd-1c88-4db1-a6bb-7f9cb1ee3351', utilitarian_aggregate_welfare_paradigm).
narrative_ontology:cs_drift_state('69f8d2dd-1c88-4db1-a6bb-7f9cb1ee3351', post_encyclical_challenge_era, gap(authority_erosion, substantial, false)).
narrative_ontology:cs_created_at('69f8d2dd-1c88-4db1-a6bb-7f9cb1ee3351', '').
narrative_ontology:cs_kernel_id(ai_governance_legitimacy__technocratic_optimization_reading, ai_governance_legitimacy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__technocratic_optimization_reading, tech_firms).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__technocratic_optimization_reading, institutional_investors).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__technocratic_optimization_reading, high_skill_workers).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__technocratic_optimization_reading, early_adopters).
narrative_ontology:constraint_victim(ai_governance_legitimacy__technocratic_optimization_reading, displaced_workers).
narrative_ontology:constraint_victim(ai_governance_legitimacy__technocratic_optimization_reading, digital_infrastructure_excluded_communities).
narrative_ontology:constraint_victim(ai_governance_legitimacy__technocratic_optimization_reading, algorithmically_profiled_populations).
narrative_ontology:constraint_vindicates(ai_governance_legitimacy__technocratic_optimization_reading, utilitarian_aggregate_welfare_maximization).
narrative_ontology:constraint_vindicates(ai_governance_legitimacy__technocratic_optimization_reading, epistemic_technocracy).
narrative_ontology:constraint_vindicates(ai_governance_legitimacy__technocratic_optimization_reading, innovation_imperative_doctrine).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Design AI systems, set deployment priorities, capture efficiency gains. Frame governance as technical expertise plus market validation. Argue that regulatory constraints should defer to demonstrated performance metrics and competitive pressure. Collect rents from platform dominance while claiming meritocratic efficiency.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, tech_firms, agenda_setter,
    institutional, generational, arbitrage, global).

% Finance AI development, demand growth and efficiency returns. Benefit from aggregate welfare increases via portfolio gains. Push for governance frameworks that maximize innovation velocity and minimize compliance friction. Can reallocate capital across jurisdictions if constraints tighten.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, institutional_investors, beneficiary,
    powerful, biographical, mobile, global).

% Possess skills AI systems amplify rather than replace. Experience wage premiums, career mobility, and productivity gains. Support governance frameworks that prioritize innovation and efficiency because those frameworks strengthen their market position. Can migrate to jurisdictions with favorable tech ecosystems.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, high_skill_workers, beneficiary,
    moderate, biographical, mobile, global).

% Access AI tools early, gain productivity and convenience advantages. Benefit from algorithmic personalization and efficiency gains. Bear indirect costs through data extraction and privacy erosion but experience net positive utility under optimization metrics. Exit limited by network effects and switching costs.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, early_adopters, beneficiary,
    moderate, biographical, constrained, national).

% Lose employment to automation, face skill obsolescence. Bear transition costs not captured in aggregate welfare metrics. Governance frameworks prioritizing efficiency over distribution leave them without recourse. Cannot exit labor markets they depend on for subsistence. Resistance organized through labor movements meets 'inevitability' framing.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, displaced_workers, payer,
    powerless, biographical, trapped, national).

% Lack broadband, devices, or digital literacy. Excluded from AI-mediated services and economic opportunities. Governance focused on innovation velocity deprioritizes universal access as 'inefficient'. Geographic and economic traps prevent migration to digitally connected regions. Treated as optimization residuals rather than rights-bearers.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, digital_infrastructure_excluded_communities, payer,
    powerless, generational, trapped, regional).

% Subject to opaque algorithmic decisions in credit, employment, policing, benefits. Bear costs of false positives, discriminatory patterns, and dignity violations. Governance frameworks treating ethics as 'parameters' subordinate their harm to system efficiency. Cannot exit algorithmic systems that determine life chances. Identity characteristics (race, class, disability) lock them into profiling categories.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, algorithmically_profiled_populations, payer,
    powerless, biographical, identity_locked, global).

% Charged with AI oversight but captured by epistemic asymmetry and revolving-door dynamics. Defer to technical expertise claims from firms. Frame regulations around efficiency and innovation metrics rather than dignity or rights. Constrained by jurisdictional competition for AI investment and firms' threat to relocate.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, regulatory_agencies, agenda_setter,
    institutional, generational, constrained, national).
narrative_ontology:stakeholder_secondary_role(ai_governance_legitimacy__technocratic_optimization_reading, regulatory_agencies, observer).

% Assert alternative legitimacy grounding in Catholic Social Doctrine. Excluded from technocratic governance frameworks that treat religious principles as 'aspirational' rather than normative. Institutional authority within faith communities but marginalized in policy formation. Would testify to incommensurability of dignity with optimization metrics.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, magisterial_interpreters, excluded,
    institutional, civilizational, analytical, global).

% Lack technical expertise to contest optimization framing. Governance decisions made by expert bodies and market actors, not through inclusive deliberation. Experience consequences of AI deployment without meaningful input into legitimacy criteria. Constrained by epistemic gatekeeping and complexity barriers to participation.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, democratic_publics, excluded,
    organized, biographical, constrained, national).

% Analyze how technocratic optimization reading concentrates gains, diffuses costs, and substitutes efficiency metrics for dignity claims. Document regulatory capture, epistemic authority claims, and distributive outcomes. Have no direct stake but illuminate structural dynamics and alternative framings.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, political_economists, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Coordinates AI development and deployment around shared efficiency metrics, standardized performance benchmarks, and epistemic authority of technical expertise. Solves collective action problems in innovation investment and competency signaling.
% TRANSFER_FUNCTION: Moves productivity gains, data rents, and platform network effects from labor, users, and peripheral economies to tech firms, investors, and high-skill workers positioned to capture AI-mediated value. Legitimacy framing justifies this transfer as aggregate welfare maximization.
% ABSENT_VOICES: Magisterial interpreters asserting incommensurability of dignity with optimization parameters, democratic publics demanding inclusive deliberation over legitimacy criteria, and displaced/profiled populations bearing uncounted costs are structurally excluded from governance formation. Their exclusion is maintained through epistemic gatekeeping ('they lack technical expertise') and efficiency framing ('their concerns are aspirational, not feasible').
% DISAPPEARANCE_RATIONALE: If this legitimacy framing disappeared, AI governance would reorganize around alternative criteria: magisterial subsidiarity would subordinate technology to dignity principles with participatory accountability; democratic pluralism would ground legitimacy in inclusive deliberation; market libertarianism would reject collective oversight entirely. The current distribution of authority, investment, and accountability would shift fundamentally. Firms would lose epistemic monopoly; excluded populations would gain standing.
% FOUNDING_PROBLEM: Early AI development faced legitimacy vacuum: no agreed criteria for responsible innovation, fragmented regulatory approaches, public anxiety about autonomous systems. Technocratic optimization reading filled this vacuum by asserting efficiency and expertise as legitimacy grounds, enabling rapid scaling and investment coordination.
% FOUNDING_PROBLEM_CORROBORATION: Tech firms and institutional investors attest the founding problem persists, requiring expert-led efficiency governance. Magisterial interpreters, political economists, and labor movements attest the founding legitimacy vacuum has been filled by one contested reading that benefits its proponents, while alternative legitimacy grounds (dignity, democratic consent, subsidiarity) remain suppressed rather than resolved. Independent scholarship on AI governance pluralism supports the contested-rather-than-resolved assessment.
narrative_ontology:disappearance_verdict(ai_governance_legitimacy__technocratic_optimization_reading, world_rearranges).
narrative_ontology:founding_problem_status(ai_governance_legitimacy__technocratic_optimization_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(ai_governance_legitimacy__technocratic_optimization_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(ai_governance_legitimacy__technocratic_optimization_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(ai_governance_legitimacy__technocratic_optimization_reading_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, ExtMetricName, E),
    domain_priors:suppression_score(ai_governance_legitimacy__technocratic_optimization_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(ai_governance_legitimacy__technocratic_optimization_reading),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(ai_governance_legitimacy__technocratic_optimization_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is moderate (0.36) because the reading concentrates AI gains on positioned actors while treating dignity violations and distributional harm as 'parameter constraints' rather than governance failures. Suppression (0.42) reflects epistemic gatekeeping, regulatory capture, and jurisdictional competition that suppress alternative legitimacy framings. Theater ratio (0.28) captures increasing performance of 'ethical AI' rhetoric while substantive accountability remains subordinated to efficiency. Accessibility collapse (0.48) is moderate: alternative governance framings exist and are contested (magisterial, democratic, libertarian readings) but face barriers from entrenched expertise claims and capital mobility. Resistance (0.55) is substantial: labor movements challenge automation without safety nets, civil society contests algorithmic profiling, and religious authorities assert incommensurable dignity principles. Measurements track rising extraction and suppression as the reading institutionalizes through regulatory capture and epistemic consolidation.
 *
 * PERSPECTIVAL GAP:
 *   From tech firms and investors, the constraint appears as natural coordination around rational optimization criteria and demonstrated performance — a mountain of economic efficiency. From displaced workers and profiled populations, the same structure operates as imposed extraction justified by expertise claims they cannot contest — asymmetric suppression of dignity principles they bear costs for. From magisterial interpreters, it is structural exclusion of incommensurable normative foundations in favor of one contested utilitarian reading. The engine computes per-seat classifications from these structural asymmetries; the divergence between claimed mountain and computed extraction/coordination hybrid is the measurement this story exists to enable.
 *
 * DIRECTIONALITY LOGIC:
 *   Tech firms and institutional investors are structural beneficiaries (agenda-setting power, arbitrage exit, collect rents from optimization framing — d near beneficiary end). High-skill workers and early adopters benefit from productivity gains and efficiency coordination (d slightly beneficiary-side of symmetric). Displaced workers, digitally excluded communities, and algorithmically profiled populations are targets (powerless, trapped/identity-locked exit, bear uncounted costs — d near target end). Regulatory agencies are captured agenda-setters (constrained exit by jurisdictional competition, defer to firm expertise). Magisterial interpreters and democratic publics are excluded rather than coordinated (their legitimacy grounds are suppressed, not balanced).
 *
 * MANDATROPHY ANALYSIS:
 *   The technocratic optimization reading risks mandatrophy if it persists past the founding legitimacy coordination function into pure rent extraction. Initial coordination value: providing efficiency benchmarks and expert consensus when AI governance criteria were genuinely uncertain. Extraction creep: as alternative framings are suppressed through epistemic gatekeeping, and as regulatory capture entrenches firm authority, the 'natural' legitimacy of optimization metrics becomes a defense of concentrated gains and diffuse costs. The reading's own founding problem — legitimacy vacuum — may be resolved by plural governance acknowledging incommensurable values, but the optimization framework suppresses that resolution to maintain its epistemic monopoly. The measurement series shows extraction rising then stabilizing as capture completes, consistent with coordination function being layered over by institutional entrenchment.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    optimization_dignity_commensurability,
    'Are dignity principles commensurable with aggregate welfare maximization, or do they constitute incommensurable normative foundations requiring different legitimacy grounds?',
    'Sustained engagement between technocratic governance actors and magisterial interpreters over whether dignity violations can be ''balanced'' by efficiency gains, or whether dignity is lexically prior to optimization. Natural experiments in jurisdictions adopting dignity-first vs. efficiency-first AI governance.',
    'If incommensurable, the technocratic reading''s foundational premise collapses and governance must reorganize around dignity as optimization target (magisterial reading) or procedural legitimacy (democratic reading). If commensurable, the current optimization framing holds but must demonstrate genuine balancing rather than rhetorical subordination.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(optimization_dignity_commensurability, conceptual, 'Whether dignity and efficiency are balanceable parameters or incommensurable normative grounds.').

omega_variable(
    epistemic_authority_vs_capture,
    'Is regulatory deference to technical expertise a recognition of genuine epistemic authority, or structural capture enabling rent extraction?',
    'Comparative institutional analysis: do independent technical bodies reach different governance conclusions than firm-adjacent experts? Does revolving-door intensity correlate with firm-favorable policy? Do jurisdictions with stronger democratic oversight or magisterial influence show different efficiency-dignity tradeoffs?',
    'If genuine expertise, technocratic governance retains legitimacy and resistance is uninformed. If capture, the reading operates as extraction mechanism and alternative framings (democratic accountability, magisterial subsidiarity) gain standing.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(epistemic_authority_vs_capture, empirical, 'Whether expert governance reflects epistemic authority or institutional capture.').

omega_variable(
    aggregate_welfare_distributive_blindness,
    'Does aggregate welfare maximization constitutively exclude distributional harm, or can it be refined to internalize dignity costs?',
    'Theoretical analysis of utilitarian frameworks'' capacity to weight dignity violations, plus empirical tracking of whether ''refined'' metrics actually constrain deployment when efficiency and dignity conflict.',
    'If constitutively blind, the optimization reading structurally produces extraction and must be replaced by dignity-first or procedural frameworks. If refinable, measurement and accountability reforms could align optimization with dignity principles without changing legitimacy grounds.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(aggregate_welfare_distributive_blindness, conceptual, 'Whether utilitarian optimization can internalize dignity or structurally externalizes it.').

omega_variable(
    natural_vs_constructed_optimization_legitimacy,
    'Is the technocratic optimization reading''s claimed ''naturalness'' (mountain framing) a discovered legitimacy structure or a constructed one benefiting positioned actors?',
    'Historical analysis: did AI governance ''naturally'' converge on efficiency metrics, or did firm influence and capital mobility shape regulatory frameworks? Cross-cultural comparison: do non-Western or non-capitalist contexts produce different ''natural'' legitimacy grounds?',
    'If natural/discovered, the mountain claim holds and alternative readings are aspirational impositions. If constructed, the reading is a false summit: claimed universality obscures beneficiary concentration, and engine-computed extraction from powerless seats exposes the structural asymmetry.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(natural_vs_constructed_optimization_legitimacy, empirical, 'Whether optimization legitimacy is discovered natural law or constructed beneficiary framing (FSM test).').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(ai_governance_legitimacy__technocratic_optimization_reading, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(ai_g_tr_t0, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 0, 0.18).
narrative_ontology:measurement(ai_g_tr_t5, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 5, 0.21).
narrative_ontology:measurement(ai_g_tr_t10, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 10, 0.24).
narrative_ontology:measurement(ai_g_tr_t15, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 15, 0.26).
narrative_ontology:measurement(ai_g_tr_t20, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 20, 0.28).
narrative_ontology:measurement(ai_g_tr_t25, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 25, 0.28).

% Extraction over time
narrative_ontology:measurement(ai_g_be_t0, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 0, 0.28).
narrative_ontology:measurement(ai_g_be_t5, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 5, 0.31).
narrative_ontology:measurement(ai_g_be_t10, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 10, 0.34).
narrative_ontology:measurement(ai_g_be_t15, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 15, 0.36).
narrative_ontology:measurement(ai_g_be_t20, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 20, 0.37).
narrative_ontology:measurement(ai_g_be_t25, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 25, 0.36).

% Suppression requirement over time
narrative_ontology:measurement(ai_g_su_t0, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 0, 0.32).
narrative_ontology:measurement(ai_g_su_t5, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 5, 0.36).
narrative_ontology:measurement(ai_g_su_t10, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 10, 0.39).
narrative_ontology:measurement(ai_g_su_t15, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 15, 0.41).
narrative_ontology:measurement(ai_g_su_t20, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 20, 0.42).
narrative_ontology:measurement(ai_g_su_t25, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 25, 0.42).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(ai_governance_legitimacy__technocratic_optimization_reading, identity_coordination).
narrative_ontology:affects_constraint(ai_governance_legitimacy__technocratic_optimization_reading, ai_governance_legitimacy__magisterial_subsidiarity_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__technocratic_optimization_reading, ai_governance_legitimacy__democratic_pluralist_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__technocratic_optimization_reading, ai_governance_legitimacy__market_libertarian_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the ai_governance_legitimacy kernel. The kernel decomposes into four structural positions with different ε, beneficiary/victim sets, and legitimacy grounds. Technocratic optimization reading (this story): moderate ε, benefits firms/investors, victims are displaced/profiled, epistemic authority. Magisterial subsidiarity reading: higher ε if violated (dignity violations weighted heavily), universal beneficiaries under subsidiarity, victims are atomized/commodified populations, magisterial authority. Democratic pluralist reading: lower ε (procedural legitimacy distributes costs), beneficiaries are inclusive publics, victims are minorities excluded from deliberation, democratic authority. Market libertarian reading: lowest ε from libertarian seat (voluntary exchange), beneficiaries are property holders, victims are those coerced by collective mandates, market authority. Network edges establish mutual influence and foreclosure relations across the family.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
