% ============================================================================
% CONSTRAINT STORY: acceptable_risk_energy__option_value_preserving
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_acceptable_risk_energy__option_value_preserving, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: acceptable_risk_energy__option_value_preserving
 *   human_readable: Option-Value Preserving Acceptable Risk Framework in Energy Policy
 *   domain: risk_assessment/energy_policy/decision_theory
 *
 * SUMMARY:
 *   This constraint story models the option-value preserving reading of
 *   acceptable risk in energy policy: the framework that treats maintaining
 *   multiple energy pathways — fossil, nuclear, and renewable — as
 *   intrinsically valuable under deep uncertainty about future technology,
 *   climate sensitivity, and geopolitical shocks. The reading is CLAIMED as
 *   mountain (a descriptively accurate application of real options theory to
 *   energy planning under Knightian uncertainty) while AUTHORED with
 *   substantial beneficiaries (portfolio managers, security planners) and
 *   victims (transition advocates bearing opportunity costs of slower
 *   commitment). The claim/metric divergence is deliberate: the engine
 *   measures whether the constraint operates as genuine coordination under
 *   uncertainty or as institutionalized preference for flexibility that
 *   systematically favors status quo diversification.
 *
 * KEY AGENTS:
 *   - diversified_energy_portfolio_managers: Primary beneficiary (institutional/mobile) — collect legitimacy and capital allocation authority from the optionality framework
 *   - national_security_energy_planners: Primary beneficiary (institutional/constrained) — use the framework to treat energy diversity as strategic asset
 *   - renewable_transition_advocates: Primary victim (organized/constrained) — bear opportunity cost of capital spread across pathways rather than concentrated in renewables
 *   - nuclear_phase_out_coalitions: Primary victim (organized/constrained) — bear reputational cost as the closing-options side of debate
 *   - fossil_exit_campaigners: Primary victim (organized/constrained) — their urgency framing is suppressed by optionality framing
 *   - stranded_asset_communities: Secondary victim (powerless/trapped) — bear localized health costs of continued legacy operation
 *   - decision_theorists: Analytical observer — test whether framework describes genuine coordination or beneficiary preference
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(acceptable_risk_energy__option_value_preserving, 0.42).
domain_priors:suppression_score(acceptable_risk_energy__option_value_preserving, 0.54).
domain_priors:theater_ratio(acceptable_risk_energy__option_value_preserving, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, extractiveness, 0.42).
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, suppression_requirement, 0.54).
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, accessibility_collapse, 0.36).
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, resistance, 0.58).

% --- Constraint claim ---
narrative_ontology:constraint_claim(acceptable_risk_energy__option_value_preserving, mountain).
narrative_ontology:human_readable(acceptable_risk_energy__option_value_preserving, "Option-Value Preserving Acceptable Risk Framework in Energy Policy").
narrative_ontology:topic_domain(acceptable_risk_energy__option_value_preserving, "risk_assessment/energy_policy/decision_theory").

domain_priors:requires_active_enforcement(acceptable_risk_energy__option_value_preserving).
domain_priors:emerges_naturally(acceptable_risk_energy__option_value_preserving).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(acceptable_risk_energy__option_value_preserving, 'a5759da0-d721-4963-a9f6-b0aa323f5f57').
narrative_ontology:cs_kernel_codification('a5759da0-d721-4963-a9f6-b0aa323f5f57', distributed).
narrative_ontology:cs_authority_grounding('a5759da0-d721-4963-a9f6-b0aa323f5f57', expertise).
narrative_ontology:cs_interpretation_layer_present('a5759da0-d721-4963-a9f6-b0aa323f5f57').
narrative_ontology:cs_reading_relation('a5759da0-d721-4963-a9f6-b0aa323f5f57', acceptable_risk_energy__catastrophic_tail_dominant, coexists_with).
narrative_ontology:cs_reading_relation('a5759da0-d721-4963-a9f6-b0aa323f5f57', acceptable_risk_energy__expected_value_dominant, coexists_with).
narrative_ontology:cs_axiom('a5759da0-d721-4963-a9f6-b0aa323f5f57', foundational, irreversible_closure_costs_dominate_aggregate_expected_harms).
narrative_ontology:cs_axiom_status(irreversible_closure_costs_dominate_aggregate_expected_harms, holdable).
narrative_ontology:cs_axiom_grounding('a5759da0-d721-4963-a9f6-b0aa323f5f57', irreversible_closure_costs_dominate_aggregate_expected_harms, instrumental).
narrative_ontology:cs_axiom('a5759da0-d721-4963-a9f6-b0aa323f5f57', foundational, pathway_diversity_has_intrinsic_strategic_value).
narrative_ontology:cs_axiom_status(pathway_diversity_has_intrinsic_strategic_value, holdable).
narrative_ontology:cs_axiom_grounding('a5759da0-d721-4963-a9f6-b0aa323f5f57', pathway_diversity_has_intrinsic_strategic_value, conventional).
narrative_ontology:cs_reference_frame('a5759da0-d721-4963-a9f6-b0aa323f5f57', mid_century_deep_uncertainty_energy_planning).
narrative_ontology:cs_drift_state('a5759da0-d721-4963-a9f6-b0aa323f5f57', contemporary_renewable_cost_collapse_era, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('a5759da0-d721-4963-a9f6-b0aa323f5f57', '').
narrative_ontology:cs_kernel_id(acceptable_risk_energy__option_value_preserving, acceptable_risk_energy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__option_value_preserving, diversified_energy_portfolio_managers).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__option_value_preserving, national_security_energy_planners).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__option_value_preserving, technology_agnostic_researchers).
narrative_ontology:constraint_victim(acceptable_risk_energy__option_value_preserving, renewable_transition_advocates).
narrative_ontology:constraint_victim(acceptable_risk_energy__option_value_preserving, nuclear_phase_out_coalitions).
narrative_ontology:constraint_victim(acceptable_risk_energy__option_value_preserving, fossil_exit_campaigners).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_victim(acceptable_risk_energy__option_value_preserving, stranded_asset_communities).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__option_value_preserving, deep_uncertainty_warrants_optionality).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__option_value_preserving, irreversibility_costs_outweigh_aggregate_harms).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__option_value_preserving, technological_path_dependence_creates_lock_in).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Manage grid-scale energy portfolios balancing fossil, nuclear, and renewable capacity. The option-preserving framework justifies maintaining baseload nuclear and dispatchable fossil capacity as insurance against renewable intermittency failures or breakthrough technology delays. Their planning horizon rewards flexibility over commitment to any single pathway.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, diversified_energy_portfolio_managers, beneficiary,
    institutional, generational, mobile, national).

% Assess energy security through scenario planning under geopolitical uncertainty. The framework allows them to treat energy diversity itself as a strategic asset — nuclear provides fuel independence, fossil provides rapid scaling, renewables provide distributed resilience. Premature closure of any pathway is framed as unacceptable strategic risk.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, national_security_energy_planners, beneficiary,
    institutional, civilizational, constrained, national).

% Model energy transitions under uncertainty using real options theory and decision science. The option-preserving reading provides analytical legitimacy: their models show that maintaining multiple pathways has quantifiable value when future states are uncertain and closure decisions are irreversible.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, technology_agnostic_researchers, beneficiary,
    organized, biographical, mobile, global).

% Campaign for rapid fossil and nuclear phase-out to accelerate renewable deployment. The option-preserving framework operates as suppression of their pathway: capital allocated to maintaining legacy baseload capacity is capital not flowing to renewable scaling, and the framing of their position as premature commitment undermines political momentum.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, renewable_transition_advocates, payer,
    organized, biographical, constrained, global).

% Advocate for nuclear closure on safety, waste, and proliferation grounds. The option-preserving framework treats their position as discarding valuable flexibility under uncertainty — they bear reputational cost as the closing-off-options side of the debate, and their safety concerns are reframed as overweighting low-probability tails against aggregate expected outcomes.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, nuclear_phase_out_coalitions, payer,
    organized, generational, constrained, national).

% Push for immediate fossil fuel phase-out on climate grounds. The option-preserving framework suppresses their claims by treating fossil capacity as strategic reserve rather than stranded asset — their urgency framing is countered with optionality framing, and continued fossil investment is justified as insurance rather than inertia.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, fossil_exit_campaigners, payer,
    organized, generational, constrained, global).

% Live in regions economically dependent on fossil or nuclear infrastructure that the option-preserving framework keeps operating. They bear the localized health and environmental costs of continued operation while the benefits accrue to national-scale portfolio managers and security planners. Their exit options are constrained by regional economic lock-in.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, stranded_asset_communities, payer,
    powerless, biographical, trapped, local).

% Analyze whether the option-value preserving reading is a descriptively accurate application of real options theory to energy under deep uncertainty, or whether it systematically overweights reversibility costs relative to climate tail risk. They test whether the framework's suppression of commitment-to-any-pathway is justified by genuine uncertainty or by beneficiary preference for status quo flexibility.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, decision_theorists, observer,
    analytical, civilizational, analytical, universal).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Resolves the collective action problem of how to allocate energy investment under Knightian uncertainty: when future technology breakthroughs, climate sensitivity, and geopolitical shocks are unknowable, maintaining diverse pathways prevents irreversible commitment errors.
% TRANSFER_FUNCTION: Moves political legitimacy and capital allocation authority from advocates of rapid single-pathway commitment to managers of diversified portfolios. Moves opportunity cost of slower transition from portfolio managers to communities bearing localized costs of continued legacy operation.
% ABSENT_VOICES: Future generations whose climate outcomes depend on transition speed are structurally excluded from the uncertainty-discount calculation. Communities bearing localized health costs of option preservation have no seat in national-scale portfolio optimization.
% DISAPPEARANCE_RATIONALE: Portfolio managers and security planners attest the world would rearrange: energy investment would shift toward committed pathways with higher aggregate expected harm under uncertainty. Transition advocates attest the world would rearrange beneficially: capital would flow to the pathway with highest marginal return rather than being spread across legacy systems. Decision theorists contest whether the framework describes a genuine coordination problem or institutionalizes beneficiary preference for flexibility.
% FOUNDING_PROBLEM: Mid-20th century energy planning faced genuine deep uncertainty: nuclear was untested at scale, fossil climate effects were unknown, renewable intermittency was unsolved. Committing to any single pathway risked catastrophic lock-in if that pathway failed.
% FOUNDING_PROBLEM_CORROBORATION: Portfolio managers and national security planners attest the founding uncertainty remains live: renewable storage breakthrough timing is unknown, climate sensitivity remains uncertain, geopolitical energy shocks are unpredictable. Climate scientists and renewable engineers from outside the portfolio-management community attest the founding uncertainty has substantially resolved: solar and wind cost curves are established, battery storage is scaling, climate sensitivity bounds are tightening. The contested status is whether sufficient uncertainty remains to justify continued diversification or whether the framework now serves beneficiary preference for optionality over commitment.
narrative_ontology:disappearance_verdict(acceptable_risk_energy__option_value_preserving, contested).
narrative_ontology:founding_problem_status(acceptable_risk_energy__option_value_preserving, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(acceptable_risk_energy__option_value_preserving, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(acceptable_risk_energy__option_value_preserving, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(acceptable_risk_energy__option_value_preserving_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, ExtMetricName, E),
    domain_priors:suppression_score(acceptable_risk_energy__option_value_preserving, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(acceptable_risk_energy__option_value_preserving),
    narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(acceptable_risk_energy__option_value_preserving_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is moderate (0.42 at interval end, rising from 0.28 at founding) because the framework systematically advantages portfolio managers and security planners who benefit from maintaining diverse capacity over advocates whose pathways are delayed. Suppression is substantial (0.54, rising from 0.38) because the constraint requires active enforcement of the both-and framing against advocates pushing for commitment to any single pathway — renewable, nuclear, or fossil exit positions are all suppressed as premature commitment. Theater ratio is moderate-low (0.28, rising from 0.15) because the real options analysis is genuine decision theory, but a growing share of optionality discourse defends status quo flexibility rather than responding to live uncertainty. Accessibility collapse is low (0.36) because alternative risk frameworks — expected value dominant and catastrophic tail dominant — remain live readings. Resistance is substantial (0.58) because all three advocate groups actively contest the framework's legitimacy. The measurements show gradual extraction accumulation as renewable cost curves establish and climate bounds tighten but the optionality framework persists.
 *
 * PERSPECTIVAL GAP:
 *   The beneficiary and victim seats should compute to different types: from portfolio managers' position the constraint is genuine coordination under deep uncertainty; from transition advocates' position it operates as enforced extraction favoring status quo diversification. The engine measures this divergence from the structural data — the mountain claim does not adjudicate it. The gap widens as measurements show rising extraction and suppression even as renewable costs fall and climate bounds tighten, suggesting the framework increasingly serves beneficiary preference rather than responding to live uncertainty.
 *
 * DIRECTIONALITY LOGIC:
 *   Portfolio managers and security planners are structural beneficiaries (d near 0.2): they collect authority and flexibility from the framework and have mobile exit (can adopt alternative frameworks if optionality becomes indefensible). Transition advocates across all three pathways are targets (d near 0.7): they bear opportunity costs of slower commitment and their positions are systematically framed as discarding valuable flexibility. Stranded asset communities are full targets (d near 0.9): powerless, trapped, bearing localized costs of continued operation justified at national scale. Decision theorists are analytical observers (d = 0.0): they assess the framework's validity from outside.
 *
 * MANDATROPHY ANALYSIS:
 *   The option-preserving reading exhibits mandatrophy signatures: founded to solve genuine deep uncertainty (mid-century nuclear/fossil/renewable unknowns), increasingly operating to preserve beneficiary flexibility as founding uncertainty resolves. The R5 genealogy interview produces contested founding_problem_status: portfolio managers attest uncertainty remains live, climate scientists and renewable engineers from outside the portfolio-management community attest it has substantially resolved. The mismatch between contested founding status and world_rearranges disappearance verdict flags potential capture: the framework persists not because uncertainty warrants it but because beneficiaries prefer optionality. The classification prevents mislabeling this as pure extraction (the coordination function under genuine uncertainty is real) while detecting the extraction that accumulates as uncertainty resolves but the framework persists.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    uncertainty_resolution_vs_optionality_persistence,
    'Has the founding deep uncertainty (renewable intermittency, nuclear safety, fossil climate effects) resolved sufficiently that continued diversification now serves beneficiary preference for flexibility rather than genuine coordination under uncertainty?',
    'Longitudinal analysis correlating renewable cost curves, battery storage scaling, climate sensitivity bound tightening, and nuclear operating experience against persistence of option-preserving framework in energy planning documents. If uncertainty metrics resolve substantially but framework persists unchanged, suggests mandate outlived function.',
    'If uncertainty has resolved but framework persists, the constraint is a false summit: claimed as mountain (genuine optionality under uncertainty) but operating as tangled rope (coordination function atrophied, extraction from delayed-transition victims now primary). If uncertainty remains live, the mountain claim is vindicated.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(uncertainty_resolution_vs_optionality_persistence, empirical, 'Whether optionality framework tracks live uncertainty or institutionalized beneficiary preference').

omega_variable(
    irreversibility_framing_vs_climate_tail,
    'Does the option-preserving framework systematically overweight reversibility costs of pathway closure relative to irreversibility costs of climate tail risk, and is this weighting determined by uncertainty structure or by beneficiary position?',
    'Decision-theoretic audit of which irreversibilities the framework treats as salient. If energy pathway closure is framed as irreversible but climate tipping points are discounted as speculative tails, suggests asymmetric irreversibility framing serving beneficiary preference.',
    'Asymmetric irreversibility framing would establish that the reading is not a neutral application of real options theory but a framing that systematically advantages portfolio managers'' preference for maintaining current diversification over transition advocates'' climate concerns.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(irreversibility_framing_vs_climate_tail, conceptual, 'Whether irreversibility weights are structurally symmetric or beneficiary-determined').

omega_variable(
    committer_framing_kernel,
    'Is the acceptable_risk_energy kernel itself a single contested commitment (one energy policy framework read differently) or three distinct constraint structures that happen to share a domain?',
    'Test whether the three readings produce systematically different epsilon values and beneficiary/victim structures when applied to the same empirical cases. If epsilon variance across readings is high, they are distinct constraints; if low, they are perspectives on one constraint.',
    'High epsilon variance (observed: catastrophic_tail_dominant heavily suppresses both fossil and nuclear, expected_value_dominant favors nuclear and disadvantages renewables, option_value_preserving suppresses all commitment positions) establishes that these are genuinely distinct constraints, not observer-relative framings of one structure. This vindicates the kernel decomposition per the epsilon-invariance principle.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(committer_framing_kernel, conceptual, 'Whether the kernel decomposition into three readings is structurally warranted').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(acceptable_risk_energy__option_value_preserving, 0, 40).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(acce_tr_t0, acceptable_risk_energy__option_value_preserving, theater_ratio, 0, 0.15).
narrative_ontology:measurement_basis(acce_tr_t0, observed).
narrative_ontology:measurement(acce_tr_t8, acceptable_risk_energy__option_value_preserving, theater_ratio, 8, 0.18).
narrative_ontology:measurement_basis(acce_tr_t8, observed).
narrative_ontology:measurement(acce_tr_t16, acceptable_risk_energy__option_value_preserving, theater_ratio, 16, 0.21).
narrative_ontology:measurement_basis(acce_tr_t16, observed).
narrative_ontology:measurement(acce_tr_t24, acceptable_risk_energy__option_value_preserving, theater_ratio, 24, 0.24).
narrative_ontology:measurement_basis(acce_tr_t24, observed).
narrative_ontology:measurement(acce_tr_t32, acceptable_risk_energy__option_value_preserving, theater_ratio, 32, 0.26).
narrative_ontology:measurement_basis(acce_tr_t32, observed).
narrative_ontology:measurement(acce_tr_t40, acceptable_risk_energy__option_value_preserving, theater_ratio, 40, 0.28).
narrative_ontology:measurement_basis(acce_tr_t40, observed).

% Extraction over time
narrative_ontology:measurement(acce_be_t0, acceptable_risk_energy__option_value_preserving, base_extractiveness, 0, 0.28).
narrative_ontology:measurement_basis(acce_be_t0, observed).
narrative_ontology:measurement(acce_be_t8, acceptable_risk_energy__option_value_preserving, base_extractiveness, 8, 0.31).
narrative_ontology:measurement_basis(acce_be_t8, observed).
narrative_ontology:measurement(acce_be_t16, acceptable_risk_energy__option_value_preserving, base_extractiveness, 16, 0.35).
narrative_ontology:measurement_basis(acce_be_t16, observed).
narrative_ontology:measurement(acce_be_t24, acceptable_risk_energy__option_value_preserving, base_extractiveness, 24, 0.38).
narrative_ontology:measurement_basis(acce_be_t24, observed).
narrative_ontology:measurement(acce_be_t32, acceptable_risk_energy__option_value_preserving, base_extractiveness, 32, 0.4).
narrative_ontology:measurement_basis(acce_be_t32, observed).
narrative_ontology:measurement(acce_be_t40, acceptable_risk_energy__option_value_preserving, base_extractiveness, 40, 0.42).
narrative_ontology:measurement_basis(acce_be_t40, observed).

% Suppression requirement over time
narrative_ontology:measurement(acce_su_t0, acceptable_risk_energy__option_value_preserving, suppression_requirement, 0, 0.38).
narrative_ontology:measurement_basis(acce_su_t0, observed).
narrative_ontology:measurement(acce_su_t8, acceptable_risk_energy__option_value_preserving, suppression_requirement, 8, 0.42).
narrative_ontology:measurement_basis(acce_su_t8, observed).
narrative_ontology:measurement(acce_su_t16, acceptable_risk_energy__option_value_preserving, suppression_requirement, 16, 0.46).
narrative_ontology:measurement_basis(acce_su_t16, observed).
narrative_ontology:measurement(acce_su_t24, acceptable_risk_energy__option_value_preserving, suppression_requirement, 24, 0.49).
narrative_ontology:measurement_basis(acce_su_t24, observed).
narrative_ontology:measurement(acce_su_t32, acceptable_risk_energy__option_value_preserving, suppression_requirement, 32, 0.52).
narrative_ontology:measurement_basis(acce_su_t32, observed).
narrative_ontology:measurement(acce_su_t40, acceptable_risk_energy__option_value_preserving, suppression_requirement, 40, 0.54).
narrative_ontology:measurement_basis(acce_su_t40, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(acceptable_risk_energy__option_value_preserving, resource_allocation).
narrative_ontology:boltzmann_floor_override(acceptable_risk_energy__option_value_preserving, 0.18).
narrative_ontology:affects_constraint(acceptable_risk_energy__option_value_preserving, acceptable_risk_energy__catastrophic_tail_dominant).
narrative_ontology:affects_constraint(acceptable_risk_energy__option_value_preserving, acceptable_risk_energy__expected_value_dominant).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the acceptable_risk_energy kernel. The three readings (option_value_preserving, catastrophic_tail_dominant, expected_value_dominant) share the energy policy domain but produce distinct epsilon values, beneficiary/victim structures, and suppression targets. The option_value_preserving reading systematically suppresses commitment to any single pathway (renewable, nuclear, or fossil exit) by framing all such commitments as discarding valuable flexibility. The catastrophic_tail_dominant reading systematically suppresses nuclear and fossil by prioritizing avoidance of low-probability catastrophic outcomes. The expected_value_dominant reading systematically suppresses renewable advocacy by treating mortality-per-TWh as the only relevant metric. Each reading instantiates a different constraint with different structural properties; they are linked here as members of the same kernel family.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
