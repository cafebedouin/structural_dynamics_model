% ============================================================================
% CONSTRAINT STORY: acceptable_risk_energy__option_value_preserving
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_acceptable_risk_energy__option_value_preserving, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: acceptable_risk_energy__option_value_preserving
 *   human_readable: Option Value Energy Risk Framework
 *   domain: risk_assessment/energy_policy/decision_theory
 *
 * SUMMARY:
 *   Energy regulators frame acceptable risk as requiring preservation of
 *   multiple generation pathways under deep uncertainty about future
 *   technology costs and demand trajectories. This reading of acceptable risk
 *   emphasizes option value and decision flexibility, justifying delayed
 *   retirement of fossil and nuclear assets while renewable alternatives
 *   mature. The framework treats pathway choice symmetry as given and
 *   uncertainty as irreducible, which operationally protects incumbent
 *   generation from premature closure. Climate advocates contest this
 *   framing, arguing it systematically discounts climate risk accumulation
 *   and treats asymmetric pathways as symmetric.
 *
 * KEY AGENTS:
 *   - Incumbent energy operators: Primary beneficiary (institutional/constrained) — collect revenue from existing assets, avoid premature writedowns through option-value justification
 *   - Regulatory authorities: Agenda setter (institutional/analytical) — define acceptable risk criteria using option-value logic, justify delayed closures
 *   - Climate-vulnerable populations: Primary target (powerless/trapped) — bear accumulated climate damages from delayed fossil retirement without voice in risk assessment
 *   - Ratepayers: Secondary target (organized/constrained) — pay for parallel pathway maintenance and absorb stranded costs when delayed retirement occurs
 *   - Decision theorists: Analytical observer — study how option-value framing interacts with institutional incentives and pathway asymmetry
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(acceptable_risk_energy__option_value_preserving, 0.52).
domain_priors:suppression_score(acceptable_risk_energy__option_value_preserving, 0.58).
domain_priors:theater_ratio(acceptable_risk_energy__option_value_preserving, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, extractiveness, 0.52).
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, suppression_requirement, 0.58).
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, resistance, 0.54).

% --- Constraint claim ---
narrative_ontology:constraint_claim(acceptable_risk_energy__option_value_preserving, tangled_rope).
narrative_ontology:human_readable(acceptable_risk_energy__option_value_preserving, "Option Value Energy Risk Framework").
narrative_ontology:topic_domain(acceptable_risk_energy__option_value_preserving, "risk_assessment/energy_policy/decision_theory").

domain_priors:requires_active_enforcement(acceptable_risk_energy__option_value_preserving).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(acceptable_risk_energy__option_value_preserving, '947f7fcf-2067-474c-aa8f-0dafb4aa5e5a').
narrative_ontology:cs_kernel_codification('947f7fcf-2067-474c-aa8f-0dafb4aa5e5a', distributed).
narrative_ontology:cs_authority_grounding('947f7fcf-2067-474c-aa8f-0dafb4aa5e5a', expertise).
narrative_ontology:cs_interpretation_layer_present('947f7fcf-2067-474c-aa8f-0dafb4aa5e5a').
narrative_ontology:cs_reading_relation('947f7fcf-2067-474c-aa8f-0dafb4aa5e5a', acceptable_risk_energy__catastrophic_tail_dominant, coexists_with).
narrative_ontology:cs_reading_relation('947f7fcf-2067-474c-aa8f-0dafb4aa5e5a', acceptable_risk_energy__expected_value_dominant, coexists_with).
narrative_ontology:cs_axiom('947f7fcf-2067-474c-aa8f-0dafb4aa5e5a', foundational, flexibility_premium_under_irreducible_uncertainty).
narrative_ontology:cs_axiom_status(flexibility_premium_under_irreducible_uncertainty, holdable).
narrative_ontology:cs_axiom_grounding('947f7fcf-2067-474c-aa8f-0dafb4aa5e5a', flexibility_premium_under_irreducible_uncertainty, instrumental).
narrative_ontology:cs_axiom('947f7fcf-2067-474c-aa8f-0dafb4aa5e5a', foundational, pathway_symmetric_treatment).
narrative_ontology:cs_axiom_status(pathway_symmetric_treatment, holdable).
narrative_ontology:cs_axiom_grounding('947f7fcf-2067-474c-aa8f-0dafb4aa5e5a', pathway_symmetric_treatment, empirically_contingent).
narrative_ontology:cs_reference_frame('947f7fcf-2067-474c-aa8f-0dafb4aa5e5a', mid_century_energy_planning_uncertainty).
narrative_ontology:cs_drift_state('947f7fcf-2067-474c-aa8f-0dafb4aa5e5a', contemporary_climate_constrained_era, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('947f7fcf-2067-474c-aa8f-0dafb4aa5e5a', '').
narrative_ontology:cs_kernel_id(acceptable_risk_energy__option_value_preserving, acceptable_risk_energy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__option_value_preserving, incumbent_energy_operators).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__option_value_preserving, regulatory_authorities).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__option_value_preserving, grid_planners).
narrative_ontology:constraint_victim(acceptable_risk_energy__option_value_preserving, climate_vulnerable_populations).
narrative_ontology:constraint_victim(acceptable_risk_energy__option_value_preserving, ratepayers_bearing_stranded_costs).
narrative_ontology:constraint_victim(acceptable_risk_energy__option_value_preserving, renewable_market_entrants).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__option_value_preserving, flexibility_has_intrinsic_value).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__option_value_preserving, irreversible_decisions_warrant_delay).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Operate legacy fossil and nuclear generation assets requiring decades-long capital recovery. They argue that option-value logic justifies keeping multiple pathways viable during the energy transition, which means delaying closure decisions and maintaining regulatory frameworks that allow continued operation. They collect revenue from existing assets and avoid premature writedowns.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, incumbent_energy_operators, beneficiary,
    institutional, generational, constrained, national).

% Set acceptable risk criteria and licensing standards. They frame energy pathway decisions as requiring flexibility preservation under deep uncertainty about future technology costs, climate impacts, and demand trajectories. This framing justifies maintaining diversified generation portfolios and delaying irreversible closures, which operationally means slower fossil retirement and continued nuclear licensing.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, regulatory_authorities, agenda_setter,
    institutional, generational, analytical, national).

% Design long-term grid infrastructure under genuine uncertainty about technology trajectories and demand growth. Option-value logic provides analytical cover for conservative planning that preserves existing generation mix rather than accelerating renewable integration. They benefit from reduced planning risk and political accountability for premature closures.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, grid_planners, beneficiary,
    institutional, generational, constrained, regional).

% Bear the accumulated climate damages from delayed fossil retirement. The option-value framework treats climate risk as one uncertain factor among many, which systematically discounts harms that accumulate through delay. They have no voice in acceptable-risk determinations and carry costs that never appear in the flexibility calculation.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, climate_vulnerable_populations, payer,
    powerless, generational, trapped, global).

% Pay for maintaining multiple parallel generation pathways through rate structures that socialize stranded asset costs when delayed retirement eventually happens. The option-value justification shifts closure timing risk onto them: they pay for flexibility whose exercise they do not control, and when assets are eventually retired, they absorb the writedown through rates.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, ratepayers_bearing_stranded_costs, payer,
    organized, biographical, constrained, regional).

% Face regulatory frameworks and market structures optimized for incumbent pathway preservation. Option-value logic justifies capacity markets, nuclear subsidies, and dispatch rules that maintain fossil and nuclear viability, which crowds out renewable investment and delays market transformation. They can exit to other jurisdictions but face global coordination problems.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, renewable_market_entrants, payer,
    powerful, biographical, mobile, global).

% Argue that option-value framing systematically biases toward delay and incumbent protection by treating all pathways as symmetric when fossil retirement is climatically constrained. They are excluded from technical risk assessment processes that define acceptable risk, appearing instead in political advocacy channels where their arguments are framed as preference rather than analysis.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, energy_transition_advocates, excluded,
    organized, generational, constrained, global).

% Study how framing effects and option-value theory interact with institutional incentives. They observe that option-value logic can justify indefinite delay when uncertainty is irreducible, and that the framework treats pathway symmetry as given rather than recognizing asymmetric climate constraints. They have no direct stake but provide analytical perspective on how the framing structures outcomes.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, decision_theorists, observer,
    analytical, civilizational, analytical, universal).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a decision framework for managing energy infrastructure under genuine technological and demand uncertainty, allowing regulators to avoid premature irreversible closures when future conditions are unclear.
% TRANSFER_FUNCTION: Moves climate risk and stranded cost burden from incumbent operators and regulatory agencies onto climate-vulnerable populations and ratepayers, while transferring market opportunity from renewable entrants to incumbent generators through delayed transition timing.
% ABSENT_VOICES: Climate-vulnerable populations who bear accumulated damages from delay have no seat in technical risk assessment processes; energy transition advocates are excluded from the analytical framework that defines acceptable risk and appear only in downstream political channels where their arguments are framed as values rather than risk analysis.
% DISAPPEARANCE_RATIONALE: If option-value justification for pathway preservation disappeared, regulatory frameworks would shift from flexibility-maximizing to climate-constrained retirement schedules, fossil and nuclear operators would face accelerated closure timelines without option-value cover, and renewable integration would accelerate as market structures stopped optimizing for incumbent viability.
% FOUNDING_PROBLEM: Mid-20th century energy planning faced genuine deep uncertainty about future electricity demand growth, fossil fuel availability, and nuclear technology trajectories, requiring decision frameworks that could preserve flexibility when irreversible infrastructure commitments were necessary.
% FOUNDING_PROBLEM_CORROBORATION: Regulatory authorities and grid planners attest the founding problem remains live, citing continued uncertainty about renewable intermittency solutions and demand electrification rates. Climate scientists, renewable technology analysts, and energy economists outside the regulatory apparatus attest that the relevant uncertainties have substantially resolved since the founding era: renewable cost trajectories are established, climate constraints are binding, and the asymmetry between pathways eliminates the symmetry assumption option-value logic depends on.
narrative_ontology:disappearance_verdict(acceptable_risk_energy__option_value_preserving, world_rearranges).
narrative_ontology:founding_problem_status(acceptable_risk_energy__option_value_preserving, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(acceptable_risk_energy__option_value_preserving, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(acceptable_risk_energy__option_value_preserving, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(acceptable_risk_energy__option_value_preserving_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(acceptable_risk_energy__option_value_preserving, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(acceptable_risk_energy__option_value_preserving_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is moderate-high (0.52) because the framework systematically transfers climate risk and stranded costs from protected incumbents onto powerless populations and organized ratepayers, while genuine coordination benefit exists in managing technological uncertainty. Suppression is substantial (0.58) because maintaining the option-value framework requires excluding climate-constrained perspectives from technical risk assessment and framing transition advocacy as political preference rather than risk analysis. Theater ratio is moderate (0.42): flexibility preservation under uncertainty is a real decision theory problem, but a growing share of the analytical apparatus defends incumbent viability rather than optimizing social welfare under climate constraints. The measurements show rising extraction and theater as climate constraints tighten while the framework continues treating pathways symmetrically.
 *
 * PERSPECTIVAL GAP:
 *   The regulatory/incumbent seat experiences this as genuine coordination under uncertainty, seeing option-value logic as prudent risk management. The climate-vulnerable and ratepayer seats experience it as extraction: climate damages accumulate while flexibility justifications delay action, and stranded costs are socialized onto them when delayed retirement eventually occurs. The gap is structural: option-value maximization for decision-makers systematically externalizes costs onto those outside the decision framework.
 *
 * DIRECTIONALITY LOGIC:
 *   Incumbent operators and regulatory authorities are structural beneficiaries: the framework protects existing assets and provides analytical cover for delayed action, placing them near the beneficiary end of directionality. Climate-vulnerable populations are full targets: trapped, powerless, bearing costs excluded from the flexibility calculation — high d, high effective extraction. Ratepayers are intermediate targets: organized but constrained, paying for flexibility they do not control. Renewable entrants are powerful but face structural barriers the framework justifies, placing them as partial targets despite nominal mobility.
 *
 * MANDATROPHY ANALYSIS:
 *   This is tangled rope, not pure snare, because flexibility preservation under genuine technological uncertainty is a real coordination function — early-2000s regulatory decisions faced legitimate unknowns about renewable scalability and nuclear safety post-Fukushima. The mandate/function gap appears as climate science resolves uncertainty asymmetrically: fossil pathways face binding constraints while renewables demonstrate viability, but the option-value framework continues treating pathways symmetrically because that symmetry assumption protects incumbent assets. The extraction is not the coordination function itself but the persistence of symmetric treatment after asymmetry is established.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    uncertainty_resolution_threshold,
    'At what point does uncertainty about renewable scalability and fossil climate impacts resolve sufficiently that option-value logic no longer justifies pathway preservation?',
    'Longitudinal analysis of renewable cost curves, grid integration studies, and climate science confidence intervals. If renewable LCOE falls below fossil with storage at scale and climate constraints are quantitatively binding, the uncertainties justifying symmetry have resolved.',
    'If uncertainties have resolved, continued pathway preservation is rent protection rather than prudent flexibility management, and the constraint reclassifies from tangled rope toward snare. If uncertainties remain irreducible, the option-value framework remains coordination.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(uncertainty_resolution_threshold, empirical, 'Whether the founding uncertainties justifying option-value logic have resolved.').

omega_variable(
    pathway_symmetry_assumption,
    'Does option-value theory require treating all pathways as symmetric, or can it accommodate asymmetric constraints where one pathway faces binding limits?',
    'Decision theory analysis of option value under asymmetric constraint sets. If standard option-value formulations explicitly handle binding constraints on subsets of the option space, the framework can accommodate climate asymmetry; if they assume symmetric option sets, applying it to asymmetric pathways is a category error.',
    'If the framework cannot accommodate asymmetry, applying it to climatically constrained energy decisions is structural misuse that manufactures delay, and the extraction is higher than the coordination benefit. If it can accommodate asymmetry but implementations ignore it, the extraction is institutional capture rather than analytical necessity.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(pathway_symmetry_assumption, conceptual, 'Whether option-value logic structurally requires pathway symmetry or implementations impose it.').

omega_variable(
    stranded_cost_allocation,
    'When delayed retirement eventually occurs and assets are stranded, who bears the writedown — ratepayers through socialized recovery, or shareholders through market discipline?',
    'Regulatory rate case outcomes and jurisdiction-level analysis of stranded asset cost allocation. Track whether regulators allow cost recovery through rates or require shareholder absorption.',
    'If costs are systematically socialized, option-value logic shifts tail risk from protected incumbents onto captive ratepayers, increasing effective extraction. If shareholders bear stranded costs, the framework''s extraction is lower because downside risk remains with decision-makers.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(stranded_cost_allocation, empirical, 'Who ultimately bears the cost of flexibility preservation when options are exercised.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(acceptable_risk_energy__option_value_preserving, 0, 40).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(acce_tr_t0, acceptable_risk_energy__option_value_preserving, theater_ratio, 0, 0.22).
narrative_ontology:measurement(acce_tr_t8, acceptable_risk_energy__option_value_preserving, theater_ratio, 8, 0.26).
narrative_ontology:measurement(acce_tr_t16, acceptable_risk_energy__option_value_preserving, theater_ratio, 16, 0.31).
narrative_ontology:measurement(acce_tr_t24, acceptable_risk_energy__option_value_preserving, theater_ratio, 24, 0.35).
narrative_ontology:measurement(acce_tr_t32, acceptable_risk_energy__option_value_preserving, theater_ratio, 32, 0.38).
narrative_ontology:measurement(acce_tr_t40, acceptable_risk_energy__option_value_preserving, theater_ratio, 40, 0.42).

% Extraction over time
narrative_ontology:measurement(acce_be_t0, acceptable_risk_energy__option_value_preserving, base_extractiveness, 0, 0.35).
narrative_ontology:measurement(acce_be_t8, acceptable_risk_energy__option_value_preserving, base_extractiveness, 8, 0.38).
narrative_ontology:measurement(acce_be_t16, acceptable_risk_energy__option_value_preserving, base_extractiveness, 16, 0.42).
narrative_ontology:measurement(acce_be_t24, acceptable_risk_energy__option_value_preserving, base_extractiveness, 24, 0.46).
narrative_ontology:measurement(acce_be_t32, acceptable_risk_energy__option_value_preserving, base_extractiveness, 32, 0.49).
narrative_ontology:measurement(acce_be_t40, acceptable_risk_energy__option_value_preserving, base_extractiveness, 40, 0.52).

% Suppression requirement over time
narrative_ontology:measurement(acce_su_t0, acceptable_risk_energy__option_value_preserving, suppression_requirement, 0, 0.38).
narrative_ontology:measurement(acce_su_t8, acceptable_risk_energy__option_value_preserving, suppression_requirement, 8, 0.42).
narrative_ontology:measurement(acce_su_t16, acceptable_risk_energy__option_value_preserving, suppression_requirement, 16, 0.47).
narrative_ontology:measurement(acce_su_t24, acceptable_risk_energy__option_value_preserving, suppression_requirement, 24, 0.51).
narrative_ontology:measurement(acce_su_t32, acceptable_risk_energy__option_value_preserving, suppression_requirement, 32, 0.55).
narrative_ontology:measurement(acce_su_t40, acceptable_risk_energy__option_value_preserving, suppression_requirement, 40, 0.58).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(acceptable_risk_energy__option_value_preserving, resource_allocation).
narrative_ontology:boltzmann_floor_override(acceptable_risk_energy__option_value_preserving, 0.12).
narrative_ontology:affects_constraint(acceptable_risk_energy__option_value_preserving, acceptable_risk_energy__catastrophic_tail_dominant).
narrative_ontology:affects_constraint(acceptable_risk_energy__option_value_preserving, acceptable_risk_energy__expected_value_dominant).

% DUAL FORMULATION NOTE:
% This constraint is one of three readings of the acceptable_risk_energy kernel. The option_value_preserving reading emphasizes flexibility and treats pathways symmetrically; the catastrophic_tail_dominant reading prioritizes tail risk avoidance; the expected_value_dominant reading optimizes aggregate mortality metrics. The readings differ in victim sets (this reading's victims include climate-vulnerable populations and renewable market entrants, which are asymmetric to the other readings), in their treatment of uncertainty (this reading treats it as irreducible and justifying delay, others resolve it differently), and in institutional beneficiaries (this reading protects incumbent operators most strongly).

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
