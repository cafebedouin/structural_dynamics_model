% ============================================================================
% CONSTRAINT STORY: waitangi_sovereignty_allocation__partnership_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_waitangi_sovereignty_allocation__partnership_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: waitangi_sovereignty_allocation__partnership_reading
 *   human_readable: Treaty of Waitangi Partnership Doctrine
 *   domain: constitutional/indigenous_rights/post_colonial
 *
 * SUMMARY:
 *   The Treaty of Waitangi (1840) has competing English and Māori texts that
 *   allocate sovereignty differently. By the 1980s, judicial construction
 *   produced the partnership doctrine: an ongoing Crown-Māori relationship
 *   requiring consultation and active protection of Māori interests. This
 *   reading holds that the Treaty established neither full Crown sovereignty
 *   nor full Māori self-determination, but rather a partnership framework.
 *   The constraint coordinates relations between Crown and Māori institutions
 *   while extracting by closing the structural reallocation question —
 *   settlements are full-and-final, consultation does not equal consent, and
 *   parliamentary sovereignty remains intact.
 *
 * KEY AGENTS:
 *   - Crown legal apparatus (institutional/analytical) — interprets Treaty principles, administers consultation, determines settlement adequacy
 *   - Treaty settlement administrators (institutional/mobile) — manage reconciliation process that closes future claims
 *   - Corporate resource extractors (powerful/mobile) — benefit from consultation framework that creates process obligations without blocking development
 *   - Dispossessed Māori communities (organized/identity_locked) — bear historical loss and must accept settlements as full-and-final to access any redress
 *   - Iwi challenging settlements (organized/identity_locked) — contest adequacy of redress within a framework that preserves Crown sovereignty
 *   - Crown sovereignty proponents (powerful/mobile) — benefit from a doctrine that moderates without displacing parliamentary supremacy
 *   - Constitutional law observers (analytical/analytical) — document the partnership reading as judicial construction that manages textual divergence without resolving it
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(waitangi_sovereignty_allocation__partnership_reading, 0.48).
domain_priors:suppression_score(waitangi_sovereignty_allocation__partnership_reading, 0.52).
domain_priors:theater_ratio(waitangi_sovereignty_allocation__partnership_reading, 0.38).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, extractiveness, 0.48).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 0.52).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 0.38).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, accessibility_collapse, 0.35).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, resistance, 0.62).

% --- Constraint claim ---
narrative_ontology:constraint_claim(waitangi_sovereignty_allocation__partnership_reading, tangled_rope).
narrative_ontology:human_readable(waitangi_sovereignty_allocation__partnership_reading, "Treaty of Waitangi Partnership Doctrine").
narrative_ontology:topic_domain(waitangi_sovereignty_allocation__partnership_reading, "constitutional/indigenous_rights/post_colonial").

domain_priors:requires_active_enforcement(waitangi_sovereignty_allocation__partnership_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(waitangi_sovereignty_allocation__partnership_reading, '7b752fe2-84da-474d-b31b-fca71ab1d19a').
narrative_ontology:cs_kernel_codification('7b752fe2-84da-474d-b31b-fca71ab1d19a', fixed_text).
narrative_ontology:cs_authority_grounding('7b752fe2-84da-474d-b31b-fca71ab1d19a', lineage).
narrative_ontology:cs_interpretation_layer_present('7b752fe2-84da-474d-b31b-fca71ab1d19a').
narrative_ontology:cs_reading_relation('7b752fe2-84da-474d-b31b-fca71ab1d19a', waitangi_sovereignty_allocation__crown_sovereignty_reading, influences).
narrative_ontology:cs_reading_relation('7b752fe2-84da-474d-b31b-fca71ab1d19a', waitangi_sovereignty_allocation__rangatiratanga_reading, coexists_with).
narrative_ontology:cs_axiom('7b752fe2-84da-474d-b31b-fca71ab1d19a', foundational, treaty_creates_ongoing_partnership_obligation).
narrative_ontology:cs_axiom_status(treaty_creates_ongoing_partnership_obligation, holdable).
narrative_ontology:cs_axiom_grounding('7b752fe2-84da-474d-b31b-fca71ab1d19a', treaty_creates_ongoing_partnership_obligation, conventional).
narrative_ontology:cs_axiom('7b752fe2-84da-474d-b31b-fca71ab1d19a', secondary, consultation_satisfies_protection_duty).
narrative_ontology:cs_axiom_status(consultation_satisfies_protection_duty, holdable).
narrative_ontology:cs_axiom_grounding('7b752fe2-84da-474d-b31b-fca71ab1d19a', consultation_satisfies_protection_duty, conventional).
narrative_ontology:cs_reference_frame('7b752fe2-84da-474d-b31b-fca71ab1d19a', treaty_partnership_emergence_1980s).
narrative_ontology:cs_drift_state('7b752fe2-84da-474d-b31b-fca71ab1d19a', contemporary_post_settlement_era, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('7b752fe2-84da-474d-b31b-fca71ab1d19a', '').
narrative_ontology:cs_kernel_id(waitangi_sovereignty_allocation__partnership_reading, waitangi_sovereignty_allocation).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__partnership_reading, crown_legal_apparatus).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__partnership_reading, treaty_settlement_process_administrators).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__partnership_reading, corporate_resource_extractors).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__partnership_reading, dispossessed_maori_communities).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__partnership_reading, iwi_challenging_inadequate_settlements).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__partnership_reading, crown_sovereignty_proponents).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__partnership_reading, partnership_doctrine_legitimacy).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__partnership_reading, principles_based_interpretation).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Interprets Treaty principles through judicial doctrine, administers the consultation framework, and determines what 'good faith' and 'active protection' require in specific cases. Controls the tempo and scope of Treaty settlements. The partnership reading preserves Crown sovereignty while moderating its exercise — the apparatus benefits from a doctrine that acknowledges Māori claims without structural power transfer.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, crown_legal_apparatus, agenda_setter,
    institutional, generational, analytical, national).

% Manage the negotiation and implementation of Treaty settlements under the partnership framework. Settlements provide redress for historical breaches but remain full-and-final, precluding future claims. Administrators collect institutional authority and resources from running the process; the partnership reading legitimates the settlement machinery as reconciliation while closing the door to ongoing claims.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, treaty_settlement_process_administrators, beneficiary,
    institutional, biographical, mobile, national).

% Operate under consultation requirements that create process obligations but rarely block development. The partnership reading requires the Crown to consult iwi before issuing resource consents, but consultation does not equal consent — corporations gain social license through process compliance while substantive outcomes remain driven by economic interests. The doctrine moderates extraction without preventing it.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, corporate_resource_extractors, beneficiary,
    powerful, biographical, mobile, national).

% Lost land, resources, and autonomy through Crown actions the partnership doctrine now frames as historical breaches requiring redress. Settlements provide monetary compensation and symbolic acknowledgment but do not restore the full authority Article II guaranteed in the Māori text. Communities must accept settlements as full-and-final to access any redress; rejecting inadequate settlements means remaining outside the reconciliation framework indefinitely. Identity-locked: exit would mean abandoning Treaty claims entirely.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, dispossessed_maori_communities, payer,
    organized, generational, identity_locked, regional).

% Contest the adequacy of settlement offers and the partnership framework's structural limits. They argue consultation without veto power, and settlements that close claims in perpetuity, do not honor the Treaty's original allocation of authority. Litigation and negotiation remain their only tools; the partnership reading constrains Crown power modestly but leaves parliamentary sovereignty intact, so no court can compel structural reallocation. Identity-locked for the same reason as dispossessed communities.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, iwi_challenging_inadequate_settlements, payer,
    organized, generational, identity_locked, regional).

% Defend Westminster parliamentary supremacy and oppose any Treaty interpretation that would structurally limit Crown authority. The partnership reading serves their interests by acknowledging Māori claims through consultation and settlements while preserving the core sovereignty framework — it moderates without displacing Crown power.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, crown_sovereignty_proponents, beneficiary,
    powerful, generational, mobile, national).

% Analyze the partnership doctrine's operation and its divergence from both the English Article I text (which granted full sovereignty) and the Māori Article II text (which retained tino rangatiratanga). They document how the partnership reading emerged through judicial construction in the 1980s-90s as a third path, and how it functions to legitimate ongoing Crown authority while providing limited redress.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, constitutional_law_observers, observer,
    analytical, generational, analytical, national).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a legal framework for ongoing Crown-Māori relations when the Treaty's English and Māori texts allocate sovereignty differently: the partnership doctrine coordinates expectations about consultation, resource management, and historical redress without requiring either party to concede its textual reading.
% TRANSFER_FUNCTION: Moves decision-making authority and resource control from what the Māori text guaranteed (tino rangatiratanga over lands and taonga) to a Crown-administered consultation process that acknowledges Māori interests but leaves final authority with Parliament and the courts. Transfers historical grievances into time-limited settlement processes that close claims permanently.
% ABSENT_VOICES: Rangatiratanga advocates who hold the Māori text as authoritative are structurally marginalized: courts treat the partnership doctrine as settled law, so challenges to its adequacy must argue within the partnership frame rather than from the alternative textual allocation. International indigenous rights frameworks that would support substantive self-determination are referenced but not adopted into domestic law.
% DISAPPEARANCE_RATIONALE: If the partnership doctrine disappeared overnight, the Crown would face a binary choice between the competing textual readings: either full parliamentary sovereignty per the English text (reverting to 19th-century unilateral authority) or recognizing tino rangatiratanga per the Māori text (requiring structural power-sharing or federalism). Resource consent processes, Treaty settlements, and consultation frameworks would all collapse, forcing renegotiation from first principles.
% FOUNDING_PROBLEM: The Treaty's English and Māori texts allocate sovereignty differently (English: full cession; Māori: retention of rangatiratanga with limited kāwanatanga over settlers). By the 1970s-80s, rising Māori political mobilization and land rights litigation made the textual divergence judicially unavoidable, but neither full Crown sovereignty nor full rangatiratanga was politically feasible. The partnership doctrine emerged to resolve the impasse without requiring either party to abandon its textual claim.
% FOUNDING_PROBLEM_CORROBORATION: The textual divergence remains unresolved and contested. Legal historians and Māori scholars outside the Crown apparatus document that the partnership reading is a judicial construction, not a discovery of original intent, and that it emerged specifically to moderate sovereignty claims without resolving them. The founding problem persists because the two-text allocation has never been reconciled, only managed through the partnership framework.
narrative_ontology:disappearance_verdict(waitangi_sovereignty_allocation__partnership_reading, world_rearranges).
narrative_ontology:founding_problem_status(waitangi_sovereignty_allocation__partnership_reading, live).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(waitangi_sovereignty_allocation__partnership_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(waitangi_sovereignty_allocation__partnership_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(waitangi_sovereignty_allocation__partnership_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(waitangi_sovereignty_allocation__partnership_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(waitangi_sovereignty_allocation__partnership_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is moderate-high (0.48 at interval end) because the partnership reading transfers decision authority from what Article II guaranteed in the Māori text to a Crown-administered consultation process, and closes historical claims permanently through settlements. The coordination function is real — it provides a framework for ongoing relations — but the asymmetry is substantial: consultation without veto, redress without restoration of authority. Suppression (0.52) reflects that challenging the partnership doctrine means litigating within it or remaining outside the settlement process indefinitely; the framework has become the only recognized path to redress. Theater ratio (0.38) captures the growing gap between partnership rhetoric (equal partners, good faith) and structural reality (parliamentary sovereignty intact, settlements that close claims in perpetuity). Accessibility collapse is low (0.35) because the textual alternatives remain live political claims even as courts treat partnership as settled law. Resistance is substantial (0.62): ongoing iwi litigation, political mobilization for constitutional transformation, and international indigenous rights advocacy all contest the adequacy of the partnership reading. The measurement trajectories show modest extraction accumulation as the settlement process matures and the doctrine's limits become clearer.
 *
 * PERSPECTIVAL GAP:
 *   From the Crown apparatus seat, the partnership doctrine is a principled resolution of textual ambiguity that balances historical justice with constitutional stability. From the dispossessed and challenging iwi seats, the same structure operates as managed extraction: symbolic acknowledgment and limited redress that forecloses the structural reallocation the Māori text promised. From the corporate extractor seat, it is workable coordination that creates predictable process obligations. The engine should compute these divergences from the structural data: beneficiaries near d=0.2, organized Māori payers near d=0.75, with identity-lock amplifying effective extraction for the latter.
 *
 * DIRECTIONALITY LOGIC:
 *   Crown legal apparatus and settlement administrators are structural beneficiaries: the partnership reading preserves their institutional authority while providing a legitimacy framework for ongoing Crown governance. Corporate extractors benefit as secondary parties: consultation requirements create process costs but rarely block resource development. Dispossessed communities and challenging iwi are the targets: they bear the historical loss and must navigate a framework that acknowledges their claims symbolically while constraining structural redress. Crown sovereignty proponents benefit indirectly: the partnership doctrine moderates Crown authority just enough to maintain legitimacy without threatening parliamentary supremacy. The identity-locked exit status for Māori stakeholders reflects that abandoning Treaty claims would mean abandoning the ancestral and legal relationship that grounds their collective identity; there is no exit from the Treaty relationship itself, only choices about how to engage within its contested interpretations.
 *
 * MANDATROPHY ANALYSIS:
 *   The partnership reading resolves mandatrophy by identifying both the coordination function (managing ongoing Crown-Māori relations under textual ambiguity) and the asymmetric extraction (transferring decision authority from Māori text guarantees to Crown-administered process, closing structural reallocation through settlements). The claim is tangled_rope, not snare, because the coordination function is genuine: absent some framework, the textual divergence would produce legal chaos. The extraction is also genuine: the framework preserves Crown sovereignty and forecloses alternatives the Māori text would support. This is the canonical tangled_rope pattern: real coordination, real extraction, active enforcement to hold them together.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    partnership_vs_textual_allocation,
    'Is the partnership doctrine a legitimate interpretation of the Treaty''s dual texts, or a judicial construction that displaces both texts'' allocations to preserve Crown sovereignty?',
    'Historical and linguistic analysis of Treaty negotiations, comparison with contemporary international treaties establishing power-sharing arrangements, and examination of whether partnership doctrine outcomes track either textual reading or systematically favor Crown interests.',
    'If the partnership reading is a construction rather than a discovery, its legitimacy rests on political stability rather than textual fidelity, and challenges to its adequacy have stronger grounding. If it genuinely interprets the texts, then the textual divergence itself required a mediating framework.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(partnership_vs_textual_allocation, conceptual, 'Whether partnership doctrine interprets or displaces the Treaty''s textual allocations').

omega_variable(
    consultation_without_consent,
    'Does a consultation requirement without decision-making power constitute meaningful Treaty partnership, or does it reduce partnership to process without substance?',
    'Comparative analysis of consultation frameworks in other post-colonial jurisdictions, measurement of how often consultation changes substantive outcomes versus legitimating predetermined decisions, and tracking of Māori stakeholder assessments of consultation efficacy over time.',
    'If consultation systematically legitimates Crown decisions without altering them, then the partnership reading''s coordination function is largely theatrical and its extraction is higher than the base metric suggests. If consultation meaningfully shapes outcomes, the coordination-extraction balance shifts toward coordination.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(consultation_without_consent, empirical, 'Whether consultation requirements constitute substantive or theatrical partnership').

omega_variable(
    settlement_finality_vs_ongoing_breach,
    'Do full-and-final settlements resolve historical breaches, or does ongoing Crown authority over resources guaranteed to Māori in Article II constitute continuing breach that settlements cannot extinguish?',
    'Legal analysis of whether settlements address the Treaty breach (historical confiscation) or only its symptoms (loss of specific parcels), and tracking of whether post-settlement Crown resource decisions over taonga comply with active protection obligations or continue the breach under new framing.',
    'If settlements address only historical symptoms while ongoing Crown authority continues the structural breach, then the settlement process operates as extraction rather than redress, and the partnership reading''s claimed_type should be snare. If settlements genuinely resolve past breaches and ongoing relations operate under good-faith partnership, tangled_rope holds.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(settlement_finality_vs_ongoing_breach, conceptual, 'Whether settlements resolve or manage ongoing Treaty breach').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(waitangi_sovereignty_allocation__partnership_reading, 0, 40).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(wait_tr_t0, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 0, 0.22).
narrative_ontology:measurement(wait_tr_t8, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 8, 0.25).
narrative_ontology:measurement(wait_tr_t16, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 16, 0.29).
narrative_ontology:measurement(wait_tr_t24, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 24, 0.33).
narrative_ontology:measurement(wait_tr_t32, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 32, 0.36).
narrative_ontology:measurement(wait_tr_t40, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 40, 0.38).

% Extraction over time
narrative_ontology:measurement(wait_be_t0, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 0, 0.32).
narrative_ontology:measurement(wait_be_t8, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 8, 0.36).
narrative_ontology:measurement(wait_be_t16, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 16, 0.41).
narrative_ontology:measurement(wait_be_t24, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 24, 0.44).
narrative_ontology:measurement(wait_be_t32, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 32, 0.46).
narrative_ontology:measurement(wait_be_t40, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 40, 0.48).

% Suppression requirement over time
narrative_ontology:measurement(wait_su_t0, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 0, 0.42).
narrative_ontology:measurement(wait_su_t8, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 8, 0.45).
narrative_ontology:measurement(wait_su_t16, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 16, 0.47).
narrative_ontology:measurement(wait_su_t24, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 24, 0.49).
narrative_ontology:measurement(wait_su_t32, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 32, 0.51).
narrative_ontology:measurement(wait_su_t40, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 40, 0.52).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(waitangi_sovereignty_allocation__partnership_reading, identity_coordination).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__partnership_reading, waitangi_sovereignty_allocation__crown_sovereignty_reading).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__partnership_reading, waitangi_sovereignty_allocation__rangatiratanga_reading).

% DUAL FORMULATION NOTE:
% The waitangi_sovereignty_allocation kernel decomposes into three readings with substantially different ε values: crown_sovereignty_reading treats Māori claims as extinguished (low ε from Crown seats, very high from Māori seats); partnership_reading moderates Crown authority through consultation and settlements (moderate ε); rangatiratanga_reading would require structural power-sharing or federalism (high ε from Crown seats, low from Māori seats). The partnership reading is the currently dominant judicial interpretation. Each reading is linked via network.affects_constraints because court adoption of any reading structures the others' viability.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
