% ============================================================================
% CONSTRAINT STORY: waitangi_sovereignty_allocation__rangatiratanga_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2024-01-15
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_waitangi_sovereignty_allocation__rangatiratanga_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:stakeholder_non_agent/2,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: waitangi_sovereignty_allocation__rangatiratanga_reading
 *   human_readable: Waitangi Sovereignty Allocation (Rangatiratanga Reading)
 *   domain: constitutional_law/indigenous_rights/post_colonial_governance
 *
 * SUMMARY:
 *   The Treaty of Waitangi was signed in 1840 with radically different texts.
 *   The English version stated that Māori chiefs ceded sovereignty to the
 *   Crown. The Māori text—the one actually presented to rangatira at signing
 *   hui—used 'kāwanatanga' (a term coined for governorship over settlers) for
 *   Crown authority and 'tino rangatiratanga' (full chiefly
 *   authority/autonomy) for what Māori retained over their lands, resources,
 *   and taonga. This constraint models the rangatiratanga reading: that the
 *   Māori text promised Māori retention of substantive authority while the
 *   Crown was to govern only settlers and broker between communities. The
 *   constraint in operation is the Crown's subsequent assertion of absolute
 *   parliamentary sovereignty over all territory and peoples, subordinating
 *   the rangatiratanga promise to Westminster doctrine. The extraction is the
 *   dispossession of authority and resources; the suppression is the legal
 *   and military force required to maintain Crown jurisdiction over peoples
 *   who understood they had never ceded it.
 *
 * KEY AGENTS:
 *   - crown_government: Agenda-setter (institutional/arbitrage) — exercises plenary authority, controls interpretation, legislates over Māori interests despite Treaty promises
 *   - maori_iwi: Payer (organized/identity_locked) — assert tino rangatiratanga was retained, bear extraction through land loss and authority subordination, cannot exit due to identity fusion with territory
 *   - hapu_communities: Payer (moderate/identity_locked) — local groups who lost direct governance over ancestral lands, trapped by place-based identity
 *   - settler_descendants: Beneficiary (powerful/mobile) — secure property and political control through Crown sovereignty overriding Māori authority
 *   - waitangi_tribunal: Observer (institutional/constrained) — investigates Crown breaches, makes non-binding findings supporting rangatiratanga reading
 *   - international_indigenous_rights_observers: Excluded (institutional/analytical) — would apply UNDRIP standards, structurally excluded from domestic constitutional law
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(waitangi_sovereignty_allocation__rangatiratanga_reading, 0.82).
domain_priors:suppression_score(waitangi_sovereignty_allocation__rangatiratanga_reading, 0.89).
domain_priors:theater_ratio(waitangi_sovereignty_allocation__rangatiratanga_reading, 0.71).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, extractiveness, 0.82).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 0.89).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 0.71).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, accessibility_collapse, 0.38).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, resistance, 0.78).

% --- Constraint claim ---
narrative_ontology:constraint_claim(waitangi_sovereignty_allocation__rangatiratanga_reading, snare).
narrative_ontology:human_readable(waitangi_sovereignty_allocation__rangatiratanga_reading, "Waitangi Sovereignty Allocation (Rangatiratanga Reading)").
narrative_ontology:topic_domain(waitangi_sovereignty_allocation__rangatiratanga_reading, "constitutional_law/indigenous_rights/post_colonial_governance").

domain_priors:requires_active_enforcement(waitangi_sovereignty_allocation__rangatiratanga_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(waitangi_sovereignty_allocation__rangatiratanga_reading, '509d3187-40a6-4205-b520-ab23af527650').
narrative_ontology:cs_kernel_codification('509d3187-40a6-4205-b520-ab23af527650', fixed_text).
narrative_ontology:cs_authority_grounding('509d3187-40a6-4205-b520-ab23af527650', lineage).
narrative_ontology:cs_interpretation_layer_present('509d3187-40a6-4205-b520-ab23af527650').
narrative_ontology:cs_reading_relation('509d3187-40a6-4205-b520-ab23af527650', waitangi_sovereignty_allocation__crown_sovereignty_reading, forecloses).
narrative_ontology:cs_reading_relation('509d3187-40a6-4205-b520-ab23af527650', waitangi_sovereignty_allocation__partnership_reading, influences).
narrative_ontology:cs_axiom('509d3187-40a6-4205-b520-ab23af527650', foundational, tino_rangatiratanga_never_ceded).
narrative_ontology:cs_axiom_status(tino_rangatiratanga_never_ceded, holdable).
narrative_ontology:cs_axiom_grounding('509d3187-40a6-4205-b520-ab23af527650', tino_rangatiratanga_never_ceded, conventional).
narrative_ontology:cs_axiom('509d3187-40a6-4205-b520-ab23af527650', foundational, crown_jurisdiction_limited_to_settlers).
narrative_ontology:cs_axiom_status(crown_jurisdiction_limited_to_settlers, holdable).
narrative_ontology:cs_axiom_grounding('509d3187-40a6-4205-b520-ab23af527650', crown_jurisdiction_limited_to_settlers, conventional).
narrative_ontology:cs_axiom('509d3187-40a6-4205-b520-ab23af527650', secondary, maori_text_controls_when_divergent).
narrative_ontology:cs_axiom_status(maori_text_controls_when_divergent, holdable).
narrative_ontology:cs_axiom_grounding('509d3187-40a6-4205-b520-ab23af527650', maori_text_controls_when_divergent, conventional).
narrative_ontology:cs_reference_frame('509d3187-40a6-4205-b520-ab23af527650', te_tiriti_as_signed_in_maori).
narrative_ontology:cs_drift_state('509d3187-40a6-4205-b520-ab23af527650', contemporary_parliamentary_supremacy, gap(authority_erosion, severe, false)).
narrative_ontology:cs_created_at('509d3187-40a6-4205-b520-ab23af527650', '').
narrative_ontology:cs_kernel_id(waitangi_sovereignty_allocation__rangatiratanga_reading, waitangi_sovereignty_allocation).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__rangatiratanga_reading, crown_government).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__rangatiratanga_reading, settler_descendants).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__rangatiratanga_reading, maori_iwi).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__rangatiratanga_reading, hapu_communities).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__rangatiratanga_reading, parliamentary_sovereignty_doctrine).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__rangatiratanga_reading, treaty_as_historical_curiosity).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Exercises plenary legislative authority over all New Zealand territory including Māori lands and resources. Frames the Treaty as a founding document that transferred sovereignty, interpreting kāwanatanga as comprehensive governing authority rather than limited oversight. Controls legal interpretation through parliamentary supremacy and judicial appointments. Has systematically legislated over Māori lands, resources, and taonga without recognizing tino rangatiratanga as a limitation on Crown jurisdiction.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, crown_government, agenda_setter,
    institutional, generational, arbitrage, national).

% Assert that the Māori text preserved tino rangatiratanga (full chiefly authority) over lands, forests, fisheries, and all taonga, with Crown authority limited to kāwanatanga (governance over settlers only). Have experienced systematic land alienation, resource extraction, and cultural suppression through legislation that treats Crown sovereignty as absolute. Cannot exit: identity is constituted through ancestral connection to land and through whakapapa. Resistance takes the form of Waitangi Tribunal claims, occupation of disputed lands, and assertion of tikanga jurisdiction, but these operate within a legal framework that treats Crown authority as foundational.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, maori_iwi, payer,
    organized, civilizational, identity_locked, national).

% Local kinship groups who held and exercised mana over specific territories at the time of Treaty signing. The text they heard at hui promised protection of their rangatiratanga (authority and autonomy), not its transfer. Have lost direct governance over traditional territories through Crown legislation, with authority over land use, resource management, and cultural sites now vested in Crown agencies. Like iwi, cannot exit: their identity and social organization are place-based and genealogical.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, hapu_communities, payer,
    moderate, civilizational, identity_locked, regional).

% Population descended from British and other settlers whose land titles, property rights, and economic opportunities were secured through Crown sovereignty overriding Māori rangatiratanga. Benefit from a legal system that treats their land ownership and resource access as uncontestable rather than dependent on ongoing Māori consent. Parliamentary democracy gives them majoritarian control over institutions that determine Treaty interpretation.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, settler_descendants, beneficiary,
    powerful, biographical, mobile, national).

% Permanent commission established in 1975 to investigate Crown breaches of Treaty principles. Can make findings and recommendations but has no binding authority over Parliament. Has consistently found that the Māori text promised protection of tino rangatiratanga and that Crown actions have breached this, but Parliament is not bound by these findings and frequently legislates contrary to them. Operates as a safety valve allowing grievance articulation without requiring structural change.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, waitangi_tribunal, observer,
    institutional, generational, constrained, national).

% UN bodies and international legal scholars who would apply UNDRIP principles and international human rights frameworks recognizing indigenous self-determination. Repeatedly issue findings that New Zealand's Treaty implementation fails international standards for indigenous rights. Their framework is structurally excluded from domestic law: Parliament treats Treaty interpretation as a matter of domestic constitutional law immune to international oversight.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, international_indigenous_rights_observers, excluded,
    institutional, generational, analytical, global).

% The legal doctrine that Parliament possesses unlimited legislative authority inherited from Westminster. Listed for structural completeness as the intellectual apparatus that renders rangatiratanga claims legally illegible, but this is a doctrine, not an actor, so agent=false prevents it from feeding directionality computation.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, constitutional_law_orthodoxy, agenda_setter,
    institutional, generational, analytical, national).
narrative_ontology:stakeholder_secondary_role(waitangi_sovereignty_allocation__rangatiratanga_reading, constitutional_law_orthodoxy, beneficiary).
narrative_ontology:stakeholder_non_agent(waitangi_sovereignty_allocation__rangatiratanga_reading, constitutional_law_orthodoxy).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a single sovereign authority for settler population governance, unified legal system, and framework for land tenure and resource allocation across the territory claimed by the Crown.
% TRANSFER_FUNCTION: Moves legislative and judicial authority over Māori lands, resources, and cultural property from iwi and hapū to Crown institutions. Transfers land itself from Māori collective ownership to individual Crown titles. Extracts resource wealth from territories where Māori rangatiratanga was promised protection.
% ABSENT_VOICES: International indigenous rights framework is structurally excluded. Māori voices asserting rangatiratanga are present but systematically subordinated: they can petition the Tribunal but cannot prevent Parliament from legislating over them. The Māori text's promise of tino rangatiratanga is treated as a historical curiosity rather than a binding limitation on Crown authority.
% DISAPPEARANCE_RATIONALE: If the constraint vanished overnight—if Crown sovereignty over Māori territories and resources were no longer assumed—the entire structure of land ownership, resource management, and local governance would need renegotiation. Iwi and hapū would assert direct authority over traditional territories. Current Crown titles and resource concessions would require Māori consent to continue. The state itself would transform from unitary to genuinely federal or confederal.
% FOUNDING_PROBLEM: In 1840, the Crown sought to establish British authority over New Zealand to prevent French annexation, regulate lawless settler conduct, and create conditions for orderly colonization. From the Crown perspective, this required asserting sovereignty. From the perspective offered to rangatira at Treaty hui, this required only that they accept Crown governance over settlers (kāwanatanga) while retaining tino rangatiratanga over their own people and territories.
% FOUNDING_PROBLEM_CORROBORATION: The Crown and settler-descended legal establishment attest the founding problem was resolved by Treaty cession of sovereignty, enabling stable government and property rights. Māori iwi authorities, the Waitangi Tribunal's historical findings, and international indigenous rights bodies attest the founding problem was the Crown's unilateral need to assert authority, not a Māori-recognized necessity, and that the arrangement imposed was never what rangatira consented to in the Māori text. Tribunal historical reports from outside the Crown's direct institutional interest support the divergent-promises reading.
narrative_ontology:disappearance_verdict(waitangi_sovereignty_allocation__rangatiratanga_reading, world_rearranges).
narrative_ontology:founding_problem_status(waitangi_sovereignty_allocation__rangatiratanga_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(waitangi_sovereignty_allocation__rangatiratanga_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(waitangi_sovereignty_allocation__rangatiratanga_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(waitangi_sovereignty_allocation__rangatiratanga_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(waitangi_sovereignty_allocation__rangatiratanga_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(waitangi_sovereignty_allocation__rangatiratanga_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is high (0.82) because the constraint systematically transfers authority and resources from Māori to Crown institutions and settler beneficiaries, justified by a sovereignty claim the Māori text never made. Suppression is higher (0.89) because maintaining this authority transfer requires continuous legal enforcement against Māori claims and international indigenous rights standards. Theater ratio rises steeply over the interval (0.15 → 0.71): early colonial period involved direct military suppression and land confiscation (low theater, high direct coercion); contemporary period involves Waitangi Tribunal processes, Treaty principles rhetoric, and consultation requirements that acknowledge historical injustice while preserving parliamentary supremacy (high theater, coercion now primarily structural and legal rather than military). Accessibility collapse is lower (0.38) because the alternative—recognizing tino rangatiratanga as a binding limitation on Crown authority—remains legally and politically imaginable; it is suppressed, not impossible. Resistance is high (0.78): continuous Māori assertion of rangatiratanga through Tribunal claims, land occupations, tikanga jurisdiction assertions, and refusal to accept the Crown sovereignty premise.
 *
 * PERSPECTIVAL GAP:
 *   From the Crown institutional seat, the constraint is the legal foundation of the state: parliamentary sovereignty is the coordinating principle that makes unified governance possible, and the Treaty was the instrument that legitimated it. From Māori iwi and hapū seats, the same structure is the mechanism of ongoing dispossession: the English text's sovereignty claim is imposed over the Māori text's rangatiratanga promise, and what is framed as legal order is experienced as the suppression of authority that was never ceded. The Treaty itself is not the constraint—the constraint is the assertion of Crown sovereignty that subordinates the Māori text's promises. The engine computes these divergent classifications from the structural positions: agenda-setter/arbitrage vs. payer/identity-locked.
 *
 * DIRECTIONALITY LOGIC:
 *   Crown government is the primary beneficiary: collects the authority and resources the constraint transfers, sets the interpretive rules, sits at the arbitrage end (can exit the arrangement through constitutional reform but chooses not to). Māori iwi and hapū are the primary victims: bear the extraction (loss of authority and resources), identity-locked (cannot exit without dissolving the whakapapa and place-based identity that constitutes them), experience the constraint as forced dispossession. Settler descendants are secondary beneficiaries: their property rights and political majority are secured by Crown sovereignty subordinating Māori rangatiratanga, but they did not design the arrangement. Waitangi Tribunal is constrained observer: can articulate the rangatiratanga reading but cannot enforce it against Parliament.
 *
 * MANDATROPHY ANALYSIS:
 *   This constraint exhibits the signature of degraded mandate: the founding problem (establishing orderly governance in 1840) has been superseded by 184 years of state development, yet the sovereignty arrangement persists not because it solves a live coordination problem but because reversing it would redistribute authority and resources away from current power holders. The theater ratio rise reflects this: early direct suppression gives way to elaborate consultation and acknowledgment processes that absorb Māori claims without limiting parliamentary supremacy. The Waitangi Tribunal process is the paradigmatic theater: it investigates, makes findings, recommends redress, but Parliament remains free to ignore it. The constraint's persistence depends on suppressing the rangatiratanga alternative, not on any remaining necessity.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    textual_authority_allocation,
    'Which text governs: the English version signed by Crown officials (ceding sovereignty) or the Māori version presented to rangatira at hui (retaining tino rangatiratanga)?',
    'Constitutional court ruling on which text has legal priority when they conflict, or constitutional convention explicitly subordinating parliamentary sovereignty to Treaty terms as understood in the Māori text. International law principles favor the indigenous-language version when colonial treaties contain material discrepancies.',
    'If Māori text governs, Crown legislation over Māori lands and resources without consent is ultra vires, requiring fundamental constitutional restructuring. If English text governs, current parliamentary supremacy is vindicated and Māori claims are purely moral, not legal.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(textual_authority_allocation, conceptual, 'Which textual version controls when they promise different allocations of authority.').

omega_variable(
    rangatiratanga_modern_scope,
    'If tino rangatiratanga was retained, what is its scope in a modern state: full sovereignty (secession-capable), co-governance within Crown framework, or consultative veto only?',
    'Constitutional negotiation articulating what recognition of retained rangatiratanga requires institutionally: independent jurisdiction, mandatory power-sharing, or procedural consultation rights.',
    'Determines whether recognizing rangatiratanga requires state restructuring (federalism, separate Māori jurisdiction) or can be accommodated through enhanced consultation within existing parliamentary framework.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(rangatiratanga_modern_scope, conceptual, 'What institutional form retained rangatiratanga takes in contemporary governance.').

omega_variable(
    identity_lock_persistence,
    'Is the identity-locked exit status for Māori iwi and hapū permanent (constitutive identity fusion with place and whakapapa) or could it erode under sufficient assimilation pressure or voluntary urbanization?',
    'Longitudinal study of identity maintenance across generations of urban migration and intermarriage. Comparison with other indigenous peoples'' identity persistence under colonization.',
    'If identity lock is permanent, the constraint''s suppression of Māori authority is indefinitely extractive from trapped populations. If identity lock erodes, future generations may experience lower effective extraction as exit becomes thinkable.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(identity_lock_persistence, empirical, 'Whether identity-based trapping is a permanent structural feature or could decay.').

omega_variable(
    tribunal_theatre_or_pathway,
    'Is the Waitangi Tribunal process pure theatre (absorbs grievance without requiring structural change) or a genuine pathway to recognition (builds jurisprudential foundation for eventual Treaty supremacy)?',
    'Historical analysis of whether Tribunal findings accumulate into binding constitutional norms over time, or whether they remain permanently advisory while Parliament legislates contrary to them.',
    'If theatre, the high theater_ratio is accurately modeling performative acknowledgment masking continued extraction. If pathway, the measurement mischaracterizes a slow constitutional evolution toward enforceable Treaty rights.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(tribunal_theatre_or_pathway, empirical, 'Whether Treaty grievance mechanisms are theatre or incremental structural change.').

omega_variable(
    partnership_foreclosure,
    'Does the rangatiratanga reading foreclose the partnership reading, or can partnership coexist as a second-order interpretation built atop recognized rangatiratanga?',
    'Conceptual analysis of whether partnership (requiring consultation and good faith) is a distinct constitutional structure or merely the procedural form that recognition of rangatiratanga would take in practice.',
    'Determines whether the three readings form a mutually exclusive set or whether partnership is a nested interpretation compatible with rangatiratanga but distinct from crown_sovereignty.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(partnership_foreclosure, conceptual, 'Whether partnership is a distinct reading or nested within rangatiratanga recognition.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(waitangi_sovereignty_allocation__rangatiratanga_reading, 0, 184).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(wait_tr_t0, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 0, 0.15).
narrative_ontology:measurement_basis(wait_tr_t0, observed).
narrative_ontology:measurement(wait_tr_t30, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 30, 0.25).
narrative_ontology:measurement_basis(wait_tr_t30, observed).
narrative_ontology:measurement(wait_tr_t61, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 61, 0.38).
narrative_ontology:measurement_basis(wait_tr_t61, observed).
narrative_ontology:measurement(wait_tr_t92, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 92, 0.52).
narrative_ontology:measurement_basis(wait_tr_t92, observed).
narrative_ontology:measurement(wait_tr_t135, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 135, 0.67).
narrative_ontology:measurement_basis(wait_tr_t135, observed).
narrative_ontology:measurement(wait_tr_t184, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 184, 0.71).
narrative_ontology:measurement_basis(wait_tr_t184, observed).

% Extraction over time
narrative_ontology:measurement(wait_be_t0, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 0, 0.45).
narrative_ontology:measurement_basis(wait_be_t0, observed).
narrative_ontology:measurement(wait_be_t30, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 30, 0.68).
narrative_ontology:measurement_basis(wait_be_t30, observed).
narrative_ontology:measurement(wait_be_t61, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 61, 0.79).
narrative_ontology:measurement_basis(wait_be_t61, observed).
narrative_ontology:measurement(wait_be_t92, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 92, 0.84).
narrative_ontology:measurement_basis(wait_be_t92, observed).
narrative_ontology:measurement(wait_be_t135, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 135, 0.81).
narrative_ontology:measurement_basis(wait_be_t135, observed).
narrative_ontology:measurement(wait_be_t184, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 184, 0.82).
narrative_ontology:measurement_basis(wait_be_t184, observed).

% Suppression requirement over time
narrative_ontology:measurement(wait_su_t0, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 0, 0.72).
narrative_ontology:measurement_basis(wait_su_t0, observed).
narrative_ontology:measurement(wait_su_t30, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 30, 0.81).
narrative_ontology:measurement_basis(wait_su_t30, observed).
narrative_ontology:measurement(wait_su_t61, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 61, 0.88).
narrative_ontology:measurement_basis(wait_su_t61, observed).
narrative_ontology:measurement(wait_su_t92, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 92, 0.91).
narrative_ontology:measurement_basis(wait_su_t92, observed).
narrative_ontology:measurement(wait_su_t135, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 135, 0.9).
narrative_ontology:measurement_basis(wait_su_t135, observed).
narrative_ontology:measurement(wait_su_t184, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 184, 0.89).
narrative_ontology:measurement_basis(wait_su_t184, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(waitangi_sovereignty_allocation__rangatiratanga_reading, enforcement_mechanism).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__rangatiratanga_reading, resource_management_act_consultation).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__rangatiratanga_reading, foreshore_seabed_allocation).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__rangatiratanga_reading, te_reo_official_status).

% DUAL FORMULATION NOTE:
% This constraint is one of three readings of the waitangi_sovereignty_allocation kernel. The rangatiratanga reading models Crown sovereignty over Māori territories as extractive dispossession because the Māori text never ceded tino rangatiratanga. The crown_sovereignty reading (separate story) models the same legal structure as legitimate coordination flowing from valid sovereignty cession. The partnership reading (separate story) models an intermediate structure requiring enforceable consultation. They are linked via network edges because they share a legal-historical kernel but instantiate different constraints with different ε values, beneficiary structures, and suppression mechanisms.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
