% ============================================================================
% CONSTRAINT STORY: woman_category__sex_biology_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2025-01-01
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_woman_category__sex_biology_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: woman_category__sex_biology_reading
 *   human_readable: Woman Category: Sex-Biology Reading
 *   domain: political_philosophy/law/social_policy/bioethics
 *
 * SUMMARY:
 *   This constraint is the sex-biology reading of the contested
 *   woman-category kernel. It defines 'woman' as adult human female with XX
 *   chromosomes and typical female reproductive anatomy, treating biological
 *   sex as immutable and binary. The reading coordinates legal sex
 *   classification, medical research categories, single-sex facility
 *   administration, and athletic eligibility around natal-sex boundaries. It
 *   is claimed as tangled_rope: genuine coordination function (verifiable
 *   category boundaries, stable competitive fairness framework) combined with
 *   asymmetric extraction (systematic exclusion of transgender women from
 *   protections and spaces organized for women; incoherent treatment of
 *   intersex people). The metrics describe rising extraction and suppression
 *   over the interval as enforcement hardens around the definitional boundary
 *   in response to gender-identity advocacy.
 *
 * KEY AGENTS:
 *   - female_biology_sports_competitors: Primary beneficiary (organized/constrained) — retain access to competitive categories defined by natal sex
 *   - sex_based_data_advocates: Beneficiary (institutional/mobile) — preserve epidemiologically distinct sex categories
 *   - single_sex_space_operators: Agenda-setter (institutional/constrained) — enforce sex-based admission criteria
 *   - transgender_women: Primary victim (organized/identity_locked) — excluded from woman-category protections and spaces; exit from the definitional contest is identity-destroying
 *   - intersex_people_ambiguous_classification: Victim (powerless/trapped) — no coherent classification in binary framework
 *   - gender_identity_framework_advocates: Excluded (organized/mobile) — alternative reading structurally foreclosed in sex-biology jurisdictions
 *   - comparative_law_scholars: Observer (analytical/analytical) — analyze consequences across jurisdictions
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(woman_category__sex_biology_reading, 0.72).
domain_priors:suppression_score(woman_category__sex_biology_reading, 0.78).
domain_priors:theater_ratio(woman_category__sex_biology_reading, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, extractiveness, 0.72).
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, suppression_requirement, 0.78).
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, resistance, 0.81).

% --- Constraint claim ---
narrative_ontology:constraint_claim(woman_category__sex_biology_reading, tangled_rope).
narrative_ontology:human_readable(woman_category__sex_biology_reading, "Woman Category: Sex-Biology Reading").
narrative_ontology:topic_domain(woman_category__sex_biology_reading, "political_philosophy/law/social_policy/bioethics").

domain_priors:requires_active_enforcement(woman_category__sex_biology_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(woman_category__sex_biology_reading, '09122a70-11e7-4099-9d62-a11d8481af8e').
narrative_ontology:cs_kernel_codification('09122a70-11e7-4099-9d62-a11d8481af8e', distributed).
narrative_ontology:cs_authority_grounding('09122a70-11e7-4099-9d62-a11d8481af8e', distributed).
narrative_ontology:cs_reading_relation('09122a70-11e7-4099-9d62-a11d8481af8e', woman_category__gender_identity_reading, coexists_with).
narrative_ontology:cs_reading_relation('09122a70-11e7-4099-9d62-a11d8481af8e', woman_category__intersex_accommodation_reading, coexists_with).
narrative_ontology:cs_axiom('09122a70-11e7-4099-9d62-a11d8481af8e', foundational, sex_immutability_principle).
narrative_ontology:cs_axiom_status(sex_immutability_principle, holdable).
narrative_ontology:cs_axiom_grounding('09122a70-11e7-4099-9d62-a11d8481af8e', sex_immutability_principle, empirically_contingent).
narrative_ontology:cs_axiom('09122a70-11e7-4099-9d62-a11d8481af8e', foundational, binary_sex_natural_kind).
narrative_ontology:cs_axiom_status(binary_sex_natural_kind, holdable).
narrative_ontology:cs_axiom_grounding('09122a70-11e7-4099-9d62-a11d8481af8e', binary_sex_natural_kind, empirically_contingent).
narrative_ontology:cs_reference_frame('09122a70-11e7-4099-9d62-a11d8481af8e', binary_biological_sex_framework).
narrative_ontology:cs_drift_state('09122a70-11e7-4099-9d62-a11d8481af8e', post_gender_identity_legal_recognition_era, gap(authority_erosion, substantial, false)).
narrative_ontology:cs_created_at('09122a70-11e7-4099-9d62-a11d8481af8e', '').
narrative_ontology:cs_kernel_id(woman_category__sex_biology_reading, woman_category).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(woman_category__sex_biology_reading, female_biology_sports_competitors).
narrative_ontology:constraint_beneficiary(woman_category__sex_biology_reading, sex_based_data_advocates).
narrative_ontology:constraint_beneficiary(woman_category__sex_biology_reading, single_sex_space_operators).
narrative_ontology:constraint_victim(woman_category__sex_biology_reading, transgender_women).
narrative_ontology:constraint_victim(woman_category__sex_biology_reading, intersex_people_ambiguous_classification).
narrative_ontology:constraint_vindicates(woman_category__sex_biology_reading, sex_immutability_doctrine).
narrative_ontology:constraint_vindicates(woman_category__sex_biology_reading, binary_sex_framework).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Compete in sex-segregated athletic categories where eligibility is determined by chromosomes and natal anatomy. Argue this reading preserves competitive fairness by excluding those who underwent male puberty and retain performance advantages. Their athletic opportunities depend on the boundary holding; erosion of the sex-biology definition would force them to compete against athletes they view as retaining male-typical physical advantages.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, female_biology_sports_competitors, beneficiary,
    organized, biographical, constrained, national).

% Research institutions and policy organizations that collect and analyze sex-disaggregated data for health outcomes, violence against women, employment discrimination, and reproductive rights. Argue that accurate sex-based data collection requires biological sex categories; adoption of gender-identity frameworks would conflate distinct medical and social phenomena. Can pivot to alternative frameworks but view sex-biology data as epidemiologically necessary.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, sex_based_data_advocates, beneficiary,
    institutional, generational, mobile, national).

% Operate prisons, domestic violence shelters, changing facilities, and other sex-segregated spaces. Enforce admission criteria based on natal sex and anatomy, justified by safety, privacy, and dignity concerns of female-biology users. Face legal and social pressure to adopt gender-identity criteria; their institutional authority to maintain sex-based boundaries is the contested enforcement mechanism.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, single_sex_space_operators, agenda_setter,
    institutional, generational, constrained, national).

% Experience exclusion from sex-segregated spaces, athletic categories, and legal protections designated for women under this reading. The constraint denies recognition of their lived gender identity in contexts where sex-category membership determines access. Exit means accepting permanent classification as male or forgoing participation in gendered institutional structures; their identity is constituted through recognition as women, making exit from the definitional contest itself unthinkable.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, transgender_women, payer,
    organized, biographical, identity_locked, national).

% Fall outside the binary chromosomal/anatomical framework this reading assumes as typical. Face administrative exclusion or coercive reassignment into binary categories for legal recognition, sports eligibility, and institutional access. The constraint offers no coherent classification for non-XX, non-XY chromosomal patterns or ambiguous anatomy; they are forced into ill-fitting categories or rendered institutionally illegible.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, intersex_people_ambiguous_classification, payer,
    powerless, biographical, trapped, global).

% Advocate for legal and institutional frameworks where gender identity, not natal sex, determines category membership. Argue the sex-biology reading inflicts dignity harms and denies transgender people equal protection. Are excluded from sex-segregated policy design in jurisdictions that adopt this reading; their alternative framework is structurally foreclosed where sex-biology definitions are legally codified.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, gender_identity_framework_advocates, excluded,
    organized, generational, mobile, global).

% Analyze how different jurisdictions operationalize woman-category definitions and trace the legal, medical, and social consequences of each reading. Document that sex-biology frameworks produce stable competitive categories in sports but exclude transgender women from violence-against-women protections; gender-identity frameworks extend recognition but create new boundary disputes in single-sex spaces.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, comparative_law_scholars, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a stable, verifiable, and historically continuous definition of 'woman' for legal classification, medical research, single-sex space administration, and athletic category segregation, solving the coordination problem of who counts as a member of a protected class or eligibility category.
% TRANSFER_FUNCTION: Moves access to sex-segregated protections, spaces, and competitive categories away from transgender women (who are classified as male under this reading) and toward people with female chromosomes and anatomy; concentrates institutional authority to enforce sex-based boundaries with single-sex space operators.
% ABSENT_VOICES: Transgender women and intersex people with non-binary biology are structurally excluded from the definitional process in most jurisdictions that adopt this reading; their testimony is systematically discounted as motivated reasoning or conceptual confusion rather than lived expertise on gender classification.
% DISAPPEARANCE_RATIONALE: If the sex-biology reading disappeared overnight and was replaced by self-identification or a spectrum framework, sports governing bodies would rewrite eligibility rules within months, single-sex facilities would revise admission criteria, violence-against-women data collection would shift categories, and legal sex-change processes would become administrative rather than medical—every institution currently organized around natal-sex boundaries would reorganize around the replacement framework.
% FOUNDING_PROBLEM: Legal and institutional sex categories in the 20th century were designed to address sex-based discrimination, sex-segregated facility safety, and fair athletic competition; the categories assumed a stable binary biological sex verifiable by anatomy and chromosomes.
% FOUNDING_PROBLEM_CORROBORATION: Institutional operators (prison systems, sports federations, medical researchers) attest that chromosomal/anatomical sex remains a live administrative and scientific category. Transgender advocacy organizations and bioethicists attest that the binary-biology framework never accommodated intersex people and that its application to transgender people causes systematic harm; scholarly literature from gender studies and queer theory, external to the institutions enforcing the boundary, supports the harm-and-exclusion reading.
narrative_ontology:disappearance_verdict(woman_category__sex_biology_reading, world_rearranges).
narrative_ontology:founding_problem_status(woman_category__sex_biology_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(woman_category__sex_biology_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(woman_category__sex_biology_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(woman_category__sex_biology_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(woman_category__sex_biology_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(woman_category__sex_biology_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is high (0.72 at interval end) because the constraint excludes transgender women from legal sex-class protections, violence-against-women services, and athletic categories where their exclusion is justified by natal-sex membership rather than current harm or need; the exclusion is structural rather than case-by-case. Suppression is higher still (0.78) because maintaining the boundary requires active legal enforcement (sports eligibility rules, prison assignment policies, legal sex-change medical gatekeeping) and suppressing institutional adoption of alternative definitional frameworks. Theater ratio is moderate (0.42): the chromosomal/anatomical verification function is real in contexts where it is actually performed (sports, some legal sex changes), but a growing share of enforcement energy goes toward defending the boundary symbolically in contexts where verification is never performed (public restrooms, violence shelters where self-declaration was the historical norm). Accessibility collapse is moderate-low (0.48): alternative frameworks (gender identity, intersex accommodation) remain live and are adopted in some jurisdictions; the sex-biology reading does not operate as a natural law. Resistance is very high (0.81): transgender advocacy organizations, many medical and psychological professional bodies, and intersex rights groups actively contest this reading and lobby for its replacement. The measurement series captures enforcement intensification over a 40-year interval as the definitional boundary became a central site of legal and cultural contestation.
 *
 * PERSPECTIVAL GAP:
 *   The beneficiary and victim seats should compute very differently. From the sports-competitor and data-advocate seats, the constraint is coordination: it solves the genuine problem of maintaining stable, verifiable categories for fair competition and accurate research. From the transgender-women seat, the same structure operates as identity-denying extraction: systematic exclusion from protections and spaces based on a definition that refuses recognition of their lived gender. The seat divergence is not about different experiences of the same neutral rule—it is about whether the boundary itself is legitimate. The engine computes this from the beneficiary/victim structure and identity-locked exit on the victim side.
 *
 * DIRECTIONALITY LOGIC:
 *   Female-biology sports competitors and sex-based data advocates are structural beneficiaries: the reading preserves their access to sex-segregated competitive categories and epidemiologically distinct data collection frameworks (d near beneficiary end, low χ). Single-sex space operators are agenda-setters with constrained exit: they enforce the boundary and benefit from institutional authority to do so, but face legal liability and reputational costs under either framework (d moderate). Transgender women are the primary extraction targets: identity-locked exit (the definitional contest is about the legitimacy of their identity claim itself), organized power, national scope—high d, very high χ. Intersex people with ambiguous biology are also victims but with powerless/trapped positioning: they are administratively erased or coercively reassigned, with even less capacity to resist than transgender women (also high d, high χ). Gender-identity advocates are excluded rather than directly targeted; their exclusion is the condition of the sex-biology framework's persistence.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint exhibits mandatrophy dynamics: the founding problem (need for stable legal sex categories to address sex-based discrimination and maintain single-sex spaces) is genuinely live in some domains (sports, medical research) but substantially transformed in others (violence-against-women protections where risk assessment, not natal sex, is the live question). The growing theater ratio reflects this: enforcement increasingly defends the symbolic boundary rather than solving the operational problem the boundary was designed for. The R5 genealogy interview surfaces the contested status: institutional operators attest the founding problem is live; transgender and intersex advocates attest the framework causes more harm than it solves. The coordination-extraction bundling is what makes this tangled_rope rather than snare: the competitive-fairness and data-integrity functions are real; the exclusion of transgender women and incoherent treatment of intersex people ride on the same definitional structure.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    immutability_vs_transition,
    'Is biological sex an immutable characteristic, or can medical transition (hormones, surgery) change the salient features that justify sex-category membership for legal and social purposes?',
    'Empirical evidence on post-transition physiology, performance data, and medical outcomes in transgender populations; legal rulings on what counts as ''sex'' for equal-protection purposes; consensus or dissensus among endocrinologists and sports scientists on whether transition sufficiently alters the sex-typical traits that justify segregation.',
    'If transition is found to alter the salient features, the sex-biology reading''s claim that natal sex is the permanent and only legitimate boundary collapses, and the constraint reclassifies toward a transition-threshold framework (e.g., hormone-level or surgery-completion criteria). If transition does not alter the salient features, the sex-biology boundary holds as the stable coordination point.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(immutability_vs_transition, empirical, 'Whether medical transition changes the biological features that justify sex-category segregation.').

omega_variable(
    intersex_marginal_case,
    'Are intersex people a marginal exception to an otherwise stable binary framework, or do they reveal that the sex-biology reading''s binary premise is itself a constructed simplification of a spectrum reality?',
    'Biological evidence on the prevalence and diversity of intersex conditions; legal and medical treatment of intersex people under binary-sex frameworks; philosophical analysis of whether a category system that cannot coherently classify 1-2% of the population is a natural kind or an administrative fiction.',
    'If intersex people are a genuine marginal case, the sex-biology reading can accommodate them with exceptions while retaining its binary core. If they reveal the binary premise as constructed, the reading loses its claim to be mapping natural biological reality and becomes one contested framing among others, weakening its authority over the gender-identity reading.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(intersex_marginal_case, conceptual, 'Whether intersex variations are exceptions to a binary or evidence of a spectrum.').

omega_variable(
    coordination_extraction_separability,
    'Is the competitive-fairness coordination function in sports separable from the exclusion of transgender women, or are they structurally inseparable?',
    'Natural experiments from sports federations that adopt hormone-threshold or case-by-case eligibility criteria instead of natal-sex rules; performance data comparing transgender women athletes to cisgender women after transition; legal challenges testing whether less-exclusionary criteria can preserve competitive fairness.',
    'If separable (e.g., hormone suppression eliminates performance advantages), the exclusion component is pure extraction riding on a coordination function that could be preserved with less restrictive criteria, and the constraint reclassifies toward snare. If inseparable (natal-sex advantages persist regardless of transition), the exclusion is the price of the coordination function, and tangled_rope holds.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(coordination_extraction_separability, empirical, 'Whether transgender-women exclusion is necessary for competitive fairness or is extraction separable from coordination.').

omega_variable(
    reading_selection_framing,
    'This story instantiates the sex-biology reading of the woman-category kernel. An alternative framing: the gender-identity reading (category membership by self-identification) or the intersex-accommodation reading (acknowledging biological spectrum). What context or signal guided the choice to generate the sex-biology reading first?',
    'The manifest specified sex_biology_reading explicitly. The choice reflects the authoring order in the SCOPE manifest, not a claim that this reading is more legitimate than its siblings. All three readings should be generated and linked as a constraint family.',
    'If the sex-biology reading were generated in isolation, it would appear to be THE constraint, not one reading of a contested kernel. Generating all three readings and linking them via network.affects_constraints makes the kernel-contestation structure explicit and routes it into the classification apparatus.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(reading_selection_framing, conceptual, 'Why the sex-biology reading was instantiated rather than a sibling reading (committer-frame under-determination).').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(woman_category__sex_biology_reading, 0, 40).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(woma_tr_t0, woman_category__sex_biology_reading, theater_ratio, 0, 0.2).
narrative_ontology:measurement_basis(woma_tr_t0, observed).
narrative_ontology:measurement(woma_tr_t8, woman_category__sex_biology_reading, theater_ratio, 8, 0.24).
narrative_ontology:measurement_basis(woma_tr_t8, observed).
narrative_ontology:measurement(woma_tr_t16, woman_category__sex_biology_reading, theater_ratio, 16, 0.29).
narrative_ontology:measurement_basis(woma_tr_t16, observed).
narrative_ontology:measurement(woma_tr_t24, woman_category__sex_biology_reading, theater_ratio, 24, 0.34).
narrative_ontology:measurement_basis(woma_tr_t24, observed).
narrative_ontology:measurement(woma_tr_t32, woman_category__sex_biology_reading, theater_ratio, 32, 0.38).
narrative_ontology:measurement_basis(woma_tr_t32, observed).
narrative_ontology:measurement(woma_tr_t40, woman_category__sex_biology_reading, theater_ratio, 40, 0.42).
narrative_ontology:measurement_basis(woma_tr_t40, observed).

% Extraction over time
narrative_ontology:measurement(woma_be_t0, woman_category__sex_biology_reading, base_extractiveness, 0, 0.48).
narrative_ontology:measurement_basis(woma_be_t0, observed).
narrative_ontology:measurement(woma_be_t8, woman_category__sex_biology_reading, base_extractiveness, 8, 0.54).
narrative_ontology:measurement_basis(woma_be_t8, observed).
narrative_ontology:measurement(woma_be_t16, woman_category__sex_biology_reading, base_extractiveness, 16, 0.61).
narrative_ontology:measurement_basis(woma_be_t16, observed).
narrative_ontology:measurement(woma_be_t24, woman_category__sex_biology_reading, base_extractiveness, 24, 0.67).
narrative_ontology:measurement_basis(woma_be_t24, observed).
narrative_ontology:measurement(woma_be_t32, woman_category__sex_biology_reading, base_extractiveness, 32, 0.7).
narrative_ontology:measurement_basis(woma_be_t32, observed).
narrative_ontology:measurement(woma_be_t40, woman_category__sex_biology_reading, base_extractiveness, 40, 0.72).
narrative_ontology:measurement_basis(woma_be_t40, observed).

% Suppression requirement over time
narrative_ontology:measurement(woma_su_t0, woman_category__sex_biology_reading, suppression_requirement, 0, 0.55).
narrative_ontology:measurement_basis(woma_su_t0, observed).
narrative_ontology:measurement(woma_su_t8, woman_category__sex_biology_reading, suppression_requirement, 8, 0.6).
narrative_ontology:measurement_basis(woma_su_t8, observed).
narrative_ontology:measurement(woma_su_t16, woman_category__sex_biology_reading, suppression_requirement, 16, 0.66).
narrative_ontology:measurement_basis(woma_su_t16, observed).
narrative_ontology:measurement(woma_su_t24, woman_category__sex_biology_reading, suppression_requirement, 24, 0.71).
narrative_ontology:measurement_basis(woma_su_t24, observed).
narrative_ontology:measurement(woma_su_t32, woman_category__sex_biology_reading, suppression_requirement, 32, 0.75).
narrative_ontology:measurement_basis(woma_su_t32, observed).
narrative_ontology:measurement(woma_su_t40, woman_category__sex_biology_reading, suppression_requirement, 40, 0.78).
narrative_ontology:measurement_basis(woma_su_t40, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(woman_category__sex_biology_reading, identity_coordination).
narrative_ontology:affects_constraint(woman_category__sex_biology_reading, woman_category__gender_identity_reading).
narrative_ontology:affects_constraint(woman_category__sex_biology_reading, woman_category__intersex_accommodation_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the woman_category kernel. The kernel decomposes into three structurally distinct constraints with different ε values, beneficiary/victim structures, and enforcement mechanisms: (1) sex_biology_reading (this constraint—natal sex as determinant, high ε where exclusion of transgender women operates), (2) gender_identity_reading (self-identification as determinant, ε shifts to institutional-accommodation costs and single-sex-space safety disputes), (3) intersex_accommodation_reading (non-binary spectrum acknowledged, ε includes administrative complexity of multi-category systems). All three readings address the same kernel question (what determines woman-category membership) but instantiate different constraints that must be modeled separately per the ε-invariance principle. Network edges link them as a constraint family; each reading influences the legitimacy and adoption conditions of the others.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
