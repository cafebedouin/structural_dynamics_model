% ============================================================================
% CONSTRAINT STORY: westphalia_sovereignty__conditional_responsibility
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2025-01-15
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_westphalia_sovereignty__conditional_responsibility, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: westphalia_sovereignty__conditional_responsibility
 *   human_readable: Responsibility to Protect Doctrine (Conditional Sovereignty)
 *   domain: international_law/political_theory
 *
 * SUMMARY:
 *   The Responsibility to Protect (R2P) doctrine reframes sovereignty as
 *   conditional on states meeting protection obligations toward their
 *   populations. When states fail to prevent or halt mass atrocities,
 *   international institutions claim authority to authorize intervention,
 *   overriding territorial inviolability. The doctrine emerged from post-Cold
 *   War humanitarian crises and was formalized in UN documents. It is
 *   presented as principled evolution of international law; critics read it
 *   as legitimation infrastructure for selective intervention by powerful
 *   states. This story instantiates the conditional_responsibility reading of
 *   the westphalia_sovereignty kernel. The claimed type is tangled_rope
 *   (genuine coordination function layered with asymmetric extraction), while
 *   metrics describe substantially extractive operation with high suppression
 *   and rising theater as application patterns diverge from stated
 *   principles.
 *
 * KEY AGENTS:
 *   - intervention_coalitions: Agenda-setter (institutional/arbitrage) — execute interventions with humanitarian legitimacy cover
 *   - international_governance_institutions: Agenda-setter/beneficiary (institutional/analytical) — adjudicate sovereignty lapses, gain expanded jurisdiction
 *   - humanitarian_advocacy_organizations: Beneficiary (organized/mobile) — document atrocities, lobby for intervention, gain institutional access
 *   - populations_under_atrocity_regimes: Beneficiary/payer (powerless/trapped) — nominal protection recipients who bear intervention costs
 *   - states_facing_intervention: Payer (institutional/constrained) — lose territorial inviolability, face regime change
 *   - regional_hegemons_constrained: Payer (institutional/constrained) — lose exclusive regional authority
 *   - non_intervening_states: Observer (institutional/mobile) — monitor for selective enforcement patterns
 *   - legal_scholars_international_law: Observer (analytical/analytical) — analyze coherence and application asymmetries
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(westphalia_sovereignty__conditional_responsibility, 0.68).
domain_priors:suppression_score(westphalia_sovereignty__conditional_responsibility, 0.71).
domain_priors:theater_ratio(westphalia_sovereignty__conditional_responsibility, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, extractiveness, 0.68).
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, suppression_requirement, 0.71).
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, accessibility_collapse, 0.47).
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, resistance, 0.73).

% --- Constraint claim ---
narrative_ontology:constraint_claim(westphalia_sovereignty__conditional_responsibility, tangled_rope).
narrative_ontology:human_readable(westphalia_sovereignty__conditional_responsibility, "Responsibility to Protect Doctrine (Conditional Sovereignty)").
narrative_ontology:topic_domain(westphalia_sovereignty__conditional_responsibility, "international_law/political_theory").

domain_priors:requires_active_enforcement(westphalia_sovereignty__conditional_responsibility).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(westphalia_sovereignty__conditional_responsibility, '0a150956-d3d5-423f-a4e9-4abbfce4e15f').
narrative_ontology:cs_kernel_codification('0a150956-d3d5-423f-a4e9-4abbfce4e15f', formalized).
narrative_ontology:cs_authority_grounding('0a150956-d3d5-423f-a4e9-4abbfce4e15f', extraction).
narrative_ontology:cs_interpretation_layer_present('0a150956-d3d5-423f-a4e9-4abbfce4e15f').
narrative_ontology:cs_reading_relation('0a150956-d3d5-423f-a4e9-4abbfce4e15f', westphalia_sovereignty__absolute_non_intervention, forecloses).
narrative_ontology:cs_reading_relation('0a150956-d3d5-423f-a4e9-4abbfce4e15f', westphalia_sovereignty__graded_sovereignty, coexists_with).
narrative_ontology:cs_axiom('0a150956-d3d5-423f-a4e9-4abbfce4e15f', foundational, sovereignty_conditional_on_protection).
narrative_ontology:cs_axiom_status(sovereignty_conditional_on_protection, holdable).
narrative_ontology:cs_axiom_grounding('0a150956-d3d5-423f-a4e9-4abbfce4e15f', sovereignty_conditional_on_protection, deontological).
narrative_ontology:cs_axiom('0a150956-d3d5-423f-a4e9-4abbfce4e15f', foundational, international_community_authority_over_domestic_atrocities).
narrative_ontology:cs_axiom_status(international_community_authority_over_domestic_atrocities, holdable).
narrative_ontology:cs_axiom_grounding('0a150956-d3d5-423f-a4e9-4abbfce4e15f', international_community_authority_over_domestic_atrocities, conventional).
narrative_ontology:cs_reference_frame('0a150956-d3d5-423f-a4e9-4abbfce4e15f', post_westphalia_state_equality).
narrative_ontology:cs_drift_state('0a150956-d3d5-423f-a4e9-4abbfce4e15f', post_cold_war_humanitarian_era, gap(authority_erosion, substantial, false)).
narrative_ontology:cs_created_at('0a150956-d3d5-423f-a4e9-4abbfce4e15f', '').
narrative_ontology:cs_kernel_id(westphalia_sovereignty__conditional_responsibility, westphalia_sovereignty).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, intervention_coalitions).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, international_governance_institutions).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, humanitarian_advocacy_organizations).
narrative_ontology:constraint_victim(westphalia_sovereignty__conditional_responsibility, populations_under_atrocity_regimes).
narrative_ontology:constraint_victim(westphalia_sovereignty__conditional_responsibility, states_facing_intervention).
narrative_ontology:constraint_victim(westphalia_sovereignty__conditional_responsibility, regional_hegemons_constrained).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, populations_under_atrocity_regimes).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__conditional_responsibility, universal_human_rights_primacy).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__conditional_responsibility, international_community_responsibility).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Military coalitions or regional organizations authorized to intervene when atrocities are declared. They determine operational scope, rules of engagement, and duration. Gain legitimacy through humanitarian framing while exercising force projection capabilities that would otherwise face sovereignty-barrier resistance. Their authority to act is conditional on international body authorization, but selection of intervention targets and means remains discretionary.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, intervention_coalitions, agenda_setter,
    institutional, generational, arbitrage, global).

% UN Security Council and associated bodies that adjudicate when sovereignty protections lapse. They declare atrocity thresholds, authorize intervention, and set post-intervention governance terms. Gain expanded jurisdiction over domestic state conduct that absolute sovereignty would bar, positioning themselves as arbiters of state legitimacy rather than mere coordinators of equal sovereigns.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, international_governance_institutions, agenda_setter,
    institutional, civilizational, analytical, global).
narrative_ontology:stakeholder_secondary_role(westphalia_sovereignty__conditional_responsibility, international_governance_institutions, beneficiary).

% NGOs and advocacy networks that document atrocities and lobby for intervention. They gain institutional access, funding streams, and moral authority from the doctrine's existence. Their reporting shapes the evidentiary basis for intervention decisions, giving them agenda-setting influence without direct enforcement power.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, humanitarian_advocacy_organizations, beneficiary,
    organized, generational, mobile, global).

% Civilians facing mass violence who are the nominal beneficiaries of protection. They receive intervention that may halt immediate atrocities but bear the costs of military action, post-conflict instability, and loss of self-determination as external actors reshape governance. Their preference between sovereignty and intervention is rarely consulted; the doctrine operates over their heads.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, populations_under_atrocity_regimes, beneficiary,
    powerless, immediate, trapped, local).
narrative_ontology:stakeholder_secondary_role(westphalia_sovereignty__conditional_responsibility, populations_under_atrocity_regimes, payer).

% Governments accused of failing protection obligations who lose territorial inviolability. They face military action, regime change, or externally imposed governance structures. Their sovereignty claim is overridden by international adjudication, with limited procedural recourse and no exit from the jurisdictional reach of the doctrine.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, states_facing_intervention, payer,
    institutional, generational, constrained, national).

% Major powers in regions where interventions occur, whose traditional spheres of influence are penetrated by coalitions invoking responsibility to protect. They lose exclusive regional authority and face legitimacy costs if they resist interventions framed as humanitarian, even when strategic interests are at stake.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, regional_hegemons_constrained, payer,
    institutional, generational, constrained, continental).

% States not targeted for intervention and not part of intervention coalitions. They watch the doctrine's application for pattern evidence of selective enforcement, strategic pretexts, or institutional capture. Their support or opposition shapes the doctrine's legitimacy but they face no immediate constraint from its operation.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, non_intervening_states, observer,
    institutional, generational, mobile, global).

% Academic and professional legal communities analyzing doctrine coherence, application patterns, and jus cogens conflicts. They debate whether conditional sovereignty represents genuine legal evolution or rhetorical cover for power projection, providing external accountability commentary without enforcement capacity.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, legal_scholars_international_law, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Solves the collective action problem of responding to mass atrocities: creates a shared framework for when sovereignty protections lapse, establishes authorization procedures, and coordinates intervention legitimacy across states with diverse interests.
% TRANSFER_FUNCTION: Transfers discretionary authority over domestic state conduct from sovereigns to international institutions and intervention coalitions. Transfers military and governance control from targeted states to intervening actors. Transfers legitimacy claims from absolute sovereignty principles to conditional responsibility frameworks.
% ABSENT_VOICES: Populations under atrocity regimes whose preference between intervention and self-determination is presumed rather than consulted. States without Security Council veto power whose sovereignty protections are asymmetrically vulnerable. Regional organizations excluded from decision-making whose spheres are penetrated.
% DISAPPEARANCE_RATIONALE: If the doctrine vanished, states facing atrocities would reassert absolute sovereignty defenses, intervention coalitions would lose humanitarian legitimacy cover, international governance institutions would lose jurisdiction over domestic conduct, and military interventions would revert to explicit balance-of-power or strategic-interest justifications without multilateral coordination framework.
% FOUNDING_PROBLEM: Westphalian absolute sovereignty created impunity for states committing mass atrocities against their own populations, with no legitimate mechanism for external intervention to halt genocide, ethnic cleansing, or crimes against humanity.
% FOUNDING_PROBLEM_CORROBORATION: Humanitarian advocacy organizations and intervention coalitions attest the problem remains live, citing ongoing atrocities. Legal scholars from non-intervening states and regional hegemons constrained by the doctrine attest that selective application and institutional capture have transformed the doctrine from atrocity-prevention into legitimation for strategic intervention, with systematic evidence of enforcement asymmetry correlating with target-state geopolitical isolation rather than atrocity severity.
narrative_ontology:disappearance_verdict(westphalia_sovereignty__conditional_responsibility, world_rearranges).
narrative_ontology:founding_problem_status(westphalia_sovereignty__conditional_responsibility, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(westphalia_sovereignty__conditional_responsibility, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(westphalia_sovereignty__conditional_responsibility, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(westphalia_sovereignty__conditional_responsibility_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(westphalia_sovereignty__conditional_responsibility, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(westphalia_sovereignty__conditional_responsibility_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is high (0.68) because the doctrine transfers discretionary authority over state conduct to institutions and coalitions with agenda-setting power, creating asymmetric vulnerability for states without veto protection. Suppression is higher (0.71) because the constraint's operation depends on overriding sovereignty claims through authorized force, not on voluntary coordination. Theater is substantial (0.42) as the gap between humanitarian framing and strategic application grows: interventions correlate with geopolitical isolation of targets rather than atrocity severity alone, with comparable crises receiving asymmetric responses. Accessibility collapse is moderate (0.47) because alternative sovereignty frameworks (absolute non-intervention, negotiated regional solutions) remain contested. Resistance is high (0.73) from states and regional blocs asserting sovereignty protections, producing ongoing institutional conflict. All measurements share a single time grid with values authored at each examined point.
 *
 * PERSPECTIVAL GAP:
 *   From the agenda-setter seats (intervention coalitions, governance institutions), the constraint operates as evolved coordination solving genuine atrocity-prevention problems. From the payer seats (targeted states, regional hegemons, populations bearing intervention costs), the same structure operates as extractive transfer of authority with selective enforcement masking strategic interests. The powerless/trapped populations occupy the most asymmetric position: named as beneficiaries in the doctrine's justification but experiencing both atrocity-regime violence and intervention costs with no voice in either. The engine computes these divergent classifications from the structural data; the claim does not adjudicate between them.
 *
 * DIRECTIONALITY LOGIC:
 *   Intervention coalitions and international governance institutions are structural beneficiaries (gain authority, legitimacy, and operational scope — d near beneficiary end). States facing intervention are primary targets (lose sovereignty protection, face force — d near target end). Regional hegemons are also payers (constrained authority, legitimacy costs). Populations under atrocity regimes occupy dual position: nominal beneficiaries of protection but bearing intervention costs without voice in the process — modeled with both roles, exit trapped, resulting in d closer to target than pure beneficiary despite humanitarian framing. Humanitarian advocacy organizations are beneficiaries (institutional access, funding, influence) without enforcement costs.
 *
 * MANDATROPHY ANALYSIS:
 *   The coordination function (solving collective action problems for atrocity response) is genuine but has been layered with substantial extraction as application patterns systematically favor intervening-coalition interests over consistent humanitarian criteria. The doctrine prevents mislabeling pure power projection as humanitarian intervention by requiring institutional authorization and atrocity-threshold documentation, but the authorization process itself is captured by veto-holding powers whose intervention decisions correlate with strategic rather than solely humanitarian variables. The mandatrophy check reveals partial mandate exhaustion: the founding problem (impunity for mass atrocities) is addressed through expanded international authority, but that authority is wielded asymmetrically, with enforcement concentrated on geopolitically isolated states while comparable atrocities in strategically protected contexts receive non-intervention responses. The gap between humanitarian mandate and strategic application is the extraction mechanism.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    atrocity_threshold_determinacy,
    'Are the criteria for when protection obligations are failed and sovereignty protections lapse determinate enough to prevent strategic manipulation, or do threshold ambiguities enable selective application?',
    'Systematic cross-case analysis of intervention authorization decisions controlling for atrocity severity, civilian death tolls, and target-state geopolitical alignment. If atrocity variables predict intervention after controlling for alignment, thresholds are principled; if alignment predicts intervention independent of atrocity severity, thresholds are strategically manipulated.',
    'Determinate thresholds would support the coordination framing and reduce extraction by constraining discretion. Manipulable thresholds would establish the doctrine as legitimation infrastructure for strategic intervention, increasing measured extraction and supporting reclassification toward snare.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(atrocity_threshold_determinacy, empirical, 'Whether atrocity thresholds are determinate or strategically malleable').

omega_variable(
    population_preference_consultation,
    'When populations under atrocity regimes face the choice between continued sovereignty of an atrocity-committing state and external intervention, are their preferences systematically consulted, or is the intervention decision made over their heads by external actors?',
    'Procedural audit of intervention authorization processes for mechanisms that solicit and incorporate affected-population preferences. Post-intervention surveys of civilian populations asking whether they would have chosen intervention given known costs.',
    'If preferences are systematically consulted and incorporated, populations are genuine beneficiaries. If decisions are made without consultation, populations are objects rather than subjects, and their dual beneficiary/payer position tilts toward payer, increasing effective extraction at the powerless seat.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(population_preference_consultation, empirical, 'Whether affected populations are consulted or overridden in intervention decisions').

omega_variable(
    absolute_vs_conditional_sovereignty_incommensurability,
    'Is the dispute between absolute and conditional sovereignty a resolvable empirical question about coordination optimality, or an irreducible normative conflict about whether territorial authority is intrinsically sovereign or held conditionally on performance?',
    'If coordination-theoretic analysis can identify intervention rules that all parties would endorse behind a veil of ignorance about their future geopolitical position, the dispute is resolvable. If parties'' positions track their structural interests even under veil conditions, the dispute is normative and irreducible.',
    'If resolvable, the kernel contest is about optimal coordination design and evidence can settle it. If irreducible, different readings will persist as long as structural interests diverge, and the doctrine''s classification will remain observer-dependent.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(absolute_vs_conditional_sovereignty_incommensurability, conceptual, 'Whether sovereignty status is empirically optimizable or normatively irreducible').

omega_variable(
    reading_selection_kernel_ambiguity,
    'The westphalia_sovereignty kernel admits multiple readings. Is this constraint''s conditional_responsibility reading the ''true'' interpretation of evolving international law, or one contested framing among several live alternatives?',
    'This is a committer-frame ambiguity inherent to kernel structure. The conditional_responsibility reading is one instantiation of the kernel; absolute_non_intervention and graded_sovereignty are sibling readings. No resolution mechanism exists within a single reading; the kernel contest itself is the irreducible fact.',
    'This reading''s metrics describe the constraint as it operates under conditional_responsibility framing. Sibling readings would measure different constraints (different beneficiaries, different ε values). The kernel structure routes this ambiguity into the omega rather than forcing reconciliation.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(reading_selection_kernel_ambiguity, conceptual, 'Kernel reading selection under-determines constraint identity').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(westphalia_sovereignty__conditional_responsibility, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(west_tr_t0, westphalia_sovereignty__conditional_responsibility, theater_ratio, 0, 0.22).
narrative_ontology:measurement_basis(west_tr_t0, observed).
narrative_ontology:measurement(west_tr_t5, westphalia_sovereignty__conditional_responsibility, theater_ratio, 5, 0.27).
narrative_ontology:measurement_basis(west_tr_t5, observed).
narrative_ontology:measurement(west_tr_t10, westphalia_sovereignty__conditional_responsibility, theater_ratio, 10, 0.32).
narrative_ontology:measurement_basis(west_tr_t10, observed).
narrative_ontology:measurement(west_tr_t15, westphalia_sovereignty__conditional_responsibility, theater_ratio, 15, 0.36).
narrative_ontology:measurement_basis(west_tr_t15, observed).
narrative_ontology:measurement(west_tr_t20, westphalia_sovereignty__conditional_responsibility, theater_ratio, 20, 0.39).
narrative_ontology:measurement_basis(west_tr_t20, observed).
narrative_ontology:measurement(west_tr_t25, westphalia_sovereignty__conditional_responsibility, theater_ratio, 25, 0.42).
narrative_ontology:measurement_basis(west_tr_t25, observed).

% Extraction over time
narrative_ontology:measurement(west_be_t0, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 0, 0.48).
narrative_ontology:measurement_basis(west_be_t0, observed).
narrative_ontology:measurement(west_be_t5, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 5, 0.53).
narrative_ontology:measurement_basis(west_be_t5, observed).
narrative_ontology:measurement(west_be_t10, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 10, 0.59).
narrative_ontology:measurement_basis(west_be_t10, observed).
narrative_ontology:measurement(west_be_t15, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 15, 0.63).
narrative_ontology:measurement_basis(west_be_t15, observed).
narrative_ontology:measurement(west_be_t20, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 20, 0.66).
narrative_ontology:measurement_basis(west_be_t20, observed).
narrative_ontology:measurement(west_be_t25, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 25, 0.68).
narrative_ontology:measurement_basis(west_be_t25, observed).

% Suppression requirement over time
narrative_ontology:measurement(west_su_t0, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 0, 0.54).
narrative_ontology:measurement_basis(west_su_t0, observed).
narrative_ontology:measurement(west_su_t5, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 5, 0.59).
narrative_ontology:measurement_basis(west_su_t5, observed).
narrative_ontology:measurement(west_su_t10, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 10, 0.64).
narrative_ontology:measurement_basis(west_su_t10, observed).
narrative_ontology:measurement(west_su_t15, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 15, 0.67).
narrative_ontology:measurement_basis(west_su_t15, observed).
narrative_ontology:measurement(west_su_t20, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 20, 0.69).
narrative_ontology:measurement_basis(west_su_t20, observed).
narrative_ontology:measurement(west_su_t25, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 25, 0.71).
narrative_ontology:measurement_basis(west_su_t25, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(westphalia_sovereignty__conditional_responsibility, enforcement_mechanism).
narrative_ontology:affects_constraint(westphalia_sovereignty__conditional_responsibility, westphalia_sovereignty__absolute_non_intervention).
narrative_ontology:affects_constraint(westphalia_sovereignty__conditional_responsibility, westphalia_sovereignty__graded_sovereignty).

% DUAL FORMULATION NOTE:
% This constraint is part of the westphalia_sovereignty kernel family. The conditional_responsibility reading instantiates one interpretation of territorial inviolability where sovereignty is forfeited upon protection-obligation failure. The absolute_non_intervention reading would treat sovereignty as categorical regardless of internal conduct. The graded_sovereignty reading would treat authority as scalar capacity. All three readings operate over the same domain (state territorial authority and intervention legitimacy) but have different beneficiary sets, victim sets, and ε values. They are linked via network.affects_constraints because institutional adoption of one reading constrains the legitimacy conditions for invoking the others.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
