% ============================================================================
% CONSTRAINT STORY: woman_category__intersex_accommodation_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_woman_category__intersex_accommodation_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: woman_category__intersex_accommodation_reading
 *   human_readable: Woman Category: Intersex Accommodation Reading
 *   domain: political_philosophy/law/social_policy/bioethics
 *
 * SUMMARY:
 *   This constraint is the intersex accommodation reading of the contested
 *   woman-category kernel. It holds that 'woman' should include people with
 *   typical female biology plus intersex variations that do not fit the male
 *   category, acknowledging biological sex as a spectrum rather than a
 *   binary. The reading emerged from intersex advocacy challenging medical
 *   pathologization and legal erasure of people born with ambiguous sex
 *   characteristics. It coordinates genuine accommodation of biological
 *   reality (approximately 1.7% of humans have intersex variations) while
 *   extracting from two victim groups: elite female athletes with typical
 *   biology (who face changed competitive fields when performance-relevant
 *   intersex variations qualify for the female category) and people with
 *   ambiguous biology who are selectively included or excluded depending on
 *   whether their inclusion serves or destabilizes the reading's
 *   accommodation framework. The constraint is claimed as tangled_rope
 *   because it genuinely solves the founding problem (prevents medical harm
 *   and legal erasure of intersex people) while simultaneously extracting
 *   from those who bear the costs of selective enforcement. The engine
 *   computes per-seat classifications from the structural data; the
 *   claim/metric independence is preserved.
 *
 * KEY AGENTS:
 *   - intersex_advocacy_organizations: Primary agenda-setter (organized/mobile) — campaigns for spectrum framework
 *   - people_with_intersex_variations: Primary beneficiary (moderate/identity_locked) — but also payer when selectively excluded
 *   - elite_female_athletes_with_typical_biology: Primary payer (moderate/constrained) — competitive field changes
 *   - people_with_ambiguous_biology_excluded_from_both_categories: Primary victim (powerless/trapped) — caught in selective enforcement
 *   - sports_governing_bodies: Secondary agenda-setter (institutional/constrained) — operationalizes thresholds
 *   - legal_scholars_analyzing_category_coherence: Analytical observer (analytical/analytical) — documents structure
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(woman_category__intersex_accommodation_reading, 0.68).
domain_priors:suppression_score(woman_category__intersex_accommodation_reading, 0.72).
domain_priors:theater_ratio(woman_category__intersex_accommodation_reading, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, extractiveness, 0.68).
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, suppression_requirement, 0.72).
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, accessibility_collapse, 0.61).
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, resistance, 0.58).

% --- Constraint claim ---
narrative_ontology:constraint_claim(woman_category__intersex_accommodation_reading, tangled_rope).
narrative_ontology:human_readable(woman_category__intersex_accommodation_reading, "Woman Category: Intersex Accommodation Reading").
narrative_ontology:topic_domain(woman_category__intersex_accommodation_reading, "political_philosophy/law/social_policy/bioethics").

domain_priors:requires_active_enforcement(woman_category__intersex_accommodation_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(woman_category__intersex_accommodation_reading, '8601c58c-965f-485e-afe4-9d0d3cf2bbb1').
narrative_ontology:cs_kernel_codification('8601c58c-965f-485e-afe4-9d0d3cf2bbb1', distributed).
narrative_ontology:cs_authority_grounding('8601c58c-965f-485e-afe4-9d0d3cf2bbb1', distributed).
narrative_ontology:cs_reading_relation('8601c58c-965f-485e-afe4-9d0d3cf2bbb1', woman_category__sex_biology_reading, influences).
narrative_ontology:cs_reading_relation('8601c58c-965f-485e-afe4-9d0d3cf2bbb1', woman_category__gender_identity_reading, coexists_with).
narrative_ontology:cs_axiom('8601c58c-965f-485e-afe4-9d0d3cf2bbb1', foundational, biological_sex_as_spectrum).
narrative_ontology:cs_axiom_status(biological_sex_as_spectrum, holdable).
narrative_ontology:cs_axiom_grounding('8601c58c-965f-485e-afe4-9d0d3cf2bbb1', biological_sex_as_spectrum, empirically_contingent).
narrative_ontology:cs_axiom('8601c58c-965f-485e-afe4-9d0d3cf2bbb1', foundational, category_accommodation_over_binary_enforcement).
narrative_ontology:cs_axiom_status(category_accommodation_over_binary_enforcement, holdable).
narrative_ontology:cs_axiom_grounding('8601c58c-965f-485e-afe4-9d0d3cf2bbb1', category_accommodation_over_binary_enforcement, deontological).
narrative_ontology:cs_reference_frame('8601c58c-965f-485e-afe4-9d0d3cf2bbb1', binary_sex_assignment_with_surgical_correction).
narrative_ontology:cs_drift_state('8601c58c-965f-485e-afe4-9d0d3cf2bbb1', post_intersex_advocacy_era, gap(repudiation_pressure, substantial, true)).
narrative_ontology:cs_created_at('8601c58c-965f-485e-afe4-9d0d3cf2bbb1', '').
narrative_ontology:cs_kernel_id(woman_category__intersex_accommodation_reading, woman_category).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(woman_category__intersex_accommodation_reading, intersex_advocacy_organizations).
narrative_ontology:constraint_beneficiary(woman_category__intersex_accommodation_reading, medical_professionals_treating_intersex_conditions).
narrative_ontology:constraint_beneficiary(woman_category__intersex_accommodation_reading, people_with_intersex_variations).
narrative_ontology:constraint_victim(woman_category__intersex_accommodation_reading, elite_female_athletes_with_typical_biology).
narrative_ontology:constraint_victim(woman_category__intersex_accommodation_reading, people_with_ambiguous_biology_excluded_from_both_categories).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_victim(woman_category__intersex_accommodation_reading, people_with_intersex_variations).
narrative_ontology:constraint_victim(woman_category__intersex_accommodation_reading, sports_governing_bodies).
narrative_ontology:constraint_vindicates(woman_category__intersex_accommodation_reading, biological_sex_spectrum_doctrine).
narrative_ontology:constraint_vindicates(woman_category__intersex_accommodation_reading, category_accommodation_over_binary_enforcement).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Campaign for legal and social recognition that biological sex exists on a spectrum rather than as a binary. They frame strict binary enforcement as medicalizing and stigmatizing people born with intersex variations. They coordinate testimony, policy advocacy, and public education arguing that category membership should accommodate biological diversity rather than forcing assignment to one of two boxes.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, intersex_advocacy_organizations, agenda_setter,
    organized, generational, mobile, global).

% Provide clinical care and diagnostic frameworks for people born with differences in sex development. They benefit from frameworks that acknowledge biological complexity without pathologizing variation. Their professional authority is enhanced when policy defers to medical expertise about biological ambiguity, though they also face pressure to resolve ambiguity through assignment rather than accommodation.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, medical_professionals_treating_intersex_conditions, beneficiary,
    institutional, biographical, constrained, global).

% Born with chromosomal, hormonal, or anatomical variations that do not fit typical male or female patterns. They benefit when legal and social categories acknowledge their existence without forcing binary assignment, but they pay when accommodation frameworks are selectively enforced only in contexts where their inclusion benefits others. Many report that spectrum frameworks are invoked rhetorically but rarely translate into concrete legal protections or medical autonomy.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, people_with_intersex_variations, beneficiary,
    moderate, biographical, identity_locked, global).
narrative_ontology:stakeholder_secondary_role(woman_category__intersex_accommodation_reading, people_with_intersex_variations, payer).

% Compete in women's sports categories under eligibility rules that determine who qualifies as 'woman' for competitive purposes. They bear the cost when accommodation of intersex variations with performance-relevant differences (elevated endogenous testosterone, atypical muscle development) changes the competitive field. Their objection is not to intersex people's existence but to whether all variations should qualify for the female category in contexts where physical performance advantage matters. Exit means abandoning elite competition.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, elite_female_athletes_with_typical_biology, payer,
    moderate, biographical, constrained, global).

% Have intersex variations that this reading includes in 'woman' when convenient (to demonstrate non-binary spectrum) but excludes when inclusion would create category instability (elite sports with performance implications). They are caught in selective enforcement: acknowledged as proof the binary is false, but excluded from female spaces when their inclusion challenges female-category coherence. They cannot exit the framing because their biology is the site of the contest.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, people_with_ambiguous_biology_excluded_from_both_categories, payer,
    powerless, biographical, trapped, global).

% Administer eligibility rules for sex-segregated competition. They set thresholds for testosterone levels, chromosomal patterns, or surgical status to operationalize 'woman' in competitive contexts. They navigate pressure from human rights advocates (demanding inclusion) and from female athletes (demanding fair competition). Every threshold they draw becomes a target for litigation. Their institutional legitimacy depends on being seen as fair by both sides, which is structurally impossible when the sides have incompatible fairness definitions.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, sports_governing_bodies, agenda_setter,
    institutional, generational, constrained, global).
narrative_ontology:stakeholder_secondary_role(woman_category__intersex_accommodation_reading, sports_governing_bodies, payer).

% Analyze how category definitions interact with anti-discrimination law, privacy rights, and institutional access rules. They document the Semenya case and similar litigation as revealing the constraint's structure: intersex accommodation is invoked to challenge binary enforcement when binary enforcement excludes people from desired categories, but the same accommodation framework struggles to provide stable inclusion criteria that preserve the function binary categories were built to serve.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, legal_scholars_analyzing_category_coherence, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Acknowledges biological reality that approximately 1.7% of humans are born with sex characteristics that do not fit typical male or female patterns, preventing medical pathologization and legal erasure of people whose bodies do not conform to binary expectations.
% TRANSFER_FUNCTION: Moves definitional authority over 'woman' from chromosomal/anatomical criteria (sex_biology_reading) or self-identification (gender_identity_reading) to a spectrum framework that includes intersex variations, transferring social and institutional recognition from strictly binary assignments to accommodation of biological ambiguity. Moves competitive advantage in elite sports from typical female biology to a wider set that may include performance-relevant intersex variations.
% ABSENT_VOICES: People with intersex variations who reject both binary assignment and spectrum-based categorical inclusion are structurally absent; they would argue that accommodating intersex people within existing binary categories (even a widened 'woman') still centers binary logic rather than abolishing the categories. Their position is foreclosed by the reading's premise that the binary can be preserved through accommodation.
% DISAPPEARANCE_RATIONALE: If this constraint disappeared overnight, policy would snap back to enforcing strict binary assignment (sex_biology_reading) or adopt identity-based membership (gender_identity_reading). Sports governing bodies would revert to chromosomal or surgical-status rules without biological-spectrum justification. Medical protocols would resume pathologizing intersex variations as disorders requiring correction. Legal identity documents would lose the third-category or spectrum options that this reading enabled in some jurisdictions. People with intersex variations would lose the rhetorical leverage that spectrum frameworks provide against binary enforcement.
% FOUNDING_PROBLEM: Strict binary sex assignment caused medical harm (non-consensual infant surgeries, hormone treatment without informed consent) and legal erasure (inability to obtain identity documents, exclusion from sex-segregated spaces regardless of actual biology) for people born with intersex variations. The binary could not accommodate biological reality.
% FOUNDING_PROBLEM_CORROBORATION: Intersex advocacy organizations and medical ethics bodies attest the founding problem is live: non-consensual surgeries still occur, legal binary assignment still creates hardship for people whose biology is ambiguous. Independent human rights reports from UN bodies and medical journals document ongoing harm. However, the NEW problem this reading generates—selective enforcement that includes intersex people when it challenges binary enforcement but excludes them when it destabilizes category function—is attested by sports litigation (Semenya case analysis) and legal scholars outside the advocacy organizations.
narrative_ontology:disappearance_verdict(woman_category__intersex_accommodation_reading, world_rearranges).
narrative_ontology:founding_problem_status(woman_category__intersex_accommodation_reading, live).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(woman_category__intersex_accommodation_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(woman_category__intersex_accommodation_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(woman_category__intersex_accommodation_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(woman_category__intersex_accommodation_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(woman_category__intersex_accommodation_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is substantial (0.68) because the reading imposes costs on two groups: athletes with typical female biology face competitive disadvantage when performance-relevant intersex variations are accommodated, and people with ambiguous biology are selectively included/excluded based on whether inclusion serves the framework's stability. Suppression is high (0.72) because the constraint requires active enforcement of which intersex variations qualify for which category in which contexts, suppressing objections from both athletes (demanding fair competition) and from intersex people (objecting to selective inclusion). Theater ratio is moderate-low (0.28): the biological-spectrum framework is scientifically grounded and addresses real medical harm, but a growing share of enforcement activity is about defending the reading against challenges in elite sports contexts where performance advantage makes accommodation costly. The Semenya case is the canonical example: rules targeting specific intersex variations with performance implications reveal that accommodation is selective rather than universal. Accessibility collapse is moderate (0.61): alternatives exist (strict binary enforcement, identity-based membership) but spectrum frameworks have gained institutional traction in medical ethics and some legal jurisdictions. Resistance is substantial (0.58): elite sports contexts generate ongoing litigation, and athletes with typical biology organize against rule changes that accommodate performance-relevant variations. The measurement series shows extraction and suppression rising as the reading encounters contexts (elite sports) where accommodation destabilizes category function.
 *
 * PERSPECTIVAL GAP:
 *   The agenda-setter seat (intersex advocacy) experiences this constraint as genuine coordination solving medical harm and legal erasure. The payer seats (elite athletes, excluded intersex people) experience it as extraction: athletes face competitive costs from performance-relevant accommodations, excluded intersex people face rhetorical inclusion but practical exclusion. The gap is not about different perceptions of the same structure—it is about structural position determining whose costs are visible. From the advocacy seat, the reading protects a marginalized group; from the athlete seat, it changes competitive fairness without their consent; from the excluded-intersex seat, it uses their existence to challenge binary enforcement but abandons them when inclusion would destabilize the framework. The engine computes these divergent per-seat classifications from the power/exit/beneficiary-victim structure.
 *
 * DIRECTIONALITY LOGIC:
 *   Intersex advocacy organizations are the primary beneficiaries and agenda-setters (d near beneficiary end): they gain institutional recognition and rhetorical leverage from spectrum frameworks. Medical professionals are secondary beneficiaries (d slightly beneficiary-side): their authority is enhanced when policy defers to medical expertise about ambiguity. People with intersex variations are split: beneficiaries when spectrum frameworks prevent pathologization (d beneficiary-side), but payers when selective enforcement excludes them from desired categories (d target-side for the excluded subgroup). Elite female athletes with typical biology are primary payers (d near target end): constrained exit, face competitive costs they cannot avoid. People with ambiguous biology excluded from both categories are primary victims (d full target end): trapped, powerless, caught in selective enforcement with no exit. Sports governing bodies are secondary payers (d moderate target-side): institutional actors bearing litigation costs and legitimacy loss from unsatisfiable demands.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint began with a legitimate mandate: prevent medical harm and legal erasure of people born with intersex variations. That founding problem is still live (non-consensual surgeries continue, binary legal frameworks still cause hardship). But the reading now operates in contexts (elite sports) where its function has shifted from preventing harm to adjudicating competitive advantage. The Semenya case reveals the mandate shift: the constraint is invoked to challenge binary enforcement when binary enforcement excludes, but selective thresholds are imposed when accommodation would destabilize the category. This is not yet full mandatrophy (the founding problem is not dead), but it is mandate drift: from 'accommodate biological reality' to 'accommodate only those variations that preserve category function in high-stakes contexts.' The six-questions founding_problem_status is 'live' because medical harm and legal erasure are ongoing, but the NEW problem the reading generates (selective enforcement) is also live and attested by observers outside the beneficiary set.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    selective_enforcement_boundary,
    'Does this reading include all intersex variations in ''woman'' universally, or only those variations that preserve category function in the contexts where the reading is applied?',
    'Systematic comparison of which intersex variations are accommodated in low-stakes contexts (identity documents, medical forms, social recognition) versus high-stakes contexts (elite sports eligibility, sex-segregated spaces with safety concerns). If the same variation is included in one context but excluded in another based on functional consequences rather than biological criteria, enforcement is selective.',
    'If enforcement is selective, the reading operates as tangled_rope or snare rather than rope: it coordinates accommodation rhetorically but extracts from the excluded subgroup (people with variations that destabilize category function) and from those who bear the costs of accommodation (elite athletes). If enforcement is universal, it is closer to rope but must answer how it preserves the coordination function that sex-segregated categories were built to serve.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(selective_enforcement_boundary, empirical, 'Whether intersex accommodation is universal or selectively enforced by context.').

omega_variable(
    performance_advantage_threshold,
    'At what magnitude of performance advantage does accommodating an intersex variation in female sports become extractive rather than coordinative?',
    'Quantitative sports science analysis measuring performance gaps between athletes with typical female biology and athletes with specific intersex variations (elevated testosterone, atypical muscle development, etc.). If the gap exceeds the variation within typical female populations by multiple standard deviations, accommodation transfers competitive advantage rather than merely recognizing biological diversity.',
    'This omega determines whether the elite-athlete victim group''s claims are about fairness (accommodation creates advantage) or discrimination (accommodation merely recognizes diversity). If performance-relevant intersex variations create advantage comparable to male physiology, the reading''s sports application is extractive. If advantage is within typical female variation, accommodation is genuinely coordinative.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(performance_advantage_threshold, empirical, 'Magnitude of performance advantage from accommodated intersex variations.').

omega_variable(
    category_stability_under_accommodation,
    'Can the category ''woman'' remain functionally stable and serve its coordination purposes (sex-segregated sports, sex-specific health screening, sex-disaggregated violence statistics) while accommodating all intersex variations, or does accommodation beyond a certain threshold dissolve the category''s boundary?',
    'Analysis of category coherence across institutional contexts: if accommodating all intersex variations preserves category function in most contexts but destabilizes it in a few high-stakes contexts (elite sports), the category is conditionally stable. If accommodation creates definitional collapse across multiple domains, the category cannot serve its original coordinating function under this reading.',
    'If accommodation dissolves category stability, this reading cannot replace sex_biology_reading without losing the coordination function sex categories provide. The reading would then be extractive by definition: it takes the legitimacy benefits of acknowledging biological complexity while destroying the coordination infrastructure. If stability is preserved, the reading is genuinely coordinative.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(category_stability_under_accommodation, conceptual, 'Whether accommodating intersex variations preserves or dissolves woman-category stability.').

omega_variable(
    committer_framing_underdetermination,
    'Is this reading genuinely a distinct position from sex_biology_reading, or is it sex_biology_reading with expanded definitional boundaries?',
    'Conceptual analysis of whether the reading''s core axiom (biological_sex_as_spectrum) constitutes a different framework or merely widens the existing binary framework''s inclusion criteria. If the reading still grounds membership in biological features (chromosomes, hormones, anatomy) rather than identity or social construction, it is structurally continuous with sex_biology_reading. If it treats ''spectrum'' as metaphysically distinct from ''expanded binary,'' the readings are genuinely different.',
    'If this reading is a variant of sex_biology_reading rather than a distinct reading, the kernel has two live readings (biology-based and identity-based) rather than three, and this constraint should be reframed as a modification of sex_biology_reading rather than an independent constraint. The network structure and axiom set would change accordingly.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(committer_framing_underdetermination, conceptual, 'Whether this reading is distinct from sex_biology_reading or a variant of it.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(woman_category__intersex_accommodation_reading, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(woma_tr_t0, woman_category__intersex_accommodation_reading, theater_ratio, 0, 0.15).
narrative_ontology:measurement(woma_tr_t5, woman_category__intersex_accommodation_reading, theater_ratio, 5, 0.18).
narrative_ontology:measurement(woma_tr_t10, woman_category__intersex_accommodation_reading, theater_ratio, 10, 0.21).
narrative_ontology:measurement(woma_tr_t15, woman_category__intersex_accommodation_reading, theater_ratio, 15, 0.24).
narrative_ontology:measurement(woma_tr_t20, woman_category__intersex_accommodation_reading, theater_ratio, 20, 0.26).
narrative_ontology:measurement(woma_tr_t25, woman_category__intersex_accommodation_reading, theater_ratio, 25, 0.28).

% Extraction over time
narrative_ontology:measurement(woma_be_t0, woman_category__intersex_accommodation_reading, base_extractiveness, 0, 0.42).
narrative_ontology:measurement(woma_be_t5, woman_category__intersex_accommodation_reading, base_extractiveness, 5, 0.48).
narrative_ontology:measurement(woma_be_t10, woman_category__intersex_accommodation_reading, base_extractiveness, 10, 0.54).
narrative_ontology:measurement(woma_be_t15, woman_category__intersex_accommodation_reading, base_extractiveness, 15, 0.6).
narrative_ontology:measurement(woma_be_t20, woman_category__intersex_accommodation_reading, base_extractiveness, 20, 0.65).
narrative_ontology:measurement(woma_be_t25, woman_category__intersex_accommodation_reading, base_extractiveness, 25, 0.68).

% Suppression requirement over time
narrative_ontology:measurement(woma_su_t0, woman_category__intersex_accommodation_reading, suppression_requirement, 0, 0.52).
narrative_ontology:measurement(woma_su_t5, woman_category__intersex_accommodation_reading, suppression_requirement, 5, 0.57).
narrative_ontology:measurement(woma_su_t10, woman_category__intersex_accommodation_reading, suppression_requirement, 10, 0.62).
narrative_ontology:measurement(woma_su_t15, woman_category__intersex_accommodation_reading, suppression_requirement, 15, 0.66).
narrative_ontology:measurement(woma_su_t20, woman_category__intersex_accommodation_reading, suppression_requirement, 20, 0.69).
narrative_ontology:measurement(woma_su_t25, woman_category__intersex_accommodation_reading, suppression_requirement, 25, 0.72).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(woman_category__intersex_accommodation_reading, identity_coordination).
narrative_ontology:boltzmann_floor_override(woman_category__intersex_accommodation_reading, 0.12).
narrative_ontology:affects_constraint(woman_category__intersex_accommodation_reading, woman_category__sex_biology_reading).
narrative_ontology:affects_constraint(woman_category__intersex_accommodation_reading, woman_category__gender_identity_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the woman_category kernel. The kernel decomposes into three structural claims with different ε values: sex_biology_reading (strict binary, high suppression of intersex people), gender_identity_reading (self-identification, high suppression of sex-based category functions), and this reading (biological spectrum, moderate extraction from athletes and selectively-excluded intersex people). The readings are linked because they compete for institutional adoption: each reading's success changes the legitimacy landscape for the others. All three readings acknowledge different subsets of the biological and social reality; none can satisfy all stakeholders simultaneously. The constraint family is the full set of three readings plus their network edges.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
