% ============================================================================
% CONSTRAINT STORY: acceptable_risk_energy__expected_value_dominant
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_acceptable_risk_energy__expected_value_dominant, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: acceptable_risk_energy__expected_value_dominant
 *   human_readable: Expected Value Dominant Acceptable Risk Framework for Energy Policy
 *   domain: risk_assessment/energy_policy/decision_theory
 *
 * SUMMARY:
 *   The expected-value-dominant reading of acceptable risk treats
 *   mortality-per-TWh as the canonical metric for energy pathway comparison.
 *   Catastrophic nuclear accidents are discounted by their low probability;
 *   fossil fuel deaths from air pollution and mining enter the victim set at
 *   full weight. This reading supports rapid fossil-to-nuclear transitions by
 *   making nuclear appear orders of magnitude safer in aggregate. The
 *   constraint is claimed as tangled_rope: genuine coordination function
 *   (commensurable risk metrics enable rational allocation) plus asymmetric
 *   extraction (the framework systematically suppresses concerns that don't
 *   reduce to expected mortality, benefiting actors whose risks are
 *   rare-but-catastrophic over actors whose risks are diffuse-but-ongoing).
 *
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(acceptable_risk_energy__expected_value_dominant, 0.68).
domain_priors:suppression_score(acceptable_risk_energy__expected_value_dominant, 0.81).
domain_priors:theater_ratio(acceptable_risk_energy__expected_value_dominant, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, extractiveness, 0.68).
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, suppression_requirement, 0.81).
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, accessibility_collapse, 0.71).
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, resistance, 0.74).

% --- Constraint claim ---
narrative_ontology:constraint_claim(acceptable_risk_energy__expected_value_dominant, tangled_rope).
narrative_ontology:human_readable(acceptable_risk_energy__expected_value_dominant, "Expected Value Dominant Acceptable Risk Framework for Energy Policy").
narrative_ontology:topic_domain(acceptable_risk_energy__expected_value_dominant, "risk_assessment/energy_policy/decision_theory").

domain_priors:requires_active_enforcement(acceptable_risk_energy__expected_value_dominant).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(acceptable_risk_energy__expected_value_dominant, '0a904828-32fe-48ec-9734-362c76e37f4f').
narrative_ontology:cs_kernel_codification('0a904828-32fe-48ec-9734-362c76e37f4f', formalized).
narrative_ontology:cs_authority_grounding('0a904828-32fe-48ec-9734-362c76e37f4f', expertise).
narrative_ontology:cs_interpretation_layer_present('0a904828-32fe-48ec-9734-362c76e37f4f').
narrative_ontology:cs_reading_relation('0a904828-32fe-48ec-9734-362c76e37f4f', acceptable_risk_energy__catastrophic_tail_dominant, coexists_with).
narrative_ontology:cs_reading_relation('0a904828-32fe-48ec-9734-362c76e37f4f', acceptable_risk_energy__option_value_preserving, influences).
narrative_ontology:cs_axiom('0a904828-32fe-48ec-9734-362c76e37f4f', foundational, probability_weighted_aggregation_sufficiency).
narrative_ontology:cs_axiom_status(probability_weighted_aggregation_sufficiency, holdable).
narrative_ontology:cs_axiom_grounding('0a904828-32fe-48ec-9734-362c76e37f4f', probability_weighted_aggregation_sufficiency, empirically_contingent).
narrative_ontology:cs_axiom('0a904828-32fe-48ec-9734-362c76e37f4f', secondary, catastrophic_potential_reducible_to_expected_value).
narrative_ontology:cs_axiom_status(catastrophic_potential_reducible_to_expected_value, holdable).
narrative_ontology:cs_axiom_grounding('0a904828-32fe-48ec-9734-362c76e37f4f', catastrophic_potential_reducible_to_expected_value, empirically_contingent).
narrative_ontology:cs_reference_frame('0a904828-32fe-48ec-9734-362c76e37f4f', post_chernobyl_probabilistic_safety_era).
narrative_ontology:cs_drift_state('0a904828-32fe-48ec-9734-362c76e37f4f', contemporary_fukushima_post, gap(axiom_overriding, substantial, false)).
narrative_ontology:cs_created_at('0a904828-32fe-48ec-9734-362c76e37f4f', '').
narrative_ontology:cs_kernel_id(acceptable_risk_energy__expected_value_dominant, acceptable_risk_energy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__expected_value_dominant, nuclear_energy_advocates).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__expected_value_dominant, climate_policy_institutions).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__expected_value_dominant, expected_utility_economists).
narrative_ontology:constraint_victim(acceptable_risk_energy__expected_value_dominant, fossil_fuel_adjacent_populations).
narrative_ontology:constraint_victim(acceptable_risk_energy__expected_value_dominant, communities_near_mines).
narrative_ontology:constraint_victim(acceptable_risk_energy__expected_value_dominant, climate_vulnerable_regions).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__expected_value_dominant, expected_utility_maximization).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__expected_value_dominant, aggregate_welfare_dominance).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Benefit structurally from a framework that discounts nuclear accident probability while counting fossil harm at full weight. The mortality-per-TWh metric makes nuclear appear cleanest by orders of magnitude, providing policy legitimacy and investment justification. Can shift to other technical arguments if this framing loses traction.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, nuclear_energy_advocates, beneficiary,
    organized, generational, mobile, global).

% Set the acceptable risk standard in energy transitions. Use mortality-per-TWh as the canonical metric in policy documents, grant criteria, and comparative assessments. Justify pathways by aggregate expected harm rather than distributional or tail concerns. Face pressure from multiple constituencies but control the framing apparatus.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, climate_policy_institutions, agenda_setter,
    institutional, generational, constrained, global).

% The framework vindicates their methodological commitments: probability-weighted aggregation, revealed preference, monetary valuation of statistical life. Their analytical toolkit becomes the policy standard. Can pivot to other applications if energy policy shifts away from this frame.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, expected_utility_economists, beneficiary,
    organized, biographical, mobile, global).

% Bear ongoing mortality from air pollution, mining accidents, and respiratory disease in coal regions. Under this framework their deaths are counted at full probability and enter the aggregate metric immediately, not discounted. Geographic and economic immobility keeps them adjacent to fossil infrastructure.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, fossil_fuel_adjacent_populations, payer,
    powerless, biographical, trapped, regional).

% Experience direct extraction harm: mine collapse risk, water contamination, respiratory illness from particulate exposure. The expected value framework counts these harms at full weight in the mortality tally, which makes fossil fuel look worse and alternative pathways more justified. Trapped by economic dependence and lack of relocation resources.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, communities_near_mines, payer,
    powerless, biographical, trapped, local).

% Bear climate harm from continued fossil reliance. Expected value aggregation assigns them significant weight in the harm tally, which supports rapid transition arguments. However, the framework's focus on mortality excludes non-fatal climate impacts and distributional injustice. Geographic immobility and lack of adaptive capacity.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, climate_vulnerable_regions, payer,
    powerless, generational, trapped, regional).

% Would object to discounting catastrophic tail risk by probability alone. Their potential for permanent displacement, multi-generational contamination, and total loss of place is compressed into a probability-weighted expected value that treats their concentrated catastrophic loss as equivalent to diffuse statistical harm. Not present in the rooms where mortality-per-TWh becomes policy standard.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, nuclear_accident_proximate_populations, excluded,
    powerless, generational, trapped, local).

% Document that public risk perception diverges systematically from expected utility: dread, control, voluntariness, and catastrophic potential matter independently of aggregate mortality. Provide evidence that the expected value frame suppresses these dimensions but do not set policy. Can study other risk domains if energy policy becomes unreceptive.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, risk_perception_researchers, observer,
    organized, biographical, analytical, global).

% Would argue that long-lived nuclear waste, facility decommissioning burdens, and irreversible contamination events impose costs on generations not present in current expected value calculations. The mortality-per-TWh metric is time-bounded and excludes multi-century stewardship obligations. Present in some forums but structurally weak against immediate aggregate metrics.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, intergenerational_advocates, excluded,
    moderate, civilizational, constrained, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a commensurable metric for comparing energy pathway risks: mortality-per-TWh allows regulators, utilities, and policy analysts to rank technologies on a single axis and justify transitions with quantified harm reduction.
% TRANSFER_FUNCTION: Moves policy legitimacy and investment flow from high mortality-per-TWh pathways (fossil) toward low mortality-per-TWh pathways (nuclear, renewables). Discounts catastrophic nuclear risk by probability, amplifying fossil harm by counting ongoing deaths at full weight.
% ABSENT_VOICES: Nuclear-accident-proximate populations and intergenerational advocates are structurally excluded. The former would contest probability-weighting of their catastrophic loss; the latter would contest time-bounding the metric to current mortality while ignoring multi-century waste burdens. Both are absent from the technical committees and economic models where mortality-per-TWh is standardized.
% DISAPPEARANCE_RATIONALE: If this framing vanished overnight, energy policy would lose its canonical commensurability metric. Debates would fragment into incommensurable concerns: some prioritizing aggregate expected harm, others catastrophic potential, others distributional justice, others intergenerational burdens. Investment justifications for nuclear expansion would lose their quantified superiority claim. The coalitions supporting rapid transitions would need new analytical foundations.
% FOUNDING_PROBLEM: Mid-20th-century energy policy faced growing fossil pollution evidence but lacked a standardized framework for comparing diverse harms across technologies. Mortality-per-TWh was developed to make coal deaths, nuclear accidents, and renewable risks commensurable for rational allocation.
% FOUNDING_PROBLEM_CORROBORATION: Energy economists and climate policy institutions attest the founding problem remains live: we still need commensurable metrics for technology comparison. Risk perception researchers and environmental justice advocates attest the founding problem has shifted: the real challenge is now distributional equity and tail risk management, not aggregate commensurability. Independent meta-analyses from outside the benefiting analytical communities document systematic public rejection of probability-weighted catastrophic risk, supporting the shifted-function reading.
narrative_ontology:disappearance_verdict(acceptable_risk_energy__expected_value_dominant, world_rearranges).
narrative_ontology:founding_problem_status(acceptable_risk_energy__expected_value_dominant, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(acceptable_risk_energy__expected_value_dominant, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(acceptable_risk_energy__expected_value_dominant, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(acceptable_risk_energy__expected_value_dominant_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(acceptable_risk_energy__expected_value_dominant, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(acceptable_risk_energy__expected_value_dominant_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is substantial (0.68 at interval end) because the metric's structure pre-determines outcomes: probability-weighting compresses catastrophic potential into expected value, which systematically favors technologies with rare-but-severe failure modes over technologies with frequent-but-moderate harms. Suppression is high (0.81) because maintaining the framework requires active exclusion of alternative risk framings: dread, voluntariness, reversibility, and distributional concerns must be labeled 'irrational' or 'psychological bias' to keep expected utility as the policy standard. Theater ratio is moderate (0.42): the coordination function is genuine—commensurability enables comparison—but a growing share of analytical effort defends the probability-weighting axiom against empirical evidence of its systematic divergence from public values. Accessibility collapse is substantial (0.71) because once mortality-per-TWh becomes the policy standard, alternative metrics lose funding and institutional footholds. Resistance is high (0.74) because excluded populations and risk perception researchers persistently contest the framework.
 *
 * PERSPECTIVAL GAP:
 *   From the beneficiary and agenda-setter seats, this is genuine technocratic coordination: a rational metric for comparing diverse harms. From the payer seats, the same structure operates as enforced extraction: their deaths are counted to justify transitions, but the framework that uses their mortality also suppresses the distributional and catastrophic concerns they would prioritize. From the excluded seats, probability-weighting is itself the extraction mechanism: it treats their concentrated catastrophic loss as equivalent to diffuse statistical harm, erasing what makes the risk unacceptable to them.
 *
 * DIRECTIONALITY LOGIC:
 *   Nuclear energy advocates and expected utility economists are structural beneficiaries: the framework vindicates their preferred pathways and methodological commitments. They are mobile—can shift to other arguments if this frame loses traction. Climate policy institutions are agenda-setters: they standardize the metric in grant criteria and comparative assessments, but face pressure from multiple constituencies. Fossil-adjacent populations, mining communities, and climate-vulnerable regions are the payers: their ongoing mortality enters the tally at full weight, which makes fossil fuels look worse and justifies rapid transitions, but the framework that counts their deaths also discounts the catastrophic risks they would fear most. They are trapped by geography and economics. Nuclear-accident-proximate populations and intergenerational advocates are excluded: their concerns (catastrophic potential, multi-century burdens) are structurally incommensurable with the expected value frame and are absent from the rooms where mortality-per-TWh becomes standard.
 *
 * MANDATROPHY ANALYSIS:
 *   The founding problem (lack of commensurable energy risk metrics) has been substantially solved: we have standardized mortality-per-TWh data across all major pathways. But the constraint persists with rising suppression because expected utility maximization has become institutionally entrenched as THE framework for acceptable risk, not merely A tool for one kind of comparison. The coordination function (enabling quantified comparison) remains live; the extraction (systematic suppression of non-expected-utility concerns) has accumulated as the framework's dominance grew.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    probability_weighting_legitimacy,
    'Is discounting catastrophic risk by probability a descriptively accurate representation of public values, or does it systematically suppress dimensions of risk (dread, irreversibility, voluntariness) that people treat as independently significant?',
    'Systematic meta-analysis of risk perception studies comparing revealed preferences to expected utility predictions; longitudinal surveys of populations near high-consequence facilities; natural experiments where communities choose between rare-catastrophic and frequent-moderate risks.',
    'If probability-weighting systematically diverges from public values, the framework''s claim to rational allocation is undermined and it is reclassified as an extractive expert imposition. If it aligns, the coordination claim is strengthened.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(probability_weighting_legitimacy, empirical, 'Whether expected utility probability-weighting matches public risk values.').

omega_variable(
    commensurability_vs_suppression,
    'Does the mortality-per-TWh metric enable rational comparison by making diverse harms commensurable, or does commensurability itself suppress incommensurable concerns (distributional justice, intergenerational burdens, option value) that should independently constrain policy?',
    'Conceptual analysis of what information is lost when catastrophic potential, geographic concentration, and multi-century stewardship obligations are compressed into a single expected mortality number. Policy case studies where mortality-per-TWh recommendations conflict with distributional equity or option value concerns.',
    'If commensurability is suppression, the coordination function is itself the extraction mechanism—the framework''s analytical power is what excludes the concerns of powerless seats. If commensurability is neutral aggregation, the extraction is only in the weight assigned to different harm types.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(commensurability_vs_suppression, conceptual, 'Whether commensurability enables or suppresses legitimate concerns.').

omega_variable(
    time_horizon_truncation,
    'Does mortality-per-TWh''s focus on operational-phase deaths systematically undercount long-duration harms (nuclear waste stewardship, decommissioning, irreversible contamination) that impose burdens on generations not present in current calculations?',
    'Multi-century cost accounting for nuclear facilities including waste storage, facility decommissioning, and contamination remediation. Comparison of intergenerational burden distribution across energy pathways when time horizon extends beyond current policy frames.',
    'If long-duration harms are systematically undercounted, the framework''s apparent favorability toward nuclear is an artifact of time-bounding the metric. If they are appropriately included, the metric is more robust than critics claim.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(time_horizon_truncation, empirical, 'Whether the metric time-bounds away intergenerational burdens.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(acceptable_risk_energy__expected_value_dominant, 0, 35).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(acce_tr_t0, acceptable_risk_energy__expected_value_dominant, theater_ratio, 0, 0.22).
narrative_ontology:measurement(acce_tr_t7, acceptable_risk_energy__expected_value_dominant, theater_ratio, 7, 0.26).
narrative_ontology:measurement(acce_tr_t14, acceptable_risk_energy__expected_value_dominant, theater_ratio, 14, 0.31).
narrative_ontology:measurement(acce_tr_t21, acceptable_risk_energy__expected_value_dominant, theater_ratio, 21, 0.36).
narrative_ontology:measurement(acce_tr_t28, acceptable_risk_energy__expected_value_dominant, theater_ratio, 28, 0.39).
narrative_ontology:measurement(acce_tr_t35, acceptable_risk_energy__expected_value_dominant, theater_ratio, 35, 0.42).

% Extraction over time
narrative_ontology:measurement(acce_be_t0, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 0, 0.48).
narrative_ontology:measurement(acce_be_t7, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 7, 0.53).
narrative_ontology:measurement(acce_be_t14, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 14, 0.58).
narrative_ontology:measurement(acce_be_t21, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 21, 0.63).
narrative_ontology:measurement(acce_be_t28, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 28, 0.66).
narrative_ontology:measurement(acce_be_t35, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 35, 0.68).

% Suppression requirement over time
narrative_ontology:measurement(acce_su_t0, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 0, 0.62).
narrative_ontology:measurement(acce_su_t7, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 7, 0.68).
narrative_ontology:measurement(acce_su_t14, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 14, 0.73).
narrative_ontology:measurement(acce_su_t21, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 21, 0.77).
narrative_ontology:measurement(acce_su_t28, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 28, 0.79).
narrative_ontology:measurement(acce_su_t35, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 35, 0.81).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:affects_constraint(acceptable_risk_energy__expected_value_dominant, acceptable_risk_energy__catastrophic_tail_dominant).
narrative_ontology:affects_constraint(acceptable_risk_energy__expected_value_dominant, acceptable_risk_energy__option_value_preserving).

% DUAL FORMULATION NOTE:
% This constraint is one of three readings of the acceptable_risk_energy kernel. All three share the same institutional domain (energy policy risk assessment) but differ fundamentally in ε: the expected_value_dominant reading treats catastrophic potential as probability-discounted and thus shows moderate-to-high extraction (systematically suppresses tail concerns); the catastrophic_tail_dominant reading refuses to discount catastrophic potential and shows lower extraction but higher accessibility collapse (tail-averse framing becomes inescapable once adopted); the option_value_preserving reading treats pathway diversity itself as a risk-mitigation good and shows low extraction but contested coordination (flexibility may preserve options or merely defer hard choices). Decomposed per ε-invariance principle: each reading instantiates a different constraint with its own stable ε, beneficiaries, and victim set.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
