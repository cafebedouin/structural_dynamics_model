% ============================================================================
% CONSTRAINT STORY: ai_governance_legitimacy__democratic_pluralist_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2024-01-15
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_ai_governance_legitimacy__democratic_pluralist_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: ai_governance_legitimacy__democratic_pluralist_reading
 *   human_readable: Democratic Pluralist AI Governance (Inclusive Deliberation Reading)
 *   domain: theological_ethics/technology_governance/political_theology
 *
 * SUMMARY:
 *   This constraint instantiates the democratic pluralist reading of AI
 *   governance legitimacy within a contested kernel. It grounds authority in
 *   inclusive deliberation, consent of the governed, and procedural fairness
 *   rather than in religious doctrine or technocratic expertise. The
 *   encyclical Antiqua Nova is treated as one contribution among many, not as
 *   uniquely authoritative. Civil society organizations and democratic
 *   institutions coordinate participatory infrastructure; minority rights
 *   holders benefit from structural protections against override; populations
 *   excluded from deliberation bear uncompensated costs. The constraint
 *   claims scaffold type because it builds transitional participatory
 *   capacity with an implicit sunset: as democratic institutions mature AI
 *   governance capability, the deliberative scaffolding should yield to
 *   normal legislative process.
 *
 * KEY AGENTS:
 *   - civil_society_organizations: Primary agenda-setters (organized/mobile) — convene and facilitate multi-stakeholder processes
 *   - democratic_institutions: Co-agenda-setters and beneficiaries (institutional/constrained) — translate deliberation into binding policy
 *   - minority_rights_holders: Primary beneficiaries (organized/constrained) — voices amplified by inclusion requirements
 *   - populations_under_authoritarian_regimes: Structural victims (powerless/trapped) — cannot access deliberative infrastructure
 *   - marginalized_communities_excluded_from_deliberation: Victims (powerless/trapped) — nominally included but lack resources to participate
 *   - catholic_magisterium: Excluded (institutional/mobile) — denied interpretive monopoly
 *   - technocratic_governance_bodies: Excluded (institutional/constrained) — expertise subordinated to democratic mandate
 *   - political_theology_scholars: Analytical observers (analytical/analytical) — assess competing legitimacy frameworks
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(ai_governance_legitimacy__democratic_pluralist_reading, 0.4).
domain_priors:suppression_score(ai_governance_legitimacy__democratic_pluralist_reading, 0.48).
domain_priors:theater_ratio(ai_governance_legitimacy__democratic_pluralist_reading, 0.3).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, extractiveness, 0.4).
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 0.48).
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 0.3).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, accessibility_collapse, 0.42).
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, resistance, 0.55).

% --- Constraint claim ---
narrative_ontology:constraint_claim(ai_governance_legitimacy__democratic_pluralist_reading, scaffold).
narrative_ontology:human_readable(ai_governance_legitimacy__democratic_pluralist_reading, "Democratic Pluralist AI Governance (Inclusive Deliberation Reading)").
narrative_ontology:topic_domain(ai_governance_legitimacy__democratic_pluralist_reading, "theological_ethics/technology_governance/political_theology").

domain_priors:requires_active_enforcement(ai_governance_legitimacy__democratic_pluralist_reading).
narrative_ontology:has_sunset_clause(ai_governance_legitimacy__democratic_pluralist_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(ai_governance_legitimacy__democratic_pluralist_reading, 'baccb3c1-5e07-4c88-aee6-5b7a67d46de2').
narrative_ontology:cs_kernel_codification('baccb3c1-5e07-4c88-aee6-5b7a67d46de2', distributed).
narrative_ontology:cs_authority_grounding('baccb3c1-5e07-4c88-aee6-5b7a67d46de2', distributed).
narrative_ontology:cs_reading_relation('baccb3c1-5e07-4c88-aee6-5b7a67d46de2', ai_governance_legitimacy__magisterial_subsidiarity_reading, coexists_with).
narrative_ontology:cs_reading_relation('baccb3c1-5e07-4c88-aee6-5b7a67d46de2', ai_governance_legitimacy__technocratic_optimization_reading, coexists_with).
narrative_ontology:cs_reading_relation('baccb3c1-5e07-4c88-aee6-5b7a67d46de2', ai_governance_legitimacy__market_libertarian_reading, influences).
narrative_ontology:cs_axiom('baccb3c1-5e07-4c88-aee6-5b7a67d46de2', foundational, legitimacy_derives_from_democratic_consent).
narrative_ontology:cs_axiom_status(legitimacy_derives_from_democratic_consent, holdable).
narrative_ontology:cs_axiom_grounding('baccb3c1-5e07-4c88-aee6-5b7a67d46de2', legitimacy_derives_from_democratic_consent, deontological).
narrative_ontology:cs_axiom('baccb3c1-5e07-4c88-aee6-5b7a67d46de2', foundational, no_tradition_holds_interpretive_monopoly).
narrative_ontology:cs_axiom_status(no_tradition_holds_interpretive_monopoly, holdable).
narrative_ontology:cs_axiom_grounding('baccb3c1-5e07-4c88-aee6-5b7a67d46de2', no_tradition_holds_interpretive_monopoly, conventional).
narrative_ontology:cs_axiom('baccb3c1-5e07-4c88-aee6-5b7a67d46de2', secondary, inclusive_deliberation_produces_legitimate_norms).
narrative_ontology:cs_axiom_status(inclusive_deliberation_produces_legitimate_norms, holdable).
narrative_ontology:cs_axiom_grounding('baccb3c1-5e07-4c88-aee6-5b7a67d46de2', inclusive_deliberation_produces_legitimate_norms, instrumental).
narrative_ontology:cs_reference_frame('baccb3c1-5e07-4c88-aee6-5b7a67d46de2', postwar_liberal_democratic_consensus).
narrative_ontology:cs_drift_state('baccb3c1-5e07-4c88-aee6-5b7a67d46de2', contemporary_ai_governance_crisis, gap(practice_drift, substantial, true)).
narrative_ontology:cs_created_at('baccb3c1-5e07-4c88-aee6-5b7a67d46de2', '').
narrative_ontology:cs_kernel_id(ai_governance_legitimacy__democratic_pluralist_reading, ai_governance_legitimacy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__democratic_pluralist_reading, civil_society_organizations).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__democratic_pluralist_reading, democratic_institutions).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__democratic_pluralist_reading, minority_rights_holders).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__democratic_pluralist_reading, independent_ethics_boards).
narrative_ontology:constraint_victim(ai_governance_legitimacy__democratic_pluralist_reading, populations_under_authoritarian_regimes).
narrative_ontology:constraint_victim(ai_governance_legitimacy__democratic_pluralist_reading, marginalized_communities_excluded_from_deliberation).
narrative_ontology:constraint_victim(ai_governance_legitimacy__democratic_pluralist_reading, low_capacity_stakeholders).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Convene and facilitate multi-stakeholder deliberative processes on AI ethics and governance. They mobilize diverse constituencies, translate technical questions into public discourse, and hold institutional actors accountable. Their legitimacy derives from representativeness and procedural fairness rather than epistemic authority.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, civil_society_organizations, agenda_setter,
    organized, generational, mobile, global).

% Legislatures, regulatory agencies, and courts that translate deliberative outcomes into binding policy. They gain legitimacy from electoral accountability and separation of powers. The constraint empowers them as arbiters of competing values rather than deferring to religious or technocratic monopolies.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, democratic_institutions, agenda_setter,
    institutional, generational, constrained, national).
narrative_ontology:stakeholder_secondary_role(ai_governance_legitimacy__democratic_pluralist_reading, democratic_institutions, beneficiary).

% Groups whose voices are structurally amplified by inclusive deliberation requirements: religious minorities, disability communities, indigenous populations, gender and sexual minorities. The constraint protects them from majoritarian or technocratic override by requiring their participation in governance design.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, minority_rights_holders, beneficiary,
    organized, biographical, constrained, global).

% Multi-stakeholder bodies that assess AI systems against human rights frameworks. The constraint legitimizes their pluralistic composition and denies any single tradition's claim to interpretive monopoly, enabling them to balance competing values through public reason.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, independent_ethics_boards, beneficiary,
    organized, biographical, mobile, global).

% Cannot access deliberative infrastructure the constraint presumes. They bear AI harms without participatory recourse because the constraint's enforcement depends on democratic institutions they lack. The framework names them as rights-holders but cannot reach them structurally.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, populations_under_authoritarian_regimes, payer,
    powerless, biographical, trapped, national).

% Groups nominally included in deliberative processes but lacking resources, literacy, or access to participate meaningfully: unhoused populations, undocumented workers, populations under surveillance. They carry AI governance costs without real voice despite the constraint's inclusion rhetoric.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, marginalized_communities_excluded_from_deliberation, payer,
    powerless, biographical, trapped, local).

% Small civil society groups, community organizations, and informal collectives invited to deliberative processes they cannot sustain participation in. Deliberation favors well-resourced actors; the constraint's extraction is the uncompensated time and expertise demanded from those with minimal organizational capacity.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, low_capacity_stakeholders, payer,
    moderate, immediate, constrained, regional).

% Claims authoritative interpretive role in AI ethics via natural law doctrine and papal teaching. The constraint admits the encyclical as one voice among many, denying its privileged status. The Magisterium remains structurally present but its authority claim is rejected by the framework's pluralistic design.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, catholic_magisterium, excluded,
    institutional, civilizational, mobile, global).

% International standard-setting bodies and expert committees that claim governance authority from technical competence rather than democratic mandate. The constraint subordinates their expertise to public deliberation, treating optimization as one value among many rather than the master criterion.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, technocratic_governance_bodies, excluded,
    institutional, biographical, constrained, global).

% Analyze how different traditions ground normative authority over technology. They document the structural competition between religious, democratic, and technocratic legitimacy claims and assess which populations are served or excluded by each reading.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, political_theology_scholars, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes participatory infrastructure for multi-stakeholder deliberation on AI governance: transparent processes, inclusive representation mechanisms, rights-based constraints on automation, and accountability structures. Solves the collective action problem of balancing competing values without defaulting to any single tradition's monopoly.
% TRANSFER_FUNCTION: Moves decision authority from religious and technocratic elites to representative democratic processes. Redistributes governance costs onto under-resourced participants who must engage in sustained deliberation without compensation. Transfers legitimacy from epistemic hierarchies to procedural fairness and consent.
% ABSENT_VOICES: Populations under authoritarian regimes who lack democratic infrastructure to access the deliberative framework. Marginalized communities too surveilled, precarious, or under-resourced to participate meaningfully despite nominal inclusion. Their exclusion is structural, not intentional, but systematic.
% DISAPPEARANCE_RATIONALE: If the constraint vanished, AI governance would default to existing power structures: technocratic optimization in liberal democracies, authoritarian control in non-democracies, market coordination in weak-state contexts. Civil society would lose structural leverage; minority protections would depend on majoritarian benevolence; the encyclical and other religious frameworks would compete directly for interpretive authority without the pluralistic mediation layer.
% FOUNDING_PROBLEM: No shared framework existed for adjudicating competing normative claims over AI development in pluralistic societies. Religious traditions claimed transcendent authority; technocratic bodies claimed epistemic authority; market actors claimed efficiency; democratic institutions lacked technical capacity. The collision produced governance deadlock and ad-hoc power grabs.
% FOUNDING_PROBLEM_CORROBORATION: Political theorists across traditions (Habermasian discourse ethics, Rawlsian public reason, deliberative democracy scholars) independently document the legitimacy crisis in technology governance. International organizations (UNESCO AI Ethics, Council of Europe AI framework) adopt multi-stakeholder deliberation as the least-contested mechanism. The founding problem's persistence is attested outside the direct beneficiary set.
narrative_ontology:disappearance_verdict(ai_governance_legitimacy__democratic_pluralist_reading, world_rearranges).
narrative_ontology:founding_problem_status(ai_governance_legitimacy__democratic_pluralist_reading, live).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(ai_governance_legitimacy__democratic_pluralist_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(ai_governance_legitimacy__democratic_pluralist_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(ai_governance_legitimacy__democratic_pluralist_reading_tests).
:- end_tests(ai_governance_legitimacy__democratic_pluralist_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is moderate (0.40) because deliberative processes impose real participation costs on under-resourced stakeholders and the framework systematically excludes populations without democratic infrastructure. This is not zero-sum rent extraction but structural asymmetry in who can afford sustained engagement. Suppression is moderate (0.48) because enforcement depends on electoral accountability and judicial review that many populations cannot access; the constraint functions where democratic institutions exist and fails where they don't. Theater ratio rises then stabilizes (peaks 0.32 at t=20) as initial genuine coordination is partially displaced by performative inclusion rituals that lack decision authority. Accessibility collapse is moderate-low (0.42) because alternative governance frameworks remain structurally available — religious traditions and technocratic bodies don't disappear, they're subordinated. Resistance is moderate-high (0.55) because excluded traditions (Magisterium, technocrats) actively contest the framework's legitimacy and marginalized populations resist uncompensated participation demands.
 *
 * PERSPECTIVAL GAP:
 *   From the civil society and democratic institution seats, the constraint is genuine coordination scaffolding that solves a real legitimacy crisis through inclusive process. From the powerless/trapped victim seats (authoritarian populations, marginalized communities), the same structure operates as extraction: it demands participation resources they lack and excludes them from governance benefits. From the excluded institutional seats (Magisterium, technocrats), it appears as illegitimate power redistribution that subordinates truth claims to procedural majoritarianism. The engine computes these divergent per-seat types from the structural data; the claimed scaffold type represents the coordinating actors' framing, not adjudication of the contest.
 *
 * DIRECTIONALITY LOGIC:
 *   Civil society organizations and democratic institutions are primary beneficiaries: the framework empowers their coordinating role and denies competitors' monopoly claims (d near beneficiary end). Minority rights holders benefit from structural voice amplification (d near beneficiary end). Populations under authoritarian regimes and marginalized communities excluded from deliberation are structural targets: they bear governance costs without access to the participatory mechanisms the constraint presumes (d near target end, high chi). The catholic_magisterium and technocratic_governance_bodies are excluded rather than targeted — their authority claims are rejected but they're not coerced to participate.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint resolves potential mandatrophy by explicitly claiming scaffold with sunset clause: it builds transitional participatory infrastructure meant to yield to mature democratic AI governance capacity, not to persist indefinitely. The founding problem (legitimacy deadlock across competing normative frameworks) remains live and corroborated outside the beneficiary set. The extraction measured is structural cost asymmetry in deliberative access, not zombie rent-seeking. If founding_problem_status shifts to 'dead' while the constraint persists, that signals capture.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    deliberative_capacity_asymmetry,
    'Does inclusive deliberation structurally favor well-resourced actors despite procedural fairness commitments, or can deliberative infrastructure genuinely equalize voice across capacity gradients?',
    'Longitudinal tracking of deliberative outcomes by participant resource level. If under-resourced stakeholders'' positions systematically lose despite procedural inclusion, the constraint''s coordination claim weakens toward extraction.',
    'If deliberation systematically favors the well-resourced, measured extractiveness should rise and the scaffold should reclassify toward tangled_rope (coordination that extracts from those it coordinates). If capacity can be equalized through design, the scaffold claim holds.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(deliberative_capacity_asymmetry, empirical, 'Whether deliberative infrastructure can equalize voice across resource asymmetry or structurally reproduces existing power').

omega_variable(
    authoritarian_regime_exclusion,
    'Is the constraint''s failure to reach populations under authoritarian regimes a fixable implementation gap or a structural limitation of democratic pluralist governance?',
    'Assess whether alternative governance frameworks (e.g., international human rights enforcement, civil society networks in closed societies) can extend protections the constraint cannot reach. If unreachable populations grow, the victim set expands.',
    'If structurally unfixable, the constraint''s extractiveness rises as the excluded population grows. If bridgeable through design, the scaffold''s coordination function extends and extractiveness stabilizes or falls.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(authoritarian_regime_exclusion, conceptual, 'Whether democratic deliberation can structurally reach non-democratic contexts or systematically excludes them').

omega_variable(
    committer_frame_kernel_contest,
    'Is the democratic_pluralist_reading the uniquely legitimate framework for AI governance, or is it one contestable reading among siblings that each ground legitimacy differently?',
    'This is the kernel itself: no resolution mechanism exists within any single reading. The contest is adjudicated through actual governance adoption, institutional survival, and which populations'' interests are structurally served.',
    'This reading claims no interpretive monopoly by design. The magisterial_subsidiarity_reading claims the Magisterium holds unique authority; the technocratic_optimization_reading claims expertise does; the market_libertarian_reading claims voluntary exchange does. Each reading''s ε, beneficiary structure, and enforcement differ. The omega documents that this constraint is one reading, not the kernel itself.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(committer_frame_kernel_contest, conceptual, 'Kernel contest: this is one reading of ai_governance_legitimacy, contested by siblings with different authority grounds').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(ai_governance_legitimacy__democratic_pluralist_reading, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(ai_g_tr_t0, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 0, 0.18).
narrative_ontology:measurement(ai_g_tr_t5, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 5, 0.22).
narrative_ontology:measurement(ai_g_tr_t10, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 10, 0.26).
narrative_ontology:measurement(ai_g_tr_t15, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 15, 0.3).
narrative_ontology:measurement(ai_g_tr_t20, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 20, 0.32).
narrative_ontology:measurement(ai_g_tr_t25, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 25, 0.3).

% Extraction over time
narrative_ontology:measurement(ai_g_be_t0, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 0, 0.32).
narrative_ontology:measurement(ai_g_be_t5, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 5, 0.35).
narrative_ontology:measurement(ai_g_be_t10, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 10, 0.38).
narrative_ontology:measurement(ai_g_be_t15, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 15, 0.4).
narrative_ontology:measurement(ai_g_be_t20, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 20, 0.42).
narrative_ontology:measurement(ai_g_be_t25, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 25, 0.4).

% Suppression requirement over time
narrative_ontology:measurement(ai_g_su_t0, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 0, 0.4).
narrative_ontology:measurement(ai_g_su_t5, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 5, 0.43).
narrative_ontology:measurement(ai_g_su_t10, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 10, 0.46).
narrative_ontology:measurement(ai_g_su_t15, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 15, 0.48).
narrative_ontology:measurement(ai_g_su_t20, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 20, 0.5).
narrative_ontology:measurement(ai_g_su_t25, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 25, 0.48).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(ai_governance_legitimacy__democratic_pluralist_reading, identity_coordination).
narrative_ontology:affects_constraint(ai_governance_legitimacy__democratic_pluralist_reading, ai_governance_legitimacy__magisterial_subsidiarity_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__democratic_pluralist_reading, ai_governance_legitimacy__technocratic_optimization_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__democratic_pluralist_reading, ai_governance_legitimacy__market_libertarian_reading).

% DUAL FORMULATION NOTE:
% This constraint is one of four readings decomposing the ai_governance_legitimacy kernel. Each reading has distinct ε, distinct beneficiary/victim structure, distinct enforcement. The democratic_pluralist_reading (this constraint) denies interpretive monopoly and builds participatory infrastructure. The magisterial_subsidiarity_reading claims Catholic Social Doctrine as uniquely authoritative. The technocratic_optimization_reading subordinates ethics to aggregate welfare maximization. The market_libertarian_reading grounds legitimacy in voluntary exchange and exit. All four affect each other via institutional competition and resource allocation.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
