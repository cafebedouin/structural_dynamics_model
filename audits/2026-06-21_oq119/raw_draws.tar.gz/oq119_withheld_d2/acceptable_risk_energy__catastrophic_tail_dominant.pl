% ============================================================================
% CONSTRAINT STORY: acceptable_risk_energy__catastrophic_tail_dominant
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2025-01-01
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_acceptable_risk_energy__catastrophic_tail_dominant, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: acceptable_risk_energy__catastrophic_tail_dominant
 *   human_readable: Catastrophic-Tail-Dominant Acceptable Risk (Energy Policy)
 *   domain: risk_assessment/energy_policy/decision_theory
 *
 * SUMMARY:
 *   Energy policy frameworks operationalize 'acceptable risk' by weighting
 *   different harm profiles. This constraint instantiates one contested
 *   reading: that low-probability catastrophic outcomes (nuclear accidents)
 *   warrant infinite or lexically prior weight even when alternative pathways
 *   (fossil generation) produce higher expected aggregate mortality. The
 *   reading emerged from post-Chernobyl public dread and is maintained
 *   through regulatory licensing that treats nuclear risk as categorically
 *   inadmissible while accepting distributed fossil mortality as background.
 *   The constraint is CLAIMED as tangled_rope (genuine coordination problem
 *   around uncertainty, but asymmetric extraction) while metrics describe
 *   substantial and rising extractiveness — the engine measures that
 *   divergence.
 *
 * KEY AGENTS:
 *   - fossil_fuel_industry: Primary beneficiary (institutional/constrained) — gains market share from nuclear suppression without setting the framework directly
 *   - anti_nuclear_advocacy_groups: Agenda-setter (organized/mobile) — embed catastrophic-tail priority into public discourse and regulation
 *   - regulatory_bodies_risk_averse: Agenda-setter + beneficiary (institutional/identity_locked) — operationalize the framework; institutional identity fused with preventing dread scenario
 *   - distributed_fossil_mortality_victims: Payer (powerless/trapped) — bear continuous health burden discounted as acceptable background
 *   - climate_vulnerable_populations: Payer (powerless/trapped) — carry tail risk of climate destabilization from extended fossil dependence
 *   - nuclear_industry_operators: Payer (powerful/constrained) — face asymmetric regulatory burden suppressing deployment
 *   - expected_value_advocates: Excluded (organized/mobile) — mortality-per-TWh framing inadmissible under this reading
 *   - energy_economists: Observer (analytical/analytical) — document the extraction and framework asymmetry
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(acceptable_risk_energy__catastrophic_tail_dominant, 0.68).
domain_priors:suppression_score(acceptable_risk_energy__catastrophic_tail_dominant, 0.79).
domain_priors:theater_ratio(acceptable_risk_energy__catastrophic_tail_dominant, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, extractiveness, 0.68).
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 0.79).
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, accessibility_collapse, 0.52).
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, resistance, 0.71).

% --- Constraint claim ---
narrative_ontology:constraint_claim(acceptable_risk_energy__catastrophic_tail_dominant, tangled_rope).
narrative_ontology:human_readable(acceptable_risk_energy__catastrophic_tail_dominant, "Catastrophic-Tail-Dominant Acceptable Risk (Energy Policy)").
narrative_ontology:topic_domain(acceptable_risk_energy__catastrophic_tail_dominant, "risk_assessment/energy_policy/decision_theory").

domain_priors:requires_active_enforcement(acceptable_risk_energy__catastrophic_tail_dominant).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(acceptable_risk_energy__catastrophic_tail_dominant, '2ce27e77-4a77-4639-9a46-7e3ef8aeacc3').
narrative_ontology:cs_kernel_codification('2ce27e77-4a77-4639-9a46-7e3ef8aeacc3', distributed).
narrative_ontology:cs_authority_grounding('2ce27e77-4a77-4639-9a46-7e3ef8aeacc3', distributed).
narrative_ontology:cs_reading_relation('2ce27e77-4a77-4639-9a46-7e3ef8aeacc3', acceptable_risk_energy__expected_value_dominant, coexists_with).
narrative_ontology:cs_reading_relation('2ce27e77-4a77-4639-9a46-7e3ef8aeacc3', acceptable_risk_energy__option_value_preserving, coexists_with).
narrative_ontology:cs_axiom('2ce27e77-4a77-4639-9a46-7e3ef8aeacc3', foundational, catastrophic_outcomes_lexically_prior).
narrative_ontology:cs_axiom_status(catastrophic_outcomes_lexically_prior, holdable).
narrative_ontology:cs_axiom_grounding('2ce27e77-4a77-4639-9a46-7e3ef8aeacc3', catastrophic_outcomes_lexically_prior, deontological).
narrative_ontology:cs_axiom('2ce27e77-4a77-4639-9a46-7e3ef8aeacc3', secondary, distributed_mortality_discountable_as_background).
narrative_ontology:cs_axiom_status(distributed_mortality_discountable_as_background, holdable).
narrative_ontology:cs_axiom_grounding('2ce27e77-4a77-4639-9a46-7e3ef8aeacc3', distributed_mortality_discountable_as_background, conventional).
narrative_ontology:cs_reference_frame('2ce27e77-4a77-4639-9a46-7e3ef8aeacc3', post_chernobyl_public_trust_mandate).
narrative_ontology:cs_drift_state('2ce27e77-4a77-4639-9a46-7e3ef8aeacc3', contemporary_climate_urgency_era, gap(axiom_overriding, substantial, false)).
narrative_ontology:cs_created_at('2ce27e77-4a77-4639-9a46-7e3ef8aeacc3', '').
narrative_ontology:cs_kernel_id(acceptable_risk_energy__catastrophic_tail_dominant, acceptable_risk_energy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__catastrophic_tail_dominant, fossil_fuel_industry).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__catastrophic_tail_dominant, anti_nuclear_advocacy_groups).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__catastrophic_tail_dominant, regulatory_bodies_risk_averse).
narrative_ontology:constraint_victim(acceptable_risk_energy__catastrophic_tail_dominant, distributed_fossil_mortality_victims).
narrative_ontology:constraint_victim(acceptable_risk_energy__catastrophic_tail_dominant, climate_vulnerable_populations).
narrative_ontology:constraint_victim(acceptable_risk_energy__catastrophic_tail_dominant, nuclear_industry_operators).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__catastrophic_tail_dominant, catastrophic_risk_lexical_priority).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__catastrophic_tail_dominant, precautionary_principle_energy).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Benefits from regulatory framework that treats distributed mortality (air pollution, extraction accidents) as acceptable background risk while elevating catastrophic nuclear scenarios to inadmissible status. This asymmetry preserves market share by keeping nuclear suppressed despite higher aggregate mortality from fossil generation. Does not directly set the risk framework but profits from its operation.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, fossil_fuel_industry, beneficiary,
    institutional, biographical, constrained, global).

% Set the acceptable risk discourse through activism, litigation, and public campaigns emphasizing vivid catastrophic scenarios (Chernobyl, Fukushima) while backgrounding distributed harms. Frame nuclear accidents as categorically different from fossil mortality due to involuntariness, dread, and irreversibility. Their success in embedding this frame into regulation is the constraint's enforcement mechanism.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, anti_nuclear_advocacy_groups, agenda_setter,
    organized, generational, mobile, national).

% Administer licensing and safety standards that operationalize catastrophic-risk priority. Their institutional mandate is defined by preventing high-visibility failures; a coal plant mortality spike is distributed across time and space and does not threaten the regulator's legitimacy, but a reactor incident concentrates blame. Identity-locked because the regulatory body's professional identity is fused with preventing the dread scenario, making expected-value reframing existentially threatening to the institution.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, regulatory_bodies_risk_averse, agenda_setter,
    institutional, biographical, identity_locked, national).
narrative_ontology:stakeholder_secondary_role(acceptable_risk_energy__catastrophic_tail_dominant, regulatory_bodies_risk_averse, beneficiary).

% Bear the health burden of particulate emissions, extraction-site pollution, and climate-intensified disasters. These harms accumulate continuously but diffusely, rendering them statistically visible but politically inert under a framework that discounts distributed risk. Trapped because the energy system they depend on is the source of harm, and the risk framework treats their mortality as the acceptable baseline.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, distributed_fossil_mortality_victims, payer,
    powerless, immediate, trapped, local).

% Carry the tail risk of climate destabilization driven by continued fossil reliance. The framework's suppression of low-carbon nuclear pathways extends fossil dependence and locks in emissions trajectories that concentrate harm on populations least responsible for emissions and least able to adapt. The catastrophic-tail framing paradoxically increases their exposure to a different catastrophic tail (climate tipping points).
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, climate_vulnerable_populations, payer,
    powerless, generational, trapped, global).

% Face asymmetric regulatory burdens, extended licensing timelines, and capital costs inflated by the catastrophic-tail framework's demand for defense-in-depth against arbitrarily low-probability scenarios. The framework treats nuclear risk as inadmissible while accepting higher aggregate mortality from alternatives, which suppresses nuclear deployment even where it would reduce total harm. Constrained exit because pivoting to other sectors means abandoning decades of capital and expertise.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, nuclear_industry_operators, payer,
    powerful, generational, constrained, global).

% Argue from mortality-per-TWh metrics that nuclear has lower expected harm than fossil alternatives. Their framing is excluded from the regulatory consensus because the catastrophic-tail reading treats concentration of harm as categorically different from dispersion, making aggregate comparisons inadmissible. They publish analyses, testify, and advocate for framework revision but remain outside the decision structure.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, expected_value_advocates, excluded,
    organized, generational, mobile, global).

% Model trade-offs between energy pathways using expected-value, option-value, and tail-risk frameworks. Observe that the catastrophic-tail-dominant reading produces higher aggregate mortality than alternatives it suppresses, and that the framework's asymmetry (infinite weight on nuclear accidents, finite weight on fossil mortality) cannot be justified within a single coherent risk metric. Document the extraction and its beneficiaries without adjudicating which reading is correct.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, energy_economists, observer,
    analytical, biographical, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Solves a genuine decision problem under uncertainty: how to weigh low-probability catastrophic outcomes against higher-probability distributed harms when consequences differ in kind (concentrated vs. diffuse, voluntary vs. involuntary, reversible vs. irreversible).
% TRANSFER_FUNCTION: Moves regulatory approval, capital investment, and social license from low-aggregate-harm but high-dread pathways (nuclear) to high-aggregate-harm but low-dread pathways (fossil), effectively transferring mortality risk from potential nuclear-accident victims to actual distributed fossil-mortality victims. Also transfers economic rents to incumbent fossil industry by suppressing competitive nuclear deployment.
% ABSENT_VOICES: Future generations bearing climate risk, distributed mortality victims whose harms are backgrounded, and expected-value advocates whose framework is excluded from the regulatory consensus. They are kept out because their presence would force explicit justification of the asymmetric weighting that sustains the constraint.
% DISAPPEARANCE_RATIONALE: If the catastrophic-tail-dominant framing vanished overnight and regulators weighted risks by expected aggregate mortality, nuclear licensing would accelerate, fossil generation would face stricter air-quality and climate accounting, energy system composition would shift toward lower-mortality pathways, and both anti-nuclear advocacy and fossil-industry revenue streams would erode. The constraint structures the entire energy policy landscape.
% FOUNDING_PROBLEM: Early nuclear regulation responded to public dread following Chernobyl and Three Mile Island by embedding catastrophic-risk avoidance into licensing frameworks, treating reactor accidents as qualitatively inadmissible regardless of probability or aggregate harm comparison.
% FOUNDING_PROBLEM_CORROBORATION: Regulatory bodies and anti-nuclear advocates attest the founding problem (public trust, catastrophic-risk salience) remains live and justifies continued framework. Energy economists, climate scientists, and expected-value advocates outside the benefiting coalitions attest the founding problem has shifted: modern reactor designs, probabilistic risk assessment, and climate urgency change the decision context, but the framework persists because it protects institutional and economic interests rather than because the original risk profile remains.
narrative_ontology:disappearance_verdict(acceptable_risk_energy__catastrophic_tail_dominant, world_rearranges).
narrative_ontology:founding_problem_status(acceptable_risk_energy__catastrophic_tail_dominant, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(acceptable_risk_energy__catastrophic_tail_dominant, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(acceptable_risk_energy__catastrophic_tail_dominant, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(acceptable_risk_energy__catastrophic_tail_dominant_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(acceptable_risk_energy__catastrophic_tail_dominant, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(acceptable_risk_energy__catastrophic_tail_dominant_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is substantial (0.68 at interval end) because the framework produces higher aggregate mortality than suppressed alternatives, transferring risk from potential concentrated victims to actual distributed victims while protecting fossil-industry rents. Suppression is high (0.79) because maintaining the framework requires active exclusion of expected-value and option-value framings from regulatory consensus. Theater ratio is moderate (0.42): the catastrophic-risk concern is genuine, but rising share of activity defends the asymmetric weighting itself rather than minimizing total harm. Accessibility collapse is moderate (0.52) because alternative risk frameworks remain intellectually available even as they are excluded from policy; resistance is high (0.71) from nuclear industry, climate advocates, and expected-value economists whose framings are suppressed. The measurement grid is aligned — every metric is authored at every examined time point.
 *
 * PERSPECTIVAL GAP:
 *   From the agenda-setter and regulatory seats, this reading solves a genuine coordination problem (how to maintain public trust and prevent dread outcomes under deep uncertainty). From the payer seats (distributed victims, climate-vulnerable populations), the same structure operates as enforced extraction that produces higher mortality than suppressed alternatives. From the excluded seat (expected-value advocates), the framework is incoherent asymmetry maintained by suppression. The engine computes these divergences from the structural data; the authored claim (tangled_rope) does not adjudicate them.
 *
 * DIRECTIONALITY LOGIC:
 *   Agenda-setters (anti-nuclear advocacy, risk-averse regulators) are structural beneficiaries in different ways: advocacy groups gain influence and funding by maintaining salience of the dread scenario; regulators' institutional identity is stabilized by the framework that treats their mandate as preventing the inadmissible outcome. Fossil industry is beneficiary without agenda-setting (collects rents from nuclear suppression but does not directly control the risk discourse). Distributed mortality victims and climate-vulnerable populations are full targets (bear extraction, trapped exit). Nuclear operators are targets with constrained rather than trapped exit (can pivot but at high cost). Expected-value advocates are excluded rather than targeted — their framework is kept out of the decision structure.
 *
 * MANDATROPHY ANALYSIS:
 *   The founding problem (post-accident public trust, catastrophic-risk salience) has materially shifted: reactor designs have changed, probabilistic risk assessment has advanced, and climate urgency alters the decision context. But the framework persists because it protects institutional identity (regulators), revenue streams (fossil industry), and advocacy-group influence (anti-nuclear coalitions). The mandatrophy signature is the (founding_problem_status=contested + disappearance_verdict=world_rearranges) mismatch: the problem the framework was built for is disputed as live, yet its disappearance would reorganize the energy landscape, indicating the framework now serves the beneficiaries rather than the founding function. Rising theater_ratio and extractiveness over the interval support this reading: coordination costs stay bounded while extraction and performative justification accumulate.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    harm_commensurability,
    'Are concentrated catastrophic harms and distributed continuous harms commensurable within a single risk metric, or does their qualitative difference (involuntary vs. voluntary, dread vs. familiar, irreversible vs. chronic) justify lexical priority for catastrophic tails?',
    'Philosophical and empirical work on risk perception, moral weights for different harm profiles, and whether stated-preference data on dread vs. statistical harm reflect coherent values or framing effects. No purely empirical resolution — requires normative judgment about which risk intuitions to privilege.',
    'If harms are commensurable, the framework''s asymmetric weighting is extraction (produces higher mortality to avoid lower-probability dread). If incommensurable, asymmetric weighting is justified coordination around genuine values conflict, and measured extraction reflects the price of honoring lexical priority.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(harm_commensurability, conceptual, 'Whether catastrophic and distributed harms are commensurable in a single risk metric.').

omega_variable(
    institutional_identity_lock,
    'Is regulatory identity-lock (regulators'' professional self-concept fused with preventing dread scenarios) a structural feature necessary for the framework''s function, or is it a captured preference that could be revised without loss of coordination?',
    'Natural experiment from jurisdictions where regulatory mandate shifted to expected-value or climate-risk priority: if trust and safety outcomes hold under reframing, identity-lock is separable capture; if outcomes degrade, it is structural to the coordination function.',
    'If identity-lock is separable, it is a source of extraction (keeps framework rigid beyond functional necessity). If inseparable, it is the price of maintaining regulator legitimacy under public dread, and reframing risks trust collapse.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(institutional_identity_lock, empirical, 'Whether regulatory identity-lock with dread-prevention is structural or separable capture.').

omega_variable(
    sibling_reading_displacement,
    'Does adoption of this reading (catastrophic-tail-dominant) in one jurisdiction structurally displace expected-value or option-value readings in neighboring jurisdictions through legitimacy contagion, or do the readings remain independent choices?',
    'Cross-jurisdictional analysis of regulatory framework diffusion: if catastrophic-tail adoption in one polity predicts adoption elsewhere independent of local risk conditions, readings are coupled through legitimacy rather than independent; if adoption tracks local conditions, readings are structurally independent.',
    'If coupled, this reading exerts extractive pressure beyond its direct jurisdiction by foreclosing sibling readings elsewhere. If independent, extraction is contained within adopting jurisdictions and other readings remain available as alternatives.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(sibling_reading_displacement, empirical, 'Whether this reading structurally displaces sibling readings in other jurisdictions.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(acceptable_risk_energy__catastrophic_tail_dominant, 0, 40).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(acce_tr_t0, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 0, 0.25).
narrative_ontology:measurement_basis(acce_tr_t0, observed).
narrative_ontology:measurement(acce_tr_t8, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 8, 0.29).
narrative_ontology:measurement_basis(acce_tr_t8, observed).
narrative_ontology:measurement(acce_tr_t16, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 16, 0.33).
narrative_ontology:measurement_basis(acce_tr_t16, observed).
narrative_ontology:measurement(acce_tr_t24, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 24, 0.37).
narrative_ontology:measurement_basis(acce_tr_t24, observed).
narrative_ontology:measurement(acce_tr_t32, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 32, 0.4).
narrative_ontology:measurement_basis(acce_tr_t32, observed).
narrative_ontology:measurement(acce_tr_t40, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 40, 0.42).
narrative_ontology:measurement_basis(acce_tr_t40, observed).

% Extraction over time
narrative_ontology:measurement(acce_be_t0, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 0, 0.48).
narrative_ontology:measurement_basis(acce_be_t0, observed).
narrative_ontology:measurement(acce_be_t8, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 8, 0.54).
narrative_ontology:measurement_basis(acce_be_t8, observed).
narrative_ontology:measurement(acce_be_t16, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 16, 0.59).
narrative_ontology:measurement_basis(acce_be_t16, observed).
narrative_ontology:measurement(acce_be_t24, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 24, 0.63).
narrative_ontology:measurement_basis(acce_be_t24, observed).
narrative_ontology:measurement(acce_be_t32, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 32, 0.66).
narrative_ontology:measurement_basis(acce_be_t32, observed).
narrative_ontology:measurement(acce_be_t40, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 40, 0.68).
narrative_ontology:measurement_basis(acce_be_t40, observed).

% Suppression requirement over time
narrative_ontology:measurement(acce_su_t0, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 0, 0.62).
narrative_ontology:measurement_basis(acce_su_t0, observed).
narrative_ontology:measurement(acce_su_t8, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 8, 0.67).
narrative_ontology:measurement_basis(acce_su_t8, observed).
narrative_ontology:measurement(acce_su_t16, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 16, 0.71).
narrative_ontology:measurement_basis(acce_su_t16, observed).
narrative_ontology:measurement(acce_su_t24, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 24, 0.74).
narrative_ontology:measurement_basis(acce_su_t24, observed).
narrative_ontology:measurement(acce_su_t32, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 32, 0.77).
narrative_ontology:measurement_basis(acce_su_t32, observed).
narrative_ontology:measurement(acce_su_t40, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 40, 0.79).
narrative_ontology:measurement_basis(acce_su_t40, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(acceptable_risk_energy__catastrophic_tail_dominant, resource_allocation).
narrative_ontology:affects_constraint(acceptable_risk_energy__catastrophic_tail_dominant, acceptable_risk_energy__expected_value_dominant).
narrative_ontology:affects_constraint(acceptable_risk_energy__catastrophic_tail_dominant, acceptable_risk_energy__option_value_preserving).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the acceptable_risk_energy kernel. The catastrophic_tail_dominant reading treats nuclear risk as lexically prior; expected_value_dominant minimizes aggregate mortality; option_value_preserving maintains pathway flexibility. ε differs across readings because they produce different mortality distributions and suppress different alternatives. All three readings are linked as a constraint family decomposing the single colloquial concept 'acceptable risk in energy policy' into structurally distinct claims.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
