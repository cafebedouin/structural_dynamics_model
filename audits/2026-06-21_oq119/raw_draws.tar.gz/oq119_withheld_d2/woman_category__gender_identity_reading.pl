% ============================================================================
% CONSTRAINT STORY: woman_category__gender_identity_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2025-01-01
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_woman_category__gender_identity_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: woman_category__gender_identity_reading
 *   human_readable: Woman Category Membership via Gender Identity
 *   domain: political_philosophy/law/social_policy/bioethics
 *
 * SUMMARY:
 *   The gender-identity reading of 'woman' defines category membership by
 *   self-identified gender rather than biological sex, making 'woman' =
 *   'anyone who identifies as a woman' regardless of chromosomes, anatomy, or
 *   reproductive biology. This reading emerged from transgender rights
 *   advocacy and has been institutionalized in identity documents,
 *   anti-discrimination law, and facility access policies across multiple
 *   jurisdictions. It solves a genuine coordination problem—how to legally
 *   recognize transgender people—but generates extraction where it overrides
 *   sex-based protections and creates rights collisions in sports and
 *   sex-segregated spaces. The claim/metric gap is deliberate: claimed as
 *   tangled_rope (coordination + extraction), with metrics authored to
 *   describe the substantial and rising extractiveness the constraint imposes
 *   on women seeking sex-based accommodations.
 *
 * KEY AGENTS:
 *   - transgender_women: Primary beneficiary (moderate/identity_locked) — gain legal recognition and facility access through self-identification
 *   - gender_identity_advocacy_organizations: Agenda setter (organized/mobile) — coordinate legal strategy and institutional capture of definitional apparatus
 *   - women_seeking_sex_based_protections: Payer (organized/constrained) — lose sex-based accommodations reframed as discriminatory
 *   - female_athletes_in_sex_segregated_sports: Payer (moderate/constrained) — lose competitive opportunities under redefined fairness criteria
 *   - survivors_in_sex_segregated_spaces: Payer (powerless/trapped) — experience diminished safety in trauma recovery spaces
 *   - feminist_legal_theorists: Observer (analytical/analytical) — examine whether reading advances or undermines sex-based equality
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(woman_category__gender_identity_reading, 0.68).
domain_priors:suppression_score(woman_category__gender_identity_reading, 0.72).
domain_priors:theater_ratio(woman_category__gender_identity_reading, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, extractiveness, 0.68).
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, suppression_requirement, 0.72).
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, resistance, 0.81).

% --- Constraint claim ---
narrative_ontology:constraint_claim(woman_category__gender_identity_reading, tangled_rope).
narrative_ontology:human_readable(woman_category__gender_identity_reading, "Woman Category Membership via Gender Identity").
narrative_ontology:topic_domain(woman_category__gender_identity_reading, "political_philosophy/law/social_policy/bioethics").

domain_priors:requires_active_enforcement(woman_category__gender_identity_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(woman_category__gender_identity_reading, '64cc1f65-a113-4bc1-b0b4-9ee648576816').
narrative_ontology:cs_kernel_codification('64cc1f65-a113-4bc1-b0b4-9ee648576816', distributed).
narrative_ontology:cs_authority_grounding('64cc1f65-a113-4bc1-b0b4-9ee648576816', distributed).
narrative_ontology:cs_reading_relation('64cc1f65-a113-4bc1-b0b4-9ee648576816', woman_category__sex_biology_reading, forecloses).
narrative_ontology:cs_reading_relation('64cc1f65-a113-4bc1-b0b4-9ee648576816', woman_category__intersex_accommodation_reading, influences).
narrative_ontology:cs_axiom('64cc1f65-a113-4bc1-b0b4-9ee648576816', foundational, gender_identity_ontological_primacy).
narrative_ontology:cs_axiom_status(gender_identity_ontological_primacy, holdable).
narrative_ontology:cs_axiom_grounding('64cc1f65-a113-4bc1-b0b4-9ee648576816', gender_identity_ontological_primacy, empirically_contingent).
narrative_ontology:cs_axiom('64cc1f65-a113-4bc1-b0b4-9ee648576816', foundational, self_identification_sufficient_for_category_membership).
narrative_ontology:cs_axiom_status(self_identification_sufficient_for_category_membership, holdable).
narrative_ontology:cs_axiom_grounding('64cc1f65-a113-4bc1-b0b4-9ee648576816', self_identification_sufficient_for_category_membership, conventional).
narrative_ontology:cs_axiom('64cc1f65-a113-4bc1-b0b4-9ee648576816', secondary, sex_based_category_boundaries_are_discriminatory).
narrative_ontology:cs_axiom_status(sex_based_category_boundaries_are_discriminatory, holdable).
narrative_ontology:cs_axiom_grounding('64cc1f65-a113-4bc1-b0b4-9ee648576816', sex_based_category_boundaries_are_discriminatory, deontological).
narrative_ontology:cs_reference_frame('64cc1f65-a113-4bc1-b0b4-9ee648576816', gender_identity_self_determination).
narrative_ontology:cs_drift_state('64cc1f65-a113-4bc1-b0b4-9ee648576816', contemporary_institutional_capture, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('64cc1f65-a113-4bc1-b0b4-9ee648576816', '').
narrative_ontology:cs_kernel_id(woman_category__gender_identity_reading, woman_category).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(woman_category__gender_identity_reading, transgender_women).
narrative_ontology:constraint_beneficiary(woman_category__gender_identity_reading, nonbinary_people_assigned_male).
narrative_ontology:constraint_beneficiary(woman_category__gender_identity_reading, gender_identity_advocacy_organizations).
narrative_ontology:constraint_victim(woman_category__gender_identity_reading, women_seeking_sex_based_protections).
narrative_ontology:constraint_victim(woman_category__gender_identity_reading, female_athletes_in_sex_segregated_sports).
narrative_ontology:constraint_victim(woman_category__gender_identity_reading, survivors_in_sex_segregated_spaces).
narrative_ontology:constraint_vindicates(woman_category__gender_identity_reading, gender_self_determination_doctrine).
narrative_ontology:constraint_vindicates(woman_category__gender_identity_reading, identity_primacy_over_biology).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Gain legal recognition and access to women's facilities, services, and protections by affirming gender identity. Identity lock is constitutive: the reading makes self-identification definitional, so exit would mean abandoning the framework that validates their category membership. Face resistance in sports eligibility and sex-segregated spaces where physical characteristics become contested.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, transgender_women, beneficiary,
    moderate, biographical, identity_locked, national).

% Benefit from expanded category definitions that decouple legal recognition from binary biological sex. The framework's identity-primacy logic extends to nonbinary identifications, though institutional implementation remains contested. Identity lock operates similarly: the reading's axioms ground their claims.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, nonbinary_people_assigned_male, beneficiary,
    moderate, biographical, identity_locked, national).

% Coordinate legal strategy, draft model legislation, provide expert testimony, and mobilize constituencies to institutionalize gender-identity definitions in law. Control the interpretive apparatus that applies the reading to edge cases. Have organizational mobility to shift resources across jurisdictions.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, gender_identity_advocacy_organizations, agenda_setter,
    organized, generational, mobile, national).

% Bear the cost when sex-based accommodations (domestic violence shelters, rape crisis centers, single-sex hospital wards) are reframed as discriminatory under the identity reading. Cannot exit the legal category without abandoning protections historically grounded in sex-based vulnerability. Organized resistance capacity but constrained by institutional capture of definition.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, women_seeking_sex_based_protections, payer,
    organized, biographical, constrained, national).

% Lose competitive opportunities when category membership becomes self-identified rather than biology-based, as physiological advantages from male puberty persist in transgender women athletes. Exit means leaving competitive sports entirely; staying means competing under redefined rules that shift fairness criteria.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, female_athletes_in_sex_segregated_sports, payer,
    moderate, biographical, constrained, national).

% Experience trauma triggers or diminished psychological safety when sex-segregated trauma recovery spaces admit transgender women, particularly those with male anatomy. Cannot exit without abandoning care; cannot voice objections without being labeled discriminatory under the reading's logic. Powerless because institutional policy follows the identity reading while their concerns are categorized as bias.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, survivors_in_sex_segregated_spaces, payer,
    powerless, immediate, trapped, local).

% Previously evaluated gender dysphoria diagnoses and transition readiness; now excluded from the definitional chain when self-identification becomes sufficient. Their clinical expertise is reframed as gatekeeping rather than assessment. Constrained because they operate within institutional frameworks that increasingly adopt the identity reading.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, medical_gatekeepers, excluded,
    institutional, biographical, constrained, national).

% Analyze whether the reading advances or undermines sex-based equality frameworks, examining whether identity-based definitions preserve or dissolve the analytic category that tracks sex-based oppression. Document the collision between competing rights claims and assess which feminist traditions the reading serves or contradicts.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, feminist_legal_theorists, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides legal recognition and social inclusion for people whose gender identity differs from assigned sex at birth, solving the coordination problem of how institutions categorize people for access to gendered facilities, documents, and protections when identity and biology diverge.
% TRANSFER_FUNCTION: Transfers category access and associated protections from a sex-biology criterion to a gender-identity criterion, moving legal standing, facility access, and competitive opportunities from one group (those meeting biological criteria) toward another (those meeting identity criteria), with particular transfer intensity in sports eligibility and sex-segregated spaces.
% ABSENT_VOICES: Women who experience the reading as dissolving sex-based protections are systematically excluded from institutional policy-making because objecting to the identity reading is categorized as discriminatory rather than as a competing rights claim. Medical professionals who assess gender dysphoria are excluded from the definitional apparatus when self-identification becomes sufficient. Both exclusions are structural: dissent from the reading is treated as evidence of bias rather than as legitimate disagreement about category boundaries.
% DISAPPEARANCE_RATIONALE: If the gender-identity reading vanished overnight, transgender women would lose legal recognition and access to women's facilities in jurisdictions that have adopted it; sports governing bodies would revert to biology-based eligibility; identity documents would require biological or medical criteria; and institutions would need alternative frameworks for addressing gender dysphoria and transition. The social and legal landscape would reorganize around whichever alternative reading filled the vacuum.
% FOUNDING_PROBLEM: Transgender people, particularly transgender women, lacked legal recognition and faced exclusion from appropriate facilities, documentation, and social participation when institutional categories were rigidly sex-biology-based with no accommodation for gender identity.
% FOUNDING_PROBLEM_CORROBORATION: Transgender advocacy organizations and medical associations specializing in gender care attest the problem remains live, citing ongoing discrimination and gatekeeping. Feminist legal theorists outside the beneficiary set acknowledge the founding problem was real but increasingly attest the reading has overshot into extractive territory, dissolving protections for a different vulnerable group. Legislative testimony and court records document both the original exclusion problem and the emerging rights-collision problem.
narrative_ontology:disappearance_verdict(woman_category__gender_identity_reading, world_rearranges).
narrative_ontology:founding_problem_status(woman_category__gender_identity_reading, live).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(woman_category__gender_identity_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(woman_category__gender_identity_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(woman_category__gender_identity_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(woman_category__gender_identity_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(woman_category__gender_identity_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is substantial (0.68) because the reading imposes costs on multiple constituencies: women lose sex-based legal protections that are reframed as discriminatory; female athletes lose competitive fairness; survivors lose access to sex-segregated trauma spaces. These costs exceed the coordination benefit of transgender inclusion because they dissolve the category that tracks sex-based vulnerability. Suppression is high (0.72) because dissent is not treated as legitimate disagreement but as evidence of bias—objecting to the reading carries social and professional costs. Theater is moderate-low (0.28): the inclusion function is genuine, but enforcement increasingly focuses on suppressing challenges rather than on solving the founding problem. Accessibility collapse is moderate (0.48): biological definitions remain conceptually available, but institutions treat them as impermissible. Resistance is very high (0.81): sustained organized opposition from feminist groups, parents, athletes, and survivors who contest the reading's dissolution of sex-based categories. The temporal trajectory shows rising extraction and suppression as the reading expanded from identity documents (lower extraction) into sports and sex-segregated spaces (higher extraction, sharper rights collisions).
 *
 * PERSPECTIVAL GAP:
 *   The agenda-setter and beneficiary seats should compute as rope or scaffold: the reading solves a real coordination problem (transgender recognition) with manageable overhead. The payer seats—particularly survivors and female athletes—should compute as snare: from their position the reading operates as enforced extraction that dissolves protections and fairness criteria they depend on, sustained by suppressing their objections as discriminatory. The engine computes this divergence from the structural data; the authored claim does not adjudicate it.
 *
 * DIRECTIONALITY LOGIC:
 *   Transgender women and advocacy organizations are structural beneficiaries (low d): they gain recognition, access, and legal standing under the reading. Women seeking sex-based protections, female athletes, and survivors are structural targets (high d): they bear the extraction as the reading reframes sex-based accommodations as discriminatory and overrides their competing claims. The identity-locked exit for beneficiaries reflects that the reading's definitional axioms constitute their claim to category membership—exiting would mean abandoning the framework that validates their identity. The trapped exit for survivors reflects that institutional policy follows the reading while categorizing their objections as bias, leaving them unable to exit without abandoning care or voice concerns without penalty.
 *
 * MANDATROPHY ANALYSIS:
 *   The reading coordinates transgender inclusion (genuine function) while extracting from sex-based protections (asymmetric cost). Mandatrophy analysis clarifies this is not pure extraction masked as coordination—the transgender exclusion problem was real—but the solution has drifted toward extractive territory as institutional capture spreads the reading into domains (sports, trauma spaces) where rights collisions intensify. The rising extraction trajectory shows function drift: early implementation in identity documents was lower-extraction coordination; expansion into sex-segregated competitive and safety contexts increased extraction substantially. The moderate theater ratio reflects that inclusion remains the stated function, but enforcement effort increasingly targets dissent suppression rather than solving coordination problems.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    identity_primacy_grounding,
    'Is gender identity a genuine natural kind with causal primacy over biological sex for legal and social purposes, or is identity-primacy a normative choice that overrides biology-based categories for inclusion goals?',
    'If developmental neuroscience establishes stable, early-forming gender identity as neurologically distinct from biological sex and predictive of post-transition outcomes, the identity-primacy claim gains empirical support. If identity remains fluid, socially constructed, or post-hoc in substantial populations, the reading is a normative reframing rather than a natural-kind discovery.',
    'If identity is a genuine natural kind, the reading is coordination around a real feature of persons and extraction is the price of correcting misclassification. If identity is normative construction, the reading is redistributive policy dressed as factual discovery, and the extraction is pure transfer rather than correction.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(identity_primacy_grounding, empirical, 'Whether identity-primacy rests on natural-kind grounding or normative preference').

omega_variable(
    rights_collision_adjudication,
    'In domains where transgender inclusion and sex-based protections collide (sports fairness, trauma space safety), is there a principled basis for prioritizing one right over the other, or is the collision irreducible and jurisdiction-dependent?',
    'Comparative analysis of jurisdictions that prioritize differently: do transgender inclusion policies in sports preserve competitive fairness? Do sex-segregated trauma spaces that admit transgender women preserve survivor outcomes? If neither outcome can be preserved simultaneously, the collision is irreducible and resolution is political rather than principled.',
    'If the collision is adjudicable on principled grounds, one reading should dominate in contested domains. If irreducible, extraction is unavoidable regardless of which reading prevails—someone bears the cost of the unresolvable conflict.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(rights_collision_adjudication, conceptual, 'Whether rights collisions in this reading are adjudicable or structurally irreducible').

omega_variable(
    suppression_mechanism,
    'Is the suppression of sex-based objections structural (institutional enforcement against dissent) or internalized (self-censorship from social costs), and what proportion is each?',
    'Anonymous survey of women in affected domains (athletes, shelter staff, healthcare workers) measuring gap between private beliefs and public statements about the reading. Large gaps indicate internalized suppression; punitive enforcement actions indicate structural suppression.',
    'If suppression is primarily structural, removing enforcement mechanisms would allow alternative readings to resurface. If internalized, the reading has reshaped belief itself and would persist even without active enforcement. The distinction affects whether resistance is latent or exhausted.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(suppression_mechanism, empirical, 'Proportion of suppression that is structural vs. internalized').

omega_variable(
    kernel_decomposition_necessity,
    'Could the founding problem (transgender exclusion) have been solved without replacing sex-based categories wholesale, or does transgender inclusion necessarily require redefining ''woman'' for all purposes?',
    'Comparison with jurisdictions that created a third legal category (non-binary, intersex) or domain-specific rules (identity documents vs. sports vs. medical care) rather than redefining binary categories. If those jurisdictions achieve comparable inclusion without dissolving sex-based protections, wholesale redefinition was not necessary.',
    'If the founding problem could have been solved with a narrower intervention, the sweeping redefinition constitutes scope creep and the extraction is avoidable. If wholesale redefinition was structurally necessary, the extraction is the price of solving the coordination problem and not separable from the solution.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(kernel_decomposition_necessity, conceptual, 'Whether the constraint''s scope is necessary or represents function creep').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(woman_category__gender_identity_reading, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(woma_tr_t0, woman_category__gender_identity_reading, theater_ratio, 0, 0.1).
narrative_ontology:measurement_basis(woma_tr_t0, observed).
narrative_ontology:measurement(woma_tr_t5, woman_category__gender_identity_reading, theater_ratio, 5, 0.14).
narrative_ontology:measurement_basis(woma_tr_t5, observed).
narrative_ontology:measurement(woma_tr_t10, woman_category__gender_identity_reading, theater_ratio, 10, 0.18).
narrative_ontology:measurement_basis(woma_tr_t10, observed).
narrative_ontology:measurement(woma_tr_t15, woman_category__gender_identity_reading, theater_ratio, 15, 0.22).
narrative_ontology:measurement_basis(woma_tr_t15, observed).
narrative_ontology:measurement(woma_tr_t20, woman_category__gender_identity_reading, theater_ratio, 20, 0.25).
narrative_ontology:measurement_basis(woma_tr_t20, observed).
narrative_ontology:measurement(woma_tr_t25, woman_category__gender_identity_reading, theater_ratio, 25, 0.28).
narrative_ontology:measurement_basis(woma_tr_t25, observed).

% Extraction over time
narrative_ontology:measurement(woma_be_t0, woman_category__gender_identity_reading, base_extractiveness, 0, 0.35).
narrative_ontology:measurement_basis(woma_be_t0, observed).
narrative_ontology:measurement(woma_be_t5, woman_category__gender_identity_reading, base_extractiveness, 5, 0.42).
narrative_ontology:measurement_basis(woma_be_t5, observed).
narrative_ontology:measurement(woma_be_t10, woman_category__gender_identity_reading, base_extractiveness, 10, 0.51).
narrative_ontology:measurement_basis(woma_be_t10, observed).
narrative_ontology:measurement(woma_be_t15, woman_category__gender_identity_reading, base_extractiveness, 15, 0.59).
narrative_ontology:measurement_basis(woma_be_t15, observed).
narrative_ontology:measurement(woma_be_t20, woman_category__gender_identity_reading, base_extractiveness, 20, 0.64).
narrative_ontology:measurement_basis(woma_be_t20, observed).
narrative_ontology:measurement(woma_be_t25, woman_category__gender_identity_reading, base_extractiveness, 25, 0.68).
narrative_ontology:measurement_basis(woma_be_t25, observed).

% Suppression requirement over time
narrative_ontology:measurement(woma_su_t0, woman_category__gender_identity_reading, suppression_requirement, 0, 0.45).
narrative_ontology:measurement_basis(woma_su_t0, observed).
narrative_ontology:measurement(woma_su_t5, woman_category__gender_identity_reading, suppression_requirement, 5, 0.52).
narrative_ontology:measurement_basis(woma_su_t5, observed).
narrative_ontology:measurement(woma_su_t10, woman_category__gender_identity_reading, suppression_requirement, 10, 0.59).
narrative_ontology:measurement_basis(woma_su_t10, observed).
narrative_ontology:measurement(woma_su_t15, woman_category__gender_identity_reading, suppression_requirement, 15, 0.65).
narrative_ontology:measurement_basis(woma_su_t15, observed).
narrative_ontology:measurement(woma_su_t20, woman_category__gender_identity_reading, suppression_requirement, 20, 0.69).
narrative_ontology:measurement_basis(woma_su_t20, observed).
narrative_ontology:measurement(woma_su_t25, woman_category__gender_identity_reading, suppression_requirement, 25, 0.72).
narrative_ontology:measurement_basis(woma_su_t25, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(woman_category__gender_identity_reading, identity_coordination).
narrative_ontology:boltzmann_floor_override(woman_category__gender_identity_reading, 0.12).
narrative_ontology:affects_constraint(woman_category__gender_identity_reading, woman_category__sex_biology_reading).
narrative_ontology:affects_constraint(woman_category__gender_identity_reading, woman_category__intersex_accommodation_reading).
narrative_ontology:affects_constraint(woman_category__gender_identity_reading, sex_segregated_sports_eligibility).
narrative_ontology:affects_constraint(woman_category__gender_identity_reading, single_sex_space_access_rules).
narrative_ontology:affects_constraint(woman_category__gender_identity_reading, legal_sex_designation_on_documents).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the woman_category kernel. The kernel decomposes into three structurally distinct readings because ε values diverge by 0.3+ across readings: gender_identity_reading shows substantial extraction (0.68) concentrated in sports and sex-segregated spaces where rights collide; sex_biology_reading would show lower extraction from this constituency but higher extraction from transgender populations and resistance from advocacy organizations; intersex_accommodation_reading occupies different structural space (non-binary spectrum rather than identity redefinition). Each reading has distinct beneficiary/victim structures and suppression patterns, requiring separate constraint stories per ε-invariance. Linked via network.affects_constraints.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
