% ============================================================================
% CONSTRAINT STORY: westphalia_sovereignty__absolute_non_intervention
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2025-01-16
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_westphalia_sovereignty__absolute_non_intervention, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: westphalia_sovereignty__absolute_non_intervention
 *   human_readable: Westphalian Sovereignty: Absolute Non-Intervention Reading
 *   domain: international_law/political_theory/state_systems
 *
 * SUMMARY:
 *   The Westphalian sovereignty system established territorial inviolability
 *   as the foundation of international order following the Thirty Years' War.
 *   This constraint models the ABSOLUTE NON-INTERVENTION reading: sovereignty
 *   as categorical barrier to external interference regardless of internal
 *   conduct. Under this reading, state elites (both authoritarian and
 *   democratic) gain complete discretion over domestic populations, shielded
 *   from international accountability even during mass atrocities. The
 *   doctrine coordinates interstate relations by establishing clear
 *   jurisdictional boundaries, but extracts heavily from populations trapped
 *   under repressive regimes who are defined out of the international
 *   protection system. The claim is tangled_rope (genuine coordination
 *   function plus asymmetric extraction requiring active enforcement); the
 *   metrics describe rising extraction and theatrical maintenance as the gap
 *   between founding function (preventing religious wars) and current
 *   operation (shielding state violence) widens.
 *
 * KEY AGENTS:
 *   - state_elites_authoritarian: Primary beneficiary (institutional/constrained) — collect absolute domestic discretion, shield regime violence from external accountability
 *   - state_elites_democratic: Beneficiary + agenda_setter (institutional/mobile) — maintain policy autonomy, reciprocally protected by same norm that shields authoritarian violence
 *   - populations_under_authoritarian_rule: Primary victim (powerless/trapped) — bear full cost of regime repression with no external recourse
 *   - stateless_populations: Victim (powerless/trapped) — exist in sovereignty gaps, defined as non-entities
 *   - ethnic_minorities_facing_repression: Victim (powerless/identity_locked) — face systematic violence justified as internal governance
 *   - sovereignty_doctrine_advocates: Agenda setter (institutional/analytical) — maintain legal architecture treating territorial inviolability as foundation of order
 *   - humanitarian_intervention_advocates: Excluded (organized/mobile) — structurally barred from legal framework under this reading
 *   - international_legal_scholars: Analytical observer — document sovereignty-human rights tension
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(westphalia_sovereignty__absolute_non_intervention, 0.72).
domain_priors:suppression_score(westphalia_sovereignty__absolute_non_intervention, 0.81).
domain_priors:theater_ratio(westphalia_sovereignty__absolute_non_intervention, 0.48).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, extractiveness, 0.72).
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 0.81).
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, theater_ratio, 0.48).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, accessibility_collapse, 0.42).
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, resistance, 0.68).

% --- Constraint claim ---
narrative_ontology:constraint_claim(westphalia_sovereignty__absolute_non_intervention, tangled_rope).
narrative_ontology:human_readable(westphalia_sovereignty__absolute_non_intervention, "Westphalian Sovereignty: Absolute Non-Intervention Reading").
narrative_ontology:topic_domain(westphalia_sovereignty__absolute_non_intervention, "international_law/political_theory/state_systems").

domain_priors:requires_active_enforcement(westphalia_sovereignty__absolute_non_intervention).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(westphalia_sovereignty__absolute_non_intervention, '7fc3a7df-9960-4c23-a419-b0ebd31228a1').
narrative_ontology:cs_kernel_codification('7fc3a7df-9960-4c23-a419-b0ebd31228a1', fixed_text).
narrative_ontology:cs_authority_grounding('7fc3a7df-9960-4c23-a419-b0ebd31228a1', lineage).
narrative_ontology:cs_interpretation_layer_present('7fc3a7df-9960-4c23-a419-b0ebd31228a1').
narrative_ontology:cs_reading_relation('7fc3a7df-9960-4c23-a419-b0ebd31228a1', westphalia_sovereignty__conditional_responsibility, coexists_with).
narrative_ontology:cs_reading_relation('7fc3a7df-9960-4c23-a419-b0ebd31228a1', westphalia_sovereignty__graded_sovereignty, coexists_with).
narrative_ontology:cs_axiom('7fc3a7df-9960-4c23-a419-b0ebd31228a1', foundational, territorial_inviolability_categorical).
narrative_ontology:cs_axiom_status(territorial_inviolability_categorical, holdable).
narrative_ontology:cs_axiom_grounding('7fc3a7df-9960-4c23-a419-b0ebd31228a1', territorial_inviolability_categorical, conventional).
narrative_ontology:cs_axiom('7fc3a7df-9960-4c23-a419-b0ebd31228a1', secondary, internal_affairs_unreviewable).
narrative_ontology:cs_axiom_status(internal_affairs_unreviewable, holdable).
narrative_ontology:cs_axiom_grounding('7fc3a7df-9960-4c23-a419-b0ebd31228a1', internal_affairs_unreviewable, conventional).
narrative_ontology:cs_reference_frame('7fc3a7df-9960-4c23-a419-b0ebd31228a1', westphalian_territorial_order_1648).
narrative_ontology:cs_drift_state('7fc3a7df-9960-4c23-a419-b0ebd31228a1', post_rwandan_genocide_era, gap(axiom_overriding, substantial, false)).
narrative_ontology:cs_created_at('7fc3a7df-9960-4c23-a419-b0ebd31228a1', '').
narrative_ontology:cs_kernel_id(westphalia_sovereignty__absolute_non_intervention, westphalia_sovereignty).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__absolute_non_intervention, state_elites_authoritarian).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__absolute_non_intervention, state_elites_democratic).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__absolute_non_intervention, sovereignty_doctrine_advocates).
narrative_ontology:constraint_victim(westphalia_sovereignty__absolute_non_intervention, populations_under_authoritarian_rule).
narrative_ontology:constraint_victim(westphalia_sovereignty__absolute_non_intervention, stateless_populations).
narrative_ontology:constraint_victim(westphalia_sovereignty__absolute_non_intervention, ethnic_minorities_facing_repression).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__absolute_non_intervention, territorial_integrity_doctrine).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__absolute_non_intervention, non_interference_principle).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Control domestic territory with minimal external accountability. Use sovereignty doctrine to deflect international pressure over human rights violations, mass detention, or political repression. Frame external criticism as illegitimate interference and violation of territorial inviolability.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, state_elites_authoritarian, beneficiary,
    institutional, biographical, constrained, national).

% Invoke sovereignty to resist external governance mandates and maintain policy autonomy in areas like environmental regulation, labor standards, or economic policy. Benefit from the norm's reciprocal protection while also being constrained by it when considering humanitarian intervention.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, state_elites_democratic, beneficiary,
    institutional, generational, mobile, national).
narrative_ontology:stakeholder_secondary_role(westphalia_sovereignty__absolute_non_intervention, state_elites_democratic, agenda_setter).

% Bear the full cost of regime violence and repression with no external recourse. The sovereignty shield prevents international intervention or protection even during mass atrocities. Exit options are geographic (refugee flight, often prevented) or regime change (violently suppressed).
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, populations_under_authoritarian_rule, payer,
    powerless, biographical, trapped, national).

% Exist in the gaps between territorial sovereignties without protection from any state. The absolute sovereignty reading treats them as non-entities in the international legal order—no state claims responsibility, and the territorial inviolability norm prevents external actors from establishing protection.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, stateless_populations, payer,
    powerless, generational, trapped, regional).

% Face systematic discrimination or violence that the controlling state justifies as internal governance. Cannot exit their identity even if they could exit the territory. External advocacy is blocked by the sovereignty norm treating minority rights as purely domestic matters.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, ethnic_minorities_facing_repression, payer,
    powerless, generational, identity_locked, national).

% Maintain the international legal architecture through UN Charter interpretation, diplomatic practice, and scholarly doctrine. Treat territorial inviolability as the foundation of international order and any erosion of the absolute norm as risking interstate chaos.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, sovereignty_doctrine_advocates, agenda_setter,
    institutional, civilizational, analytical, global).

% Argue that sovereignty should not shield mass atrocities and that the international community has responsibility to protect populations when states fail to do so. Are structurally excluded from the legal framework under this reading—their position is defined as illegitimate interference.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, humanitarian_intervention_advocates, excluded,
    organized, generational, mobile, global).

% Analyze the tension between state sovereignty and human rights obligations. Document how the absolute non-intervention reading shields atrocities and track the doctrinal contest between Westphalian sovereignty and responsibility-to-protect frameworks.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, international_legal_scholars, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes stable boundaries between state jurisdictions, preventing constant interstate interference and wars of regime change. Provides predictable framework for diplomatic recognition, treaty obligations, and territorial integrity claims.
% TRANSFER_FUNCTION: Transfers absolute discretion over domestic populations from any international oversight body to the territorial state elite. Concentrates power to define 'internal affairs' in the hands of whoever controls the state apparatus, excluding external humanitarian actors.
% ABSENT_VOICES: Populations suffering mass atrocities under authoritarian regimes, ethnic minorities facing state-sponsored violence, human rights organizations, and states willing to intervene for humanitarian purposes—all structurally excluded because the reading defines their participation as illegitimate interference.
% DISAPPEARANCE_RATIONALE: If the absolute non-intervention norm vanished, the international order would reorganize around competing legitimacy standards: humanitarian intervention would become legally available, authoritarian regimes would lose their primary shield against external pressure, coalition-building for protective intervention would accelerate, and the entire diplomatic architecture of territorial inviolability would require reconstruction around new principles.
% FOUNDING_PROBLEM: The Thirty Years' War and earlier religious wars of intervention devastated Europe through cycles of external interference in domestic governance. States needed a coordination mechanism to end perpetual interference and establish stable boundaries for sovereignty.
% FOUNDING_PROBLEM_CORROBORATION: Sovereignty doctrine advocates and diplomatic historians attest the founding problem remains live—without absolute inviolability, great powers would return to constant interference and proxy wars. Humanitarian intervention advocates and genocide scholars attest the founding problem is transformed—the primary threat to populations is now state violence against their own people, not external interference, supported by systematic documentation of mass atrocities shielded by sovereignty claims from Rwanda to Syria.
narrative_ontology:disappearance_verdict(westphalia_sovereignty__absolute_non_intervention, world_rearranges).
narrative_ontology:founding_problem_status(westphalia_sovereignty__absolute_non_intervention, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(westphalia_sovereignty__absolute_non_intervention, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(westphalia_sovereignty__absolute_non_intervention, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(westphalia_sovereignty__absolute_non_intervention_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(westphalia_sovereignty__absolute_non_intervention, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(westphalia_sovereignty__absolute_non_intervention_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is high (0.72) because the constraint grants absolute discretion to state elites over populations with no exit options, creating structural power asymmetry far beyond coordination needs. Suppression is higher still (0.81) because maintaining the absolute reading requires actively excluding humanitarian intervention advocates, suppressing responsibility-to-protect claims, and enforcing non-interference even during documented genocides. Theater ratio is moderate-high (0.48): the norm still performs genuine coordination work (preventing wars of regime change, establishing diplomatic boundaries) but a growing share of doctrinal maintenance activity defends regime violence rather than interstate stability. Accessibility collapse is moderate-low (0.42): alternative frameworks (R2P, conditional sovereignty, human rights obligations) remain live and contested—the absolute reading persists not because alternatives are unthinkable but because enforcement machinery excludes them. Resistance is high (0.68): humanitarian crises repeatedly challenge the norm; enforcement costs rise with each atrocity the doctrine shields. All measurements share one time grid as required.
 *
 * PERSPECTIVAL GAP:
 *   From authoritarian state elites, this is essential protection of sovereignty against imperial interference—the norm prevents great power domination. From democratic state elites, it is a necessary if imperfect coordination mechanism balancing autonomy against international obligations. From trapped populations under repressive regimes, the same structure operates as enforced abandonment—the sovereignty shield traps them with their oppressors. From humanitarian advocates, it is a legal architecture that systematically prioritizes regime stability over population protection. The engine computes these divergent classifications from the structural data; the authored claim (tangled_rope) does not adjudicate between them.
 *
 * DIRECTIONALITY LOGIC:
 *   State elites (both authoritarian and democratic) are structural beneficiaries—they collect absolute domestic discretion and the norm protects their territorial control (d near beneficiary end). Authoritarian elites extract more heavily because they lack democratic accountability mechanisms. Populations under authoritarian rule, stateless populations, and repressed minorities are the targets—they bear the full cost of regime violence with sovereignty blocking external protection (d near target end, amplified by trapped/identity_locked exit). Democratic state elites occupy a complex position: beneficiaries of policy autonomy but also constrained by reciprocal obligations, hence mobile exit options. Humanitarian advocates are excluded rather than coordinated—their exclusion is the enforcement object itself.
 *
 * MANDATROPHY ANALYSIS:
 *   The coordination function (preventing interstate wars of regime change) remains partially valid—unilateral intervention would destabilize the international system. But the extraction function (shielding mass atrocities, concentrating power in state apparatus regardless of regime type) has grown substantially as the gap between the founding problem (Thirty Years' War religious violence) and current operation (state violence against own populations) widens. The theater_ratio trajectory shows performative maintenance rising: doctrinal activity increasingly defends the norm itself rather than solving the coordination problem. This is not pure mandatrophy (the coordination function persists) nor pure snare (genuine stability benefits exist), but tangled_rope—the same structure that coordinates also extracts, and both functions require active enforcement to persist.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    coordination_extraction_boundary,
    'Is the absolute non-intervention norm structurally necessary for interstate stability, or is the stability function separable from the atrocity-shielding function?',
    'Natural experiments from regional systems (EU, African Union) that maintain interstate peace while authorizing humanitarian intervention under specified conditions. If stability holds with conditional sovereignty, the functions are separable.',
    'If separable, the atrocity-shielding is pure extraction riding on a real coordination function; if inseparable, some measured extraction is the inherent price of preventing wars of regime change. Determines whether reform can preserve coordination benefits while removing extraction costs.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(coordination_extraction_boundary, empirical, 'Whether absolute territorial inviolability and interstate stability are structurally bound or separable functions').

omega_variable(
    kernel_reading_under_determination,
    'Is the 1648 Westphalian settlement ITSELF committed to absolute non-intervention, or does the historical kernel underdetermine the choice between absolute and conditional sovereignty readings?',
    'Historical analysis of Treaty of Westphalia provisions, subsequent state practice, and doctrinal evolution. What did the original settlement actually lock in versus what later interpreters projected onto it?',
    'If the kernel underdetermines the reading, then competing sovereignty frameworks (R2P, graded authority) are equally legitimate interpretations of the founding commitment, not violations of it. Shifts the doctrinal contest from ''upholding versus betraying Westphalia'' to ''which reading better serves current coordination needs.''',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(kernel_reading_under_determination, conceptual, 'Whether the sovereignty kernel itself determines the absolute reading or permits multiple interpretations').

omega_variable(
    great_power_exception_hypocrisy,
    'Does the actual interstate practice honor the absolute non-intervention norm symmetrically, or do great powers invoke it selectively while routinely intervening when convenient?',
    'Systematic coding of intervention episodes and sovereignty-norm invocations by power status. If great powers intervene frequently but invoke sovereignty to block intervention against client states, the norm''s coordination function is theater.',
    'If enforcement is asymmetric, the measured theater_ratio is too low—the norm primarily serves great power prerogatives rather than genuine coordination, and the tangled_rope classification understates extraction. If enforcement is symmetric, the coordination function is real despite the atrocity costs.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(great_power_exception_hypocrisy, empirical, 'Whether sovereignty norm enforcement is symmetric or a great power prerogative').

omega_variable(
    victim_population_agency,
    'Do populations under authoritarian rule experience the sovereignty shield as externally imposed extraction, or do some populations prefer non-intervention to the risk of destabilizing external interference?',
    'Survey and interview data from populations in authoritarian states about preferences regarding external intervention, weighted by exposure to regime violence. Distinguish between elite-captured signals and genuine population preferences.',
    'If substantial populations prefer the sovereignty shield despite living under repression, the victim classification is oversimplified and some ''extraction'' is actually demanded protection from external chaos. If populations overwhelmingly reject the shield when not under elite control, the extraction measurement is accurate.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(victim_population_agency, preference, 'Whether trapped populations experience sovereignty as protection or abandonment').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(westphalia_sovereignty__absolute_non_intervention, 0, 35).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(west_tr_t0, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 0, 0.22).
narrative_ontology:measurement(west_tr_t7, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 7, 0.28).
narrative_ontology:measurement(west_tr_t14, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 14, 0.35).
narrative_ontology:measurement(west_tr_t21, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 21, 0.4).
narrative_ontology:measurement(west_tr_t28, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 28, 0.45).
narrative_ontology:measurement(west_tr_t35, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 35, 0.48).

% Extraction over time
narrative_ontology:measurement(west_be_t0, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 0, 0.48).
narrative_ontology:measurement(west_be_t7, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 7, 0.54).
narrative_ontology:measurement(west_be_t14, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 14, 0.61).
narrative_ontology:measurement(west_be_t21, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 21, 0.67).
narrative_ontology:measurement(west_be_t28, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 28, 0.7).
narrative_ontology:measurement(west_be_t35, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 35, 0.72).

% Suppression requirement over time
narrative_ontology:measurement(west_su_t0, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 0, 0.62).
narrative_ontology:measurement(west_su_t7, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 7, 0.68).
narrative_ontology:measurement(west_su_t14, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 14, 0.73).
narrative_ontology:measurement(west_su_t21, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 21, 0.77).
narrative_ontology:measurement(west_su_t28, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 28, 0.79).
narrative_ontology:measurement(west_su_t35, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 35, 0.81).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(westphalia_sovereignty__absolute_non_intervention, enforcement_mechanism).
narrative_ontology:affects_constraint(westphalia_sovereignty__absolute_non_intervention, westphalia_sovereignty__conditional_responsibility).
narrative_ontology:affects_constraint(westphalia_sovereignty__absolute_non_intervention, westphalia_sovereignty__graded_sovereignty).
narrative_ontology:affects_constraint(westphalia_sovereignty__absolute_non_intervention, un_charter_article_2_4).
narrative_ontology:affects_constraint(westphalia_sovereignty__absolute_non_intervention, humanitarian_intervention_doctrine).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the westphalia_sovereignty kernel. The absolute_non_intervention reading shields regime violence via categorical territorial inviolability (ε = 0.72, high suppression of intervention alternatives). The conditional_responsibility reading makes sovereignty contingent on population protection, authorizing intervention during mass atrocities (different victim set, different ε). The graded_sovereignty reading distributes authority along a state-capacity spectrum (different beneficiary structure, different suppression profile). All three reference the 1648 settlement but instantiate structurally distinct constraints—they are linked in the network, not merged into one observable-dependent story.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
