% ============================================================================
% CONSTRAINT STORY: waitangi_sovereignty_allocation__crown_sovereignty_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2025-01-09
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_waitangi_sovereignty_allocation__crown_sovereignty_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: waitangi_sovereignty_allocation__crown_sovereignty_reading
 *   human_readable: Crown Sovereignty Reading of Treaty of Waitangi Article I
 *   domain: constitutional_law/indigenous_rights/post_colonial_governance
 *
 * SUMMARY:
 *   The Treaty of Waitangi (1840) exists in English and Māori versions with
 *   systematically different meanings for Article I. The English text states
 *   Māori chiefs 'cede absolutely and without reservation all the rights and
 *   powers of Sovereignty' to the Crown. The Māori text (te Tiriti) states
 *   chiefs cede 'te kāwanatanga katoa' (the governorship entirely) to the
 *   Queen. Crown sovereignty reading treats the English text as authoritative
 *   and interprets Article I as complete sovereignty cession, establishing
 *   Westminster parliamentary supremacy. This reading became constitutional
 *   bedrock for colonial governance, land confiscation legislation, and
 *   resource extraction. The constraint is CLAIMED as snare—the Crown's own
 *   framing now acknowledges systematic Treaty breach while maintaining
 *   parliamentary sovereignty doctrine. Metrics describe highly extractive,
 *   heavily suppressed operation where alternatives to Crown sovereignty have
 *   been actively foreclosed through institutional and legal mechanisms over
 *   180+ years.
 *
 * KEY AGENTS:
 *   - crown_executive: Primary agenda-setter (institutional/arbitrage) — exercises unilateral authority, collects legitimacy for resource extraction
 *   - settler_parliament: Primary beneficiary (institutional/mobile) — receives legislative supremacy without consent requirements
 *   - colonial_resource_extractors: Secondary beneficiary (powerful/mobile) — gain land and resource access through parliamentary supremacy
 *   - iwi_collective_authorities: Primary target (organized/identity_locked) — lose political authority and resource control
 *   - maori_resource_holders: Primary target (moderate/identity_locked) — experience systematic land alienation
 *   - maori_political_institutions: Primary target (organized/identity_locked) — subordinated to Crown institutional hierarchy
 *   - treaty_tribunal: Analytical observer (institutional/analytical) — documents Treaty breach under alternative readings
 *   - constitutional_scholars: Analytical observer (analytical/analytical) — analyzes textual and historical evidence
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(waitangi_sovereignty_allocation__crown_sovereignty_reading, 0.82).
domain_priors:suppression_score(waitangi_sovereignty_allocation__crown_sovereignty_reading, 0.88).
domain_priors:theater_ratio(waitangi_sovereignty_allocation__crown_sovereignty_reading, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, extractiveness, 0.82).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 0.88).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, accessibility_collapse, 0.71).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, resistance, 0.76).

% --- Constraint claim ---
narrative_ontology:constraint_claim(waitangi_sovereignty_allocation__crown_sovereignty_reading, snare).
narrative_ontology:human_readable(waitangi_sovereignty_allocation__crown_sovereignty_reading, "Crown Sovereignty Reading of Treaty of Waitangi Article I").
narrative_ontology:topic_domain(waitangi_sovereignty_allocation__crown_sovereignty_reading, "constitutional_law/indigenous_rights/post_colonial_governance").

domain_priors:requires_active_enforcement(waitangi_sovereignty_allocation__crown_sovereignty_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(waitangi_sovereignty_allocation__crown_sovereignty_reading, '0b7a4a24-f66b-4ee3-9cb7-ddb6cc5efa56').
narrative_ontology:cs_kernel_codification('0b7a4a24-f66b-4ee3-9cb7-ddb6cc5efa56', fixed_text).
narrative_ontology:cs_authority_grounding('0b7a4a24-f66b-4ee3-9cb7-ddb6cc5efa56', extraction).
narrative_ontology:cs_interpretation_layer_present('0b7a4a24-f66b-4ee3-9cb7-ddb6cc5efa56').
narrative_ontology:cs_reading_relation('0b7a4a24-f66b-4ee3-9cb7-ddb6cc5efa56', waitangi_sovereignty_allocation__partnership_reading, forecloses).
narrative_ontology:cs_reading_relation('0b7a4a24-f66b-4ee3-9cb7-ddb6cc5efa56', waitangi_sovereignty_allocation__rangatiratanga_reading, forecloses).
narrative_ontology:cs_axiom('0b7a4a24-f66b-4ee3-9cb7-ddb6cc5efa56', foundational, complete_sovereignty_cession_via_english_text).
narrative_ontology:cs_axiom_status(complete_sovereignty_cession_via_english_text, holdable).
narrative_ontology:cs_axiom_grounding('0b7a4a24-f66b-4ee3-9cb7-ddb6cc5efa56', complete_sovereignty_cession_via_english_text, conventional).
narrative_ontology:cs_axiom('0b7a4a24-f66b-4ee3-9cb7-ddb6cc5efa56', foundational, parliamentary_supremacy_unlimited).
narrative_ontology:cs_axiom_status(parliamentary_supremacy_unlimited, holdable).
narrative_ontology:cs_axiom_grounding('0b7a4a24-f66b-4ee3-9cb7-ddb6cc5efa56', parliamentary_supremacy_unlimited, conventional).
narrative_ontology:cs_axiom('0b7a4a24-f66b-4ee3-9cb7-ddb6cc5efa56', secondary, crown_unilateral_resource_authority).
narrative_ontology:cs_axiom_status(crown_unilateral_resource_authority, holdable).
narrative_ontology:cs_axiom_grounding('0b7a4a24-f66b-4ee3-9cb7-ddb6cc5efa56', crown_unilateral_resource_authority, conventional).
narrative_ontology:cs_reference_frame('0b7a4a24-f66b-4ee3-9cb7-ddb6cc5efa56', westminster_parliamentary_sovereignty_doctrine).
narrative_ontology:cs_drift_state('0b7a4a24-f66b-4ee3-9cb7-ddb6cc5efa56', contemporary_treaty_tribunal_era, gap(authority_erosion, substantial, true)).
narrative_ontology:cs_created_at('0b7a4a24-f66b-4ee3-9cb7-ddb6cc5efa56', '').
narrative_ontology:cs_kernel_id(waitangi_sovereignty_allocation__crown_sovereignty_reading, waitangi_sovereignty_allocation).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__crown_sovereignty_reading, crown_executive).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__crown_sovereignty_reading, settler_parliament).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__crown_sovereignty_reading, colonial_resource_extractors).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__crown_sovereignty_reading, iwi_collective_authorities).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__crown_sovereignty_reading, maori_resource_holders).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__crown_sovereignty_reading, maori_political_institutions).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__crown_sovereignty_reading, westminster_parliamentary_sovereignty_doctrine).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__crown_sovereignty_reading, territorial_sovereignty_doctrine).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Claims plenary legislative power over all New Zealand territory based on English text cession. Exercises unilateral authority over resource allocation, land policy, and institutional structure. Justifies extraction and subordination of Māori authority as legitimate exercise of ceded sovereignty. Maintains parliamentary supremacy doctrine as constitutional bedrock.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, crown_executive, agenda_setter,
    institutional, generational, arbitrage, national).

% Receives legislative supremacy and resource control authority without substantive consent requirements. Enacts land confiscation, resource allocation, and governance frameworks that subordinate Māori interests to settler-majority voting. Benefits from Crown sovereignty reading's elimination of power-sharing constraints.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, settler_parliament, beneficiary,
    institutional, generational, mobile, national).

% Acquire access to Māori lands and resources through parliamentary legislation enacted without Māori veto. Operate under legal frameworks that treat Crown land titles as superior to customary tenure. Benefit from sovereignty reading that subordinates Māori property claims to parliamentary will.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, colonial_resource_extractors, beneficiary,
    powerful, biographical, mobile, national).

% Lose political authority and resource control under Crown sovereignty interpretation. Their traditional governance structures are subordinated to Crown institutions; their authority over lands and resources is reduced to whatever Parliament permits. Identity fusion with iwi governance roles makes exit from the constitutional arrangement psychologically and culturally unthinkable—challenging Crown sovereignty means challenging the legitimacy of the post-contact state itself.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, iwi_collective_authorities, payer,
    organized, civilizational, identity_locked, regional).

% Experience systematic land alienation and resource expropriation through parliamentary legislation. Their customary property rights are overridden by Crown land titles and confiscation acts. The sovereignty reading treats their interests as subordinate to settler-majority preferences. Identity as tangata whenua is constituted through the land relationship the constraint undermines; exit from the constitutional contest means accepting permanent dispossession.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, maori_resource_holders, payer,
    moderate, generational, identity_locked, regional).

% Lose institutional standing as co-equal authorities. Their capacity for self-governance is reduced to delegated powers at Crown discretion. Parliamentary supremacy reading denies them veto rights over legislation affecting their communities. Their challenge requires maintaining alternative constitutional narrative across generations while operating within Crown legal framework.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, maori_political_institutions, payer,
    organized, civilizational, identity_locked, national).

% Investigates historical Treaty breaches and articulates principles of partnership and active protection that contest Crown sovereignty reading. Has statutory authority to investigate but not to overturn legislation. Documents systematic divergence between Crown conduct and Treaty obligations under alternative readings.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, treaty_tribunal, observer,
    institutional, generational, analytical, national).

% Analyze textual discrepancies between English and Māori Treaty versions and historical evidence of signatories' understanding. Document how Crown sovereignty reading contradicts contemporaneous Māori testimony and Māori-text meaning. Map systemic consequences of sovereignty interpretation for indigenous rights.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, constitutional_scholars, observer,
    analytical, biographical, analytical, national).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes unambiguous constitutional hierarchy for colonial governance: Crown holds plenary legislative power, enabling coherent territorial administration under Westminster parliamentary model without power-sharing complexity.
% TRANSFER_FUNCTION: Moves political authority, land tenure rights, and resource control from iwi collective structures to Crown institutions and settler Parliament, enabling systematic resource extraction and land alienation through parliamentary legislation.
% ABSENT_VOICES: Māori signatories who understood Article I as ceding only kāwanatanga (governorship over settlers) while retaining rangatiratanga (chiefly authority). Historical record shows chiefs' contemporaneous statements rejecting sovereignty cession were systematically excluded from Crown's constitutional interpretation. Alternative readings grounded in Māori text and oral testimony remain structurally marginalized in parliamentary sovereignty doctrine.
% DISAPPEARANCE_RATIONALE: If Crown sovereignty reading vanished, constitutional order would require renegotiation of power-sharing arrangements between Crown and iwi authorities. Land tenure, resource rights, and legislative processes would be contested. Current parliamentary supremacy doctrine depends on this reading's foreclosure of Māori co-sovereignty claims. Absence would require either partnership model or full recognition of rangatiratanga retention, fundamentally restructuring New Zealand constitutional law.
% FOUNDING_PROBLEM: Colonial governance required legal framework for British settlement and resource extraction in territory where Māori retained demographic majority and military capacity in 1840. Crown needed constitutional foundation for territorial claims and legislative authority over both settlers and Māori.
% FOUNDING_PROBLEM_CORROBORATION: Crown and settler historians attest the problem remains live, citing need for constitutional certainty. Treaty Tribunal, Māori political institutions, and constitutional historians outside beneficiary groups attest the founding security problem dissolved by mid-19th century when settler population and military capacity surpassed Māori. Tribunal reports document that continued invocation of founding problem serves to justify ongoing extraction rather than address genuine governance coordination need. Contemporary sovereignty reading persists to legitimate accumulated land alienation and institutional subordination, not to solve coordination problem that motivated 1840 Treaty.
narrative_ontology:disappearance_verdict(waitangi_sovereignty_allocation__crown_sovereignty_reading, world_rearranges).
narrative_ontology:founding_problem_status(waitangi_sovereignty_allocation__crown_sovereignty_reading, dead).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(waitangi_sovereignty_allocation__crown_sovereignty_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(waitangi_sovereignty_allocation__crown_sovereignty_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(waitangi_sovereignty_allocation__crown_sovereignty_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(waitangi_sovereignty_allocation__crown_sovereignty_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(waitangi_sovereignty_allocation__crown_sovereignty_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is very high (0.82) because sovereignty reading enables systematic land alienation and resource expropriation through parliamentary legislation that treats Māori interests as subordinate to settler-majority will. Suppression is higher still (0.88) because the reading's persistence depends on actively foreclosing alternative Treaty interpretations through parliamentary sovereignty doctrine and Crown institutional dominance. Theater ratio is moderate-low (0.28): the Treaty settlement process and Tribunal investigations are real governance functions, but growing share of Crown Treaty engagement is performative acknowledgment of breach while maintaining the sovereignty doctrine that enables ongoing extraction. Accessibility collapse is substantial (0.71) because sovereignty reading has become constitutional bedrock; resistance remains high (0.76) because Māori political mobilization and Tribunal findings persistently challenge the reading's legitimacy. Measurement series shows extraction accumulation and enforcement intensification over 180 years as sovereignty doctrine became more entrenched despite mounting evidence of textual and historical contradiction.
 *
 * PERSPECTIVAL GAP:
 *   From Crown executive seat, sovereignty reading is legitimate constitutional foundation established by valid Treaty cession. From iwi authority and Māori resource holder seats, same structure operates as systematic breach of Treaty promises and vehicle for intergenerational dispossession. Engine computes this divergence from structural data—agenda-setter with mobile exit and extraction collection versus payers with identity-locked exit and accumulated loss. Claimed type (snare) reflects Crown's own contemporary acknowledgment of systematic breach even while maintaining parliamentary sovereignty doctrine.
 *
 * DIRECTIONALITY LOGIC:
 *   Crown executive and settler Parliament are structural beneficiaries (exercise sovereignty claims, control resource allocation—d near beneficiary end, modulated upward slightly by Tribunal findings and settlement obligations). Colonial resource extractors benefit from parliamentary land legislation (d near beneficiary end). Iwi authorities, Māori resource holders, and Māori political institutions are primary targets (lose authority and resources, identity-locked exit—d near full-target end). Identity lock is severe: challenging Crown sovereignty reading means challenging the constitutional legitimacy of the post-contact state itself; Māori political identity is constituted through the Treaty relationship this reading distorts. Treaty Tribunal and constitutional scholars occupy analytical seats.
 *
 * MANDATROPHY ANALYSIS:
 *   Founding problem (colonial governance coordination) dissolved by mid-19th century when settler demographic and military dominance was established. Crown sovereignty reading persists not to solve coordination problem but to legitimate accumulated land alienation and foreclose Māori co-sovereignty claims. This is not mislabeling pure extraction as coordination—the coordination function was real in 1840 but became obsolete as power asymmetry grew. Classification as snare with dead founding problem captures mandatrophy: arrangement persists through suppression of alternatives (parliamentary sovereignty doctrine, institutional foreclosure of rangatiratanga claims) rather than ongoing coordination benefit. Theater ratio rise reflects growing gap between settlement-process acknowledgment of breach and maintenance of sovereignty doctrine that enables ongoing subordination.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    textual_authority_selection,
    'Is the English text''s ''sovereignty'' the authoritative meaning, or does the Māori text''s ''kāwanatanga'' (governorship) represent the understanding to which chiefs consented?',
    'Historical linguistics analysis of kāwanatanga usage in 1840 missionary translations; contemporaneous testimony from Māori signatories about their understanding; international law doctrines on treaty interpretation when versions conflict.',
    'If Māori text is authoritative, sovereignty was never ceded—Crown holds only governorship over settlers. This would invalidate parliamentary sovereignty doctrine and require power-sharing constitutional structure. Classification would shift toward partnership or rangatiratanga readings. If English text controls, Crown sovereignty reading stands but must account for systematic divergence between Crown interpretation and Māori understanding.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(textual_authority_selection, empirical, 'Which text represents the agreement to which parties actually consented').

omega_variable(
    sovereignty_as_natural_vs_constructed,
    'Is Crown sovereignty a natural consequence of Treaty signing, or a constructed legal fiction that benefits identifiable parties (settler Parliament, resource extractors) by foreclosing Māori co-sovereignty claims?',
    'Comparative analysis of other Treaty-based constitutional arrangements (Canadian Crown-First Nations, US treaty federalism); examination of alternative sovereignty models that emerged in jurisdictions where indigenous peoples retained greater bargaining power; analysis of whether parliamentary supremacy doctrine is logically necessary or serves beneficiary extraction.',
    'If sovereignty is constructed, extraction is the primary function and coordination is cover story. If sovereignty naturally flows from any Treaty (regardless of text), then extraction may be coordination cost rather than extractive overhead. Current evidence (textual divergence, contemporaneous Māori testimony, systematic land confiscation following sovereignty assertion) suggests constructed rather than natural.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(sovereignty_as_natural_vs_constructed, conceptual, 'Whether sovereignty interpretation is natural law or serves beneficiary interests').

omega_variable(
    founding_problem_obsolescence_timing,
    'When did the colonial governance coordination problem dissolve such that sovereignty reading''s persistence became extractive rather than functional?',
    'Historical demographic data on settler-Māori population ratios; military capacity analysis; timing of major land confiscation acts relative to security threats; economic analysis of when resource extraction exceeded coordination cost.',
    'If founding problem remained live into 20th century, early extraction may be justified coordination cost. If problem dissolved by 1860s (post-Land Wars), 150+ years of sovereignty doctrine operation is pure extraction. Timing determines when mandatrophy condition was met and whether current arrangement is degraded scaffold or entrenched snare.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(founding_problem_obsolescence_timing, empirical, 'When coordination function became obsolete and extraction became primary').

omega_variable(
    alternative_sovereignty_model_viability,
    'Could a partnership or co-sovereignty model coordinate colonial governance while preserving Māori rangatiratanga, or is Westminster parliamentary supremacy structurally necessary for territorial governance?',
    'Analysis of historical moments when co-sovereignty arrangements were proposed (1860s Native Land Court reforms, 1980s Treaty settlement process); comparative study of other jurisdictions with indigenous co-governance (Aotearoa local government models, Sami Parliaments, treaty federalism); examination of whether current Treaty settlement process could evolve into constitutional power-sharing.',
    'If alternatives are viable, sovereignty reading''s foreclosure of partnership/rangatiratanga models is pure extraction. If Westminster supremacy is structurally necessary, some measured extraction may be coordination cost. Evidence from local co-governance successes suggests alternatives are viable, supporting extraction interpretation.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(alternative_sovereignty_model_viability, conceptual, 'Whether parliamentary sovereignty is necessary or serves to foreclose viable alternatives').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(waitangi_sovereignty_allocation__crown_sovereignty_reading, 0, 180).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(wait_tr_t0, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 0, 0.12).
narrative_ontology:measurement_basis(wait_tr_t0, observed).
narrative_ontology:measurement(wait_tr_t30, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 30, 0.15).
narrative_ontology:measurement_basis(wait_tr_t30, observed).
narrative_ontology:measurement(wait_tr_t60, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 60, 0.18).
narrative_ontology:measurement_basis(wait_tr_t60, observed).
narrative_ontology:measurement(wait_tr_t90, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 90, 0.22).
narrative_ontology:measurement_basis(wait_tr_t90, observed).
narrative_ontology:measurement(wait_tr_t120, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 120, 0.25).
narrative_ontology:measurement_basis(wait_tr_t120, observed).
narrative_ontology:measurement(wait_tr_t150, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 150, 0.27).
narrative_ontology:measurement_basis(wait_tr_t150, observed).
narrative_ontology:measurement(wait_tr_t180, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 180, 0.28).
narrative_ontology:measurement_basis(wait_tr_t180, observed).

% Extraction over time
narrative_ontology:measurement(wait_be_t0, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 0, 0.58).
narrative_ontology:measurement_basis(wait_be_t0, observed).
narrative_ontology:measurement(wait_be_t30, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 30, 0.68).
narrative_ontology:measurement_basis(wait_be_t30, observed).
narrative_ontology:measurement(wait_be_t60, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 60, 0.74).
narrative_ontology:measurement_basis(wait_be_t60, observed).
narrative_ontology:measurement(wait_be_t90, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 90, 0.79).
narrative_ontology:measurement_basis(wait_be_t90, observed).
narrative_ontology:measurement(wait_be_t120, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 120, 0.81).
narrative_ontology:measurement_basis(wait_be_t120, observed).
narrative_ontology:measurement(wait_be_t150, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 150, 0.82).
narrative_ontology:measurement_basis(wait_be_t150, observed).
narrative_ontology:measurement(wait_be_t180, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 180, 0.82).
narrative_ontology:measurement_basis(wait_be_t180, observed).

% Suppression requirement over time
narrative_ontology:measurement(wait_su_t0, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 0, 0.72).
narrative_ontology:measurement_basis(wait_su_t0, observed).
narrative_ontology:measurement(wait_su_t30, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 30, 0.78).
narrative_ontology:measurement_basis(wait_su_t30, observed).
narrative_ontology:measurement(wait_su_t60, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 60, 0.82).
narrative_ontology:measurement_basis(wait_su_t60, observed).
narrative_ontology:measurement(wait_su_t90, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 90, 0.85).
narrative_ontology:measurement_basis(wait_su_t90, observed).
narrative_ontology:measurement(wait_su_t120, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 120, 0.87).
narrative_ontology:measurement_basis(wait_su_t120, observed).
narrative_ontology:measurement(wait_su_t150, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 150, 0.88).
narrative_ontology:measurement_basis(wait_su_t150, observed).
narrative_ontology:measurement(wait_su_t180, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 180, 0.88).
narrative_ontology:measurement_basis(wait_su_t180, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(waitangi_sovereignty_allocation__crown_sovereignty_reading, enforcement_mechanism).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__crown_sovereignty_reading, waitangi_sovereignty_allocation__partnership_reading).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__crown_sovereignty_reading, waitangi_sovereignty_allocation__rangatiratanga_reading).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__crown_sovereignty_reading, resource_management_act_treaty_principles).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__crown_sovereignty_reading, maori_land_court_jurisdiction).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__crown_sovereignty_reading, foreshore_seabed_legislation).

% DUAL FORMULATION NOTE:
% This constraint is one of three readings of the waitangi_sovereignty_allocation kernel. The crown_sovereignty_reading (ε=0.82) enables systematic extraction through parliamentary supremacy doctrine. The partnership_reading (separate story) would show lower ε through consent and consultation requirements. The rangatiratanga_reading (separate story) would show substantially lower ε or possible inversion by retaining Māori authority over lands and taonga. The readings are not different measurements of one constraint—they are different constraints instantiated from the same kernel text. Network links document how sovereignty reading forecloses partnership and rangatiratanga interpretations structurally and influences downstream Treaty-principles jurisprudence in resource management and land law.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
