% ============================================================================
% CONSTRAINT STORY: ai_governance_legitimacy__market_libertarian_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-19
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_ai_governance_legitimacy__market_libertarian_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: ai_governance_legitimacy__market_libertarian_reading
 *   human_readable: Market Libertarian AI Governance Framework (Property Rights as Pre-Political)
 *   domain: theological_ethics/technology_governance/political_theology
 *
 * SUMMARY:
 *   This constraint instantiates the market libertarian reading of the
 *   contested kernel 'AI governance legitimacy'. It grounds legitimacy in
 *   property rights and voluntary exchange, treating these as pre-political
 *   natural law rather than social construction. The encyclical's
 *   subsidiarity principle is selectively embraced for its decentralizing
 *   thrust while its solidarity demands are rejected as illegitimate
 *   coercion. The framework claims mountain status: it presents property
 *   rights as natural constraints that would persist regardless of
 *   institutional enforcement, deriving from human nature rather than
 *   collective choice. However, identifiable beneficiaries exist
 *   (entrepreneurs, investors, high-autonomy individuals who capture
 *   innovation rents and exercise exit options) alongside identifiable
 *   victims (those lacking market power, facing coordination failures, or
 *   trapped in monopsony labor markets). This beneficiary structure, combined
 *   with the framework's active exclusion of competing interpretive
 *   authorities, triggers FSM evaluation.
 *
 * KEY AGENTS:
 *   - entrepreneurs: Primary beneficiaries (powerful/arbitrage) — capture innovation rents under minimal constraint
 *   - investors: Primary beneficiaries (powerful/arbitrage) — protected investment returns
 *   - high_autonomy_individuals: Beneficiaries (moderate/mobile) — dignity secured through exit options
 *   - market_powerless_individuals: Primary victims (powerless/trapped) — bear algorithmic harms without recourse
 *   - coordination_failure_communities: Victims (organized/constrained) — collective harms unaddressed by individual transactions
 *   - monopsony_labor_market_workers: Victims (moderate/constrained) — formal exit freedom without substantive bargaining power
 *   - contractarian_theorists: Agenda setters (institutional/analytical) — provide philosophical grounding
 *   - magisterial_interpreters: Excluded (institutional/analytical) — interpretive authority rejected
 *   - democratic_accountability_advocates: Excluded (organized/constrained) — democratic mandates treated as illegitimate absent unanimity
 *   - political_theologians: Observers (institutional/analytical) — document structural divergence across readings
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(ai_governance_legitimacy__market_libertarian_reading, 0.28).
domain_priors:suppression_score(ai_governance_legitimacy__market_libertarian_reading, 0.22).
domain_priors:theater_ratio(ai_governance_legitimacy__market_libertarian_reading, 0.15).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, extractiveness, 0.28).
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 0.22).
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 0.15).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, accessibility_collapse, 0.82).
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, resistance, 0.35).

% --- Constraint claim ---
narrative_ontology:constraint_claim(ai_governance_legitimacy__market_libertarian_reading, mountain).
narrative_ontology:human_readable(ai_governance_legitimacy__market_libertarian_reading, "Market Libertarian AI Governance Framework (Property Rights as Pre-Political)").
narrative_ontology:topic_domain(ai_governance_legitimacy__market_libertarian_reading, "theological_ethics/technology_governance/political_theology").

domain_priors:requires_active_enforcement(ai_governance_legitimacy__market_libertarian_reading).
domain_priors:emerges_naturally(ai_governance_legitimacy__market_libertarian_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(ai_governance_legitimacy__market_libertarian_reading, 'aed8fa46-34c7-499f-988b-11d640a0f30a').
narrative_ontology:cs_kernel_codification('aed8fa46-34c7-499f-988b-11d640a0f30a', distributed).
narrative_ontology:cs_authority_grounding('aed8fa46-34c7-499f-988b-11d640a0f30a', expertise).
narrative_ontology:cs_reading_relation('aed8fa46-34c7-499f-988b-11d640a0f30a', ai_governance_legitimacy__magisterial_subsidiarity_reading, forecloses).
narrative_ontology:cs_reading_relation('aed8fa46-34c7-499f-988b-11d640a0f30a', ai_governance_legitimacy__democratic_pluralist_reading, coexists_with).
narrative_ontology:cs_reading_relation('aed8fa46-34c7-499f-988b-11d640a0f30a', ai_governance_legitimacy__technocratic_optimization_reading, influences).
narrative_ontology:cs_axiom('aed8fa46-34c7-499f-988b-11d640a0f30a', foundational, property_rights_prepolitical_natural_law).
narrative_ontology:cs_axiom_status(property_rights_prepolitical_natural_law, holdable).
narrative_ontology:cs_axiom_grounding('aed8fa46-34c7-499f-988b-11d640a0f30a', property_rights_prepolitical_natural_law, deontological).
narrative_ontology:cs_axiom('aed8fa46-34c7-499f-988b-11d640a0f30a', foundational, voluntary_exchange_sole_legitimate_coordination).
narrative_ontology:cs_axiom_status(voluntary_exchange_sole_legitimate_coordination, holdable).
narrative_ontology:cs_axiom_grounding('aed8fa46-34c7-499f-988b-11d640a0f30a', voluntary_exchange_sole_legitimate_coordination, deontological).
narrative_ontology:cs_axiom('aed8fa46-34c7-499f-988b-11d640a0f30a', secondary, markets_efficient_without_concentration_failures).
narrative_ontology:cs_axiom_status(markets_efficient_without_concentration_failures, holdable).
narrative_ontology:cs_axiom_grounding('aed8fa46-34c7-499f-988b-11d640a0f30a', markets_efficient_without_concentration_failures, empirically_contingent).
narrative_ontology:cs_reference_frame('aed8fa46-34c7-499f-988b-11d640a0f30a', lockean_natural_rights_framework).
narrative_ontology:cs_drift_state('aed8fa46-34c7-499f-988b-11d640a0f30a', contemporary_ai_market_concentration, gap(axiom_overriding, substantial, false)).
narrative_ontology:cs_created_at('aed8fa46-34c7-499f-988b-11d640a0f30a', '').
narrative_ontology:cs_kernel_id(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__market_libertarian_reading, entrepreneurs).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__market_libertarian_reading, investors).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__market_libertarian_reading, high_autonomy_individuals).
narrative_ontology:constraint_victim(ai_governance_legitimacy__market_libertarian_reading, market_powerless_individuals).
narrative_ontology:constraint_victim(ai_governance_legitimacy__market_libertarian_reading, coordination_failure_communities).
narrative_ontology:constraint_victim(ai_governance_legitimacy__market_libertarian_reading, monopsony_labor_market_workers).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Build AI systems under minimal regulatory constraint. Property rights protection allows them to capture innovation rents directly. Exit options include jurisdictional arbitrage and private governance structures. The framework treats their creative autonomy as pre-political right not subject to collective override.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, entrepreneurs, beneficiary,
    powerful, biographical, arbitrage, global).

% Deploy capital seeking highest risk-adjusted returns in AI markets. The framework protects investment returns from redistributive claims. Exit through portfolio diversification and jurisdictional choice. Contractual freedom maximizes capital allocation efficiency.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, investors, beneficiary,
    powerful, biographical, arbitrage, global).

% Navigate AI systems through consumer choice and competitive switching. Their preferences shape markets through exit and voice. The framework protects their freedom from collective mandates about technology use. Dignity is secured through option value, not centralized protection.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, high_autonomy_individuals, beneficiary,
    moderate, biographical, mobile, national).

% Face AI systems shaped by others' preferences and capital deployment. Lack resources to exercise meaningful exit or negotiate terms. Bear algorithmic harms without recourse when markets fail to provide alternatives. The framework treats their vulnerability as residual problem for charity, not structural claim on governance.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, market_powerless_individuals, payer,
    powerless, immediate, trapped, local).

% Experience collective harms from AI deployment that no individual transaction captures: environmental degradation, labor displacement, epistemic pollution. Cannot coordinate to bargain effectively with capital. The framework offers no mechanism for their interests to bind AI development absent property-right violation.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, coordination_failure_communities, payer,
    organized, generational, constrained, regional).

% Sell labor to AI-enabled employers in concentrated markets. Formal freedom to exit does not produce substantive bargaining power when alternative employers are scarce. The framework treats monopsony as efficiency-justified market structure, not governance failure requiring intervention.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, monopsony_labor_market_workers, payer,
    moderate, biographical, constrained, national).

% Provide philosophical grounding for treating property rights as pre-political. Interpret subsidiarity through Lockean rather than Catholic Social Doctrine lens. Their framework authorizes the constraint by deriving legitimacy from voluntary exchange rather than common good.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, contractarian_theorists, agenda_setter,
    institutional, generational, analytical, global).

% Assert that Catholic Social Doctrine subordinates property rights to common good and universal destination of goods. Their reading of subsidiarity includes solidarity as non-negotiable complement. Excluded because this framework rejects their interpretive authority over political legitimacy.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, magisterial_interpreters, excluded,
    institutional, civilizational, analytical, global).

% Argue AI governance requires democratic deliberation and collective authorization. Would impose participatory structures on technology development. Excluded because this framework treats democratic mandates as legitimate only when unanimous or constitutional.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, democratic_accountability_advocates, excluded,
    organized, generational, constrained, national).

% Analyze competing readings of how theological principles ground technology governance. Document the structural divergence between this reading's Lockean property-rights foundation and the encyclical's common-good priority. Their analysis reveals what counts as natural versus constructed in each framework.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, political_theologians, observer,
    institutional, civilizational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Solves the problem of allocating AI development resources and innovation incentives by treating property rights as pre-political coordination mechanism. Markets aggregate preferences without requiring collective deliberation.
% TRANSFER_FUNCTION: Protects innovation rents and investment returns by preventing redistribution claims from reaching them. Moves costs of coordination failure and monopsony power to those lacking exit options.
% ABSENT_VOICES: Magisterial interpreters who subordinate property to common good; democratic accountability advocates who require collective authorization; those harmed by coordination failures who lack property claims to ground standing. They are structurally excluded because the framework denies their authority to impose governance constraints absent property-right violation.
% DISAPPEARANCE_RATIONALE: If this framework disappeared, AI governance would become subject to democratic deliberation or magisterial interpretation. Property rights would no longer pre-empt solidarity claims. Innovation would face collective constraints. Markets would lose privileged status as legitimacy-conferring mechanism. The entire structure of who has standing to constrain AI development would reorganize.
% FOUNDING_PROBLEM: How to govern AI development in pluralistic society where no single tradition (religious or secular) commands consensus. The reading solves this by treating voluntary exchange as the only universally legitimate coordination mechanism, avoiding need for shared substantive values.
% FOUNDING_PROBLEM_CORROBORATION: Political philosophers in the social contract tradition attest the founding problem remains live. Catholic Social Doctrine scholars attest the problem is mis-specified: treating value pluralism as foundational rather than provisional concedes the ontological ground their tradition contests. Democratic theorists attest the reading solves pluralism by excluding democratic authority, not by achieving legitimate coordination.
narrative_ontology:disappearance_verdict(ai_governance_legitimacy__market_libertarian_reading, world_rearranges).
narrative_ontology:founding_problem_status(ai_governance_legitimacy__market_libertarian_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(ai_governance_legitimacy__market_libertarian_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(ai_governance_legitimacy__market_libertarian_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(ai_governance_legitimacy__market_libertarian_reading_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, ExtMetricName, E),
    domain_priors:suppression_score(ai_governance_legitimacy__market_libertarian_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(ai_governance_legitimacy__market_libertarian_reading),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(ai_governance_legitimacy__market_libertarian_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is low-moderate (0.28) because the framework does produce genuine coordination benefits through market aggregation of preferences, but these benefits are asymmetrically distributed: high-autonomy actors gain substantive freedom while market-powerless actors face costs the framework does not register as governance failures. Suppression is low (0.22) because the constraint does not require heavy coercive apparatus once property rights are established — but this low score reflects the framework's success at naturalizing its own categories, not absence of exclusion. Accessibility collapse is high (0.82) because once property rights are accepted as pre-political, alternatives that would subordinate them to common good become conceptually inaccessible within the framework. Resistance is moderate (0.35) because democratic and magisterial traditions mount sustained opposition, but the framework has substantial institutional support. Theater ratio is low (0.15) because enforcement mechanisms (contract law, private arbitration) are functional rather than performative. The measurements show modest drift as market concentration increases extraction slightly while maintaining low theater.
 *
 * PERSPECTIVAL GAP:
 *   Entrepreneurs and contractarian theorists should compute this as mountain: property rights appear to them as natural constraints discovered rather than constructed, coordination through markets as the only universally legitimate mechanism. Market-powerless individuals and coordination-failure communities should compute this as snare or tangled rope: the framework's naturalizing move excludes their claims from consideration while protecting asymmetric power. The engine measures this divergence from the structural data. The claimed type (mountain) reflects the reading's own self-understanding; the metrics capture the extraction and exclusion that self-understanding obscures.
 *
 * DIRECTIONALITY LOGIC:
 *   Entrepreneurs and investors sit near the beneficiary end (d ≈ 0.15): the framework protects their property claims and enables jurisdictional arbitrage. High-autonomy individuals are also beneficiaries (d ≈ 0.25) but with less extreme asymmetry. Market-powerless individuals sit near the target end (d ≈ 0.85): they bear costs the framework does not recognize as requiring governance response. Coordination-failure communities (d ≈ 0.70) and monopsony workers (d ≈ 0.65) fall between, harmed but not maximally so. Contractarian theorists as agenda setters benefit from the framework's intellectual legitimation (d ≈ 0.20). Excluded voices (magisterial interpreters, democratic advocates) experience the constraint as suppression of their authority claims (d ≈ 0.75).
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint claims mountain status (natural law) while serving identifiable beneficiaries and excluding competing interpretive authorities. This is the FSM signature pattern: a governance framework presenting itself as pre-political necessity while concentrating benefits and suppressing alternative readings. The mandatrophy analysis must distinguish genuine coordination (market aggregation does solve preference-revelation problems) from extraction disguised as nature (treating property rights as pre-political forecloses solidarity claims). The framework's founding problem (governing AI without value consensus) is contested: social contract theorists say it remains live, Catholic Social Doctrine scholars say it is mis-specified, democratic theorists say it is solved by exclusion rather than legitimate coordination. The disappearance test confirms this is not inert natural law: if the framework vanished, the structure of who has standing to constrain AI development would fundamentally reorganize.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    property_rights_naturality,
    'Are property rights in AI systems pre-political natural law (as this reading claims), or are they socially constructed institutions that rest on collective choice and can legitimately be subordinated to common good (as magisterial reading claims)?',
    'Comparative institutional analysis examining which societies with different property-rights regimes achieve better protection of human dignity; historical analysis of how property-rights frameworks emerged and changed; philosophical argument about whether any normative framework can be pre-political.',
    'If property rights are natural law, solidarity demands constitute illegitimate coercion and this constraint is a genuine mountain. If property rights are constructed, the framework''s mountain claim is false summit and extraction from market-powerless individuals requires governance response rather than being dismissed as residual problem.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(property_rights_naturality, conceptual, 'Whether property rights are discovered natural law or constructed institution subject to revision').

omega_variable(
    market_failure_scope,
    'What is the empirical scope of coordination failures and monopsony power in AI-enabled markets? Do these failures remain marginal (as framework assumes) or become systematic as market concentration increases?',
    'Longitudinal market-structure analysis tracking concentration, labor-market monopsony measures, welfare impact studies of algorithmic deployment on vulnerable populations, measurement of exit-option quality for different stakeholder groups.',
    'If failures are marginal, the framework''s extraction is coordination cost and mountain claim holds. If failures are systematic and growing, the victims list expands and the constraint operates as snare disguised as natural law — the FSM verdict is confirmed.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(market_failure_scope, empirical, 'Whether market failures in AI governance are marginal or systematic').

omega_variable(
    subsidiarity_solidarity_coupling,
    'Can subsidiarity (decentralization principle) be coherently separated from solidarity (mutual-aid principle) as this reading attempts, or are they structurally coupled in Catholic Social Doctrine such that accepting one commits you to the other?',
    'Theological analysis of encyclical tradition; examination of historical cases where subsidiarity was invoked without solidarity to determine if this produces stable doctrine or performative contradiction; magisterial commentary on whether selective appropriation of principles is legitimate.',
    'If principles are separable, this reading''s selective appropriation is coherent and its rejection of solidarity demands is philosophically legitimate. If principles are structurally coupled, the reading''s move is incoherent and its claim to ground legitimacy in subsidiarity collapses — it would be extracting rhetorical cover from a tradition whose core claims it rejects.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(subsidiarity_solidarity_coupling, conceptual, 'Whether subsidiarity and solidarity are separable principles or structurally coupled').

omega_variable(
    exit_dignity_sufficiency,
    'Is exit-option availability sufficient to protect human dignity in AI systems (as this reading claims), or does dignity require substantive conditions that markets alone may not provide?',
    'Philosophical analysis of dignity concepts; empirical studies comparing dignity outcomes in high-exit versus low-exit market structures; examination of whether formal freedom produces substantive autonomy when actors face severe resource asymmetries.',
    'If exit suffices, the framework''s low suppression score is accurate and victims'' harms are self-inflicted failures to exit. If dignity requires substantive conditions beyond exit, the framework''s treatment of market-powerless individuals as residual problem rather than governance failure is itself a form of extraction — the constraint operates to protect high-autonomy actors'' freedom while abandoning those who lack exit capacity.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(exit_dignity_sufficiency, conceptual, 'Whether exit options alone suffice to protect human dignity or substantive conditions are required').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(ai_governance_legitimacy__market_libertarian_reading, 0, 30).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(ai_g_tr_t0, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 0, 0.12).
narrative_ontology:measurement(ai_g_tr_t6, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 6, 0.13).
narrative_ontology:measurement(ai_g_tr_t12, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 12, 0.14).
narrative_ontology:measurement(ai_g_tr_t18, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 18, 0.14).
narrative_ontology:measurement(ai_g_tr_t24, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 24, 0.15).
narrative_ontology:measurement(ai_g_tr_t30, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 30, 0.15).

% Extraction over time
narrative_ontology:measurement(ai_g_be_t0, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 0, 0.22).
narrative_ontology:measurement(ai_g_be_t6, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 6, 0.24).
narrative_ontology:measurement(ai_g_be_t12, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 12, 0.26).
narrative_ontology:measurement(ai_g_be_t18, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 18, 0.27).
narrative_ontology:measurement(ai_g_be_t24, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 24, 0.28).
narrative_ontology:measurement(ai_g_be_t30, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 30, 0.28).

% Suppression requirement over time
narrative_ontology:measurement(ai_g_su_t0, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 0, 0.18).
narrative_ontology:measurement(ai_g_su_t6, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 6, 0.19).
narrative_ontology:measurement(ai_g_su_t12, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 12, 0.2).
narrative_ontology:measurement(ai_g_su_t18, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 18, 0.21).
narrative_ontology:measurement(ai_g_su_t24, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 24, 0.22).
narrative_ontology:measurement(ai_g_su_t30, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 30, 0.22).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(ai_governance_legitimacy__market_libertarian_reading, resource_allocation).
narrative_ontology:affects_constraint(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy__magisterial_subsidiarity_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy__democratic_pluralist_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy__technocratic_optimization_reading).

% DUAL FORMULATION NOTE:
% This constraint is part of the ai_governance_legitimacy kernel family (4 readings). Each reading derives governance legitimacy from different foundational principles and produces different beneficiary/victim structures. This market_libertarian_reading has lowest measured extraction (0.28) because it offloads costs to those without property claims, enabling minimal-intervention framing. The magisterial_subsidiarity_reading subordinates property to common good; the democratic_pluralist_reading requires collective authorization; the technocratic_optimization_reading treats ethical constraints as secondary parameters. Network edges model mutual influence: this reading's property-rights naturalization affects how other readings must argue; magisterial reading's solidarity demands affect this reading's legitimacy claims.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
