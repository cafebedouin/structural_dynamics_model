% ============================================================================
% CONSTRAINT STORY: ai_governance_legitimacy__magisterial_subsidiarity_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_ai_governance_legitimacy__magisterial_subsidiarity_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: ai_governance_legitimacy__magisterial_subsidiarity_reading
 *   human_readable: AI Governance via Magisterial Catholic Social Doctrine
 *   domain: theological_ethics/technology_governance/political_theology
 *
 * SUMMARY:
 *   This constraint instantiates the Magisterial reading of AI governance
 *   legitimacy within Catholic Social Thought. It centers conformity to CST
 *   principles—common good, subsidiarity, solidarity, universal destination
 *   of goods—as authoritatively interpreted by the Church's teaching office.
 *   Technology is subordinated to these principles through demands for
 *   transparent accountability, participatory governance structures, and
 *   protection of vulnerable populations. The encyclical explicitly rejects
 *   pure technocratic optimization and market libertarian frameworks,
 *   positioning them as inadequate to protect human dignity. This is ONE
 *   reading of a contested kernel; sibling readings ground legitimacy in
 *   democratic pluralism, technocratic performance, or market mechanisms.
 *
 * KEY AGENTS:
 *   - magisterium: Agenda-setter (institutional/analytical) — issues authoritative interpretations of CST principles for AI governance
 *   - workers: Beneficiary (organized/constrained) — protected by subsidiarity and dignity principles
 *   - global_south_populations: Beneficiary (powerless/trapped) — solidarity demands inclusion and protection from exploitation
 *   - families: Beneficiary (moderate/constrained) — common good centers their flourishing
 *   - marginalized_communities: Beneficiary (powerless/trapped) — universal destination of goods requires access and protection
 *   - ecclesial_institutions: Beneficiary (institutional/mobile) — gain standing in governance arenas under CST frameworks
 *   - private_tech_monopolies: Payer (powerful/mobile) — must subordinate profit to dignity; resist via lobbying
 *   - military_industrial_complex: Payer (institutional/constrained) — autonomous weapons and surveillance challenged by solidarity
 *   - extractive_finance_actors: Payer (powerful/arbitrage) — predatory exclusion challenged by universal destination principle
 *   - secular_governance_actors: Excluded (institutional/mobile) — democratic legitimation marginalized by Magisterial authority claim
 *   - technocratic_experts: Excluded (organized/mobile) — professional authority subordinated to doctrinal interpretation
 *   - competition_authorities: Observer (institutional/analytical) — evaluate constraint's market discipline effects
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(ai_governance_legitimacy__magisterial_subsidiarity_reading, 0.5).
domain_priors:suppression_score(ai_governance_legitimacy__magisterial_subsidiarity_reading, 0.62).
domain_priors:theater_ratio(ai_governance_legitimacy__magisterial_subsidiarity_reading, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__magisterial_subsidiarity_reading, extractiveness, 0.5).
narrative_ontology:constraint_metric(ai_governance_legitimacy__magisterial_subsidiarity_reading, suppression_requirement, 0.62).
narrative_ontology:constraint_metric(ai_governance_legitimacy__magisterial_subsidiarity_reading, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__magisterial_subsidiarity_reading, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(ai_governance_legitimacy__magisterial_subsidiarity_reading, resistance, 0.58).

% --- Constraint claim ---
narrative_ontology:constraint_claim(ai_governance_legitimacy__magisterial_subsidiarity_reading, tangled_rope).
narrative_ontology:human_readable(ai_governance_legitimacy__magisterial_subsidiarity_reading, "AI Governance via Magisterial Catholic Social Doctrine").
narrative_ontology:topic_domain(ai_governance_legitimacy__magisterial_subsidiarity_reading, "theological_ethics/technology_governance/political_theology").

domain_priors:requires_active_enforcement(ai_governance_legitimacy__magisterial_subsidiarity_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(ai_governance_legitimacy__magisterial_subsidiarity_reading, '904a75b0-ae03-4527-b1f9-fd7827ea6c23').
narrative_ontology:cs_kernel_codification('904a75b0-ae03-4527-b1f9-fd7827ea6c23', formalized).
narrative_ontology:cs_authority_grounding('904a75b0-ae03-4527-b1f9-fd7827ea6c23', lineage).
narrative_ontology:cs_interpretation_layer_present('904a75b0-ae03-4527-b1f9-fd7827ea6c23').
narrative_ontology:cs_reading_relation('904a75b0-ae03-4527-b1f9-fd7827ea6c23', ai_governance_legitimacy__democratic_pluralist_reading, coexists_with).
narrative_ontology:cs_reading_relation('904a75b0-ae03-4527-b1f9-fd7827ea6c23', ai_governance_legitimacy__technocratic_optimization_reading, influences).
narrative_ontology:cs_reading_relation('904a75b0-ae03-4527-b1f9-fd7827ea6c23', ai_governance_legitimacy__market_libertarian_reading, influences).
narrative_ontology:cs_axiom('904a75b0-ae03-4527-b1f9-fd7827ea6c23', foundational, magisterial_interpretive_authority_over_technology).
narrative_ontology:cs_axiom_status(magisterial_interpretive_authority_over_technology, holdable).
narrative_ontology:cs_axiom_grounding('904a75b0-ae03-4527-b1f9-fd7827ea6c23', magisterial_interpretive_authority_over_technology, theological).
narrative_ontology:cs_axiom('904a75b0-ae03-4527-b1f9-fd7827ea6c23', foundational, human_dignity_primacy_over_efficiency).
narrative_ontology:cs_axiom_status(human_dignity_primacy_over_efficiency, holdable).
narrative_ontology:cs_axiom_grounding('904a75b0-ae03-4527-b1f9-fd7827ea6c23', human_dignity_primacy_over_efficiency, deontological).
narrative_ontology:cs_axiom('904a75b0-ae03-4527-b1f9-fd7827ea6c23', secondary, solidarity_demands_protection_of_vulnerable).
narrative_ontology:cs_axiom_status(solidarity_demands_protection_of_vulnerable, holdable).
narrative_ontology:cs_axiom_grounding('904a75b0-ae03-4527-b1f9-fd7827ea6c23', solidarity_demands_protection_of_vulnerable, deontological).
narrative_ontology:cs_reference_frame('904a75b0-ae03-4527-b1f9-fd7827ea6c23', vatican_ii_social_encyclical_tradition).
narrative_ontology:cs_drift_state('904a75b0-ae03-4527-b1f9-fd7827ea6c23', contemporary_ai_governance_discourse, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('904a75b0-ae03-4527-b1f9-fd7827ea6c23', '').
narrative_ontology:cs_kernel_id(ai_governance_legitimacy__magisterial_subsidiarity_reading, ai_governance_legitimacy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__magisterial_subsidiarity_reading, workers).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__magisterial_subsidiarity_reading, global_south_populations).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__magisterial_subsidiarity_reading, families).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__magisterial_subsidiarity_reading, marginalized_communities).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__magisterial_subsidiarity_reading, ecclesial_institutions).
narrative_ontology:constraint_victim(ai_governance_legitimacy__magisterial_subsidiarity_reading, private_tech_monopolies).
narrative_ontology:constraint_victim(ai_governance_legitimacy__magisterial_subsidiarity_reading, military_industrial_complex).
narrative_ontology:constraint_victim(ai_governance_legitimacy__magisterial_subsidiarity_reading, extractive_finance_actors).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% The authoritative teaching office of the Catholic Church. Issues encyclicals and doctrinal statements establishing normative principles for technology governance. Claims interpretive authority over how the common good, subsidiarity, solidarity, and universal destination of goods apply to AI systems. Exercises influence through moral teaching, not coercive state power.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, magisterium, agenda_setter,
    institutional, civilizational, analytical, global).

% Those whose labor is displaced or degraded by AI automation. The reading's subsidiarity principle demands governance structures that protect their agency and dignity. Benefit from constraints that require participatory oversight and reject pure efficiency optimization. Their ability to exit automation pressures depends on collective organization and policy intervention.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, workers, beneficiary,
    organized, biographical, constrained, global).

% Communities in developing regions bearing disproportionate costs of AI deployment (data extraction, environmental externalities, automated exclusion from services). The solidarity principle demands their inclusion in governance and protection from exploitation. They lack market power or technical capacity to shape systems unilaterally.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, global_south_populations, beneficiary,
    powerless, generational, trapped, continental).

% Household units whose formation, stability, and child-rearing capacity is affected by algorithmic labor markets, surveillance, and content moderation. The common good principle centers their flourishing as a social priority. Benefit from constraints that subordinate technological efficiency to relational goods. Their exit from platform ecosystems is constrained by network effects.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, families, beneficiary,
    moderate, generational, constrained, local).

% Groups systematically excluded or harmed by algorithmic systems: refugees, disabled persons, linguistic minorities, the incarcerated. The universal destination of goods principle demands their access to AI's benefits. Constraint requires governance to center their protection. They have minimal voice in current technology development.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, marginalized_communities, beneficiary,
    powerless, biographical, trapped, national).

% The network of Catholic social organizations, charities, universities, and advocacy bodies. Gain institutional standing and normative influence when governance frameworks adopt CST principles. Their participation in civil society coalitions and international law advocacy becomes structurally privileged under this reading. Can pivot resources across multiple governance arenas.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, ecclesial_institutions, beneficiary,
    institutional, civilizational, mobile, global).

% Corporations whose business models depend on unregulated data extraction, algorithmic optimization for engagement, and platform lock-in. The constraint demands they subordinate profit maximization to dignity and common good criteria, accept transparency mandates, and share governance with stakeholders. They resist through lobbying, forum-shopping across jurisdictions, and rhetorical capture of subsidiarity language to oppose oversight.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, private_tech_monopolies, payer,
    powerful, biographical, mobile, global).

% Defense contractors and national security agencies deploying autonomous weapons and mass surveillance. The constraint's rejection of pure technocratic logic and its solidarity demands threaten autonomous lethality programs and dragnet data collection. They bear costs of compliance with human dignity standards in lethal force decisions. Exit requires abandoning core mission functions.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, military_industrial_complex, payer,
    institutional, generational, constrained, national).

% Algorithmic traders, predatory lenders, automated credit-scoring platforms. The universal destination of goods principle challenges their exclusion of the poor from financial access; the common good principle subordinates their short-term extraction to long-term stability. They bear compliance costs and reduced margins under governance that prioritizes inclusion. They exit via regulatory arbitrage to permissive jurisdictions.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, extractive_finance_actors, payer,
    powerful, immediate, arbitrage, global).

% Non-Catholic policymakers, UN agencies, democratic legislatures operating under pluralist frameworks. The constraint centers Magisterial interpretation as authoritative, marginalizing other ethical traditions and democratic deliberation as co-equal sources. They would argue for public reason and inclusive legitimation processes but are positioned as secondary under this reading's authority structure.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, secular_governance_actors, excluded,
    institutional, generational, mobile, national).

% AI researchers, engineers, and policy analysts whose professional identity grounds legitimacy in demonstrated technical competence and performance metrics. The constraint subordinates their expertise to theological principles they do not share. They would demand that governance optimize for measurable outcomes, not conformity to doctrinal interpretation.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, technocratic_experts, excluded,
    organized, biographical, mobile, global).

% Antitrust regulators evaluating AI monopolies under competition law. They analyze whether CST-grounded governance constraints market concentration, and whether ecclesial advocacy coalitions effectively discipline extractive actors. They measure the constraint's effectiveness independently of its theological framing.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, competition_authorities, observer,
    institutional, generational, analytical, national).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a stable normative framework grounded in a multi-century tradition for evaluating AI governance questions. Coordinates civil society actors, labor organizations, and international advocacy bodies around shared principles. Offers thick ethical concepts (dignity, solidarity, subsidiarity) that resist reduction to efficiency metrics.
% TRANSFER_FUNCTION: Transfers normative authority from secular technocratic expertise and democratic pluralism to Magisterial interpretation. Moves governance legitimacy from performance metrics and consent of the governed to conformity with CST principles. Transfers institutional standing to ecclesial organizations in policy arenas.
% ABSENT_VOICES: Secular democratic publics who ground legitimacy in inclusive deliberation rather than doctrinal authority. Non-Catholic religious traditions with competing theological frameworks. Technocratic experts whose professional authority is subordinated. All are structurally positioned as secondary under this reading's interpretive monopoly claim.
% DISAPPEARANCE_RATIONALE: If this constraint vanished, CST advocates argue AI governance would collapse into pure market logic or technocratic optimization, losing protections for the vulnerable. Secular pluralists argue governance would proceed through democratic institutions and public reason without epistemic loss. The dispute is over whether CST's thick concepts are necessary or one voice among many.
% FOUNDING_PROBLEM: Early AI governance discourse was dominated by utilitarian efficiency optimization and corporate self-regulation, with no structural protection for human dignity, worker agency, or the Global South. The vulnerable were systematically excluded from governance conversations.
% FOUNDING_PROBLEM_CORROBORATION: Civil society organizations, labor unions, and international human rights bodies consistently report that AI governance remains captured by corporate interests and technocratic framing. Independent scholarship on algorithmic accountability documents ongoing exclusion of marginalized voices. This corroboration comes from outside the ecclesial beneficiary set.
narrative_ontology:disappearance_verdict(ai_governance_legitimacy__magisterial_subsidiarity_reading, contested).
narrative_ontology:founding_problem_status(ai_governance_legitimacy__magisterial_subsidiarity_reading, live).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(ai_governance_legitimacy__magisterial_subsidiarity_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(ai_governance_legitimacy__magisterial_subsidiarity_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(ai_governance_legitimacy__magisterial_subsidiarity_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(ai_governance_legitimacy__magisterial_subsidiarity_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(ai_governance_legitimacy__magisterial_subsidiarity_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness (0.50) is substantial but not maximal: the constraint genuinely coordinates civil society actors and provides thick ethical concepts that resist metric reduction, but it also transfers interpretive authority from democratic publics to an institutional hierarchy and marginalizes non-Catholic ethical traditions. Suppression (0.62) reflects the enforcement requirement: moral suasion, civil society pressure, and ecclesial witness must be sustained to discipline extractive actors who have exit options. Theater ratio (0.28) is moderate-low: CST advocacy has real institutional effects in international law and corporate accountability, but some performative adoption occurs without structural compliance. Accessibility collapse (0.48) and resistance (0.58) reflect the constraint's contested status: alternatives (pluralist, technocratic, market frameworks) remain live and vigorously defended.
 *
 * PERSPECTIVAL GAP:
 *   From the ecclesial beneficiary seats, the constraint is a genuine coordination mechanism that protects human dignity against technocratic reductionism and market fundamentalism. From secular pluralist and technocratic seats, the same structure operates as extraction: it privileges one interpretive tradition over democratic deliberation and technical expertise, creating asymmetric authority without consent. The engine computes this divergence from the structural data—the authored claim as tangled_rope names the entanglement of coordination (thick ethical concepts, civil society coordination) with extraction (interpretive monopoly, marginalization of pluralist voices).
 *
 * DIRECTIONALITY LOGIC:
 *   The Magisterium and ecclesial institutions are structural beneficiaries: they gain interpretive authority and institutional standing. Workers, Global South populations, families, and marginalized communities are beneficiaries of the constraint's operation: subsidiarity and solidarity principles demand protections they lack under alternative frameworks. Private tech monopolies, the military-industrial complex, and extractive finance actors are targets: they bear compliance costs and reduced autonomy. Secular governance actors and technocratic experts are excluded rather than coordinated: their legitimation claims are structurally subordinated.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint resists pure snare classification because it provides real coordination goods: a stable normative framework, civil society coalition-building, and concepts that resist reduction to efficiency metrics. It resists pure rope classification because it extracts epistemic authority from democratic publics and marginalizes non-Catholic traditions without their consent. The tangled_rope designation captures this: beneficiaries (the vulnerable) and victims (extractive actors) are distinct, but the coordination function (ethical stability) and the extraction (interpretive monopoly) are inseparable in the constraint's operation. Mandatrophy is avoided by naming both functions explicitly.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    interpretive_authority_legitimacy,
    'Does Magisterial interpretation of CST principles constitute legitimate authority for secular AI governance, or does it require democratic validation through inclusive public reason?',
    'Observation of governance outcomes in jurisdictions that adopt CST frameworks versus pluralist frameworks. Measurement of stakeholder consent and voluntary adoption versus compliance under ecclesial pressure. Analysis of whether CST-grounded policies persist when ecclesial influence wanes.',
    'If Magisterial authority requires democratic validation, the constraint''s coordination function persists but its extraction (interpretive monopoly) becomes illegitimate, shifting the reading toward democratic_pluralist_reading. If authority is self-validating, the constraint operates as claimed.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(interpretive_authority_legitimacy, conceptual, 'Whether ecclesial interpretive authority is legitimate in secular governance without democratic consent').

omega_variable(
    subsidiarity_scope_ambiguity,
    'Does the subsidiarity principle demand decentralized participatory governance (requiring dismantling of tech monopolies), or does it permit concentrated institutional authority when justified by the common good?',
    'Theological debate within the Magisterium and among CST scholars. Observation of whether ecclesial advocacy supports antitrust enforcement or accommodates corporate concentration with ethical guidelines.',
    'A strong subsidiarity reading increases suppression of tech monopolies and reduces the constraint''s extractiveness (more distributed authority). A weak reading permits monopolistic coordination under ethical constraints, raising extractiveness.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(subsidiarity_scope_ambiguity, conceptual, 'Internal tension within CST between subsidiarity (decentralization) and common good (potentially centralized coordination)').

omega_variable(
    enforcement_mechanism_effectiveness,
    'Can moral suasion, civil society pressure, and ecclesial witness effectively discipline powerful tech monopolies and military actors, or does the constraint require state coercion to enforce compliance?',
    'Observation of corporate behavior in response to ecclesial advocacy versus legal mandates. Measurement of whether voluntary CST adoption leads to structural change or performative compliance.',
    'If enforcement requires state power, the constraint''s suppression is understated and its extraction shifts from ecclesial institutions to state actors. If moral suasion suffices, the constraint operates as described.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(enforcement_mechanism_effectiveness, empirical, 'Whether non-coercive ecclesial enforcement mechanisms can discipline extractive actors').

omega_variable(
    coordination_extraction_separability,
    'Can the constraint''s coordination function (thick ethical concepts, civil society coalition-building) be separated from its extraction (interpretive monopoly, marginalization of pluralist voices)?',
    'Natural experiment: jurisdictions that adopt CST-derived principles through democratic deliberation without ecclesial authority claims. Observation of whether the principles retain their coordination power when reframed in pluralist language.',
    'If separable, the tangled_rope classification shifts toward rope (coordination without extraction). If inseparable, the tangled_rope designation is structural and the constraint cannot be purified.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(coordination_extraction_separability, conceptual, 'Whether coordination and extraction are structurally entangled or accidentally coupled').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(ai_governance_legitimacy__magisterial_subsidiarity_reading, 0, 30).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(ai_g_tr_t0, ai_governance_legitimacy__magisterial_subsidiarity_reading, theater_ratio, 0, 0.2).
narrative_ontology:measurement(ai_g_tr_t6, ai_governance_legitimacy__magisterial_subsidiarity_reading, theater_ratio, 6, 0.22).
narrative_ontology:measurement(ai_g_tr_t12, ai_governance_legitimacy__magisterial_subsidiarity_reading, theater_ratio, 12, 0.24).
narrative_ontology:measurement(ai_g_tr_t18, ai_governance_legitimacy__magisterial_subsidiarity_reading, theater_ratio, 18, 0.26).
narrative_ontology:measurement(ai_g_tr_t24, ai_governance_legitimacy__magisterial_subsidiarity_reading, theater_ratio, 24, 0.27).
narrative_ontology:measurement(ai_g_tr_t30, ai_governance_legitimacy__magisterial_subsidiarity_reading, theater_ratio, 30, 0.28).

% Extraction over time
narrative_ontology:measurement(ai_g_be_t0, ai_governance_legitimacy__magisterial_subsidiarity_reading, base_extractiveness, 0, 0.42).
narrative_ontology:measurement(ai_g_be_t6, ai_governance_legitimacy__magisterial_subsidiarity_reading, base_extractiveness, 6, 0.44).
narrative_ontology:measurement(ai_g_be_t12, ai_governance_legitimacy__magisterial_subsidiarity_reading, base_extractiveness, 12, 0.46).
narrative_ontology:measurement(ai_g_be_t18, ai_governance_legitimacy__magisterial_subsidiarity_reading, base_extractiveness, 18, 0.48).
narrative_ontology:measurement(ai_g_be_t24, ai_governance_legitimacy__magisterial_subsidiarity_reading, base_extractiveness, 24, 0.49).
narrative_ontology:measurement(ai_g_be_t30, ai_governance_legitimacy__magisterial_subsidiarity_reading, base_extractiveness, 30, 0.5).

% Suppression requirement over time
narrative_ontology:measurement(ai_g_su_t0, ai_governance_legitimacy__magisterial_subsidiarity_reading, suppression_requirement, 0, 0.5).
narrative_ontology:measurement(ai_g_su_t6, ai_governance_legitimacy__magisterial_subsidiarity_reading, suppression_requirement, 6, 0.53).
narrative_ontology:measurement(ai_g_su_t12, ai_governance_legitimacy__magisterial_subsidiarity_reading, suppression_requirement, 12, 0.56).
narrative_ontology:measurement(ai_g_su_t18, ai_governance_legitimacy__magisterial_subsidiarity_reading, suppression_requirement, 18, 0.58).
narrative_ontology:measurement(ai_g_su_t24, ai_governance_legitimacy__magisterial_subsidiarity_reading, suppression_requirement, 24, 0.6).
narrative_ontology:measurement(ai_g_su_t30, ai_governance_legitimacy__magisterial_subsidiarity_reading, suppression_requirement, 30, 0.62).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(ai_governance_legitimacy__magisterial_subsidiarity_reading, identity_coordination).
narrative_ontology:affects_constraint(ai_governance_legitimacy__magisterial_subsidiarity_reading, ai_governance_legitimacy__democratic_pluralist_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__magisterial_subsidiarity_reading, ai_governance_legitimacy__technocratic_optimization_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__magisterial_subsidiarity_reading, ai_governance_legitimacy__market_libertarian_reading).

% DUAL FORMULATION NOTE:
% This constraint is one of four sibling readings decomposing the ai_governance_legitimacy kernel. Each reading instantiates a distinct constraint with its own ε, beneficiary/victim structure, and type. The magisterial_subsidiarity_reading claims substantially higher extractiveness than democratic_pluralist_reading (which distributes interpretive authority) but lower than technocratic_optimization_reading (which concentrates authority in expert classes without ethical constraint). All four readings link via network.affects_constraints to establish the constraint family.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
