% ============================================================================
% CONSTRAINT STORY: westphalia_sovereignty__graded_sovereignty
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_westphalia_sovereignty__graded_sovereignty, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: westphalia_sovereignty__graded_sovereignty
 *   human_readable: Graded Sovereignty: Capacity-Calibrated Intervention Authority
 *   domain: international_law/political_theory
 *
 * SUMMARY:
 *   The graded sovereignty reading reconceptualizes territorial authority as
 *   a scalar property rather than a binary status. States exist on a spectrum
 *   from full sovereignty (high-capacity Western democracies) to nominal
 *   sovereignty (failed or fragile states), with intervention legitimacy
 *   calibrated to assessed capacity deficits. This reading emerged from
 *   post-Cold War humanitarian crises and state failures, gaining
 *   institutional expression through governance indicators, development
 *   conditionality, and stabilization doctrines. The framework is claimed as
 *   descriptive realism acknowledging state heterogeneity; critics read it as
 *   prescriptive hierarchy that produces the tiering it purports to measure.
 *   The claim/metric gap is deliberate: the constraint is claimed as
 *   tangled_rope (genuine coordination function addressing real capacity
 *   variance, with extractive overhead) while metrics describe substantial
 *   extraction and active enforcement—the engine measures the divergence.
 *
 * KEY AGENTS:
 *   - capacity_assessment_institutions: agenda_setter (institutional/arbitrage) — develop and administer the metrics determining state position on sovereignty spectrum
 *   - intervening_powers: beneficiary (institutional/mobile) — gain doctrinal cover for operations that absolute sovereignty would bar
 *   - low_capacity_states: payer (powerless/trapped) — subject to external oversight and intervention calibrated to their deficits
 *   - populations_under_paternalistic_oversight: payer (powerless/trapped) — lose collective self-determination under capacity-based intervention
 *   - international_legal_scholars: observer (analytical/analytical) — analyze whether framework describes or produces hierarchy
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(westphalia_sovereignty__graded_sovereignty, 0.68).
domain_priors:suppression_score(westphalia_sovereignty__graded_sovereignty, 0.71).
domain_priors:theater_ratio(westphalia_sovereignty__graded_sovereignty, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, extractiveness, 0.68).
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, suppression_requirement, 0.71).
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, resistance, 0.64).

% --- Constraint claim ---
narrative_ontology:constraint_claim(westphalia_sovereignty__graded_sovereignty, tangled_rope).
narrative_ontology:human_readable(westphalia_sovereignty__graded_sovereignty, "Graded Sovereignty: Capacity-Calibrated Intervention Authority").
narrative_ontology:topic_domain(westphalia_sovereignty__graded_sovereignty, "international_law/political_theory").

domain_priors:requires_active_enforcement(westphalia_sovereignty__graded_sovereignty).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(westphalia_sovereignty__graded_sovereignty, '1c7e96d0-48ff-4fd9-b87f-d4101bb77469').
narrative_ontology:cs_kernel_codification('1c7e96d0-48ff-4fd9-b87f-d4101bb77469', distributed).
narrative_ontology:cs_authority_grounding('1c7e96d0-48ff-4fd9-b87f-d4101bb77469', expertise).
narrative_ontology:cs_interpretation_layer_present('1c7e96d0-48ff-4fd9-b87f-d4101bb77469').
narrative_ontology:cs_reading_relation('1c7e96d0-48ff-4fd9-b87f-d4101bb77469', westphalia_sovereignty__absolute_non_intervention, influences).
narrative_ontology:cs_reading_relation('1c7e96d0-48ff-4fd9-b87f-d4101bb77469', westphalia_sovereignty__conditional_responsibility, coexists_with).
narrative_ontology:cs_axiom('1c7e96d0-48ff-4fd9-b87f-d4101bb77469', foundational, sovereignty_as_earned_capacity).
narrative_ontology:cs_axiom_status(sovereignty_as_earned_capacity, holdable).
narrative_ontology:cs_axiom_grounding('1c7e96d0-48ff-4fd9-b87f-d4101bb77469', sovereignty_as_earned_capacity, empirically_contingent).
narrative_ontology:cs_axiom('1c7e96d0-48ff-4fd9-b87f-d4101bb77469', foundational, intervention_legitimacy_scales_with_deficit).
narrative_ontology:cs_axiom_status(intervention_legitimacy_scales_with_deficit, holdable).
narrative_ontology:cs_axiom_grounding('1c7e96d0-48ff-4fd9-b87f-d4101bb77469', intervention_legitimacy_scales_with_deficit, instrumental).
narrative_ontology:cs_reference_frame('1c7e96d0-48ff-4fd9-b87f-d4101bb77469', westphalian_formal_equality).
narrative_ontology:cs_drift_state('1c7e96d0-48ff-4fd9-b87f-d4101bb77469', post_cold_war_humanitarian_era, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('1c7e96d0-48ff-4fd9-b87f-d4101bb77469', '').
narrative_ontology:cs_kernel_id(westphalia_sovereignty__graded_sovereignty, westphalia_sovereignty).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, capacity_assessment_institutions).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, intervening_powers).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, development_agencies).
narrative_ontology:constraint_victim(westphalia_sovereignty__graded_sovereignty, low_capacity_states).
narrative_ontology:constraint_victim(westphalia_sovereignty__graded_sovereignty, populations_under_paternalistic_oversight).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, high_capacity_democracies).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__graded_sovereignty, liberal_internationalist_order).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__graded_sovereignty, graduated_sovereignty_doctrine).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Develop and administer the metrics by which state capacity is measured: governance indicators, rule-of-law scores, institutional quality assessments. Their methodologies determine which states sit where on the sovereignty spectrum and thus which are subject to external oversight. Collect funding and legitimacy from their role as neutral arbiters of state functionality.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, capacity_assessment_institutions, agenda_setter,
    institutional, generational, arbitrage, global).

% Use capacity deficits as legal justification for intervention in weak states—humanitarian missions, stabilization operations, regime support or replacement. The graded framework provides doctrinal cover for actions that would violate absolute sovereignty norms. They benefit from expanded operational latitude and reduced diplomatic cost.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, intervening_powers, beneficiary,
    institutional, generational, mobile, global).

% Administer capacity-building programs in states classified as deficient, operating with reduced sovereignty constraints on their conditions and oversight. The graded framework justifies intrusive conditionality and administrative substitution as legitimate responses to measured deficits rather than neo-colonial overreach.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, development_agencies, beneficiary,
    institutional, biographical, mobile, global).

% Subject to external intervention, conditional aid, and administrative oversight calibrated to their assessed capacity deficits. Cannot credibly threaten exit from the international system; their weakness is both the measured condition and the structural constraint on resistance. Bear the sovereignty costs that high-capacity states do not.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, low_capacity_states, payer,
    powerless, generational, trapped, national).

% Live under regimes whose sovereignty is discounted by external assessment, making them subject to interventions their own state cannot prevent. The framework positions them as beneficiaries of protection but deprives them of collective self-determination—their political agency is superseded by the capacity judgment.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, populations_under_paternalistic_oversight, payer,
    powerless, biographical, trapped, national).

% Enjoy full territorial inviolability while sitting atop the capacity hierarchy. The graded framework affirms their sovereignty as earned rather than inherent, which justifies the asymmetric treatment of weaker states. They set the standards by which capacity is measured and are structurally insulated from ever falling below the threshold.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, high_capacity_democracies, beneficiary,
    institutional, generational, arbitrage, global).

% Advocate for categorical territorial inviolability regardless of internal capacity. They are excluded from the standard-setting process that produces capacity metrics and from the intervention-authorization decisions those metrics enable. Their position is treated as obsolete post-colonial nostalgia rather than a live legal doctrine.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, sovereignty_absolutists, excluded,
    organized, generational, constrained, global).

% Analyze whether graded sovereignty is a descriptive recognition of existing state heterogeneity or a prescriptive framework that produces the hierarchy it claims to measure. They document the distributional consequences and doctrinal tensions but do not set policy.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, international_legal_scholars, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Acknowledges the empirical reality that states vary dramatically in capacity to govern, maintain order, and protect populations; provides a doctrinal framework for international response calibrated to actual state functionality rather than formal equality fiction.
% TRANSFER_FUNCTION: Moves territorial authority and decision-making power from weak states to external actors—intervening powers, development agencies, capacity-assessment bodies—in proportion to measured deficits. Creates a hierarchy where sovereignty becomes conditional on meeting externally-set standards.
% ABSENT_VOICES: States and movements that reject the capacity-measurement framework entirely, arguing sovereignty is inherent and categorical regardless of internal conditions. Also absent: populations within weak states who might prefer self-determination under dysfunction to paternalistic oversight under external management.
% DISAPPEARANCE_RATIONALE: If the graded framework vanished and all states reverted to formal equality, the doctrinal justification for calibrated intervention would collapse. Weak states would gain veto power over external involvement in their affairs; humanitarian intervention and stabilization operations would require different legal grounding; the institutional apparatus of capacity assessment would lose its policy function. The international system would reorganize around either absolute sovereignty or some other legitimacy principle.
% FOUNDING_PROBLEM: Post-colonial international system faced states with wildly disparate governing capacity trying to operate under uniform sovereignty rules; failed states became black holes for humanitarian crisis and transnational threats with no doctrinal mechanism for external response short of outright colonialism.
% FOUNDING_PROBLEM_CORROBORATION: Capacity-assessment institutions and intervening powers attest the problem remains live, citing ongoing state failures and humanitarian emergencies. Post-colonial states and sovereignty scholars attest the founding problem was never solved but rather reframed: what was called incapacity is often the legacy of extractive colonialism, and the graded framework reproduces hierarchies it claims to manage. Independent legal and historical analysis documents both the persistent capacity heterogeneity and the continuity between colonial trusteeship and contemporary oversight regimes.
narrative_ontology:disappearance_verdict(westphalia_sovereignty__graded_sovereignty, world_rearranges).
narrative_ontology:founding_problem_status(westphalia_sovereignty__graded_sovereignty, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(westphalia_sovereignty__graded_sovereignty, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(westphalia_sovereignty__graded_sovereignty, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(westphalia_sovereignty__graded_sovereignty_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(westphalia_sovereignty__graded_sovereignty, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(westphalia_sovereignty__graded_sovereignty_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is high (0.68) because the framework transfers decision-making authority from weak states to external actors, with that transfer justified by capacity metrics the weak states did not set and cannot contest. Suppression is higher (0.71) because low-capacity states cannot exit the assessment regime—their weakness is both the measured condition and the structural bar to resistance. Theater ratio is moderate (0.42): capacity-building programs often substitute for local governance rather than support it, and intervention justifications cite humanitarian need while serving strategic interests. The measurement series shows extraction and theater rising as the framework matured and capacity metrics became institutionally entrenched. Accessibility collapse is moderate-low (0.48) because alternative sovereignty frameworks (absolute non-intervention, conditional responsibility) remain doctrinally available; resistance is substantial (0.64) from post-colonial states and sovereignty absolutists who contest the legitimacy of graded hierarchies.
 *
 * PERSPECTIVAL GAP:
 *   From the capacity-assessment and intervening seats, the framework is pragmatic recognition of state heterogeneity enabling calibrated response to real dysfunction. From the low-capacity state seats, the same structure operates as externally-imposed hierarchy legitimizing intervention they cannot resist. From the analytical seat, the framework's descriptive and prescriptive elements are impossible to separate—measuring capacity always involves normative judgments about what capacity means, and those judgments are set by the actors who benefit from the hierarchy.
 *
 * DIRECTIONALITY LOGIC:
 *   Capacity-assessment institutions are structural beneficiaries (control the metrics, collect legitimacy and funding from arbiter role—d near beneficiary end). Intervening powers and development agencies are beneficiaries (expanded operational latitude, reduced diplomatic costs—d near beneficiary end). Low-capacity states and populations under oversight are targets (bear sovereignty costs, subject to paternalistic intervention—d near target end, amplified by trapped exit). High-capacity democracies are beneficiaries (full sovereignty affirmed, structurally insulated from ever falling below threshold—d near beneficiary end).
 *
 * MANDATROPHY ANALYSIS:
 *   The framework's coordination function—acknowledging empirical capacity variance and enabling international response—is real but increasingly swamped by extractive overhead. The founding problem (how to respond to state failure without colonialism) has not been solved; it has been reframed so the response mechanism itself reproduces hierarchies. The graded reading differs from absolute sovereignty by making intervention calibratable rather than categorically impermissible; it differs from conditional responsibility by tying legitimacy to ongoing capacity deficits rather than discrete atrocity thresholds. The measurement trajectory suggests mission drift: early emphasis on humanitarian protection has given way to institutionalized oversight regimes where capacity-building substitutes for sovereignty rather than restoring it.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    measurement_neutrality,
    'Are capacity metrics neutral descriptions of state functionality, or do they encode the political preferences and institutional interests of the measuring bodies?',
    'Cross-cultural validation studies of governance indicators; historical analysis of how capacity standards have shifted with geopolitical priorities; examination of which measured deficits trigger intervention and which do not.',
    'If metrics are shown to systematically encode measurer preferences, the framework is exposed as prescriptive hierarchy dressed as descriptive assessment. If metrics are robust across evaluators and track independent dysfunction measures, the descriptive claim is strengthened.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(measurement_neutrality, empirical, 'Whether capacity assessment is neutral measurement or interested construction').

omega_variable(
    hierarchy_production,
    'Does the graded framework describe pre-existing state heterogeneity, or does it produce the hierarchy it claims to measure by treating weak states as permanently deficient?',
    'Longitudinal study of states'' capacity trajectories under graded-sovereignty regimes versus alternative frameworks; examination of whether external oversight builds capacity or substitutes for it; analysis of graduation criteria and whether states ever move up the hierarchy.',
    'If weak states systematically fail to graduate from oversight despite capacity-building interventions, the framework is producing permanent hierarchy rather than temporary support. If states do graduate and regain full sovereignty, the scaffolding claim is vindicated.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(hierarchy_production, conceptual, 'Whether the framework measures or manufactures state hierarchy').

omega_variable(
    continuity_with_colonialism,
    'Is graded sovereignty a break from colonial trusteeship or a continuation of it under different doctrinal packaging?',
    'Comparative analysis of colonial mandate systems and contemporary oversight regimes; examination of which populations are subject to each and on what justifications; study of whether colonial territories that gained independence under capacity-building regimes achieved full sovereignty or graduated into permanent oversight.',
    'Structural continuity would establish the framework as rebranded imperialism; genuine discontinuity would support the post-colonial legitimacy claim. The distributional pattern—formerly colonized regions disproportionately classified as low-capacity—is already documented.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(continuity_with_colonialism, conceptual, 'Whether graded sovereignty is post-colonial innovation or colonial continuity').

omega_variable(
    committer_kernel_under_determination,
    'Does disagreement among absolute, conditional, and graded readings stem from different empirical assessments of state capacity and protection needs, or from incommensurable normative commitments about the basis of political authority?',
    'Philosophical analysis of whether sovereignty is conceptually scalar or binary; examination of whether readings could converge given sufficient empirical data or whether they rest on axioms that cannot be reconciled.',
    'If the contest is empirical, better capacity measurement could produce reading convergence. If the contest is normative and axiomatic, the readings will remain incommensurable regardless of evidence, and choice among them is a political commitment rather than a factual determination.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(committer_kernel_under_determination, conceptual, 'Whether kernel contest is resolvable by evidence or rooted in incommensurable axioms').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(westphalia_sovereignty__graded_sovereignty, 0, 35).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(west_tr_t0, westphalia_sovereignty__graded_sovereignty, theater_ratio, 0, 0.28).
narrative_ontology:measurement(west_tr_t7, westphalia_sovereignty__graded_sovereignty, theater_ratio, 7, 0.32).
narrative_ontology:measurement(west_tr_t14, westphalia_sovereignty__graded_sovereignty, theater_ratio, 14, 0.36).
narrative_ontology:measurement(west_tr_t21, westphalia_sovereignty__graded_sovereignty, theater_ratio, 21, 0.39).
narrative_ontology:measurement(west_tr_t28, westphalia_sovereignty__graded_sovereignty, theater_ratio, 28, 0.41).
narrative_ontology:measurement(west_tr_t35, westphalia_sovereignty__graded_sovereignty, theater_ratio, 35, 0.42).

% Extraction over time
narrative_ontology:measurement(west_be_t0, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 0, 0.52).
narrative_ontology:measurement(west_be_t7, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 7, 0.57).
narrative_ontology:measurement(west_be_t14, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 14, 0.61).
narrative_ontology:measurement(west_be_t21, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 21, 0.65).
narrative_ontology:measurement(west_be_t28, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 28, 0.67).
narrative_ontology:measurement(west_be_t35, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 35, 0.68).

% Suppression requirement over time
narrative_ontology:measurement(west_su_t0, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 0, 0.58).
narrative_ontology:measurement(west_su_t7, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 7, 0.62).
narrative_ontology:measurement(west_su_t14, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 14, 0.65).
narrative_ontology:measurement(west_su_t21, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 21, 0.68).
narrative_ontology:measurement(west_su_t28, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 28, 0.7).
narrative_ontology:measurement(west_su_t35, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 35, 0.71).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(westphalia_sovereignty__graded_sovereignty, enforcement_mechanism).
narrative_ontology:affects_constraint(westphalia_sovereignty__graded_sovereignty, westphalia_sovereignty__absolute_non_intervention).
narrative_ontology:affects_constraint(westphalia_sovereignty__graded_sovereignty, westphalia_sovereignty__conditional_responsibility).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the westphalia_sovereignty kernel. The absolute_non_intervention and conditional_responsibility siblings are separate constraint stories, each with distinct ε values, beneficiary/victim structures, and classification profiles. They are linked via network.affects_constraints. The graded reading influences both siblings: it shifts default assumptions about sovereignty toward conditionality and hierarchy, making absolute inviolability harder to maintain and making conditional frameworks more widely applicable.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
