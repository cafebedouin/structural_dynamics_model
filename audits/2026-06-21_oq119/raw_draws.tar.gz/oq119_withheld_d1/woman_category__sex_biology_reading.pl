% ============================================================================
% CONSTRAINT STORY: woman_category__sex_biology_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2025-01-01
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_woman_category__sex_biology_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: woman_category__sex_biology_reading
 *   human_readable: Woman Category: Sex Biology Reading
 *   domain: political_philosophy/law/social_policy/bioethics
 *
 * SUMMARY:
 *   This constraint is the sex-biology reading of the contested kernel 'woman
 *   category'. Under this reading, legal and social category membership for
 *   'woman' is determined by chromosomal and reproductive anatomy (the
 *   typical XX/female-anatomy case), not by gender identity. The reading
 *   structures sex-segregated competitive sports, violence-against-women
 *   policy, shelter access, and legal sex classification in jurisdictions
 *   that adopt it. The constraint is claimed as tangled_rope: a genuine
 *   coordination function (maintaining sex-based protections and competitive
 *   fairness where biological sex is operationally relevant) coupled with
 *   asymmetric extraction (transgender women are excluded from protections
 *   they seek; intersex people face categorical ambiguity). The metrics
 *   describe rising extractiveness and suppression over the interval as
 *   enforcement intensifies and identity-based challenges are actively
 *   resisted.
 *
 * KEY AGENTS:
 *   - female_athletes_competitive_sports: Beneficiary (organized/constrained) — protected competitive category
 *   - sex_segregated_shelter_operators: Agenda-setter + beneficiary (institutional/mobile) — set admission policies
 *   - sex_based_data_collection_institutions: Beneficiary (institutional/mobile) — track sex-based patterns
 *   - transgender_women: Payer (organized/identity_locked) — excluded from category and protections
 *   - intersex_people_nonbinary_presentation: Payer (moderate/constrained) — ambiguously positioned
 *   - gender_identity_legal_advocates: Excluded (organized/constrained) — structurally excluded from definitional process
 *   - jurisprudence_scholars: Observer (analytical/analytical) — analyze divergent legal outcomes
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(woman_category__sex_biology_reading, 0.72).
domain_priors:suppression_score(woman_category__sex_biology_reading, 0.78).
domain_priors:theater_ratio(woman_category__sex_biology_reading, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, extractiveness, 0.72).
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, suppression_requirement, 0.78).
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, accessibility_collapse, 0.61).
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, resistance, 0.74).

% --- Constraint claim ---
narrative_ontology:constraint_claim(woman_category__sex_biology_reading, tangled_rope).
narrative_ontology:human_readable(woman_category__sex_biology_reading, "Woman Category: Sex Biology Reading").
narrative_ontology:topic_domain(woman_category__sex_biology_reading, "political_philosophy/law/social_policy/bioethics").

domain_priors:requires_active_enforcement(woman_category__sex_biology_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(woman_category__sex_biology_reading, '486b1b04-7f26-4110-a6d3-253d735f4556').
narrative_ontology:cs_kernel_codification('486b1b04-7f26-4110-a6d3-253d735f4556', distributed).
narrative_ontology:cs_authority_grounding('486b1b04-7f26-4110-a6d3-253d735f4556', distributed).
narrative_ontology:cs_reading_relation('486b1b04-7f26-4110-a6d3-253d735f4556', woman_category__gender_identity_reading, forecloses).
narrative_ontology:cs_reading_relation('486b1b04-7f26-4110-a6d3-253d735f4556', woman_category__intersex_accommodation_reading, influences).
narrative_ontology:cs_axiom('486b1b04-7f26-4110-a6d3-253d735f4556', foundational, biological_sex_dispositive_for_category).
narrative_ontology:cs_axiom_status(biological_sex_dispositive_for_category, holdable).
narrative_ontology:cs_axiom_grounding('486b1b04-7f26-4110-a6d3-253d735f4556', biological_sex_dispositive_for_category, empirically_contingent).
narrative_ontology:cs_axiom('486b1b04-7f26-4110-a6d3-253d735f4556', secondary, gender_identity_legally_irrelevant).
narrative_ontology:cs_axiom_status(gender_identity_legally_irrelevant, holdable).
narrative_ontology:cs_axiom_grounding('486b1b04-7f26-4110-a6d3-253d735f4556', gender_identity_legally_irrelevant, conventional).
narrative_ontology:cs_reference_frame('486b1b04-7f26-4110-a6d3-253d735f4556', second_wave_feminist_sex_segregation).
narrative_ontology:cs_drift_state('486b1b04-7f26-4110-a6d3-253d735f4556', contemporary_gender_identity_era, gap(authority_erosion, substantial, false)).
narrative_ontology:cs_created_at('486b1b04-7f26-4110-a6d3-253d735f4556', '').
narrative_ontology:cs_kernel_id(woman_category__sex_biology_reading, woman_category).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(woman_category__sex_biology_reading, female_athletes_competitive_sports).
narrative_ontology:constraint_beneficiary(woman_category__sex_biology_reading, sex_segregated_shelter_operators).
narrative_ontology:constraint_beneficiary(woman_category__sex_biology_reading, sex_based_data_collection_institutions).
narrative_ontology:constraint_victim(woman_category__sex_biology_reading, transgender_women).
narrative_ontology:constraint_victim(woman_category__sex_biology_reading, intersex_people_nonbinary_presentation).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Benefit from sex-segregated competitive categories defined by natal biology. The constraint preserves competitive fairness frameworks where performance advantages from male puberty are excluded. Exit means abandoning elite competition or accepting categories where puberty-driven performance gaps are present.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, female_athletes_competitive_sports, beneficiary,
    organized, biographical, constrained, global).

% Operate single-sex facilities for survivors of male violence, using biological sex as admission criterion. The constraint provides legal cover and operational clarity for excluding people with male anatomy regardless of identity. They set admission policies and enforce boundaries.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, sex_segregated_shelter_operators, agenda_setter,
    institutional, generational, mobile, national).
narrative_ontology:stakeholder_secondary_role(woman_category__sex_biology_reading, sex_segregated_shelter_operators, beneficiary).

% Public health agencies, research institutions, and violence-prevention organizations that track patterns of male violence against females, reproductive health outcomes, and sex-linked medical conditions. The constraint allows data collection tracking biological sex without identity variables complicating analysis of sex-based patterns.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, sex_based_data_collection_institutions, beneficiary,
    institutional, generational, mobile, global).

% Excluded from legal protections, facilities, and social categories they understand themselves to belong to. The constraint treats their identity claims as irrelevant to category membership, requiring them to access male facilities or forgo sex-segregated protections entirely. Identity-locked because exit means repudiating core self-concept.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, transgender_women, payer,
    organized, biographical, identity_locked, global).

% Ambiguously positioned within the constraint's framework. The typical-case definition admits some intersex variations as 'close enough' to female biology while excluding others; the enforcement machinery produces inconsistent outcomes depending on which biological markers administrators treat as dispositive.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, intersex_people_nonbinary_presentation, payer,
    moderate, biographical, constrained, global).

% Advocate for self-identification frameworks in law and policy. Under this reading their clients' identity claims carry no legal weight for category membership; they are structurally excluded from the definitional apparatus itself.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, gender_identity_legal_advocates, excluded,
    organized, generational, constrained, national).

% Analyze how different readings of 'woman' produce divergent legal outcomes in anti-discrimination law, Title IX enforcement, and sex-segregated facility access. Track the case law and legislative contests where readings collide.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, jurisprudence_scholars, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a stable, verifiable category boundary for sex-segregated spaces, competitive sports, and data collection where biological sex differences are claimed to be operationally relevant (violence patterns, reproductive health, athletic performance).
% TRANSFER_FUNCTION: Transfers legal standing, facility access, competitive eligibility, and protection under sex-based law from transgender women (excluded under this reading) to people with female biology (included). Moves the costs of categorical ambiguity onto intersex people and the costs of exclusion onto transgender women.
% ABSENT_VOICES: Transgender women and intersex advocates are present in public discourse but structurally excluded from the definitional process in jurisdictions adopting this reading. They contest the reading's empirical premises and normative framing but their testimony is treated as advocacy rather than corrective evidence.
% DISAPPEARANCE_RATIONALE: If this reading's enforcement vanished, eligibility for sex-segregated competitive sports, shelter access policies, and legal sex classification would immediately shift to accommodate self-identification or multi-factor frameworks. Violence-against-women data collection protocols would need redesign, athletic governing bodies would alter eligibility rules, and legal sex markers would become non-dispositive for facility access.
% FOUNDING_PROBLEM: Early feminist legal advocacy established sex-segregated protections to address documented patterns of male violence against females and systematic exclusion of females from competitive athletics and public life. The category 'woman' was operationalized via observable biology because identity-based claims were not yet part of the discourse.
% FOUNDING_PROBLEM_CORROBORATION: Advocates of this reading attest the founding problem remains live: male violence against females persists and athletic performance gaps rooted in male puberty remain measurable. Critics outside the beneficiary set attest the founding problem's framing is incomplete: the legal architecture built for one problem (sex-based exclusion and violence) is now being wielded to exclude a different class (transgender women) whose inclusion would not reproduce the original harms. Independent legal scholars and bioethicists document both the persistence of sex-based violence patterns and the mismatch between the original problem and current exclusionary applications.
narrative_ontology:disappearance_verdict(woman_category__sex_biology_reading, world_rearranges).
narrative_ontology:founding_problem_status(woman_category__sex_biology_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(woman_category__sex_biology_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(woman_category__sex_biology_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(woman_category__sex_biology_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(woman_category__sex_biology_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(woman_category__sex_biology_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is high (0.72 at interval end) because the constraint excludes transgender women from legal protections and social goods they understand themselves to qualify for, and imposes categorical ambiguity on intersex people; the exclusion is not a side effect but the enforcement object. Suppression is higher (0.78) because persistence depends on actively resisting identity-based legal claims and enforcing biological verification in contexts (shelter access, sports eligibility) where such verification was historically unnecessary. Theater ratio is moderate (0.42): the competitive-fairness and violence-prevention functions are real in some contexts, but a growing share of enforcement activity defends the definitional boundary itself rather than addressing the underlying substantive concerns. Accessibility collapse is moderate (0.61): alternative framings exist and are live in other jurisdictions, but adopting this reading forecloses identity-based frameworks within the same legal system. Resistance is high (0.74): transgender advocates and allies mount sustained legal and political challenges; the constraint requires active defense.
 *
 * PERSPECTIVAL GAP:
 *   The beneficiary and agenda-setter seats (female athletes, shelter operators, data institutions) should compute this constraint as coordination: it solves a real problem (performance fairness, safety, epidemiological clarity) they face. The payer seats (transgender women, intersex people) should compute it as extraction: it denies them access to protections and categories they need, enforced through active suppression of their claims. The observer seat sees the structural divergence: same constraint, different experienced types depending on position relative to the biological-sex boundary.
 *
 * DIRECTIONALITY LOGIC:
 *   Female athletes and sex-segregated institutions are structural beneficiaries: they receive the coordination function (protected categories, operational clarity) and bear low costs. Transgender women are the primary targets: excluded from protections, identity-locked (exit means repudiating self-concept), high d toward full extraction. Intersex people are also targets but with moderate power and constrained (not identity-locked) exit; they bear categorical ambiguity costs. Gender identity advocates are excluded rather than coordinated — their exclusion is structural to the reading.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint's mandate (protect females from male violence, maintain competitive fairness) has not outlived its function in the view of its advocates: patterns of male violence persist, athletic performance gaps remain measurable. But critics argue the architecture built for one problem (excluding males from female spaces) is now being applied to a different case (excluding transgender women) where the original justification does not transfer. The mandatrophy question turns on whether transgender women's inclusion in female categories would reproduce the harms the segregation was built to prevent — a contested empirical and normative claim that distinguishes this reading from its siblings.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    performance_advantage_magnitude,
    'What is the magnitude and persistence of athletic performance advantages conferred by male puberty, after transition-related interventions (hormone therapy, surgery)?',
    'Longitudinal studies tracking transgender women athletes'' performance metrics before and after transition, compared to cisgender female and male athletes in the same sports. Meta-analysis of existing studies controlling for training, age, and sport type.',
    'If advantages are negligible or eliminated by transition protocols, the competitive-fairness justification for exclusion dissolves and the constraint''s coordination function in athletics becomes a cover story for exclusion. If advantages persist substantially, the exclusion has a measurable fairness basis and the extraction is the price of maintaining competitive equity.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(performance_advantage_magnitude, empirical, 'Empirical basis for athletic exclusion under sex-biology framework').

omega_variable(
    violence_pattern_transferability,
    'Do transgender women exhibit patterns of violence toward females consistent with male perpetrators, or with female perpetrators, or neither?',
    'Criminological data comparing offense rates and types for transgender women, cisgender men, and cisgender women. Analysis of incidents in sex-segregated facilities (prisons, shelters) where transgender women have been housed with cisgender women.',
    'If transgender women''s offense patterns match cisgender women''s, the violence-prevention justification for exclusion from female spaces fails and the constraint operates as pure exclusion. If patterns match cisgender men''s, exclusion has an empirical safety basis. If neither (distinct third pattern), current frameworks are inadequate and novel institutional designs are required.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(violence_pattern_transferability, empirical, 'Empirical basis for shelter/facility exclusion under sex-biology framework').

omega_variable(
    intersex_boundary_arbitrariness,
    'Where does the sex-biology reading place the categorical boundary for intersex people, and is that boundary principled or arbitrary?',
    'Analysis of how the reading handles Swyer syndrome (XY chromosomes, female anatomy), complete androgen insensitivity (XY, phenotypically female), 5-alpha reductase deficiency (ambiguous development), and other intersex variations. Does the reading produce consistent category placements or does it route intersex people into ''whichever category is more convenient for the current enforcement context''?',
    'If the reading handles intersex cases consistently via principled biological criteria, it is internally coherent (though still extractive toward transgender women). If intersex placements are arbitrary or convenience-driven, the constraint''s biological-essentialism framing is undermined and the category boundary is revealed as socially constructed rather than naturally determined.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(intersex_boundary_arbitrariness, conceptual, 'Internal coherence of biological-category boundary').

omega_variable(
    reading_under_determination,
    'Is the sex-biology reading the only defensible interpretation of the woman-category kernel, or do sibling readings (gender-identity, intersex-accommodation) address coordination problems the sex-biology reading leaves unsolved?',
    'Comparative institutional analysis: jurisdictions adopting different readings, tracked over time for outcomes in violence prevention, athletic fairness, legal clarity, and inclusion of marginalized groups. Which problems does each reading solve and which does it create?',
    'If the sex-biology reading solves all coordination problems without creating new extraction, it is the uniquely justified reading. If sibling readings solve problems this reading cannot address (legal recognition for transgender people, coherent treatment of intersex variations) without losing the sex-biology reading''s coordination functions, the kernel is genuinely contested and no single reading is structurally dominant.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(reading_under_determination, conceptual, 'Whether the kernel contest is resolvable or irreducibly multi-reading').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(woman_category__sex_biology_reading, 0, 30).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(woma_tr_t0, woman_category__sex_biology_reading, theater_ratio, 0, 0.25).
narrative_ontology:measurement(woma_tr_t6, woman_category__sex_biology_reading, theater_ratio, 6, 0.29).
narrative_ontology:measurement(woma_tr_t12, woman_category__sex_biology_reading, theater_ratio, 12, 0.33).
narrative_ontology:measurement(woma_tr_t18, woman_category__sex_biology_reading, theater_ratio, 18, 0.37).
narrative_ontology:measurement(woma_tr_t24, woman_category__sex_biology_reading, theater_ratio, 24, 0.4).
narrative_ontology:measurement(woma_tr_t30, woman_category__sex_biology_reading, theater_ratio, 30, 0.42).

% Extraction over time
narrative_ontology:measurement(woma_be_t0, woman_category__sex_biology_reading, base_extractiveness, 0, 0.55).
narrative_ontology:measurement(woma_be_t6, woman_category__sex_biology_reading, base_extractiveness, 6, 0.59).
narrative_ontology:measurement(woma_be_t12, woman_category__sex_biology_reading, base_extractiveness, 12, 0.64).
narrative_ontology:measurement(woma_be_t18, woman_category__sex_biology_reading, base_extractiveness, 18, 0.68).
narrative_ontology:measurement(woma_be_t24, woman_category__sex_biology_reading, base_extractiveness, 24, 0.7).
narrative_ontology:measurement(woma_be_t30, woman_category__sex_biology_reading, base_extractiveness, 30, 0.72).

% Suppression requirement over time
narrative_ontology:measurement(woma_su_t0, woman_category__sex_biology_reading, suppression_requirement, 0, 0.58).
narrative_ontology:measurement(woma_su_t6, woman_category__sex_biology_reading, suppression_requirement, 6, 0.63).
narrative_ontology:measurement(woma_su_t12, woman_category__sex_biology_reading, suppression_requirement, 12, 0.68).
narrative_ontology:measurement(woma_su_t18, woman_category__sex_biology_reading, suppression_requirement, 18, 0.72).
narrative_ontology:measurement(woma_su_t24, woman_category__sex_biology_reading, suppression_requirement, 24, 0.75).
narrative_ontology:measurement(woma_su_t30, woman_category__sex_biology_reading, suppression_requirement, 30, 0.78).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(woman_category__sex_biology_reading, identity_coordination).
narrative_ontology:affects_constraint(woman_category__sex_biology_reading, woman_category__gender_identity_reading).
narrative_ontology:affects_constraint(woman_category__sex_biology_reading, woman_category__intersex_accommodation_reading).

% DUAL FORMULATION NOTE:
% This constraint is one of three readings of the woman_category kernel. The sex_biology_reading, gender_identity_reading, and intersex_accommodation_reading are structurally distinct constraints (different ε, different victim sets, different enforcement mechanisms) that cannot be collapsed into one story with an observable parameter. Each reading routes different populations into 'woman' category membership, producing divergent legal and social outcomes. The network edges link the constraint family; the omega variables document the irreducible contest.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
