% ============================================================================
% CONSTRAINT STORY: waitangi_sovereignty_allocation__partnership_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_waitangi_sovereignty_allocation__partnership_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:stakeholder_non_agent/2,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: waitangi_sovereignty_allocation__partnership_reading
 *   human_readable: Treaty of Waitangi Partnership Reading
 *   domain: constitutional_law/indigenous_rights/post_colonial_governance
 *
 * SUMMARY:
 *   The Treaty of Waitangi (1840) established a relationship between the
 *   British Crown and Māori iwi, but profound textual divergence between the
 *   English and Māori language versions created enduring ambiguity over
 *   sovereignty allocation. The partnership reading emerged in the 1980s-90s
 *   through Waitangi Tribunal jurisprudence and judicial development of
 *   Treaty principles. This reading holds that the Treaty created an ongoing
 *   partnership requiring the Crown to act in good faith, actively protect
 *   Māori interests, and consult on matters affecting them. The constraint is
 *   claimed as tangled_rope because it combines genuine coordination
 *   (institutional framework for managing Crown-Māori relations, settlement
 *   process for historical grievances) with asymmetric extraction
 *   (partnership doctrine preserves Crown sovereignty while channeling Māori
 *   claims into administrative process that cannot fundamentally challenge
 *   the allocation). The metrics describe substantial extraction that has
 *   accumulated over time as the framework matured, with rising suppression
 *   requirements to maintain the reading against sovereignty challenges.
 *
 * KEY AGENTS:
 *   - crown_executive: Primary agenda-setter (institutional/constrained exit) — administers principles doctrine and settlements; benefits from legitimacy grant
 *   - maori_collectives_with_settlements: Beneficiary (organized/constrained exit) — receive redress and co-governance rights through settlement process
 *   - dispossessed_iwi_without_settlements: Primary target (moderate/identity_locked exit) — bear ongoing costs of dispossession while redress is channeled through settlement framework
 *   - waitangi_tribunal_institutional_structure: Beneficiary and agenda-setter (institutional/mobile exit) — interpretive authority legitimized by partnership reading
 *   - pakeha_majority_electorate: Payer (organized/constrained exit) — bear diffuse costs of settlements and consultation requirements
 *   - resource_extraction_industries: Payer (powerful/mobile exit) — consultation adds costs and time; can exit to other jurisdictions
 *   - constitutional_law_observers: Analytical seat — evaluate whether partnership is genuine power-sharing or extraction preserving sovereignty
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(waitangi_sovereignty_allocation__partnership_reading, 0.58).
domain_priors:suppression_score(waitangi_sovereignty_allocation__partnership_reading, 0.62).
domain_priors:theater_ratio(waitangi_sovereignty_allocation__partnership_reading, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, extractiveness, 0.58).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 0.62).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, resistance, 0.56).

% --- Constraint claim ---
narrative_ontology:constraint_claim(waitangi_sovereignty_allocation__partnership_reading, tangled_rope).
narrative_ontology:human_readable(waitangi_sovereignty_allocation__partnership_reading, "Treaty of Waitangi Partnership Reading").
narrative_ontology:topic_domain(waitangi_sovereignty_allocation__partnership_reading, "constitutional_law/indigenous_rights/post_colonial_governance").

domain_priors:requires_active_enforcement(waitangi_sovereignty_allocation__partnership_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(waitangi_sovereignty_allocation__partnership_reading, '04a4eb70-d3bb-4b9f-a97f-9d8ed9b73f9a').
narrative_ontology:cs_kernel_codification('04a4eb70-d3bb-4b9f-a97f-9d8ed9b73f9a', fixed_text).
narrative_ontology:cs_authority_grounding('04a4eb70-d3bb-4b9f-a97f-9d8ed9b73f9a', lineage).
narrative_ontology:cs_interpretation_layer_present('04a4eb70-d3bb-4b9f-a97f-9d8ed9b73f9a').
narrative_ontology:cs_reading_relation('04a4eb70-d3bb-4b9f-a97f-9d8ed9b73f9a', waitangi_sovereignty_allocation__crown_sovereignty_reading, coexists_with).
narrative_ontology:cs_reading_relation('04a4eb70-d3bb-4b9f-a97f-9d8ed9b73f9a', waitangi_sovereignty_allocation__rangatiratanga_reading, coexists_with).
narrative_ontology:cs_axiom('04a4eb70-d3bb-4b9f-a97f-9d8ed9b73f9a', foundational, treaty_created_ongoing_partnership).
narrative_ontology:cs_axiom_status(treaty_created_ongoing_partnership, holdable).
narrative_ontology:cs_axiom_grounding('04a4eb70-d3bb-4b9f-a97f-9d8ed9b73f9a', treaty_created_ongoing_partnership, conventional).
narrative_ontology:cs_axiom('04a4eb70-d3bb-4b9f-a97f-9d8ed9b73f9a', secondary, crown_sovereignty_with_consultation_duty).
narrative_ontology:cs_axiom_status(crown_sovereignty_with_consultation_duty, holdable).
narrative_ontology:cs_axiom_grounding('04a4eb70-d3bb-4b9f-a97f-9d8ed9b73f9a', crown_sovereignty_with_consultation_duty, conventional).
narrative_ontology:cs_reference_frame('04a4eb70-d3bb-4b9f-a97f-9d8ed9b73f9a', treaty_as_partnership_foundation).
narrative_ontology:cs_drift_state('04a4eb70-d3bb-4b9f-a97f-9d8ed9b73f9a', contemporary_settlements_era, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('04a4eb70-d3bb-4b9f-a97f-9d8ed9b73f9a', '').
narrative_ontology:cs_kernel_id(waitangi_sovereignty_allocation__partnership_reading, waitangi_sovereignty_allocation).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__partnership_reading, crown_executive).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__partnership_reading, maori_collectives_with_settlements).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__partnership_reading, waitangi_tribunal_institutional_structure).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__partnership_reading, dispossessed_iwi_without_settlements).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__partnership_reading, parliamentary_legislative_autonomy).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__partnership_reading, pakeha_majority_electorate).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__partnership_reading, resource_extraction_industries).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__partnership_reading, good_faith_consultation_doctrine).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__partnership_reading, treaty_principles_framework).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Administers the Treaty principles doctrine through Office of Treaty Settlements and Treaty consultation processes. Sets the agenda for what constitutes good faith consultation and active protection. Benefits from the partnership reading's legitimacy grant while retaining ultimate parliamentary sovereignty. Constrained exit because repudiating the partnership framework would delegitimize governance of indigenous policy and invite constitutional crisis.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, crown_executive, agenda_setter,
    institutional, generational, constrained, national).

% Iwi and hapū that have negotiated Treaty settlements receive financial redress, return of cultural sites, co-governance arrangements, and formal Crown apologies. Gain recognition, resources, and consultation rights. Exit constrained because rejecting settlements means forgoing redress and returning to unsettled historical grievances with no guarantee of better terms.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, maori_collectives_with_settlements, beneficiary,
    organized, generational, constrained, regional).

% Māori collectives whose historical claims remain unresolved or inadequately addressed. Bear the costs of land alienation, resource extraction, and cultural erosion while the partnership reading channels recognition and redress primarily through the settlement process. Identity-locked because their claim to rangatiratanga and cultural survival is constitutive of who they are; exit is not a coherent option.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, dispossessed_iwi_without_settlements, payer,
    moderate, generational, identity_locked, regional).

% Quasi-judicial body that investigates Treaty breaches and issues non-binding recommendations. The partnership reading legitimizes its institutional existence and interpretive authority. Benefits from the framework's ambiguity which gives the Tribunal wide scope for principles development. Mobile exit because the institution could pivot to other constitutional roles or be restructured.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, waitangi_tribunal_institutional_structure, beneficiary,
    institutional, generational, mobile, national).
narrative_ontology:stakeholder_secondary_role(waitangi_sovereignty_allocation__partnership_reading, waitangi_tribunal_institutional_structure, agenda_setter).

% Westminster parliamentary sovereignty is formally unconstrained but practically moderated by consultation requirements and principles doctrine. Parliament can legislate contrary to Treaty principles but faces normative and political costs. Listed here as non-agent entity for structural completeness; the constraint extracts from parliamentary freedom of action.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, parliamentary_legislative_autonomy, payer,
    institutional, generational, analytical, national).
narrative_ontology:stakeholder_non_agent(waitangi_sovereignty_allocation__partnership_reading, parliamentary_legislative_autonomy).

% Non-Māori citizens whose preferences may conflict with Treaty-mandated consultation or co-governance arrangements. Bear diffuse costs through tax-funded settlements and constrained resource access where co-governance applies. Constrained exit because citizenship and residence are not easily abandoned.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, pakeha_majority_electorate, payer,
    organized, biographical, constrained, national).

% Mining, forestry, fishing, and energy sectors required to consult iwi with customary interests and negotiate benefit-sharing. Consultation adds time and cost; co-governance can block projects. Mobile exit because capital can relocate to jurisdictions without indigenous consultation requirements.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, resource_extraction_industries, payer,
    powerful, biographical, mobile, national).

% Legal scholars and comparative constitutionalists who analyze whether the partnership reading is a genuine power-sharing arrangement or an extraction mechanism that preserves Crown sovereignty while channeling Māori claims into administrative process.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, constitutional_law_observers, observer,
    analytical, generational, analytical, national).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a framework for managing Crown-Māori relations that acknowledges historical injustice and creates institutional channels for consultation, redress, and co-governance, preventing ongoing conflict over sovereignty and resource control.
% TRANSFER_FUNCTION: Moves financial settlements, returned land, co-governance rights, and consultation authority from Crown to settled iwi. Moves normative legitimacy from contested Crown authority to partnership-based governance. Moves legislative freedom from Parliament to constrained-by-principles process.
% ABSENT_VOICES: Iwi whose claims remain unsettled or were settled on inadequate terms decades ago; Māori sovereignty advocates who reject the partnership framing entirely as legitimizing ongoing colonization; segments of the Pākehā electorate who view consultation requirements as undemocratic constraint on majority rule.
% DISAPPEARANCE_RATIONALE: If the partnership reading and its enforcement disappeared overnight, Treaty settlement processes would halt, consultation requirements would lapse, co-governance arrangements would be challenged, and the constitutional basis for managing Crown-Māori relations would revert to either raw parliamentary sovereignty or renewed sovereignty contest. Resource conflicts would escalate without the institutional buffer.
% FOUNDING_PROBLEM: Post-1975 constitutional crisis over Treaty status: rising Māori protest over land alienation and cultural suppression, international indigenous rights pressure, and need to legitimate Crown authority in post-colonial context without conceding sovereignty.
% FOUNDING_PROBLEM_CORROBORATION: The Crown and settled iwi attest the founding problem is addressed through partnership mechanisms. Legal historians and Māori sovereignty advocates outside the beneficiary set attest the founding problem persists: the partnership reading preserves Crown sovereignty while channeling Māori claims into administrative process that cannot challenge the fundamental allocation. Constitutional scholars cite that Parliament retains legal power to abrogate Treaty protections, indicating partnership is policy, not constraint on sovereignty.
narrative_ontology:disappearance_verdict(waitangi_sovereignty_allocation__partnership_reading, world_rearranges).
narrative_ontology:founding_problem_status(waitangi_sovereignty_allocation__partnership_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(waitangi_sovereignty_allocation__partnership_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(waitangi_sovereignty_allocation__partnership_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(waitangi_sovereignty_allocation__partnership_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(waitangi_sovereignty_allocation__partnership_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(waitangi_sovereignty_allocation__partnership_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is substantial (0.58) because the partnership reading channels Māori sovereignty claims into an administrative framework that preserves ultimate Crown authority: Parliament retains legal power to legislate contrary to Treaty principles, and settlements are negotiated under a fiscal cap set by the Crown. Suppression is high (0.62) because maintaining this reading against rangatiratanga (full sovereignty) claims requires active institutional enforcement through tribunal processes, judicial doctrine development, and political management. Theater ratio is moderate (0.28): consultation and principles development are genuine functions, but a growing share of institutional activity performs partnership while defending Crown sovereignty. Accessibility collapse is moderate (0.48) because alternative sovereignty framings remain conceptually and politically available to Māori communities. Resistance is substantial (0.56) because Māori sovereignty movements actively contest the partnership reading as inadequate. Measurements run on one shared grid; rising trends reflect framework maturation and accumulating extraction.
 *
 * PERSPECTIVAL GAP:
 *   From the Crown executive seat, the partnership reading is a successful coordination framework managing historical injustice through consultation and redress. From the unsettled iwi seat, the same structure operates as enforced extraction: it channels sovereignty claims into administrative process while preserving Crown control over terms and fiscal limits. From the Pākehā electorate seat, it appears as constraint on democratic majority rule. From constitutional observers' seat, it is ambiguous whether the reading genuinely shares power or performs partnership while maintaining sovereignty. The engine computes these divergences from the structural data; the claimed type does not adjudicate between them.
 *
 * DIRECTIONALITY LOGIC:
 *   Crown executive sits near beneficiary end (low d) because it collects legitimacy and administrative control while retaining sovereignty. Settled iwi are mixed beneficiaries (moderate d) because they receive genuine redress but within a framework that forecloses deeper sovereignty claims. Unsettled iwi are targets (high d) because the partnership reading structures recognition around settlements they have not achieved. Pākehā electorate and resource industries are diffuse payers (moderate-high d) bearing costs of consultation and co-governance. Waitangi Tribunal is institutional beneficiary (low d) because the reading legitimizes its interpretive role.
 *
 * MANDATROPHY ANALYSIS:
 *   The partnership reading is tangled_rope rather than pure snare because it provides genuine coordination: the settlement process delivers real redress, consultation requirements create institutional channels for Māori input, and co-governance arrangements share decision-making in specific domains. However, it is not pure rope because the coordination function coexists with asymmetric extraction: the framework preserves Crown sovereignty, settlements are capped and do not address ongoing resource control, and Parliament can override principles. Unsettled iwi pay extraction (dispossession continues, claims remain unresolved) while settled iwi receive coordination (redress, recognition). This is the structural signature of tangled rope: same mechanism, different positions, coordination for some and extraction for others.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    partnership_versus_sovereignty_preservation,
    'Does the partnership reading genuinely share sovereignty, or does it perform partnership while preserving Crown sovereignty by channeling Māori claims into administrative process?',
    'Test: if Parliament legislated to override Treaty principles or abrogate consultation requirements, would the partnership doctrine provide enforceable constraint? Current constitutional consensus is no—Parliament retains sovereignty. If courts or constitutional convention developed enforceable constraint on Parliament, partnership would move toward genuine power-sharing.',
    'If partnership is sovereignty-preserving performance, measured extraction understates the asymmetry because the framework itself is an extraction mechanism. If partnership genuinely shares power, some measured extraction is the coordination cost of dual authority.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(partnership_versus_sovereignty_preservation, conceptual, 'Whether partnership reading shares sovereignty or preserves it through institutional channeling').

omega_variable(
    settlement_adequacy_versus_fiscal_cap,
    'Are Treaty settlements adequate redress for historical dispossession, or does the Crown''s fiscal cap on total settlements extract from full redress?',
    'Compare settlement quantum to economic estimates of land value and resource rights alienated. Fiscal envelope (Crown-set cap) versus full compensatory value. If settled iwi could reopen negotiations under changed fiscal parameters, revealed preference would indicate adequacy.',
    'If settlements are adequate, extraction from settled iwi is low (they received what was owed). If fiscal cap forecloses adequate redress, extraction is higher (Crown sets the price of its own breach).',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(settlement_adequacy_versus_fiscal_cap, empirical, 'Whether settlement quantum represents adequate redress or Crown-controlled extraction').

omega_variable(
    consultation_as_coordination_versus_delay,
    'Is Treaty consultation a genuine coordination mechanism incorporating Māori perspectives, or primarily a procedural delay that performs legitimacy while resource decisions remain Crown-controlled?',
    'Measure consultation outcomes: frequency with which Crown decisions incorporate Māori objections versus frequency with which consultation is completed but decision proceeds unchanged. High incorporation rate indicates coordination; low rate indicates theater.',
    'If consultation is theater, theater_ratio is understated and effective extraction is higher (industries and Crown bear consultation costs without corresponding coordination benefit). If genuine coordination, theater_ratio is accurate.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(consultation_as_coordination_versus_delay, empirical, 'Whether consultation function is coordination or extractive delay').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(waitangi_sovereignty_allocation__partnership_reading, 0, 40).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(wait_tr_t0, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 0, 0.15).
narrative_ontology:measurement_basis(wait_tr_t0, observed).
narrative_ontology:measurement(wait_tr_t8, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 8, 0.18).
narrative_ontology:measurement_basis(wait_tr_t8, observed).
narrative_ontology:measurement(wait_tr_t16, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 16, 0.21).
narrative_ontology:measurement_basis(wait_tr_t16, observed).
narrative_ontology:measurement(wait_tr_t24, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 24, 0.24).
narrative_ontology:measurement_basis(wait_tr_t24, observed).
narrative_ontology:measurement(wait_tr_t32, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 32, 0.26).
narrative_ontology:measurement_basis(wait_tr_t32, observed).
narrative_ontology:measurement(wait_tr_t40, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 40, 0.28).
narrative_ontology:measurement_basis(wait_tr_t40, observed).

% Extraction over time
narrative_ontology:measurement(wait_be_t0, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 0, 0.45).
narrative_ontology:measurement_basis(wait_be_t0, observed).
narrative_ontology:measurement(wait_be_t8, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 8, 0.49).
narrative_ontology:measurement_basis(wait_be_t8, observed).
narrative_ontology:measurement(wait_be_t16, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 16, 0.53).
narrative_ontology:measurement_basis(wait_be_t16, observed).
narrative_ontology:measurement(wait_be_t24, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 24, 0.56).
narrative_ontology:measurement_basis(wait_be_t24, observed).
narrative_ontology:measurement(wait_be_t32, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 32, 0.57).
narrative_ontology:measurement_basis(wait_be_t32, observed).
narrative_ontology:measurement(wait_be_t40, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 40, 0.58).
narrative_ontology:measurement_basis(wait_be_t40, observed).

% Suppression requirement over time
narrative_ontology:measurement(wait_su_t0, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 0, 0.5).
narrative_ontology:measurement_basis(wait_su_t0, observed).
narrative_ontology:measurement(wait_su_t8, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 8, 0.54).
narrative_ontology:measurement_basis(wait_su_t8, observed).
narrative_ontology:measurement(wait_su_t16, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 16, 0.57).
narrative_ontology:measurement_basis(wait_su_t16, observed).
narrative_ontology:measurement(wait_su_t24, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 24, 0.6).
narrative_ontology:measurement_basis(wait_su_t24, observed).
narrative_ontology:measurement(wait_su_t32, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 32, 0.61).
narrative_ontology:measurement_basis(wait_su_t32, observed).
narrative_ontology:measurement(wait_su_t40, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 40, 0.62).
narrative_ontology:measurement_basis(wait_su_t40, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(waitangi_sovereignty_allocation__partnership_reading, identity_coordination).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__partnership_reading, waitangi_sovereignty_allocation__crown_sovereignty_reading).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__partnership_reading, waitangi_sovereignty_allocation__rangatiratanga_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the waitangi_sovereignty_allocation kernel. The partnership reading sits between crown_sovereignty (full Crown authority) and rangatiratanga (full Māori authority). Epsilon values differ because structural relationships differ: partnership reading extracts through administrative channeling while delivering partial redress; crown_sovereignty reading extracts less from Crown/Pākehā (no consultation costs) but more from Māori (no redress mechanism); rangatiratanga reading extracts from Crown/settler authority but is not institutionally implemented. Network edges model interpretive influence: partnership reading emerged as response to rangatiratanga claims and moderates crown_sovereignty reading in practice.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
