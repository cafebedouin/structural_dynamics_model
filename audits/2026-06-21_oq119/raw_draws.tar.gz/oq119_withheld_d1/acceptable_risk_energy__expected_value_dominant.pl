% ============================================================================
% CONSTRAINT STORY: acceptable_risk_energy__expected_value_dominant
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2024-01-09
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_acceptable_risk_energy__expected_value_dominant, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    constraint_indexing:directionality_override/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:stakeholder_gain_flow/2,
    narrative_ontology:fixing_cost_class/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: acceptable_risk_energy__expected_value_dominant
 *   human_readable: Expected-Value-Dominant Acceptable Risk Framework for Energy Policy
 *   domain: risk_assessment/energy_policy/decision_theory
 *
 * SUMMARY:
 *   The expected-value-dominant reading of acceptable risk in energy policy
 *   treats mortality-per-TWh—total deaths divided by total energy
 *   generated—as the definitive metric for comparing energy pathways. Under
 *   this framework, fossil fuels appear catastrophically deadly (continuous
 *   air pollution kills ~100x more per TWh than nuclear), nuclear appears
 *   extraordinarily safe (Chernobyl+Fukushima deaths amortized over global
 *   nuclear generation yield low per-TWh mortality), and concerns about
 *   catastrophic tail risk are treated as violations of rational choice
 *   theory. This reading is claimed as 'rope' (coordination via quantitative
 *   risk comparison) while the metrics describe substantially extractive
 *   operation: diffuse mortality borne by powerless populations is aggregated
 *   into coefficients; low-probability events that concern organized publics
 *   are probabilistically discounted to near-zero; and the framework's
 *   persistence depends on suppressing alternative risk weightings as
 *   innumerate.
 *
 * KEY AGENTS:
 *   - expected_utility_theorists: Agenda-setters (institutional/arbitrage) — provide axiomatic grounding, set terms of policy analysis
 *   - nuclear_industry: Primary beneficiary (institutional/constrained) — benefits from probabilistic discounting of catastrophic risk
 *   - climate_policy_advocates: Secondary beneficiary (organized/mobile) — adopt framework to discipline fossil fuels
 *   - air_pollution_exposed_populations: Primary victims (powerless/trapped) — bear continuous mortality counted as acceptable aggregate
 *   - catastrophic_risk_concerned_publics: Secondary victims (organized/constrained) — concerns excluded as irrational
 *   - decision_theory_critics: Excluded observers (moderate/analytical) — alternative frameworks published but not adopted
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(acceptable_risk_energy__expected_value_dominant, 0.71).
domain_priors:suppression_score(acceptable_risk_energy__expected_value_dominant, 0.78).
domain_priors:theater_ratio(acceptable_risk_energy__expected_value_dominant, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, extractiveness, 0.71).
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, suppression_requirement, 0.78).
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, accessibility_collapse, 0.62).
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, resistance, 0.58).

% --- Constraint claim ---
narrative_ontology:constraint_claim(acceptable_risk_energy__expected_value_dominant, tangled_rope).
narrative_ontology:human_readable(acceptable_risk_energy__expected_value_dominant, "Expected-Value-Dominant Acceptable Risk Framework for Energy Policy").
narrative_ontology:topic_domain(acceptable_risk_energy__expected_value_dominant, "risk_assessment/energy_policy/decision_theory").

domain_priors:requires_active_enforcement(acceptable_risk_energy__expected_value_dominant).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(acceptable_risk_energy__expected_value_dominant, '79cfd15b-53a6-4c43-91a7-991a5b4f7386').
narrative_ontology:cs_kernel_codification('79cfd15b-53a6-4c43-91a7-991a5b4f7386', formalized).
narrative_ontology:cs_authority_grounding('79cfd15b-53a6-4c43-91a7-991a5b4f7386', expertise).
narrative_ontology:cs_interpretation_layer_present('79cfd15b-53a6-4c43-91a7-991a5b4f7386').
narrative_ontology:cs_reading_relation('79cfd15b-53a6-4c43-91a7-991a5b4f7386', acceptable_risk_energy__catastrophic_tail_dominant, coexists_with).
narrative_ontology:cs_reading_relation('79cfd15b-53a6-4c43-91a7-991a5b4f7386', acceptable_risk_energy__option_value_preserving, coexists_with).
narrative_ontology:cs_axiom('79cfd15b-53a6-4c43-91a7-991a5b4f7386', foundational, expected_utility_uniquely_rational).
narrative_ontology:cs_axiom_status(expected_utility_uniquely_rational, holdable).
narrative_ontology:cs_axiom_grounding('79cfd15b-53a6-4c43-91a7-991a5b4f7386', expected_utility_uniquely_rational, deontological).
narrative_ontology:cs_axiom('79cfd15b-53a6-4c43-91a7-991a5b4f7386', foundational, catastrophic_probability_well_characterized).
narrative_ontology:cs_axiom_status(catastrophic_probability_well_characterized, holdable).
narrative_ontology:cs_axiom_grounding('79cfd15b-53a6-4c43-91a7-991a5b4f7386', catastrophic_probability_well_characterized, empirically_contingent).
narrative_ontology:cs_axiom('79cfd15b-53a6-4c43-91a7-991a5b4f7386', secondary, mortality_interpersonally_fungible).
narrative_ontology:cs_axiom_status(mortality_interpersonally_fungible, holdable).
narrative_ontology:cs_axiom_grounding('79cfd15b-53a6-4c43-91a7-991a5b4f7386', mortality_interpersonally_fungible, deontological).
narrative_ontology:cs_reference_frame('79cfd15b-53a6-4c43-91a7-991a5b4f7386', von_neumann_morgenstern_axioms).
narrative_ontology:cs_drift_state('79cfd15b-53a6-4c43-91a7-991a5b4f7386', post_fukushima_deep_uncertainty_recognition, gap(axiom_overriding, substantial, false)).
narrative_ontology:cs_created_at('79cfd15b-53a6-4c43-91a7-991a5b4f7386', '').
narrative_ontology:cs_kernel_id(acceptable_risk_energy__expected_value_dominant, acceptable_risk_energy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__expected_value_dominant, nuclear_industry).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__expected_value_dominant, climate_policy_advocates).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__expected_value_dominant, expected_utility_theorists).
narrative_ontology:constraint_victim(acceptable_risk_energy__expected_value_dominant, air_pollution_exposed_populations).
narrative_ontology:constraint_victim(acceptable_risk_energy__expected_value_dominant, fossil_extraction_workers).
narrative_ontology:constraint_victim(acceptable_risk_energy__expected_value_dominant, catastrophic_risk_concerned_publics).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_victim(acceptable_risk_energy__expected_value_dominant, fossil_fuel_industry).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__expected_value_dominant, expected_utility_maximization_doctrine).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__expected_value_dominant, probabilistic_risk_assessment_sufficiency).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Benefits from a framework that treats low-probability catastrophic events as negligible when averaged over long timescales. Under mortality-per-TWh accounting, nuclear appears highly favorable because Chernobyl and Fukushima deaths are divided by decades of global nuclear generation. The industry actively promotes this metric in policy forums and funds research establishing expected-value dominance as the correct risk framework.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, nuclear_industry, beneficiary,
    institutional, generational, constrained, global).

% Adopt this framework because it makes fossil fuels appear catastrophically harmful (continuous air pollution deaths) and nuclear appear clean, supporting rapid decarbonization arguments. They coordinate around mortality-per-TWh as the definitive metric for energy policy, treating alternative risk framings as innumerate or ideologically motivated.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, climate_policy_advocates, beneficiary,
    organized, generational, mobile, global).

% Provide the theoretical grounding for treating expected value as the uniquely rational decision criterion. They set the terms of analysis in cost-benefit frameworks, regulatory impact assessments, and policy schools. Their authority derives from axiomatic decision theory and the claim that any other criterion violates rationality axioms.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, expected_utility_theorists, agenda_setter,
    institutional, civilizational, arbitrage, universal).

% Bear continuous mortality from fossil fuel combustion—particulate matter, NOx, SOx—concentrated near power plants, refineries, and traffic corridors. Under the expected-value framework, their deaths are counted but then compared to the total energy generated globally, making each individual death appear as a small coefficient in an optimization problem. They have no exit from geographic exposure and limited voice in the analytic framework selection.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, air_pollution_exposed_populations, payer,
    powerless, biographical, trapped, local).

% Experience occupational mortality from mining accidents, black lung disease, and industrial injuries. The expected-value framework counts these deaths fully, creating pressure to phase out their industry. Their unions resist the framing but lack the analytic resources to propose alternative metrics that would treat their risks differently from the aggregate calculus.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, fossil_extraction_workers, payer,
    moderate, biographical, constrained, regional).

% Fear low-probability but civilization-threatening events: reactor meltdowns with transnational fallout, spent fuel pool fires, or future accidents at scale. The expected-value framework treats their concerns as irrational—high salience given to low-probability events. Their attempts to weight tail risks differently are excluded from policy consensus as violating expected utility axioms. They organize referendums and protests but the analytic apparatus remains unchanged.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, catastrophic_risk_concerned_publics, payer,
    organized, generational, constrained, national).
narrative_ontology:stakeholder_secondary_role(acceptable_risk_energy__expected_value_dominant, catastrophic_risk_concerned_publics, excluded).

% Faces regulatory pressure from mortality-per-TWh comparisons that make fossil generation look orders of magnitude more deadly than alternatives. They fund research questioning the causal attribution of air pollution deaths and promote absolute safety improvements rather than comparative metrics. Their capital is mobile enough to shift between energy sectors, but their existing assets are devalued under this risk framework.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, fossil_fuel_industry, payer,
    institutional, biographical, mobile, global).

% Adopt mortality-per-TWh and expected-value frameworks as the standard for energy safety regulation because they provide quantitative, seemingly objective bases for comparison. They commission cost-benefit analyses that embed this framework, making it the de facto decision criterion. Their institutional mandate is risk minimization, but the framework choice determines which risks count and how.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, regulatory_agencies, agenda_setter,
    institutional, generational, constrained, national).
narrative_ontology:stakeholder_secondary_role(acceptable_risk_energy__expected_value_dominant, regulatory_agencies, observer).

% Argue that expected utility maximization is not uniquely rational under deep uncertainty, that catastrophic and existential risks require non-additive treatment, and that robust decision rules or minimax regret may be more appropriate. Their alternative frameworks are published but not adopted in policy. They have analytical freedom but no institutional authority to change the consensus metric.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, decision_theory_critics, excluded,
    moderate, civilizational, analytical, universal).

% --- OQ-92 receipt surface: who RECEIVES the extraction (capture half).
% 'diffuse' = authored no-capture (piton-side); a seat name = capturer.
% ABSENT field = not authored, fail-closed. Never synthesized. ---
narrative_ontology:stakeholder_gain_flow(acceptable_risk_energy__expected_value_dominant, nuclear_industry).
narrative_ontology:fixing_cost_class(acceptable_risk_energy__expected_value_dominant, prohibitive).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes a common metric (mortality-per-TWh) for comparing energy pathway risks, enabling policy decisions about energy mix and investment that claim quantitative grounding rather than ideological priors.
% TRANSFER_FUNCTION: Transfers continuous, statistically diffuse mortality (air pollution, occupational deaths) from the 'acceptable background' category into a weighted aggregate that disciplines fossil fuel use, while transferring low-probability catastrophic nuclear risk out of the salient decision space by probabilistic discounting. The legitimacy and funding flow to nuclear and renewable energy pathways that score favorably under the metric.
% ABSENT_VOICES: Decision theory critics who argue for non-expected-utility frameworks under deep uncertainty, and communities who experience the constraint's 'acceptable' harms as unacceptable lived reality but lack the epistemic authority to challenge the analytic framework. Also absent: future generations who bear tail-risk consequences but have no seat in present expected-value calculations.
% DISAPPEARANCE_RATIONALE: If this framework disappeared overnight, energy policy would fragment into competing incommensurable risk metrics: some jurisdictions would weight catastrophic potential over expected harm, others would adopt precautionary principles, others would revert to political coalitions rather than technocratic optimization. Capital allocation between energy pathways would shift; the nuclear industry would lose its primary quantitative legitimacy claim; air pollution deaths would remain but their framing as 'unacceptable' would weaken without the comparative apparatus.
% FOUNDING_PROBLEM: Mid-20th-century energy policy lacked a systematic method for comparing risks across radically different energy technologies—continuous low-grade harms (coal pollution) versus rare catastrophic events (reactor accidents) versus diffuse long-term harms (climate change). Decisions were made via political capture, engineering intuition, or post-hoc rationalization.
% FOUNDING_PROBLEM_CORROBORATION: Expected utility theorists and regulatory economists attest the problem remains live and this framework solves it. Decision theory critics, environmental justice scholars, and existential risk researchers attest the founding problem is real but this solution is inadequate: it smuggles normative choices (linear utility in lives, discounting of tail risk, ignoring option value) into the quantitative apparatus. Legislative testimony from affected communities, academic work on decision-making under deep uncertainty, and philosophical critiques of aggregation corroborate the contested status from outside the benefiting framework.
narrative_ontology:disappearance_verdict(acceptable_risk_energy__expected_value_dominant, world_rearranges).
narrative_ontology:founding_problem_status(acceptable_risk_energy__expected_value_dominant, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(acceptable_risk_energy__expected_value_dominant, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(acceptable_risk_energy__expected_value_dominant, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(acceptable_risk_energy__expected_value_dominant_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(acceptable_risk_energy__expected_value_dominant, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(acceptable_risk_energy__expected_value_dominant_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is high (0.71) because the framework systematically discounts the concerns of those who fear catastrophic outcomes while fully counting (but then aggregating away) the mortality of those exposed to continuous pollution. The 'coordination' function—establishing a common metric—is real, but it is inseparable from asymmetric extraction: the metric choice itself determines whose deaths count as individually salient versus statistically acceptable. Suppression (0.78) is high because maintaining this framework requires active exclusion of alternative risk weightings (minimax regret, precautionary principles, option-value preservation) from policy consensus, enforced through professional gatekeeping in regulatory agencies and academic institutions. Theater ratio (0.42) reflects that cost-benefit analyses and quantitative risk assessments perform real analytic work, but a substantial and growing share of that work is devoted to defending the expected-utility axioms against challenges rather than improving actual risk estimates. Accessibility collapse (0.62) is moderate: alternative decision frameworks exist and are intellectually available, but they are excluded from policy authority. Resistance (0.58) is substantial: organized publics persistently resist nuclear expansion despite favorable mortality-per-TWh comparisons, indicating the framework has not achieved genuine consensus.
 *
 * PERSPECTIVAL GAP:
 *   From the agenda-setter seat (expected utility theorists, regulatory agencies), this constraint is legitimate technocratic coordination—the uniquely rational method for comparing incommensurable risks. From the payer seats (pollution-exposed populations, catastrophic-risk-concerned publics), the same structure operates as enforced extraction: their experienced or feared harms are defined out of salience by the analytic apparatus. The engine computes this divergence from the structural data; the authored claim (rope) versus the metrics (tangled_rope indicators) captures the gap between the framework's self-presentation and its operational reality.
 *
 * DIRECTIONALITY LOGIC:
 *   Expected utility theorists and the nuclear industry are structural beneficiaries: the framework vindicates their theoretical commitments and commercial interests. Air pollution exposed populations and catastrophic-risk-concerned publics are targets: their harms are either aggregated into acceptable background levels or probabilistically discounted. Climate advocates occupy a complex position—beneficiaries of the framework's disciplining effect on fossils, but potentially victims if tail risks materialize. Regulatory agencies are dual-positioned: they set the agenda by adopting the framework, but are also constrained by it (limited to expected-value optimization once the framework is institutionalized).
 *
 * MANDATROPHY ANALYSIS:
 *   The framework's founding mandate—systematic risk comparison across energy technologies—remains live as a coordination problem. However, the specific solution (expected-value dominance) encodes asymmetric extraction: it treats statistically diffuse harms as acceptable and catastrophic potentials as negligible, benefiting those whose risks are low-probability over those whose harms are continuous. This is genuine tangled_rope territory: real coordination function, real asymmetric extraction, requires active enforcement to suppress alternative framings. It is not a snare (the coordination function is not mere cover) and not a rope (the extraction is not incidental overhead).
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    expected_utility_uniqueness,
    'Is expected utility maximization the uniquely rational decision criterion under deep uncertainty about energy technology risks, or is it one coherent framework among several (minimax regret, robustness, precautionary principles)?',
    'Formal decision theory has established that multiple decision rules satisfy coherence axioms under different uncertainty structures. The empirical question is whether energy policy operates under risk (known probabilities) or deep uncertainty (unknown probabilities, model ambiguity), which determines which axioms apply. Resolution requires transparent uncertainty characterization in regulatory analyses.',
    'If energy risks involve deep uncertainty rather than quantifiable risk, then expected-value dominance is not uniquely rational—alternative frameworks like minimax regret or option-value preservation become equally defensible. This would dissolve the framework''s claim to technocratic objectivity and expose it as one normative choice among several.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(expected_utility_uniqueness, conceptual, 'Whether expected utility is uniquely rational for energy risk or one framework among several').

omega_variable(
    tail_risk_probability_knowability,
    'Are the probabilities of catastrophic nuclear accidents (beyond-design-basis events, spent fuel pool fires, cascading failures) sufficiently well-characterized to treat them as known risks suitable for expected-value aggregation?',
    'Engineering analysis of historical accident precursors, probabilistic risk assessment validation studies, and comparison of ex-ante PRA estimates to observed failure rates. If observed accidents consistently fall outside the modeled probability distributions, the probabilities are not knowable to the precision required for expected-value optimization.',
    'If catastrophic probabilities are not well-characterized, then discounting them via expected-value calculation smuggles epistemic uncertainty into the risk calculus as if it were aleatory uncertainty. This would support the catastrophic-tail-dominant reading over the expected-value-dominant reading.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(tail_risk_probability_knowability, empirical, 'Whether catastrophic nuclear accident probabilities are knowable enough for expected-value treatment').

omega_variable(
    aggregation_legitimacy,
    'Is it ethically legitimate to aggregate mortality across different populations and geographies into a single expected-value calculation, or do spatial concentration and distributional asymmetries make certain deaths non-fungible?',
    'This is a normative question about the interpersonal comparability of harms. Resolution would require explicit ethical framework declaration in regulatory policy—whether agencies adopt strict utilitarianism (all deaths weighted equally regardless of distribution) or rights-based frameworks (concentrated harms to identifiable populations treated differently from diffuse statistical mortality).',
    'If distributional asymmetries matter ethically, then the mortality-per-TWh metric conceals rather than reveals morally salient information. Air pollution deaths concentrated in powerless communities near fossil infrastructure would require different treatment than the global averaging implies. This would undermine the metric''s claim to objective risk comparison.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(aggregation_legitimacy, preference, 'Whether aggregating mortality across populations into expected value is ethically legitimate').

omega_variable(
    framework_path_dependence,
    'Did the expected-value-dominant framework achieve consensus because it is uniquely correct, or because it was institutionalized early by actors who benefited from its specific risk weighting?',
    'Historical analysis of regulatory framework adoption, tracing which actors funded early cost-benefit methodology development, which alternative frameworks were available but not adopted, and whether framework selection preceded or followed empirical risk characterization. Comparative policy analysis across jurisdictions that adopted different frameworks.',
    'If the framework is path-dependent rather than uniquely correct, its claim to technocratic objectivity is undermined—it becomes one contingent choice that benefits specific actors. This would expose the extractive dimension: the framework''s persistence depends on suppressing alternatives, not on superior epistemic grounding.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(framework_path_dependence, empirical, 'Whether framework dominance reflects correctness or path-dependent institutional capture').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(acceptable_risk_energy__expected_value_dominant, 0, 40).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(acce_tr_t0, acceptable_risk_energy__expected_value_dominant, theater_ratio, 0, 0.22).
narrative_ontology:measurement_basis(acce_tr_t0, observed).
narrative_ontology:measurement(acce_tr_t8, acceptable_risk_energy__expected_value_dominant, theater_ratio, 8, 0.28).
narrative_ontology:measurement_basis(acce_tr_t8, observed).
narrative_ontology:measurement(acce_tr_t16, acceptable_risk_energy__expected_value_dominant, theater_ratio, 16, 0.33).
narrative_ontology:measurement_basis(acce_tr_t16, observed).
narrative_ontology:measurement(acce_tr_t24, acceptable_risk_energy__expected_value_dominant, theater_ratio, 24, 0.37).
narrative_ontology:measurement_basis(acce_tr_t24, observed).
narrative_ontology:measurement(acce_tr_t32, acceptable_risk_energy__expected_value_dominant, theater_ratio, 32, 0.4).
narrative_ontology:measurement_basis(acce_tr_t32, observed).
narrative_ontology:measurement(acce_tr_t40, acceptable_risk_energy__expected_value_dominant, theater_ratio, 40, 0.42).
narrative_ontology:measurement_basis(acce_tr_t40, observed).

% Extraction over time
narrative_ontology:measurement(acce_be_t0, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 0, 0.51).
narrative_ontology:measurement_basis(acce_be_t0, observed).
narrative_ontology:measurement(acce_be_t8, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 8, 0.57).
narrative_ontology:measurement_basis(acce_be_t8, observed).
narrative_ontology:measurement(acce_be_t16, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 16, 0.63).
narrative_ontology:measurement_basis(acce_be_t16, observed).
narrative_ontology:measurement(acce_be_t24, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 24, 0.68).
narrative_ontology:measurement_basis(acce_be_t24, observed).
narrative_ontology:measurement(acce_be_t32, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 32, 0.7).
narrative_ontology:measurement_basis(acce_be_t32, observed).
narrative_ontology:measurement(acce_be_t40, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 40, 0.71).
narrative_ontology:measurement_basis(acce_be_t40, observed).

% Suppression requirement over time
narrative_ontology:measurement(acce_su_t0, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 0, 0.58).
narrative_ontology:measurement_basis(acce_su_t0, observed).
narrative_ontology:measurement(acce_su_t8, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 8, 0.64).
narrative_ontology:measurement_basis(acce_su_t8, observed).
narrative_ontology:measurement(acce_su_t16, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 16, 0.69).
narrative_ontology:measurement_basis(acce_su_t16, observed).
narrative_ontology:measurement(acce_su_t24, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 24, 0.73).
narrative_ontology:measurement_basis(acce_su_t24, observed).
narrative_ontology:measurement(acce_su_t32, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 32, 0.76).
narrative_ontology:measurement_basis(acce_su_t32, observed).
narrative_ontology:measurement(acce_su_t40, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 40, 0.78).
narrative_ontology:measurement_basis(acce_su_t40, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(acceptable_risk_energy__expected_value_dominant, information_standard).
narrative_ontology:boltzmann_floor_override(acceptable_risk_energy__expected_value_dominant, 0.08).
narrative_ontology:affects_constraint(acceptable_risk_energy__expected_value_dominant, acceptable_risk_energy__catastrophic_tail_dominant).
narrative_ontology:affects_constraint(acceptable_risk_energy__expected_value_dominant, acceptable_risk_energy__option_value_preserving).

% DUAL FORMULATION NOTE:
% This constraint is one of three readings of the 'acceptable risk in energy policy' kernel. The expected-value-dominant reading (this constraint) treats mortality-per-TWh as definitive and discounts catastrophic tail risk probabilistically. The catastrophic-tail-dominant reading (sibling) weights low-probability catastrophic outcomes heavily. The option-value-preserving reading (sibling) rejects singular optimization in favor of maintaining multiple pathways. These are structurally distinct constraints with different victim sets, different beneficiaries, and different epistemic authority structures—not different opinions about the same constraint.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

constraint_indexing:directionality_override(acceptable_risk_energy__expected_value_dominant, institutional, 0.15).

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
