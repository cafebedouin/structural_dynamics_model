% ============================================================================
% CONSTRAINT STORY: ai_governance_legitimacy__market_libertarian_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_ai_governance_legitimacy__market_libertarian_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: ai_governance_legitimacy__market_libertarian_reading
 *   human_readable: Market Libertarian Reading: AI Governance via Voluntary Exchange
 *   domain: theological_ethics/technology_governance/political_theology
 *
 * SUMMARY:
 *   This constraint instantiates the market libertarian reading of AI
 *   governance legitimacy from within a contested kernel that includes
 *   magisterial, technocratic, and democratic readings. It claims property
 *   rights and voluntary exchange as pre-political natural law, positioning
 *   collective solidarity mandates as illegitimate coercion. The reading
 *   selectively appropriates the encyclical's subsidiarity principle
 *   (decentralization) while rejecting its solidarity demands. Beneficiaries
 *   are those with market power and autonomy; victims are those lacking
 *   bargaining power or requiring collective action against externalities.
 *   The constraint is claimed as mountain (natural law of property rights)
 *   but the metrics document moderate extraction from powerless actors and
 *   structural exclusion of democratic and magisterial voices.
 *
 * KEY AGENTS:
 *   - entrepreneurs: Primary beneficiaries (powerful/arbitrage) — capture innovation value under minimal constraint
 *   - investors: Primary beneficiaries (powerful/arbitrage) — maximize returns absent solidarity obligations
 *   - high_autonomy_individuals: Secondary beneficiaries (moderate/mobile) — exercise genuine choice in competitive markets
 *   - low_market_power_individuals: Primary victims (powerless/trapped) — bear costs of algorithmic decisions without recourse
 *   - coordination_dependent_communities: Secondary victims (organized/constrained) — cannot address externalities without collective authority
 *   - monopsony_labor_market_workers: Primary victims (powerless/identity_locked) — 'voluntary' contracts structurally coerced
 *   - magisterial_authority: Excluded (institutional/analytical) — interpretive claims rejected as lacking coercive legitimacy
 *   - democratic_polities: Excluded (institutional/analytical) — majority mandates characterized as tyranny
 *   - libertarian_theorists: Analytical observers (analytical/analytical) — provide philosophical justification
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(ai_governance_legitimacy__market_libertarian_reading, 0.25).
domain_priors:suppression_score(ai_governance_legitimacy__market_libertarian_reading, 0.18).
domain_priors:theater_ratio(ai_governance_legitimacy__market_libertarian_reading, 0.12).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, extractiveness, 0.25).
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 0.18).
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 0.12).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, accessibility_collapse, 0.82).
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, resistance, 0.15).

% --- Constraint claim ---
narrative_ontology:constraint_claim(ai_governance_legitimacy__market_libertarian_reading, mountain).
narrative_ontology:human_readable(ai_governance_legitimacy__market_libertarian_reading, "Market Libertarian Reading: AI Governance via Voluntary Exchange").
narrative_ontology:topic_domain(ai_governance_legitimacy__market_libertarian_reading, "theological_ethics/technology_governance/political_theology").

domain_priors:emerges_naturally(ai_governance_legitimacy__market_libertarian_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(ai_governance_legitimacy__market_libertarian_reading, '812d0f79-a016-4c1f-b913-1d79d83dab61').
narrative_ontology:cs_kernel_codification('812d0f79-a016-4c1f-b913-1d79d83dab61', fixed_text).
narrative_ontology:cs_authority_grounding('812d0f79-a016-4c1f-b913-1d79d83dab61', extraction).
narrative_ontology:cs_reading_relation('812d0f79-a016-4c1f-b913-1d79d83dab61', ai_governance_legitimacy__magisterial_subsidiarity_reading, forecloses).
narrative_ontology:cs_reading_relation('812d0f79-a016-4c1f-b913-1d79d83dab61', ai_governance_legitimacy__technocratic_optimization_reading, coexists_with).
narrative_ontology:cs_reading_relation('812d0f79-a016-4c1f-b913-1d79d83dab61', ai_governance_legitimacy__democratic_pluralist_reading, coexists_with).
narrative_ontology:cs_axiom('812d0f79-a016-4c1f-b913-1d79d83dab61', foundational, property_rights_pre_political_natural_law).
narrative_ontology:cs_axiom_status(property_rights_pre_political_natural_law, holdable).
narrative_ontology:cs_axiom_grounding('812d0f79-a016-4c1f-b913-1d79d83dab61', property_rights_pre_political_natural_law, deontological).
narrative_ontology:cs_axiom('812d0f79-a016-4c1f-b913-1d79d83dab61', foundational, solidarity_mandates_illegitimate_coercion).
narrative_ontology:cs_axiom_status(solidarity_mandates_illegitimate_coercion, holdable).
narrative_ontology:cs_axiom_grounding('812d0f79-a016-4c1f-b913-1d79d83dab61', solidarity_mandates_illegitimate_coercion, deontological).
narrative_ontology:cs_axiom('812d0f79-a016-4c1f-b913-1d79d83dab61', secondary, dignity_protected_via_exit_not_collective_constraint).
narrative_ontology:cs_axiom_status(dignity_protected_via_exit_not_collective_constraint, holdable).
narrative_ontology:cs_axiom_grounding('812d0f79-a016-4c1f-b913-1d79d83dab61', dignity_protected_via_exit_not_collective_constraint, instrumental).
narrative_ontology:cs_reference_frame('812d0f79-a016-4c1f-b913-1d79d83dab61', lockean_property_rights_framework).
narrative_ontology:cs_drift_state('812d0f79-a016-4c1f-b913-1d79d83dab61', post_encyclical_solidarity_challenge, gap(authority_erosion, substantial, false)).
narrative_ontology:cs_created_at('812d0f79-a016-4c1f-b913-1d79d83dab61', '').
narrative_ontology:cs_kernel_id(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__market_libertarian_reading, entrepreneurs).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__market_libertarian_reading, investors).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__market_libertarian_reading, high_autonomy_individuals).
narrative_ontology:constraint_victim(ai_governance_legitimacy__market_libertarian_reading, low_market_power_individuals).
narrative_ontology:constraint_victim(ai_governance_legitimacy__market_libertarian_reading, coordination_dependent_communities).
narrative_ontology:constraint_victim(ai_governance_legitimacy__market_libertarian_reading, monopsony_labor_market_workers).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Build and deploy AI systems according to their own property rights and contractual arrangements. Face minimal collective oversight constraints. Benefit from low regulatory friction, rapid innovation cycles, and the ability to capture value directly from their technical innovations. Exit to favorable jurisdictions when local regulatory environments become restrictive.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, entrepreneurs, beneficiary,
    powerful, biographical, arbitrage, global).

% Allocate capital to AI ventures according to private return expectations. Benefit from unrestricted market dynamics that allow high-risk, high-reward ventures. Exit options include portfolio diversification across jurisdictions and asset classes. The absence of mandatory solidarity constraints maximizes potential returns.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, investors, beneficiary,
    powerful, biographical, arbitrage, global).

% Access AI services through competitive markets. Exercise choice through purchasing decisions and service switching. Possess skills, resources, and mobility to navigate market offerings effectively. Benefit from innovation competition and declining costs. Can exit unsatisfactory arrangements through market alternatives.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, high_autonomy_individuals, beneficiary,
    moderate, biographical, mobile, national).

% Lack bargaining power in AI service markets. Face algorithmic decisions in employment, credit, housing without effective recourse. Cannot afford premium services with better terms. Exit options are nominal—alternative services either unavailable or equivalently disadvantageous. Bear costs of market failures that collective governance would address.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, low_market_power_individuals, payer,
    powerless, immediate, trapped, local).

% Require collective action to address AI externalities—surveillance, displacement, environmental impact—but lack coercive authority under this framework. Must rely on voluntary cooperation that systematically underproduces public goods. Bear the costs of coordination failures that markets alone cannot solve.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, coordination_dependent_communities, payer,
    organized, generational, constrained, regional).

% Face concentrated employer power in AI-transformed labor markets. Geographic or skill constraints make exit infeasible. 'Voluntary' employment contracts are structurally coerced by lack of alternatives. Algorithmic management extracts surplus without collective bargaining counterweight. The framework's rejection of solidarity norms prevents organizing.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, monopsony_labor_market_workers, payer,
    powerless, biographical, identity_locked, regional).

% Claims interpretive authority over common good and human dignity but is structurally rejected by this reading as lacking legitimate coercive power over economic arrangements. Its principles are recast as voluntary moral guidance for those who accept its authority, not as binding norms for governance.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, magisterial_authority, excluded,
    institutional, civilizational, analytical, global).

% Majority democratic decisions to subordinate property rights to collective goods are characterized by this reading as illegitimate coercion. Electoral mandates for solidarity-based AI governance are rejected as tyranny of the majority. Their voice is excluded from the foundational legitimacy framework.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, democratic_polities, excluded,
    institutional, generational, analytical, national).

% Provide philosophical justification for the framework. Analyze the constraint as emerging from pre-political property rights and voluntary exchange principles. Evaluate competing readings as either compatible with liberty (subsidiarity) or fundamentally coercive (solidarity mandates).
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, libertarian_theorists, observer,
    analytical, civilizational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes voluntary exchange and contract enforcement as the sole legitimate governance mechanism for AI development and deployment. Solves the innovation coordination problem by removing collective mandates that would slow adaptation.
% TRANSFER_FUNCTION: Value flows from AI innovation accrue to property owners and contracting parties according to market prices. No mandatory redistribution toward those lacking market power. Externalities remain with those bearing them unless voluntary compensation emerges.
% ABSENT_VOICES: Those lacking market power to negotiate favorable terms, communities requiring collective action against externalities, workers in monopsony markets, and democratic majorities seeking solidarity-based governance are structurally excluded from the legitimacy foundation.
% DISAPPEARANCE_RATIONALE: Beneficiaries claim voluntary markets would persist and flourish absent this framework—it merely recognizes natural property rights. Victims claim disappearance would enable collective governance addressing power asymmetries and coordination failures. The encyclical's magisterial reading claims natural law requires solidarity constraints this framework rejects.
% FOUNDING_PROBLEM: The perceived threat that collective AI governance mandates would stifle innovation, violate property rights, and enable coercive redistribution under the guise of solidarity.
% FOUNDING_PROBLEM_CORROBORATION: Libertarian theorists and market advocates affirm the founding problem as live. The encyclical, democratic theorists, and welfare economists attest that the founding problem misconstrues the actual threat: unregulated AI markets produce power concentration and systematic harm to the vulnerable, which this framework cannot address.
narrative_ontology:disappearance_verdict(ai_governance_legitimacy__market_libertarian_reading, contested).
narrative_ontology:founding_problem_status(ai_governance_legitimacy__market_libertarian_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(ai_governance_legitimacy__market_libertarian_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(ai_governance_legitimacy__market_libertarian_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(ai_governance_legitimacy__market_libertarian_reading_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, ExtMetricName, E),
    domain_priors:suppression_score(ai_governance_legitimacy__market_libertarian_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(ai_governance_legitimacy__market_libertarian_reading),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(ai_governance_legitimacy__market_libertarian_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is moderate-low (0.25) because the framework produces genuine coordination benefits for high-autonomy actors while extracting from powerless actors through power asymmetries it refuses to address. Suppression is low (0.18) because enforcement relies primarily on contract law and reputation rather than active state coercion. Theater ratio is low (0.12) because the framework's operation is functionally consistent with its claims—voluntary exchange does govern, extraction arises from structural power differentials the framework treats as legitimate. Accessibility collapse is high (0.82) because once property rights are accepted as pre-political, alternatives requiring collective solidarity appear as coercion. Resistance is low (0.15) among those with market power; higher resistance from victims is treated as epistemically irrelevant to the natural-law claim.
 *
 * PERSPECTIVAL GAP:
 *   The beneficiary seats experience the constraint as genuine natural law enabling flourishing innovation. The victim seats experience identical structure as coercive extraction enabled by asymmetric power that the framework refuses to remedy. The analytical seats (magisterial, democratic) see a false summit: a constructed arrangement presented as pre-political natural law to immunize it from collective governance. The engine computes these divergent types from the structural data—the authored mountain claim embeds the reading's self-understanding, not adjudication.
 *
 * DIRECTIONALITY LOGIC:
 *   The structural asymmetry is severe. Beneficiary seats hold arbitrage exit and powerful/moderate power—their d values approach 0.0-0.3, yielding near-zero or negative χ (subsidy from the arrangement). Victim seats hold trapped/identity_locked exit and powerless classification—their d values approach 0.9, yielding high positive χ (extraction). The gap between beneficiary and victim effective extraction is the constraint's extractive signature, which the mountain claim obscures by naturalizing the power differential.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint exhibits classic false-summit structure: claimed as mountain (property rights as natural law) while producing systematic extraction from identifiable victims (powerless, trapped actors). The founding problem—preventing coercive collective mandates—is contested: victims attest that unregulated markets produce the actual coercion (algorithmic control, monopsony power) this framework cannot address. Disappearance verdict is contested because beneficiaries claim markets would persist naturally while victims claim collective governance would emerge to address asymmetries. The magisterial reading's solidarity principle is precisely what would address the extraction, and is the element this reading most forcefully rejects.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    natural_law_vs_constructed_legitimacy,
    'Are property rights and voluntary exchange pre-political natural law (as this reading claims) or constructed arrangements requiring ongoing democratic legitimation?',
    'Historical and anthropological evidence about whether property regimes precede political authority or are constituted by it; philosophical analysis of whether ''voluntary'' exchange under asymmetric power genuinely satisfies consent criteria.',
    'If property rights are constructed, the reading''s mountain claim collapses—it becomes a policy preference immunizing itself from collective governance by false naturalization. If genuinely natural law, collective mandates are indeed coercive interference.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(natural_law_vs_constructed_legitimacy, conceptual, 'Whether the constraint''s natural-law claim is genuine or a constructed arrangement falsely naturalized.').

omega_variable(
    voluntary_exchange_under_power_asymmetry,
    'Do contracts between parties with radically asymmetric power satisfy the moral requirement of voluntary exchange, or is structural coercion sufficient to vitiate consent?',
    'Empirical study of bargaining outcomes and welfare effects in markets with concentrated power; philosophical analysis of consent conditions under necessity.',
    'If structural coercion vitiates consent, ''voluntary'' contracts with powerless parties are extractive by this framework''s own criteria. If consent is satisfied by absence of direct force, the measured extraction reflects legitimate market outcomes.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(voluntary_exchange_under_power_asymmetry, conceptual, 'Whether structural power asymmetries constitute coercion under the framework''s own consent standard.').

omega_variable(
    coordination_failure_externalization,
    'How much of the measured extractiveness is genuine market efficiency versus externalized costs that collective governance would address but this framework forbids?',
    'Comparative institutional analysis of AI governance outcomes under market-only versus solidarity-constrained regimes; measurement of externality costs borne by coordination-dependent communities.',
    'High externalization would establish the framework as a false summit protecting beneficiaries from accountability. Low externalization would support the genuine coordination claim.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(coordination_failure_externalization, empirical, 'Proportion of measured extraction attributable to unaddressed coordination failures.').

omega_variable(
    subsidiarity_solidarity_separability,
    'Is the encyclical''s subsidiarity principle (which this reading accepts) structurally separable from its solidarity demands (which this reading rejects), or are they mutually constitutive?',
    'Theological and philosophical analysis of Catholic Social Doctrine''s internal coherence; examination of whether subsidiarity without solidarity produces the outcomes the encyclical warns against.',
    'If inseparable, this reading''s selective appropriation is incoherent—subsidiarity requires solidarity constraints this framework rejects. If separable, the reading''s decentralization claim is independently defensible.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(subsidiarity_solidarity_separability, conceptual, 'Whether this reading''s selective appropriation of the encyclical is structurally coherent.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(ai_governance_legitimacy__market_libertarian_reading, 0, 30).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(ai_g_tr_t0, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 0, 0.1).
narrative_ontology:measurement(ai_g_tr_t6, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 6, 0.11).
narrative_ontology:measurement(ai_g_tr_t12, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 12, 0.11).
narrative_ontology:measurement(ai_g_tr_t18, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 18, 0.12).
narrative_ontology:measurement(ai_g_tr_t24, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 24, 0.12).
narrative_ontology:measurement(ai_g_tr_t30, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 30, 0.12).

% Extraction over time
narrative_ontology:measurement(ai_g_be_t0, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 0, 0.22).
narrative_ontology:measurement(ai_g_be_t6, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 6, 0.23).
narrative_ontology:measurement(ai_g_be_t12, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 12, 0.24).
narrative_ontology:measurement(ai_g_be_t18, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 18, 0.25).
narrative_ontology:measurement(ai_g_be_t24, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 24, 0.25).
narrative_ontology:measurement(ai_g_be_t30, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 30, 0.25).

% Suppression requirement over time
narrative_ontology:measurement(ai_g_su_t0, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 0, 0.16).
narrative_ontology:measurement(ai_g_su_t6, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 6, 0.17).
narrative_ontology:measurement(ai_g_su_t12, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 12, 0.17).
narrative_ontology:measurement(ai_g_su_t18, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 18, 0.18).
narrative_ontology:measurement(ai_g_su_t24, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 24, 0.18).
narrative_ontology:measurement(ai_g_su_t30, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 30, 0.18).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(ai_governance_legitimacy__market_libertarian_reading, resource_allocation).
narrative_ontology:boltzmann_floor_override(ai_governance_legitimacy__market_libertarian_reading, 0.15).
narrative_ontology:affects_constraint(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy__magisterial_subsidiarity_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy__technocratic_optimization_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy__democratic_pluralist_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the ai_governance_legitimacy kernel. The market_libertarian_reading claims property rights as pre-political natural law (mountain), producing moderate extraction (0.25) from powerless actors it refuses to remedy. The magisterial_subsidiarity_reading treats solidarity as binding norm, producing lower extraction through mandatory accountability. The technocratic_optimization_reading subordinates ethical constraints to efficiency, producing higher extraction. The democratic_pluralist_reading derives legitimacy from public reason, with extraction varying by how effectively deliberation constrains power. All four readings interpret the same encyclical text and AI governance domain but instantiate structurally distinct constraints with different beneficiary/victim sets and ε values.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
