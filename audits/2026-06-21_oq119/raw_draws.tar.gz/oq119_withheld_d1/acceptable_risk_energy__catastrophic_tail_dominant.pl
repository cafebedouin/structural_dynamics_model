% ============================================================================
% CONSTRAINT STORY: acceptable_risk_energy__catastrophic_tail_dominant
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2025-01-09
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_acceptable_risk_energy__catastrophic_tail_dominant, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: acceptable_risk_energy__catastrophic_tail_dominant
 *   human_readable: Catastrophic Tail Risk Dominance in Energy Policy
 *   domain: risk_assessment/energy_policy/decision_theory
 *
 * SUMMARY:
 *   This constraint embodies one reading of the contested acceptable risk
 *   kernel in energy policy: that avoiding low-probability catastrophic
 *   events (nuclear accidents) justifies accepting higher aggregate mortality
 *   from distributed risks (fossil fuel air pollution, climate impacts). The
 *   reading is instantiated in nuclear licensing frameworks, environmental
 *   impact assessments, and insurance liability structures that treat
 *   catastrophic potential as categorically different from statistical
 *   mortality. The claim/metric gap is deliberate: claimed as tangled_rope
 *   (genuine coordination plus extraction) while metrics describe
 *   substantially extractive operation with rising theater ratio as the
 *   statistical mortality gap widens.
 *
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(acceptable_risk_energy__catastrophic_tail_dominant, 0.71).
domain_priors:suppression_score(acceptable_risk_energy__catastrophic_tail_dominant, 0.79).
domain_priors:theater_ratio(acceptable_risk_energy__catastrophic_tail_dominant, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, extractiveness, 0.71).
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 0.79).
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, resistance, 0.67).

% --- Constraint claim ---
narrative_ontology:constraint_claim(acceptable_risk_energy__catastrophic_tail_dominant, tangled_rope).
narrative_ontology:human_readable(acceptable_risk_energy__catastrophic_tail_dominant, "Catastrophic Tail Risk Dominance in Energy Policy").
narrative_ontology:topic_domain(acceptable_risk_energy__catastrophic_tail_dominant, "risk_assessment/energy_policy/decision_theory").

domain_priors:requires_active_enforcement(acceptable_risk_energy__catastrophic_tail_dominant).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(acceptable_risk_energy__catastrophic_tail_dominant, '2b3886b7-e57a-441e-883c-661762b0d972').
narrative_ontology:cs_kernel_codification('2b3886b7-e57a-441e-883c-661762b0d972', formalized).
narrative_ontology:cs_authority_grounding('2b3886b7-e57a-441e-883c-661762b0d972', lineage).
narrative_ontology:cs_interpretation_layer_present('2b3886b7-e57a-441e-883c-661762b0d972').
narrative_ontology:cs_reading_relation('2b3886b7-e57a-441e-883c-661762b0d972', acceptable_risk_energy__expected_value_dominant, forecloses).
narrative_ontology:cs_reading_relation('2b3886b7-e57a-441e-883c-661762b0d972', acceptable_risk_energy__option_value_preserving, influences).
narrative_ontology:cs_axiom('2b3886b7-e57a-441e-883c-661762b0d972', foundational, catastrophic_event_infinite_weight).
narrative_ontology:cs_axiom_status(catastrophic_event_infinite_weight, holdable).
narrative_ontology:cs_axiom_grounding('2b3886b7-e57a-441e-883c-661762b0d972', catastrophic_event_infinite_weight, deontological).
narrative_ontology:cs_axiom('2b3886b7-e57a-441e-883c-661762b0d972', secondary, distributed_mortality_discountable).
narrative_ontology:cs_axiom_status(distributed_mortality_discountable, holdable).
narrative_ontology:cs_axiom_grounding('2b3886b7-e57a-441e-883c-661762b0d972', distributed_mortality_discountable, empirically_contingent).
narrative_ontology:cs_reference_frame('2b3886b7-e57a-441e-883c-661762b0d972', post_chernobyl_precautionary_consensus).
narrative_ontology:cs_drift_state('2b3886b7-e57a-441e-883c-661762b0d972', contemporary_mortality_data_era, gap(axiom_overriding, substantial, false)).
narrative_ontology:cs_created_at('2b3886b7-e57a-441e-883c-661762b0d972', '').
narrative_ontology:cs_kernel_id(acceptable_risk_energy__catastrophic_tail_dominant, acceptable_risk_energy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__catastrophic_tail_dominant, fossil_fuel_industries).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__catastrophic_tail_dominant, renewable_energy_developers).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__catastrophic_tail_dominant, risk_averse_populations).
narrative_ontology:constraint_victim(acceptable_risk_energy__catastrophic_tail_dominant, statistical_mortality_populations).
narrative_ontology:constraint_victim(acceptable_risk_energy__catastrophic_tail_dominant, nuclear_energy_sector).
narrative_ontology:constraint_victim(acceptable_risk_energy__catastrophic_tail_dominant, climate_stability_advocates).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_victim(acceptable_risk_energy__catastrophic_tail_dominant, risk_averse_populations).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__catastrophic_tail_dominant, precautionary_principle_absolutism).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__catastrophic_tail_dominant, visible_harm_prioritization).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Benefit from continued market dominance as nuclear pathways remain suppressed. Catastrophic-tail framing deflects attention from distributed mortality (air pollution deaths, climate impacts) that accumulates continuously but lacks single catastrophic events. Their harm profile is statistically certain but temporally/spatially diffuse, allowing it to be discounted under this risk framework.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, fossil_fuel_industries, beneficiary,
    institutional, biographical, mobile, global).

% Gain policy support and investment flows as catastrophic-tail reasoning elevates their pathway relative to nuclear. Their risks (manufacturing impacts, land use, intermittency costs) are distributed and do not trigger catastrophic-event framing. The framework treats them as categorically safer even where lifecycle harm may be comparable.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, renewable_energy_developers, beneficiary,
    organized, biographical, mobile, global).

% Gain psychological security from avoiding nuclear pathways, particularly near potential plant sites. They pay through higher energy costs, continued fossil fuel externalities, and foregone climate mitigation that lower-cost nuclear might enable. The framework matches their dread-risk psychology but may not minimize their actual lifetime exposure to energy-related mortality.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, risk_averse_populations, beneficiary,
    organized, biographical, constrained, national).
narrative_ontology:stakeholder_secondary_role(acceptable_risk_energy__catastrophic_tail_dominant, risk_averse_populations, payer).

% Bear the distributed mortality burden from fossil fuel combustion (air pollution, mining accidents, climate impacts) that accumulates to higher aggregate deaths than nuclear's catastrophic tail. Their deaths are statistically predictable but individually anonymous and spread across time and space, making them invisible within catastrophic-tail frameworks. They have no organized voice in energy policy debates.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, statistical_mortality_populations, payer,
    powerless, biographical, trapped, global).

% Face regulatory suppression and stranded assets as catastrophic-tail reasoning drives policy against nuclear pathways regardless of statistical safety records. Low-probability high-consequence events dominate licensing, siting, and insurance requirements. Their actual mortality-per-TWh metrics become irrelevant under a framework that weights catastrophic potential infinitely.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, nuclear_energy_sector, payer,
    institutional, generational, trapped, global).

% Seek rapid decarbonization but find nuclear pathways suppressed under catastrophic-tail reasoning even where renewables cannot scale fast enough. They argue the framework creates a catastrophic tail risk in climate outcomes by prioritizing nuclear accident avoidance over emissions reduction urgency. Their timeline-based reasoning is subordinated to event-based catastrophe avoidance.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, climate_stability_advocates, payer,
    organized, generational, constrained, global).

% Encode catastrophic-tail dominance into licensing frameworks, environmental reviews, and liability structures. They respond to political pressure to avoid visible catastrophic failures even at cost of higher invisible distributed harm. Their institutional survival depends on preventing low-probability events that would be politically devastating, not on optimizing aggregate mortality statistics.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, regulatory_authorities, agenda_setter,
    institutional, generational, constrained, national).

% Analyze the structural implications of prioritizing tail risks over expected values. They document how dread-risk weighting creates systematic distortions in resource allocation and can increase aggregate harm while reducing catastrophic event probability. Their frameworks reveal the extractive asymmetry but do not adjudicate the normative choice between statistical lives and catastrophe avoidance.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, decision_theorists, observer,
    analytical, civilizational, analytical, universal).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Coordinates societal decision-making about energy infrastructure under deep uncertainty by providing a shared principle for comparing qualitatively different risk profiles across technologies.
% TRANSFER_FUNCTION: Moves regulatory approval, investment capital, and policy support away from nuclear pathways (low aggregate harm, catastrophic tail) toward fossil/renewable pathways (higher aggregate harm, distributed risk profile). Moves the burden of distributed mortality from visible to invisible populations.
% ABSENT_VOICES: The statistically dead from fossil fuel externalities have no seat. Future generations bearing climate costs from foregone nuclear mitigation are unrepresented. The nuclear workers and communities whose livelihoods depend on the suppressed pathway cannot overcome the catastrophic-event veto.
% DISAPPEARANCE_RATIONALE: If catastrophic-tail dominance vanished overnight and energy policy reverted to expected-value comparisons, nuclear licensing would accelerate, fossil fuel regulations would tighten to reflect actual mortality burdens, investment flows would shift dramatically, and energy system compositions would reorganize around statistical safety rather than dread avoidance.
% FOUNDING_PROBLEM: Post-Chernobyl and post-Fukushima political environment where visible catastrophic nuclear events created public demand for frameworks that absolutely prevent such events regardless of statistical trade-offs.
% FOUNDING_PROBLEM_CORROBORATION: Regulatory authorities and risk-averse populations attest the problem is live, citing continued public dread of nuclear accidents and political impossibility of siting new plants. Climate advocates and nuclear safety engineers attest the founding dread is outdated relative to modern reactor designs and comparative mortality data; their corroboration comes from lifecycle emissions analysis and mortality-per-TWh datasets published outside the benefiting regulatory structure.
narrative_ontology:disappearance_verdict(acceptable_risk_energy__catastrophic_tail_dominant, world_rearranges).
narrative_ontology:founding_problem_status(acceptable_risk_energy__catastrophic_tail_dominant, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(acceptable_risk_energy__catastrophic_tail_dominant, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(acceptable_risk_energy__catastrophic_tail_dominant, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(acceptable_risk_energy__catastrophic_tail_dominant_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(acceptable_risk_energy__catastrophic_tail_dominant, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(acceptable_risk_energy__catastrophic_tail_dominant_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is high (0.71) because the framework systematically advantages pathways with distributed harm over those with catastrophic tails, regardless of aggregate mortality comparisons. Suppression is higher still (0.79) because nuclear pathways face regulatory barriers untethered from their statistical safety records. Theater ratio is moderate and rising (0.42) as increasingly sophisticated mortality accounting reveals the statistical trade-off, yet policy frameworks continue performing catastrophe-prevention justifications. Accessibility collapse is moderate (0.48) because alternative risk frameworks (expected value, option value) remain conceptually available but politically foreclosed. Resistance is high (0.67) from climate advocates and nuclear sector who contest the framework with mortality data.
 *
 * PERSPECTIVAL GAP:
 *   From the regulatory seat, the framework is defensible coordination under deep uncertainty and political constraint. From the statistical mortality seat, it is extraction that sacrifices their lives to avoid politically visible catastrophes. From the climate advocacy seat, it creates the very catastrophic outcome (runaway warming) it claims to prevent. The engine computes these divergences from the structural positions.
 *
 * DIRECTIONALITY LOGIC:
 *   Fossil fuel industries and renewable developers benefit structurally from nuclear pathway suppression (d near beneficiary end). Risk-averse populations receive genuine psychological coordination but pay through foregone climate mitigation (d near symmetric). Statistical mortality populations and the nuclear sector are structural targets (d near target end). Regulatory authorities are agenda-setters but constrained by political dread-risk dynamics.
 *
 * MANDATROPHY ANALYSIS:
 *   The framework began as genuine coordination under post-Chernobyl uncertainty about reactor safety and public dread. Mandatrophy enters as modern mortality data reveals the statistical trade-off: fossil fuel externalities kill orders of magnitude more people than nuclear accidents even including Chernobyl and Fukushima, yet the catastrophic-tail framework persists and intensifies regulatory suppression of nuclear pathways. The coordination function (managing societal dread under uncertainty) remains real, but extraction has accumulated as beneficiaries (fossil fuel industries, regulatory agencies avoiding catastrophic-event liability) capture the framework to suppress a statistically safer alternative. The theater ratio rises as the gap between stated catastrophe-prevention justifications and actual mortality outcomes widens.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    infinite_weight_justification,
    'Is infinite weighting of catastrophic tails a defensible decision principle under deep uncertainty, or does it systematically produce higher aggregate harm by privileging visible over invisible death?',
    'Philosophical analysis of decision theory under uncertainty combined with empirical mortality accounting across energy pathways over multi-decade timescales. Resolution requires both normative choice about incommensurable values and empirical measurement of actual mortality distributions.',
    'If infinite weighting is unjustifiable, the framework is pure extraction sacrificing statistical lives to avoid politically visible events. If justifiable under deep uncertainty, extraction is lower and represents the necessary cost of coordinating under irreducible dread-risk asymmetries.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(infinite_weight_justification, conceptual, 'Whether catastrophic-tail dominance is legitimate coordination or statistical mortality extraction').

omega_variable(
    climate_catastrophe_tail,
    'Does catastrophic-tail reasoning applied to nuclear accidents but not to climate outcomes constitute internal inconsistency, or are the catastrophe types structurally different?',
    'Climate sensitivity analysis establishing the tail-risk distribution of warming outcomes, compared against nuclear accident probability distributions. Requires both physical climate models and normative framework for comparing event-based versus accumulating catastrophes.',
    'If climate represents an equivalent catastrophic tail, the framework''s selective application is extraction favoring fossil incumbents. If qualitatively different, the asymmetric treatment is justified coordination under different risk types.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(climate_catastrophe_tail, empirical, 'Whether selective catastrophic-tail application across energy risks is coherent').

omega_variable(
    distributed_harm_visibility,
    'Is the framework''s discounting of distributed mortality an unavoidable feature of human dread-risk psychology requiring coordination, or a constructed framing that benefits specific industries?',
    'Psychological research on risk perception combined with historical analysis of how distributed vs concentrated harm entered regulatory frameworks. Media analysis of whose mortality receives attention. Requires distinguishing evolved cognitive biases from manufactured ignorance.',
    'If unavoidable psychology, coordination function dominates and extraction is the price of working with human risk perception. If constructed framing, extraction is higher and beneficiaries are actively maintaining the visibility asymmetry.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(distributed_harm_visibility, conceptual, 'Whether distributed mortality invisibility is natural or constructed').

omega_variable(
    alternative_kernel_reading,
    'This constraint is one reading (catastrophic_tail_dominant) of the acceptable_risk_energy kernel. What structural elements would change under the expected_value_dominant or option_value_preserving readings?',
    'The expected_value reading would equalize victim sets across energy pathways based on mortality-per-TWh metrics, dramatically reducing nuclear suppression and shifting extraction to fossil incumbents. The option_value reading would maintain multiple pathways as insurance against model uncertainty, reducing suppression of any single pathway. The kernel decomposition routes this to network.affects_constraints.',
    'Recognition that this is one contested reading, not a discovered natural law. The extractiveness and beneficiary structure are reading-specific, not kernel-invariant.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(alternative_kernel_reading, conceptual, 'Kernel reading disambiguation per ε-invariance principle').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(acceptable_risk_energy__catastrophic_tail_dominant, 0, 35).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(acce_tr_t0, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 0, 0.28).
narrative_ontology:measurement_basis(acce_tr_t0, observed).
narrative_ontology:measurement(acce_tr_t7, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 7, 0.32).
narrative_ontology:measurement_basis(acce_tr_t7, observed).
narrative_ontology:measurement(acce_tr_t14, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 14, 0.35).
narrative_ontology:measurement_basis(acce_tr_t14, observed).
narrative_ontology:measurement(acce_tr_t21, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 21, 0.38).
narrative_ontology:measurement_basis(acce_tr_t21, observed).
narrative_ontology:measurement(acce_tr_t28, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 28, 0.4).
narrative_ontology:measurement_basis(acce_tr_t28, observed).
narrative_ontology:measurement(acce_tr_t35, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 35, 0.42).
narrative_ontology:measurement_basis(acce_tr_t35, observed).

% Extraction over time
narrative_ontology:measurement(acce_be_t0, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 0, 0.58).
narrative_ontology:measurement_basis(acce_be_t0, observed).
narrative_ontology:measurement(acce_be_t7, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 7, 0.62).
narrative_ontology:measurement_basis(acce_be_t7, observed).
narrative_ontology:measurement(acce_be_t14, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 14, 0.66).
narrative_ontology:measurement_basis(acce_be_t14, observed).
narrative_ontology:measurement(acce_be_t21, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 21, 0.69).
narrative_ontology:measurement_basis(acce_be_t21, observed).
narrative_ontology:measurement(acce_be_t28, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 28, 0.7).
narrative_ontology:measurement_basis(acce_be_t28, observed).
narrative_ontology:measurement(acce_be_t35, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 35, 0.71).
narrative_ontology:measurement_basis(acce_be_t35, observed).

% Suppression requirement over time
narrative_ontology:measurement(acce_su_t0, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 0, 0.68).
narrative_ontology:measurement_basis(acce_su_t0, observed).
narrative_ontology:measurement(acce_su_t7, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 7, 0.71).
narrative_ontology:measurement_basis(acce_su_t7, observed).
narrative_ontology:measurement(acce_su_t14, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 14, 0.74).
narrative_ontology:measurement_basis(acce_su_t14, observed).
narrative_ontology:measurement(acce_su_t21, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 21, 0.76).
narrative_ontology:measurement_basis(acce_su_t21, observed).
narrative_ontology:measurement(acce_su_t28, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 28, 0.78).
narrative_ontology:measurement_basis(acce_su_t28, observed).
narrative_ontology:measurement(acce_su_t35, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 35, 0.79).
narrative_ontology:measurement_basis(acce_su_t35, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(acceptable_risk_energy__catastrophic_tail_dominant, resource_allocation).
narrative_ontology:boltzmann_floor_override(acceptable_risk_energy__catastrophic_tail_dominant, 0.18).
narrative_ontology:affects_constraint(acceptable_risk_energy__catastrophic_tail_dominant, acceptable_risk_energy__expected_value_dominant).
narrative_ontology:affects_constraint(acceptable_risk_energy__catastrophic_tail_dominant, acceptable_risk_energy__option_value_preserving).

% DUAL FORMULATION NOTE:
% This constraint is the catastrophic_tail_dominant reading of the acceptable_risk_energy kernel. It decomposes into a constraint family with expected_value_dominant (which equalizes risk assessment across distributed and concentrated harm) and option_value_preserving (which maintains pathway diversity under deep uncertainty). Each reading has distinct ε, beneficiary/victim structures, and classification. They are linked via network.affects_constraints because they compete for the same policy space and regulatory encoding.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
