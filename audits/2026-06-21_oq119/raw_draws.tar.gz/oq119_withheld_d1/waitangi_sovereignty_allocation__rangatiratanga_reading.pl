% ============================================================================
% CONSTRAINT STORY: waitangi_sovereignty_allocation__rangatiratanga_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2024-01-15
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_waitangi_sovereignty_allocation__rangatiratanga_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: waitangi_sovereignty_allocation__rangatiratanga_reading
 *   human_readable: Treaty of Waitangi Sovereignty Allocation (Rangatiratanga Reading)
 *   domain: constitutional_law/indigenous_rights/post_colonial_governance
 *
 * SUMMARY:
 *   The Treaty of Waitangi (1840) exists in two non-equivalent texts: English
 *   and Māori. This constraint models the rangatiratanga reading—the
 *   interpretation grounded in the Māori text that most chiefs signed. In
 *   that text, Article I cedes kāwanatanga (governorship) to the Crown,
 *   understood by chiefs as limited administrative authority over settlers.
 *   Article II explicitly retains tino rangatiratanga (full chiefly
 *   authority/sovereignty) over lands, villages, forests, fisheries, and all
 *   taonga (treasures). This reading establishes a dual-authority structure:
 *   Crown jurisdiction over settlers, Māori jurisdiction over Māori
 *   territories and peoples. The constraint describes how Crown institutions
 *   systematically implemented the English-text reading (complete sovereignty
 *   cession) instead, extracting governance authority and resources that the
 *   Māori text never authorized ceding. The claim/metric independence is
 *   structural: claimed as tangled_rope (genuine coordination function in
 *   establishing formal relations, but asymmetric extraction where Article II
 *   guarantees were overridden) with metrics showing substantial extraction
 *   and high suppression. The divergence is the measurement—the gap between
 *   what the Māori text guaranteed and what was actually implemented.
 *
 * KEY AGENTS:
 *   - maori_iwi: Organized / identity_locked — tribal confederations whose rangatiratanga was guaranteed by Article II but systematically overridden
 *   - maori_hapu: Moderate / identity_locked — sub-tribal groups who signed and bore direct extraction of governance authority and land
 *   - crown_administration: Institutional / arbitrage — sets and enforces the sovereignty interpretation, collected the jurisdictional transfer
 *   - settler_population: Powerful / mobile — beneficiaries of unitary sovereignty giving them land access and legal certainty beyond treaty authorization
 *   - treaty_tribunal: Institutional observer / constrained — documents violations but lacks enforcement power within Crown-sovereignty framework
 *   - constitutional_historians: Analytical observer — document the textual divergence and implementation asymmetry
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(waitangi_sovereignty_allocation__rangatiratanga_reading, 0.68).
domain_priors:suppression_score(waitangi_sovereignty_allocation__rangatiratanga_reading, 0.79).
domain_priors:theater_ratio(waitangi_sovereignty_allocation__rangatiratanga_reading, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, extractiveness, 0.68).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 0.79).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, resistance, 0.73).

% --- Constraint claim ---
narrative_ontology:constraint_claim(waitangi_sovereignty_allocation__rangatiratanga_reading, tangled_rope).
narrative_ontology:human_readable(waitangi_sovereignty_allocation__rangatiratanga_reading, "Treaty of Waitangi Sovereignty Allocation (Rangatiratanga Reading)").
narrative_ontology:topic_domain(waitangi_sovereignty_allocation__rangatiratanga_reading, "constitutional_law/indigenous_rights/post_colonial_governance").

domain_priors:requires_active_enforcement(waitangi_sovereignty_allocation__rangatiratanga_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(waitangi_sovereignty_allocation__rangatiratanga_reading, '52b7f544-2bba-4b07-a635-c99766158c71').
narrative_ontology:cs_kernel_codification('52b7f544-2bba-4b07-a635-c99766158c71', fixed_text).
narrative_ontology:cs_authority_grounding('52b7f544-2bba-4b07-a635-c99766158c71', lineage).
narrative_ontology:cs_interpretation_layer_present('52b7f544-2bba-4b07-a635-c99766158c71').
narrative_ontology:cs_reading_relation('52b7f544-2bba-4b07-a635-c99766158c71', waitangi_sovereignty_allocation__crown_sovereignty_reading, forecloses).
narrative_ontology:cs_reading_relation('52b7f544-2bba-4b07-a635-c99766158c71', waitangi_sovereignty_allocation__partnership_reading, influences).
narrative_ontology:cs_axiom('52b7f544-2bba-4b07-a635-c99766158c71', foundational, rangatiratanga_sovereignty_retention).
narrative_ontology:cs_axiom_status(rangatiratanga_sovereignty_retention, holdable).
narrative_ontology:cs_axiom_grounding('52b7f544-2bba-4b07-a635-c99766158c71', rangatiratanga_sovereignty_retention, conventional).
narrative_ontology:cs_axiom('52b7f544-2bba-4b07-a635-c99766158c71', secondary, dual_authority_structure_required).
narrative_ontology:cs_axiom_status(dual_authority_structure_required, holdable).
narrative_ontology:cs_axiom_grounding('52b7f544-2bba-4b07-a635-c99766158c71', dual_authority_structure_required, conventional).
narrative_ontology:cs_reference_frame('52b7f544-2bba-4b07-a635-c99766158c71', article_ii_guaranteed_rangatiratanga).
narrative_ontology:cs_drift_state('52b7f544-2bba-4b07-a635-c99766158c71', contemporary_post_tribunal_era, gap(practice_drift, severe, true)).
narrative_ontology:cs_created_at('52b7f544-2bba-4b07-a635-c99766158c71', '').
narrative_ontology:cs_kernel_id(waitangi_sovereignty_allocation__rangatiratanga_reading, waitangi_sovereignty_allocation).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__rangatiratanga_reading, crown_administration).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__rangatiratanga_reading, settler_population).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__rangatiratanga_reading, maori_iwi).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__rangatiratanga_reading, maori_hapu).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__rangatiratanga_reading, crown_law_office).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__rangatiratanga_reading, westminster_parliamentary_supremacy).
narrative_ontology:constraint_vindicates(waitangi_sovereignty_allocation__rangatiratanga_reading, unitary_sovereignty_doctrine).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Tribal confederations whose chiefs signed the Māori text Article II explicitly retaining tino rangatiratanga (full chieftainship authority) over lands, forests, fisheries, and taonga while ceding only kāwanatanga (governorship over settlers). Their reading: the treaty established parallel authority structures with Māori retaining sovereignty over their own people and territories. They bear the extraction of having their governance authority systematically overridden by Crown institutions asserting unitary sovereignty, losing land through mechanisms that contravene Article II guarantees, and being subject to laws made without their consent. Exit is identity-locked: to exit the treaty framework is to abandon the only formal recognition of their status as original sovereign peoples.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, maori_iwi, payer,
    organized, generational, identity_locked, national).

% Sub-tribal kinship groups who were the actual signatories and hold mana over specific territories. The Māori text they signed preserved their tino rangatiratanga over resources and taonga within their rohe. Under Crown sovereignty interpretation, their local governance authority was dissolved into a unitary state structure, their resource management practices criminalized or overridden, and their lands alienated through Crown pre-emption that violated Article II. They cannot exit: the treaty is the documentary foundation of their claims to any recognition at all within the settler-state legal system.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, maori_hapu, payer,
    moderate, generational, identity_locked, regional).

% Governors, officials, and parliamentary institutions who interpreted the treaty through the English text (Article I: complete sovereignty cession) rather than the Māori text (Article II: retained rangatiratanga). They set policy, legislate, adjudicate, and enforce law across all territory and peoples without Māori consent structures, defending this as necessary for unified governance. They collected land, resources, and jurisdictional control that the rangatiratanga reading says was never ceded. Their position is theoretically revisable through constitutional reinterpretation, but revision threatens the legitimacy foundation of every institution built on unitary sovereignty.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, crown_administration, agenda_setter,
    institutional, generational, arbitrage, national).

% European settlers whose presence the treaty's English Article I legitimized by establishing Crown sovereignty, giving them secure property rights and British law protection. The rangatiratanga reading would have limited Crown jurisdiction to settler affairs only, leaving Māori governance intact over Māori territories. Instead, unitary sovereignty gave settlers access to Māori land through Crown mechanisms, secured their commercial activities under a single legal regime, and subordinated Māori authority to settler-majority parliaments. They benefit from land access and legal certainty that the rangatiratanga reading would not have provided.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, settler_population, beneficiary,
    powerful, biographical, mobile, national).

% Permanent commission of inquiry established in 1975 to investigate Crown breaches of treaty principles. They examine both texts, hear Māori claims of Article II violations, and issue recommendations that acknowledge the rangatiratanga reading's textual legitimacy. Their findings document systematic extraction but lack binding enforcement power: Parliament retains sovereignty to reject their recommendations. They see the structural divergence between what the Māori text guaranteed and what the Crown implemented, but operate within a constitutional framework that treats Crown sovereignty as settled.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, treaty_tribunal, observer,
    institutional, generational, constrained, national).

% Legal advisors who defend Crown actions in treaty litigation. They rely on the English text and established constitutional doctrine to maintain that Article I ceded complete sovereignty, making Article II subject to parliamentary supremacy. They acknowledge the textual divergence between English and Māori versions but argue settled law trumps treaty text. Recognizing the rangatiratanga reading would invalidate land titles, resource allocations, and jurisdictional structures they are institutionally committed to defending. They are constrained rather than arbitrage-mobile because their professional identity is fused with the Crown's constitutional position.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, crown_law_office, agenda_setter,
    institutional, generational, constrained, national).
narrative_ontology:stakeholder_secondary_role(waitangi_sovereignty_allocation__rangatiratanga_reading, crown_law_office, beneficiary).

% Scholars who examine the treaty's creation, translation, and implementation. They document that the Māori text (signed by most chiefs) and English text diverge fundamentally on sovereignty, that tino rangatiratanga and kāwanatanga are not synonyms, and that chiefs believed they were retaining authority while ceding only limited governorship. They map how Crown institutions systematically implemented the English reading despite the Māori text being the one most signatories understood. They provide the analytical frame for the structural contest but do not adjudicate which reading should prevail.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, constitutional_historians, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes a legal framework for Crown presence and settler-Māori relations in Aotearoa, providing a documented basis for governance arrangements and land transactions where previously only ad-hoc agreements and contested authority existed.
% TRANSFER_FUNCTION: Moves governance authority, land, resources, and jurisdictional control from Māori tribal structures to Crown institutions and settler beneficiaries. The rangatiratanga reading says this transfer was never authorized by the Māori text—that Article II explicitly reserved full authority to Māori over their territories and taonga, with only limited governorship over settlers ceded in Article I.
% ABSENT_VOICES: Māori who did not sign (many chiefs refused precisely because they understood rangatiratanga would be lost), Māori women whose authority in traditional governance was not represented in the male-chief signing process, and later generations of Māori whose claims to Article II guarantees face courts that treat Crown sovereignty as constitutionally settled. They are structurally excluded because the interpretive authority sits with Crown institutions whose legitimacy depends on the English-text reading.
% DISAPPEARANCE_RATIONALE: If the treaty and its sovereignty allocation vanished overnight, the legal foundation for Crown authority over Aotearoa disappears. Māori iwi and hapū would reassert rangatiratanga over their territories with no documentary constraint; settler property titles derived from Crown grants would lose their legitimizing instrument; parliamentary jurisdiction over Māori would become naked colonialism without the treaty's apparent consent mechanism. Every institution built on unitary Crown sovereignty would require re-legitimation or dissolution. The entire constitutional order is organized around one reading of this document.
% FOUNDING_PROBLEM: Ungoverned settler-Māori contact was producing violence, fraudulent land transactions, and competing sovereignty claims. Britain needed a legal instrument to establish Crown authority and regulate settlers; Māori chiefs needed documented guarantees of their authority and property as settler population grew.
% FOUNDING_PROBLEM_CORROBORATION: Crown and settler historians attest the founding problem as unregulated colonization, which the treaty solved by establishing British sovereignty. Māori historians and the Treaty Tribunal attest the founding problem as protecting Māori rangatiratanga from settler encroachment, which the treaty was meant to solve through Article II guarantees—a protection that failed when Crown institutions implemented the English-text reading. The contest is over which version of the founding problem the treaty actually addressed: imposing Crown sovereignty, or protecting Māori authority.
narrative_ontology:disappearance_verdict(waitangi_sovereignty_allocation__rangatiratanga_reading, world_rearranges).
narrative_ontology:founding_problem_status(waitangi_sovereignty_allocation__rangatiratanga_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(waitangi_sovereignty_allocation__rangatiratanga_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(waitangi_sovereignty_allocation__rangatiratanga_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(waitangi_sovereignty_allocation__rangatiratanga_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(waitangi_sovereignty_allocation__rangatiratanga_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(waitangi_sovereignty_allocation__rangatiratanga_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is high (0.68) because the constraint's operation systematically transferred authority and resources that the rangatiratanga reading says were never ceded—Article II explicitly reserved them. The extraction accumulated through land confiscations, resource alienations, and jurisdictional override that violated Article II guarantees. Suppression is higher (0.79) because maintaining this interpretation required criminalizing Māori governance practices, suppressing claims to Article II authority, and enforcing Crown law over peoples who never consented to full subjection. Theater ratio is moderate (0.42): the treaty framework provides genuine legal structure for addressing historical claims (Treaty Tribunal, settlements), but a large share of institutional energy now goes to managing the legitimacy gap between what the Māori text guaranteed and what was implemented. Accessibility collapse is lower (0.48) because the rangatiratanga reading remains textually grounded and politically live—constitutional reform toward co-governance is contested but accessible. Resistance is high (0.73) because Māori have continuously contested Crown sovereignty claims through legal challenges, tribunal processes, protests, and direct assertion of rangatiratanga, never accepting the English-text reading as legitimate.
 *
 * PERSPECTIVAL GAP:
 *   From the Crown administration and settler-population seats, the constraint is legitimate constitutional settlement (English text ceded sovereignty; institutions built on that foundation are lawful). From Māori iwi and hapū seats, the same constraint is systematic breach of the treaty they actually signed (Māori text reserved rangatiratanga; Crown implementation violated Article II). The treaty tribunal seat sees both: acknowledges rangatiratanga reading's textual legitimacy and documents violations, but lacks power to enforce against parliamentary sovereignty. The engine should compute Crown seats as experiencing coordination with modest extraction (stabilizing governance, some institutional constraint), and Māori seats as experiencing high extraction with identity-locked suppression (authority transfer never authorized, exit impossible without abandoning indigenous legal standing).
 *
 * DIRECTIONALITY LOGIC:
 *   Māori iwi and hapū are structural victims (identity_locked, organized/moderate power): the constraint extracts governance authority and resources Article II guaranteed them, and exit means abandoning their only formal recognition as sovereign peoples. Crown administration is agenda-setter and collector: they interpreted the treaty, built institutions on that interpretation, and captured jurisdictional control. Settler population are beneficiaries: unitary sovereignty gave them land access and legal protection the rangatiratanga reading would not provide. The Treaty Tribunal and historians are observers at different removes: tribunal constrained by operating within Crown-sovereignty framework, historians analytical.
 *
 * MANDATROPHY ANALYSIS:
 *   The founding problem—regulating settler-Māori contact and protecting rights—is contested rather than resolved. Crown framing: the problem was establishing orderly governance, solved by British sovereignty. Māori framing: the problem was protecting rangatiratanga from settler encroachment, which the treaty failed to solve because Crown institutions implemented the English text instead of the Māori one. The mandatrophy question is whether the coordination function (formal legal framework for relations) can be separated from the extraction function (override of Article II guarantees). Current constitutional reform debates test exactly this: co-governance proposals attempt to separate the functions by operationalizing rangatiratanga alongside Crown institutions, which is what the Māori text originally specified. Resistance to reform comes from seats whose legitimacy depends on unitary sovereignty.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    textual_authority_primacy,
    'When a treaty exists in two non-equivalent texts and most signatories signed one version, which text governs? Does the Māori text (signed by ~500 chiefs) or the English text (signed by ~40 chiefs) establish the authoritative sovereignty allocation?',
    'Constitutional court ruling applying treaty interpretation principles (contra proferentem: ambiguity resolved against the drafting party; indigenous-treaty interpretation: terms understood as indigenous signatories would have understood them). Or constitutional convention recognizing Māori-text primacy.',
    'If Māori text governs, the rangatiratanga reading becomes the authoritative interpretation, requiring fundamental constitutional restructuring toward co-governance or independent Māori jurisdiction. If English text governs, Crown sovereignty remains settled and Article II violations are historical breaches within a legitimate framework rather than void ab initio acts.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(textual_authority_primacy, conceptual, 'Which language version establishes authoritative sovereignty allocation when texts diverge').

omega_variable(
    rangatiratanga_sovereignty_equivalence,
    'Did tino rangatiratanga as understood by signing chiefs in 1840 equate to full sovereignty in the Western legal sense, or was it a different form of authority not directly translatable to European sovereignty concepts?',
    'Historical-linguistic analysis of how rangatiratanga was understood in te ao Māori (the Māori world) versus how sovereignty operated in British constitutional doctrine. Examination of speeches, debates, and subsequent actions by signing chiefs.',
    'If rangatiratanga equals sovereignty, Article II explicitly reserved sovereignty and Crown claims to complete sovereignty are void. If rangatiratanga is a distinct form of authority, the constitutional question becomes how to accommodate parallel authority structures rather than which side holds unitary sovereignty.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(rangatiratanga_sovereignty_equivalence, conceptual, 'Whether rangatiratanga and sovereignty are equivalent concepts or require parallel recognition').

omega_variable(
    crown_jurisdiction_scope_under_kawanatanga,
    'What scope of Crown authority over settlers does kāwanatanga (governorship) actually authorize? Does it permit only administrative regulation of settler affairs, or does it extend to territorial sovereignty enabling land alienation and resource control?',
    'Linguistic analysis of kāwanatanga in 1840s Māori usage (governorship, stewardship) versus how Crown institutions interpreted it (full territorial sovereignty). Comparison to other contemporary Māori-language translations of ''sovereignty'' versus ''governorship''.',
    'Narrow kāwanatanga (limited to settler governance) means Crown land acquisition required ongoing Māori consent under rangatiratanga, making much colonial land tenure unlawful. Broad kāwanatanga (territorial sovereignty) supports Crown''s historical actions but contradicts contemporary linguistic evidence that chiefs understood limited cession.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(crown_jurisdiction_scope_under_kawanatanga, empirical, 'Scope of Crown authority authorized by Article I kāwanatanga cession').

omega_variable(
    coordination_extraction_separability,
    'Is the treaty''s coordination function (legal framework for Crown-Māori relations, dispute resolution, property security) structurally separable from its extraction function (override of Article II rangatiratanga guarantees), or does the coordination depend on unitary Crown sovereignty?',
    'Natural experiment from co-governance arrangements where rangatiratanga is operationalized alongside Crown institutions: if coordination functions (legal certainty, dispute resolution) persist while extraction diminishes (Māori authority recognized), the functions are separable.',
    'If separable, constitutional reform toward co-governance can preserve coordination while ending extraction, making the constraint a solvable Tangled Rope. If inseparable, recognizing rangatiratanga dissolves the coordination framework, forcing either parallel legal systems or constitutional deadlock.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(coordination_extraction_separability, empirical, 'Whether treaty coordination requires unitary sovereignty or can accommodate parallel authority').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(waitangi_sovereignty_allocation__rangatiratanga_reading, 1840, 2024).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(wait_tr_t1840, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 1840, 0.25).
narrative_ontology:measurement_basis(wait_tr_t1840, observed).
narrative_ontology:measurement(wait_tr_t1860, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 1860, 0.28).
narrative_ontology:measurement_basis(wait_tr_t1860, observed).
narrative_ontology:measurement(wait_tr_t1880, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 1880, 0.32).
narrative_ontology:measurement_basis(wait_tr_t1880, observed).
narrative_ontology:measurement(wait_tr_t1920, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 1920, 0.38).
narrative_ontology:measurement_basis(wait_tr_t1920, observed).
narrative_ontology:measurement(wait_tr_t1975, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 1975, 0.45).
narrative_ontology:measurement_basis(wait_tr_t1975, observed).
narrative_ontology:measurement(wait_tr_t2024, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 2024, 0.42).
narrative_ontology:measurement_basis(wait_tr_t2024, observed).

% Extraction over time
narrative_ontology:measurement(wait_be_t1840, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 1840, 0.35).
narrative_ontology:measurement_basis(wait_be_t1840, observed).
narrative_ontology:measurement(wait_be_t1860, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 1860, 0.52).
narrative_ontology:measurement_basis(wait_be_t1860, observed).
narrative_ontology:measurement(wait_be_t1880, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 1880, 0.64).
narrative_ontology:measurement_basis(wait_be_t1880, observed).
narrative_ontology:measurement(wait_be_t1920, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 1920, 0.71).
narrative_ontology:measurement_basis(wait_be_t1920, observed).
narrative_ontology:measurement(wait_be_t1975, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 1975, 0.69).
narrative_ontology:measurement_basis(wait_be_t1975, observed).
narrative_ontology:measurement(wait_be_t2024, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 2024, 0.68).
narrative_ontology:measurement_basis(wait_be_t2024, observed).

% Suppression requirement over time
narrative_ontology:measurement(wait_su_t1840, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 1840, 0.45).
narrative_ontology:measurement_basis(wait_su_t1840, observed).
narrative_ontology:measurement(wait_su_t1860, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 1860, 0.62).
narrative_ontology:measurement_basis(wait_su_t1860, observed).
narrative_ontology:measurement(wait_su_t1880, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 1880, 0.74).
narrative_ontology:measurement_basis(wait_su_t1880, observed).
narrative_ontology:measurement(wait_su_t1920, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 1920, 0.81).
narrative_ontology:measurement_basis(wait_su_t1920, observed).
narrative_ontology:measurement(wait_su_t1975, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 1975, 0.76).
narrative_ontology:measurement_basis(wait_su_t1975, observed).
narrative_ontology:measurement(wait_su_t2024, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 2024, 0.79).
narrative_ontology:measurement_basis(wait_su_t2024, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(waitangi_sovereignty_allocation__rangatiratanga_reading, enforcement_mechanism).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__rangatiratanga_reading, waitangi_sovereignty_allocation__crown_sovereignty_reading).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__rangatiratanga_reading, waitangi_sovereignty_allocation__partnership_reading).

% DUAL FORMULATION NOTE:
% This reading is one of three constraints in the waitangi_sovereignty_allocation kernel family. Each reading instantiates a structurally distinct sovereignty allocation from the same founding document (Treaty of Waitangi 1840): rangatiratanga reading (this file, Māori text: retained full authority), crown_sovereignty reading (English text: complete cession), partnership_reading (evolving-principles doctrine: hybrid framework). The ε values are disjoint because the readings differ fundamentally in who are beneficiaries versus victims: this reading measures extraction against Article II guarantees that Crown implementation violated; crown_sovereignty reading treats those same acts as authorized. These are separate constraints that compete as interpretations of the same kernel, linked here because they cannot all be operationalized simultaneously within one constitutional framework.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
