% ============================================================================
% CONSTRAINT STORY: acceptable_risk_energy__option_value_preserving
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-12
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_acceptable_risk_energy__option_value_preserving, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: acceptable_risk_energy__option_value_preserving
 *   human_readable: Acceptable Risk as Option-Value Preservation in Energy Policy
 *   domain: energy_policy/decision_theory/risk_assessment
 *
 * SUMMARY:
 *   This constraint is the option-value-preserving reading of the
 *   acceptable-risk-in-energy kernel. It instantiates the real-options
 *   framework: acceptable risk is defined as maintaining technical capability
 *   across multiple energy pathways (nuclear, fossil-with-CCS,
 *   renewables-plus-storage) rather than committing fully to any single
 *   pathway, justified by deep uncertainty about future technology costs and
 *   climate-policy trajectories. The reading is claimed as tangled_rope
 *   because it genuinely coordinates against premature lock-in (a real
 *   failure mode under uncertainty) while extracting mitigation speed and
 *   capital concentration from climate advocates and pathway-specific
 *   coalitions. The metric/claim gap is deliberate: the metrics describe
 *   rising extraction as renewable cost-curves collapsed the genuine
 *   uncertainty the reading was built to hedge.
 *
 * KEY AGENTS:
 *   - energy_portfolio_managers: Agenda-setters (institutional/mobile) — administer the hedging framework, collect planning fees
 *   - regulatory_bodies_hedging_uncertainty: Agenda-setters (institutional/constrained) — set diversity mandates, avoid single-pathway political risk
 *   - incumbent_energy_firms: Beneficiaries (powerful/constrained) — stranded assets kept viable as 'portfolio insurance'
 *   - climate_mitigation_advocates: Payers (organized/constrained) — bear opportunity cost of delayed commitment
 *   - nuclear_expansion_proponents: Payers (organized/constrained) — bear suppressed-commitment cost (rationed capital)
 *   - ratepayers_bearing_portfolio_costs: Payers (powerless/trapped) — pay the option premium through socialized rate base
 *   - renewables_deployment_coalitions: Excluded (organized/constrained) — their pathway framed as default, not option
 *   - decision_theory_analysts: Observers (analytical/analytical) — see extraction when uncertainty-resolution horizon exceeds decision relevance
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(acceptable_risk_energy__option_value_preserving, 0.58).
domain_priors:suppression_score(acceptable_risk_energy__option_value_preserving, 0.52).
domain_priors:theater_ratio(acceptable_risk_energy__option_value_preserving, 0.41).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, extractiveness, 0.58).
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, suppression_requirement, 0.52).
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, theater_ratio, 0.41).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, resistance, 0.61).

% --- Constraint claim ---
narrative_ontology:constraint_claim(acceptable_risk_energy__option_value_preserving, tangled_rope).
narrative_ontology:human_readable(acceptable_risk_energy__option_value_preserving, "Acceptable Risk as Option-Value Preservation in Energy Policy").
narrative_ontology:topic_domain(acceptable_risk_energy__option_value_preserving, "energy_policy/decision_theory/risk_assessment").

domain_priors:requires_active_enforcement(acceptable_risk_energy__option_value_preserving).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(acceptable_risk_energy__option_value_preserving, '7f87423b-1bbd-4bb8-abe6-331b6ae4bac7').
narrative_ontology:cs_kernel_codification('7f87423b-1bbd-4bb8-abe6-331b6ae4bac7', formalized).
narrative_ontology:cs_authority_grounding('7f87423b-1bbd-4bb8-abe6-331b6ae4bac7', expertise).
narrative_ontology:cs_interpretation_layer_present('7f87423b-1bbd-4bb8-abe6-331b6ae4bac7').
narrative_ontology:cs_reading_relation('7f87423b-1bbd-4bb8-abe6-331b6ae4bac7', acceptable_risk_energy__catastrophic_tail_dominant, influences).
narrative_ontology:cs_reading_relation('7f87423b-1bbd-4bb8-abe6-331b6ae4bac7', acceptable_risk_energy__expected_value_dominant, influences).
narrative_ontology:cs_axiom('7f87423b-1bbd-4bb8-abe6-331b6ae4bac7', foundational, decision_flexibility_preservation_imperative).
narrative_ontology:cs_axiom_status(decision_flexibility_preservation_imperative, holdable).
narrative_ontology:cs_axiom_grounding('7f87423b-1bbd-4bb8-abe6-331b6ae4bac7', decision_flexibility_preservation_imperative, instrumental).
narrative_ontology:cs_axiom('7f87423b-1bbd-4bb8-abe6-331b6ae4bac7', secondary, irreversibility_dominates_expected_value).
narrative_ontology:cs_axiom_status(irreversibility_dominates_expected_value, holdable).
narrative_ontology:cs_axiom_grounding('7f87423b-1bbd-4bb8-abe6-331b6ae4bac7', irreversibility_dominates_expected_value, empirically_contingent).
narrative_ontology:cs_reference_frame('7f87423b-1bbd-4bb8-abe6-331b6ae4bac7', deep_uncertainty_irreducibility).
narrative_ontology:cs_drift_state('7f87423b-1bbd-4bb8-abe6-331b6ae4bac7', post_renewable_cost_collapse, gap(axiom_overriding, substantial, false)).
narrative_ontology:cs_created_at('7f87423b-1bbd-4bb8-abe6-331b6ae4bac7', '').
narrative_ontology:cs_kernel_id(acceptable_risk_energy__option_value_preserving, acceptable_risk_energy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__option_value_preserving, energy_portfolio_managers).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__option_value_preserving, regulatory_bodies_hedging_uncertainty).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__option_value_preserving, incumbent_energy_firms).
narrative_ontology:constraint_victim(acceptable_risk_energy__option_value_preserving, climate_mitigation_advocates).
narrative_ontology:constraint_victim(acceptable_risk_energy__option_value_preserving, nuclear_expansion_proponents).
narrative_ontology:constraint_victim(acceptable_risk_energy__option_value_preserving, ratepayers_bearing_portfolio_costs).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__option_value_preserving, real_options_framework_validity).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__option_value_preserving, deep_uncertainty_irreducibility).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Manage energy-system investment portfolios under regulatory mandate to maintain 'adequate diversity' and 'system resilience.' Use option-value framing to justify keeping both fossil-with-CCS and nuclear pathways open against future technology or climate-policy shocks. Collect planning fees and maintain institutional relevance by administering the hedging framework.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, energy_portfolio_managers, agenda_setter,
    institutional, generational, mobile, national).

% Set acceptable-risk standards that explicitly encode option preservation: require energy mix to maintain technical capability in multiple pathways rather than commit to single-technology dominance. Justify this as prudent hedging under deep uncertainty. Benefit from avoiding backlash from either pro-nuclear or pro-fossil coalitions by never fully closing either pathway.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, regulatory_bodies_hedging_uncertainty, agenda_setter,
    institutional, generational, constrained, national).
narrative_ontology:stakeholder_secondary_role(acceptable_risk_energy__option_value_preserving, regulatory_bodies_hedging_uncertainty, beneficiary).

% Own stranded-asset-exposed infrastructure in both fossil and nuclear sectors. The option-value reading keeps their assets commercially viable longer than early-commitment readings would—fossil plants stay online as 'backup capacity,' nuclear fleets avoid premature closure as 'portfolio insurance.' Do not set the standard but benefit from its maintenance.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, incumbent_energy_firms, beneficiary,
    powerful, biographical, constrained, national).

% Bear the opportunity cost of capital and time locked into maintaining optionality rather than committed to rapid decarbonization. Argue that the option-value framing treats climate deadlines as one uncertainty among many rather than a binding constraint, thereby extracting mitigation speed in exchange for flexibility the climate system does not grant.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, climate_mitigation_advocates, payer,
    organized, generational, constrained, global).

% Bear the cost of suppressed commitment: the reading keeps nuclear 'in the mix' but never fully resourced, because full commitment would foreclose the option to pivot. Capital for new nuclear construction is rationed to preserve portfolio balance rather than allocated to scale the technology.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, nuclear_expansion_proponents, payer,
    organized, generational, constrained, national).

% Pay for maintaining excess generating capacity across multiple pathways—idle fossil plants held as reserves, nuclear facilities kept open below economic dispatch, duplicated R&D spending. The option premium is socialized through rate base while the option itself accrues to institutional actors.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, ratepayers_bearing_portfolio_costs, payer,
    powerless, biographical, trapped, regional).

% Excluded from the option-value framework's core trade space: the reading treats renewables as the 'committed' pathway (already decided) while preserving optionality only for dispatchable baseload. Their pathway gets no hedging protection because it is framed as the default future, not an option to preserve.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, renewables_deployment_coalitions, excluded,
    organized, biographical, constrained, national).

% Model energy transitions under deep uncertainty and assess whether real-options framing appropriately captures irreversibility and path-dependence. Can see the extraction: option value is genuine when learning resolves before irreversible commitment, but the reading applies it to climate mitigation where the uncertainty does not resolve on the decision-relevant timescale.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, decision_theory_analysts, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Coordinates energy-system investment across actors who face genuine uncertainty about future technology costs, demand growth, and climate-policy stringency. Avoids premature lock-in to pathways that might prove suboptimal under future states of the world.
% TRANSFER_FUNCTION: Moves capital, construction timelines, and regulatory attention away from committed single-pathway buildout and toward maintaining technical capability across multiple pathways. Transfers decision authority from technology advocates to portfolio-optimization institutions.
% ABSENT_VOICES: Renewables coalitions are structurally excluded from the optionality framework—they appear only as the 'default' against which other options hedge, never as an option themselves. Climate-vulnerable populations whose timelines make hedging irrelevant are absent from the standard-setting process.
% DISAPPEARANCE_RATIONALE: If the option-value reading vanished, energy policy would reorganize around one of the sibling readings: either committed rapid decarbonization via renewables (expected-value reading), or nuclear/fossil preservation as catastrophic-risk hedge (tail-dominant reading). Portfolio managers would lose their hedging mandate; incumbent firms would face accelerated closure decisions; capital would concentrate rather than spread.
% FOUNDING_PROBLEM: Energy-system transitions involve irreversible multi-decade capital commitments under deep uncertainty about technology trajectories and climate-policy futures. Premature closure of viable pathways could strand society without adequate generating capacity if the committed pathway fails.
% FOUNDING_PROBLEM_CORROBORATION: Portfolio managers and regulatory economists attest the problem is live, citing unresolved technology-cost uncertainties and policy volatility. Climate scientists and renewables engineers attest the founding problem is substantially resolved—cost curves for renewables have collapsed uncertainty, and climate deadlines foreclose the hedging horizon. Independent energy-transition modeling from IPCC supports the resolved-uncertainty reading for the 2020s decision context.
narrative_ontology:disappearance_verdict(acceptable_risk_energy__option_value_preserving, world_rearranges).
narrative_ontology:founding_problem_status(acceptable_risk_energy__option_value_preserving, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(acceptable_risk_energy__option_value_preserving, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(acceptable_risk_energy__option_value_preserving, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(acceptable_risk_energy__option_value_preserving_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(acceptable_risk_energy__option_value_preserving, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(acceptable_risk_energy__option_value_preserving_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is moderate-high (0.58 at interval end) because the option-value reading extracts commitment speed and capital concentration by spreading resources across pathways beyond what expected-harm minimization or tail-risk hedging would prescribe—portfolios stay diversified even after technology costs resolve. Suppression is moderate (0.52) because the reading actively suppresses both single-pathway advocates (climate coalitions wanting committed decarbonization, nuclear advocates wanting committed buildout) through procedural hedging requirements. Theater rises substantially (0.22 → 0.41) as the genuine-uncertainty justification erodes: renewable cost curves collapsed in the 2010s, making continued fossil/nuclear preservation increasingly performative maintenance of optionality after the learning that would justify it has occurred. Accessibility collapse is low-moderate (0.48)—alternative risk framings remain conceptually available. Resistance is moderate-high (0.61)—both suppressed coalitions actively contest the reading.
 *
 * PERSPECTIVAL GAP:
 *   From the agenda-setter seats, this is genuine prudent hedging against irreducible uncertainty—keeping pathways open is coordination, not extraction. From the payer seats (climate advocates bearing opportunity cost, ratepayers paying the premium), the same structure operates as extraction: uncertainty that justified hedging in 2005 substantially resolved by 2015, but the framework persists because it benefits portfolio managers and incumbent firms. The engine computes this divergence from structural position; the authored claim (tangled_rope) does not adjudicate which perception is correct.
 *
 * DIRECTIONALITY LOGIC:
 *   Portfolio managers and regulatory bodies are structural beneficiaries (set the framework, collect institutional rents from administering hedging, avoid political backlash — d near beneficiary end). Incumbent energy firms are beneficiaries (assets stay viable longer — d beneficiary side). Climate advocates, nuclear proponents, and ratepayers are targets (bear costs of maintained optionality — d near target end). Renewables coalitions are excluded rather than coordinated (the framework does not preserve options for them). Decision theorists are analytical observers.
 *
 * MANDATROPHY ANALYSIS:
 *   The option-value reading resolves mandatrophy by asserting BOTH a coordination function (hedging against genuine deep uncertainty in energy transitions) AND asymmetric extraction (opportunity cost imposed on climate mitigation, capital rationing imposed on single-pathway advocates, option premium socialized to ratepayers). This prevents mislabeling: it is not pure extraction (genuine coordination problem existed at founding), not pure coordination (extracts from specific victim groups to preserve optionality benefiting others), not resolved mandatrophy (the coordination function persists even as extraction accumulates—some irreducible uncertainty remains about storage technology and nuclear fusion, making full premature closure arguably imprudent, even as the bulk of the hedging value has been realized).
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    uncertainty_resolution_horizon,
    'Has the deep uncertainty that justified real-options hedging in the 2000s substantially resolved by the 2020s, making continued portfolio diversification extractive rather than coordinative?',
    'Longitudinal analysis of renewable-cost forecast error bands, grid-integration studies, and climate-deadline tightening. If cost uncertainty collapsed and climate constraints foreclosed the hedging horizon, the option value evaporated but the framework persists.',
    'If uncertainty resolved, the reading''s continued operation is extraction—portfolio costs are being paid for optionality with no remaining option value. If uncertainty remains irreducible, the costs are genuine coordination overhead.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(uncertainty_resolution_horizon, empirical, 'Whether the uncertainty justifying option preservation still exists').

omega_variable(
    option_value_vs_stranded_asset_protection,
    'Is the option-value reading a genuine real-options application, or is it a legitimacy frame for protecting incumbent firms'' stranded assets?',
    'Counterfactual analysis: would portfolio managers prescribe the same diversification rule if incumbent firms had no legacy infrastructure? If the rule tracks stranded-asset exposure rather than pure option theory, it is a cover story.',
    'If the reading is stranded-asset protection dressed as hedging, the beneficiary structure is narrower (incumbent firms capture) and extraction is higher than the option-value framing suggests. If it is genuine hedging, the beneficiaries are diffuse (future society avoiding lock-in regret).',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(option_value_vs_stranded_asset_protection, conceptual, 'Whether the framing is decision theory or interest-group legitimation').

omega_variable(
    reading_relation_under_determination,
    'Does the option_value_preserving reading foreclose, coexist with, or merely influence the expected_value_dominant and catastrophic_tail_dominant sibling readings?',
    'Logical structure analysis: can a single regulatory framework hold option-preservation and expected-value-minimization simultaneously, or does maintaining optionality necessarily override mortality-per-TWh optimization? The relation depends on whether hedging is treated as a constraint or an objective.',
    'If the readings coexist (different actors hold different frames), the kernel models a live interpretive contest. If option-preservation forecloses expected-value optimization (you cannot both hedge and commit), the relation is structural displacement. Current authoring uses ''influences'' for both siblings, but this may understate the logical tension.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(reading_relation_under_determination, conceptual, 'Ambiguity in the structural relationship between readings').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(acceptable_risk_energy__option_value_preserving, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(acce_tr_t0, acceptable_risk_energy__option_value_preserving, theater_ratio, 0, 0.22).
narrative_ontology:measurement_basis(acce_tr_t0, observed).
narrative_ontology:measurement(acce_tr_t5, acceptable_risk_energy__option_value_preserving, theater_ratio, 5, 0.26).
narrative_ontology:measurement_basis(acce_tr_t5, observed).
narrative_ontology:measurement(acce_tr_t10, acceptable_risk_energy__option_value_preserving, theater_ratio, 10, 0.31).
narrative_ontology:measurement_basis(acce_tr_t10, observed).
narrative_ontology:measurement(acce_tr_t15, acceptable_risk_energy__option_value_preserving, theater_ratio, 15, 0.35).
narrative_ontology:measurement_basis(acce_tr_t15, observed).
narrative_ontology:measurement(acce_tr_t20, acceptable_risk_energy__option_value_preserving, theater_ratio, 20, 0.38).
narrative_ontology:measurement_basis(acce_tr_t20, observed).
narrative_ontology:measurement(acce_tr_t25, acceptable_risk_energy__option_value_preserving, theater_ratio, 25, 0.41).
narrative_ontology:measurement_basis(acce_tr_t25, observed).

% Extraction over time
narrative_ontology:measurement(acce_be_t0, acceptable_risk_energy__option_value_preserving, base_extractiveness, 0, 0.38).
narrative_ontology:measurement_basis(acce_be_t0, observed).
narrative_ontology:measurement(acce_be_t5, acceptable_risk_energy__option_value_preserving, base_extractiveness, 5, 0.42).
narrative_ontology:measurement_basis(acce_be_t5, observed).
narrative_ontology:measurement(acce_be_t10, acceptable_risk_energy__option_value_preserving, base_extractiveness, 10, 0.48).
narrative_ontology:measurement_basis(acce_be_t10, observed).
narrative_ontology:measurement(acce_be_t15, acceptable_risk_energy__option_value_preserving, base_extractiveness, 15, 0.53).
narrative_ontology:measurement_basis(acce_be_t15, observed).
narrative_ontology:measurement(acce_be_t20, acceptable_risk_energy__option_value_preserving, base_extractiveness, 20, 0.56).
narrative_ontology:measurement_basis(acce_be_t20, observed).
narrative_ontology:measurement(acce_be_t25, acceptable_risk_energy__option_value_preserving, base_extractiveness, 25, 0.58).
narrative_ontology:measurement_basis(acce_be_t25, observed).

% Suppression requirement over time
narrative_ontology:measurement(acce_su_t0, acceptable_risk_energy__option_value_preserving, suppression_requirement, 0, 0.35).
narrative_ontology:measurement_basis(acce_su_t0, observed).
narrative_ontology:measurement(acce_su_t5, acceptable_risk_energy__option_value_preserving, suppression_requirement, 5, 0.39).
narrative_ontology:measurement_basis(acce_su_t5, observed).
narrative_ontology:measurement(acce_su_t10, acceptable_risk_energy__option_value_preserving, suppression_requirement, 10, 0.43).
narrative_ontology:measurement_basis(acce_su_t10, observed).
narrative_ontology:measurement(acce_su_t15, acceptable_risk_energy__option_value_preserving, suppression_requirement, 15, 0.47).
narrative_ontology:measurement_basis(acce_su_t15, observed).
narrative_ontology:measurement(acce_su_t20, acceptable_risk_energy__option_value_preserving, suppression_requirement, 20, 0.5).
narrative_ontology:measurement_basis(acce_su_t20, observed).
narrative_ontology:measurement(acce_su_t25, acceptable_risk_energy__option_value_preserving, suppression_requirement, 25, 0.52).
narrative_ontology:measurement_basis(acce_su_t25, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(acceptable_risk_energy__option_value_preserving, resource_allocation).
narrative_ontology:boltzmann_floor_override(acceptable_risk_energy__option_value_preserving, 0.18).
narrative_ontology:affects_constraint(acceptable_risk_energy__option_value_preserving, acceptable_risk_energy__catastrophic_tail_dominant).
narrative_ontology:affects_constraint(acceptable_risk_energy__option_value_preserving, acceptable_risk_energy__expected_value_dominant).

% DUAL FORMULATION NOTE:
% This constraint is one of three readings of the acceptable_risk_energy kernel. The kernel decomposes because the ε values differ by the victim structure: option-value extracts from committed-pathway advocates by spreading capital; expected-value extracts from precautionary coalitions by discounting tail risk; tail-dominant extracts from expected-harm minimizers by overweighting rare catastrophes. These are not the same constraint measured differently—they are different normative frameworks with different beneficiaries, different suppression mechanisms, and different resistance coalitions. All three readings coexist in policy discourse, instantiated by different institutional actors. The option-value reading influences both siblings by shifting the legitimacy condition from 'minimize harm' or 'avoid worst case' to 'preserve flexibility,' which changes resource allocation even when other readings remain nominally operative.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
