% ============================================================================
% CONSTRAINT STORY: woman_category__gender_identity_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2025-01-01
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_woman_category__gender_identity_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: woman_category__gender_identity_reading
 *   human_readable: Gender Identity Woman Category Definition
 *   domain: political_philosophy/law/social_policy/bioethics
 *
 * SUMMARY:
 *   The gender identity reading defines 'woman' as anyone who identifies as a
 *   woman, regardless of biological sex. This constraint emerged from
 *   transgender rights advocacy in the 2010s and has been codified in
 *   progressive jurisdictions through self-identification laws for legal
 *   gender recognition, institutional policies mandating pronoun use and
 *   facility access by identified gender, and anti-discrimination frameworks
 *   treating gender identity as a protected characteristic. The constraint is
 *   CLAIMED as tangled_rope (genuine coordination for transgender
 *   recognition, but with asymmetric costs borne by natal women in specific
 *   contexts). Metrics describe substantially extractive operation with
 *   rising suppression over time as enforcement against dissent intensifies.
 *   The claim/metric gap is deliberate: the engine measures divergence.
 *
 * KEY AGENTS:
 *   - transgender_women: Primary beneficiary (organized/identity_locked) — gain legal recognition and institutional access aligned with gender identity
 *   - gender_identity_advocacy_organizations: Agenda setter (organized/mobile) — draft policy, litigate, enforce ideological conformity
 *   - progressive_institutional_administrators: Agenda setter and beneficiary (institutional/constrained) — implement the standard, gain social capital, bear political costs
 *   - natal_women_in_sex_segregated_contexts: Payer (organized/constrained) — lose privacy and safety in single-sex spaces
 *   - female_athletes_in_open_category_sports: Payer (moderate/constrained) — lose competitive fairness and opportunities
 *   - safeguarding_advocates: Payer (organized/constrained) — suppressed institutional influence despite documented risks
 *   - sex_biology_proponents: Excluded (organized/constrained) — structurally barred from policy formation
 *   - courts_and_legislative_bodies: Observer (institutional/analytical) — adjudicate rights conflicts
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(woman_category__gender_identity_reading, 0.68).
domain_priors:suppression_score(woman_category__gender_identity_reading, 0.71).
domain_priors:theater_ratio(woman_category__gender_identity_reading, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, extractiveness, 0.68).
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, suppression_requirement, 0.71).
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, resistance, 0.78).

% --- Constraint claim ---
narrative_ontology:constraint_claim(woman_category__gender_identity_reading, tangled_rope).
narrative_ontology:human_readable(woman_category__gender_identity_reading, "Gender Identity Woman Category Definition").
narrative_ontology:topic_domain(woman_category__gender_identity_reading, "political_philosophy/law/social_policy/bioethics").

domain_priors:requires_active_enforcement(woman_category__gender_identity_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(woman_category__gender_identity_reading, '0ebdcf10-2dc9-44da-9e92-a90ec95ab97e').
narrative_ontology:cs_kernel_codification('0ebdcf10-2dc9-44da-9e92-a90ec95ab97e', distributed).
narrative_ontology:cs_authority_grounding('0ebdcf10-2dc9-44da-9e92-a90ec95ab97e', distributed).
narrative_ontology:cs_reading_relation('0ebdcf10-2dc9-44da-9e92-a90ec95ab97e', woman_category__sex_biology_reading, coexists_with).
narrative_ontology:cs_reading_relation('0ebdcf10-2dc9-44da-9e92-a90ec95ab97e', woman_category__intersex_accommodation_reading, influences).
narrative_ontology:cs_axiom('0ebdcf10-2dc9-44da-9e92-a90ec95ab97e', foundational, gender_identity_primacy).
narrative_ontology:cs_axiom_status(gender_identity_primacy, holdable).
narrative_ontology:cs_axiom_grounding('0ebdcf10-2dc9-44da-9e92-a90ec95ab97e', gender_identity_primacy, deontological).
narrative_ontology:cs_axiom('0ebdcf10-2dc9-44da-9e92-a90ec95ab97e', foundational, self_identification_sufficiency).
narrative_ontology:cs_axiom_status(self_identification_sufficiency, holdable).
narrative_ontology:cs_axiom_grounding('0ebdcf10-2dc9-44da-9e92-a90ec95ab97e', self_identification_sufficiency, conventional).
narrative_ontology:cs_reference_frame('0ebdcf10-2dc9-44da-9e92-a90ec95ab97e', binary_sex_category_system).
narrative_ontology:cs_drift_state('0ebdcf10-2dc9-44da-9e92-a90ec95ab97e', contemporary_gender_identity_era, gap(axiom_overriding, substantial, false)).
narrative_ontology:cs_created_at('0ebdcf10-2dc9-44da-9e92-a90ec95ab97e', '').
narrative_ontology:cs_kernel_id(woman_category__gender_identity_reading, woman_category).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(woman_category__gender_identity_reading, transgender_women).
narrative_ontology:constraint_beneficiary(woman_category__gender_identity_reading, gender_identity_advocacy_organizations).
narrative_ontology:constraint_beneficiary(woman_category__gender_identity_reading, progressive_institutional_administrators).
narrative_ontology:constraint_victim(woman_category__gender_identity_reading, natal_women_in_sex_segregated_contexts).
narrative_ontology:constraint_victim(woman_category__gender_identity_reading, female_athletes_in_open_category_sports).
narrative_ontology:constraint_victim(woman_category__gender_identity_reading, safeguarding_advocates).
narrative_ontology:constraint_vindicates(woman_category__gender_identity_reading, gender_identity_primacy_doctrine).
narrative_ontology:constraint_vindicates(woman_category__gender_identity_reading, self_identification_sufficiency_claim).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Gain legal recognition as women in identity documents, access to sex-segregated spaces designated for women, and eligibility for women's categories in sports and institutional programs. The constraint validates their gender identity as the authoritative basis for category membership. Exit would mean denial of identity recognition and exclusion from spaces aligned with their lived gender.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, transgender_women, beneficiary,
    organized, biographical, identity_locked, national).

% Draft model legislation, advise government agencies on policy implementation, provide legal support for discrimination claims, and advocate for institutional adoption of self-identification standards. They frame the constraint as a civil rights advance and actively defend it against rollback efforts.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, gender_identity_advocacy_organizations, agenda_setter,
    organized, generational, mobile, national).

% Implement self-identification policies in schools, workplaces, healthcare systems, and government agencies. They gain social capital within progressive networks for adopting the standard but bear political costs from constituencies objecting to implementation. Their enforcement of the standard is what makes it binding rather than aspirational.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, progressive_institutional_administrators, agenda_setter,
    institutional, biographical, constrained, national).
narrative_ontology:stakeholder_secondary_role(woman_category__gender_identity_reading, progressive_institutional_administrators, beneficiary).

% Experience reduced privacy and altered safety dynamics in spaces previously segregated by biological sex: changing rooms, domestic violence shelters, prisons, hospital wards. They lose the ability to organize single-sex spaces under this definition and face social sanctions for objecting. Exit options are limited because opting out of shared facilities often means forgoing the service entirely.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, natal_women_in_sex_segregated_contexts, payer,
    organized, biographical, constrained, national).

% Compete against individuals who underwent male puberty and retain physiological advantages in strength, speed, and endurance. They lose podium placements, scholarship opportunities, and records to competitors they cannot match on performance grounds. Exit means leaving competitive sport; voice means career-ending reputational costs.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, female_athletes_in_open_category_sports, payer,
    moderate, biographical, constrained, national).

% Argue that self-identification without gatekeeping creates safeguarding risks in institutional contexts where vulnerable populations are present. They document case studies of policy exploitation but are organizationally marginalized as transphobic. The constraint suppresses their institutional influence by framing biology-based boundaries as discriminatory per se.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, safeguarding_advocates, payer,
    organized, generational, constrained, national).

% Hold that biological sex is the relevant category boundary for spaces and competitions where physical embodiment matters. They are excluded from policy-setting bodies and face employment consequences for voicing the competing reading. Their exclusion is structural: gender identity ideology treats the biology reading as inherently harmful speech.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, sex_biology_proponents, excluded,
    organized, generational, constrained, national).

% Adjudicate conflicts between gender identity recognition and sex-based rights claims. They take testimony from all stakeholder seats, commission expert analysis, and issue rulings that either entrench or constrain the self-identification standard. Some jurisdictions have legislated the gender identity reading into anti-discrimination law; others have legislated the biology reading.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, courts_and_legislative_bodies, observer,
    institutional, generational, analytical, national).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes a consistent, legible standard for determining who counts as a woman across legal, institutional, and social contexts, solving coordination problems in identity documentation, institutional record-keeping, and anti-discrimination enforcement.
% TRANSFER_FUNCTION: Transfers access rights to sex-segregated spaces, competitive categories, and legal protections from a sex-biology basis to a gender-identity basis. Moves institutional recognition and social legitimacy toward self-identified gender; moves privacy, safety, and fairness considerations predicated on biological sex out of policy scope.
% ABSENT_VOICES: Detransitioners (people who identified as transgender, transitioned, and later re-identified with natal sex) are structurally absent from policy formation; their testimony is suppressed as delegitimizing. Incarcerated women opposing male-bodied cellmates and survivors of male violence objecting to male-bodied individuals in single-sex crisis services are present but institutionally unheard.
% DISAPPEARANCE_RATIONALE: If the constraint vanished, institutions would revert to contested local standards or default to biological-sex criteria in contexts where embodiment matters. Female athletes would reorganize competition categories; prisons and shelters would re-segregate by sex; identity documents would revert to sex-at-birth markers or adopt explicit gatekeeping. Political coalitions would fracture and realign.
% FOUNDING_PROBLEM: Transgender individuals historically faced institutional non-recognition, being forced into legal and social categories misaligned with their experienced gender, causing bureaucratic obstacles and psychological harm.
% FOUNDING_PROBLEM_CORROBORATION: Gender identity advocacy organizations and transgender individuals attest the problem remains live, pointing to ongoing discrimination and non-recognition in hostile jurisdictions. Courts, legislative inquiries, and independent policy analysts outside the advocacy network attest that institutional recognition has substantially advanced in progressive jurisdictions and the founding problem has shifted to conflicts between identity recognition and sex-based rights — the constraint now persists as a contested ideological framework rather than a response to wholesale institutional exclusion.
narrative_ontology:disappearance_verdict(woman_category__gender_identity_reading, world_rearranges).
narrative_ontology:founding_problem_status(woman_category__gender_identity_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(woman_category__gender_identity_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(woman_category__gender_identity_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(woman_category__gender_identity_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(woman_category__gender_identity_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(woman_category__gender_identity_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is high (0.68 at interval end) because the coordination benefit (consistent identity recognition) accrues to transgender women while the costs (reduced privacy, safety concerns, competitive disadvantage) are borne by natal women who did not consent to the redefinition and cannot exit without forgoing services. Suppression is higher (0.71) because persistence depends on actively suppressing dissent: employment consequences, social ostracism, and institutional sanctions for questioning self-identification sufficiency. Theater ratio is moderate (0.42): the anti-discrimination function is real for transgender individuals facing hostility, but a growing share of enforcement activity polices ideological conformity rather than addressing material harms. Accessibility collapse is moderate-low (0.48) because the biology reading remains conceptually accessible and is legislatively live in many jurisdictions. Resistance is high (0.78) because natal women, athletes, safeguarding advocates, and biology proponents actively contest the constraint across legal, institutional, and social domains. Measurements show extraction and suppression rising as the constraint moves from niche advocacy to institutional mandate.
 *
 * PERSPECTIVAL GAP:
 *   From the transgender women and advocacy seats, the constraint is coordination that corrects historical injustice and aligns legal categories with lived reality. From the natal women payer seats, the same structure operates as enforced redefinition that transfers their sex-based protections to male-bodied individuals. From the institutional administrator seat, it is coordination with asymmetric political costs. The engine computes these divergences from structural position data; the authored claim does not adjudicate.
 *
 * DIRECTIONALITY LOGIC:
 *   Transgender women are structural beneficiaries (gain recognition and access, identity-locked to the outcome — d near beneficiary end). Advocacy organizations are agenda setters (control enforcement, mobile exit — d beneficiary-leaning). Progressive administrators are dual-positioned (gain social capital but bear political costs — d near symmetric). Natal women in segregated contexts, female athletes, and safeguarding advocates are targets (bear costs, constrained exit — d near target end). Sex biology proponents are excluded (their reading is suppressed, not coordinated — d full target).
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint is claimed as tangled_rope because it coordinates transgender recognition (genuine coordination problem: legal legibility, institutional consistency) while extracting from natal women in contexts where biological sex materially matters (sports, single-sex spaces). The mandatrophy question is whether the extraction component (loss of sex-based boundaries) is an unavoidable cost of the coordination function or a separable extractive layer riding on legitimate recognition claims. The measurement trajectory shows extraction accumulating as the constraint extends from identity documents (low-conflict coordination) into sports and sex-segregated spaces (high-conflict extraction). The omega variables route the irreducible uncertainty about whether the coordination and extraction are structurally separable.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    coordination_extraction_separability,
    'Is legal gender recognition separable from access to sex-segregated spaces and competitive categories?',
    'Policy experiments in jurisdictions that grant identity document changes and anti-discrimination protections for gender identity while maintaining sex-based criteria for sports and single-sex spaces. If transgender individuals achieve recognition and protection under the first regime without the second, the functions are separable.',
    'If separable, the sports and spaces access is extraction riding on legitimate recognition claims; if inseparable (recognition collapses without access), the constraint is tightly coupled coordination. Extraction measurement and tangled_rope vs rope classification diverge on this boundary.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(coordination_extraction_separability, empirical, 'Whether identity recognition and spatial access are structurally coupled or separable coordination problems').

omega_variable(
    self_id_gatekeeping_necessity,
    'Does effective recognition require no-questions-asked self-identification, or can it function with minimal gatekeeping (clinical assessment, waiting periods)?',
    'Comparative analysis of jurisdictions with different gatekeeping thresholds: if transgender individuals achieve substantive recognition under gatekept regimes at similar rates as under pure self-ID, gatekeeping does not block the coordination function.',
    'If gatekeeping is compatible with recognition, suppression of gatekeeping proposals is extractive enforcement beyond coordination need. If self-ID is necessary, suppression of dissent is coordination overhead.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(self_id_gatekeeping_necessity, empirical, 'Whether self-identification sufficiency is required for the coordination function or is an ideological add-on').

omega_variable(
    sibling_reading_displacement,
    'Does this reading structurally displace the sex_biology_reading, or do they coexist as competing frameworks held by different coalitions?',
    'Jurisdictional variation: if some polities legislate gender identity primacy and others legislate sex biology primacy, with no constitutional or international law forcing convergence, the readings coexist. If one reading''s legal entrenchment forecloses the other''s viability, displacement has occurred.',
    'If coexisting, the omega stays open and classification proceeds from local structural data. If one reading has displaced the other, the omega resolves to the displacing reading and the displaced reading becomes a historical artifact. Current status is contested coexistence with no clear attractor.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(sibling_reading_displacement, conceptual, 'Whether gender_identity_reading and sex_biology_reading are stable competing readings or one is displacing the other').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(woman_category__gender_identity_reading, 0, 20).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(woma_tr_t0, woman_category__gender_identity_reading, theater_ratio, 0, 0.25).
narrative_ontology:measurement(woma_tr_t5, woman_category__gender_identity_reading, theater_ratio, 5, 0.32).
narrative_ontology:measurement(woma_tr_t10, woman_category__gender_identity_reading, theater_ratio, 10, 0.37).
narrative_ontology:measurement(woma_tr_t15, woman_category__gender_identity_reading, theater_ratio, 15, 0.4).
narrative_ontology:measurement(woma_tr_t20, woman_category__gender_identity_reading, theater_ratio, 20, 0.42).

% Extraction over time
narrative_ontology:measurement(woma_be_t0, woman_category__gender_identity_reading, base_extractiveness, 0, 0.42).
narrative_ontology:measurement(woma_be_t5, woman_category__gender_identity_reading, base_extractiveness, 5, 0.51).
narrative_ontology:measurement(woma_be_t10, woman_category__gender_identity_reading, base_extractiveness, 10, 0.59).
narrative_ontology:measurement(woma_be_t15, woman_category__gender_identity_reading, base_extractiveness, 15, 0.64).
narrative_ontology:measurement(woma_be_t20, woman_category__gender_identity_reading, base_extractiveness, 20, 0.68).

% Suppression requirement over time
narrative_ontology:measurement(woma_su_t0, woman_category__gender_identity_reading, suppression_requirement, 0, 0.48).
narrative_ontology:measurement(woma_su_t5, woman_category__gender_identity_reading, suppression_requirement, 5, 0.56).
narrative_ontology:measurement(woma_su_t10, woman_category__gender_identity_reading, suppression_requirement, 10, 0.63).
narrative_ontology:measurement(woma_su_t15, woman_category__gender_identity_reading, suppression_requirement, 15, 0.68).
narrative_ontology:measurement(woma_su_t20, woman_category__gender_identity_reading, suppression_requirement, 20, 0.71).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(woman_category__gender_identity_reading, identity_coordination).
narrative_ontology:affects_constraint(woman_category__gender_identity_reading, woman_category__sex_biology_reading).
narrative_ontology:affects_constraint(woman_category__gender_identity_reading, woman_category__intersex_accommodation_reading).

% DUAL FORMULATION NOTE:
% The woman_category kernel decomposes into three readings with distinct ε profiles and victim sets. Gender_identity_reading has moderate ε in identity documents, high ε in sports and sex-segregated spaces. Sex_biology_reading has low ε (minimal enforcement, widely legible) but high resistance from gender identity advocates. Intersex_accommodation_reading attempts a middle path with moderate ε and lower suppression. These are not observables of one constraint; they are structurally distinct claims linked by network edges.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
