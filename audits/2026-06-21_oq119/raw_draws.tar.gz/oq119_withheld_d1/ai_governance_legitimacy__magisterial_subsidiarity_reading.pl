% ============================================================================
% CONSTRAINT STORY: ai_governance_legitimacy__magisterial_subsidiarity_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2024-01-15
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_ai_governance_legitimacy__magisterial_subsidiarity_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    constraint_indexing:directionality_override/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:stakeholder_non_agent/2,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: ai_governance_legitimacy__magisterial_subsidiarity_reading
 *   human_readable: Magisterial AI Governance via Catholic Social Doctrine
 *   domain: theological_ethics/technology_governance/political_theology
 *
 * SUMMARY:
 *   This constraint instantiates the Magisterial reading of AI governance
 *   legitimacy: technology must be subordinated to Catholic Social Doctrine
 *   principles (common good, subsidiarity, solidarity, universal destination
 *   of goods) as authoritatively interpreted by the Magisterium. It
 *   explicitly rejects pure technocratic optimization and market libertarian
 *   frameworks, demanding political oversight grounded in human dignity and
 *   participatory governance that centers the vulnerable. The constraint is
 *   CLAIMED as tangled_rope because it entangles genuine coordination
 *   (establishing shared dignity criteria, protecting vulnerable populations)
 *   with substantial extraction (imposing Catholic interpretive authority on
 *   pluralistic contexts, excluding non-Catholic moral frameworks from
 *   foundational governance claims). The metrics describe moderate-high
 *   extractiveness rising over time as interpretive authority claims harden,
 *   substantial suppression as the framework forecloses technocratic and
 *   market alternatives, and rising theater as official adherence diverges
 *   from implementation.
 *
 * KEY AGENTS:
 *   - Magisterium: Institutional agenda-setter (civilizational/analytical/global) — claims interpretive authority over governance principles
 *   - Global South workers: Powerless beneficiaries (biographical/trapped/global) — gain dignity protections and benefit redistribution
 *   - Marginalized populations: Powerless beneficiaries (biographical/trapped/global) — centered by participatory governance and solidarity principle
 *   - Private tech monopolies: Institutional payers (biographical/arbitrage/global) — face subordination of profit to dignity
 *   - Military-industrial complex: Institutional payers (generational/constrained/continental) — autonomous weapons and surveillance categorically rejected
 *   - Comparative theology observers: Analytical observers (civilizational/analytical/global) — assess interpretive authority structure
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(ai_governance_legitimacy__magisterial_subsidiarity_reading, 0.52).
domain_priors:suppression_score(ai_governance_legitimacy__magisterial_subsidiarity_reading, 0.68).
domain_priors:theater_ratio(ai_governance_legitimacy__magisterial_subsidiarity_reading, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__magisterial_subsidiarity_reading, extractiveness, 0.52).
narrative_ontology:constraint_metric(ai_governance_legitimacy__magisterial_subsidiarity_reading, suppression_requirement, 0.68).
narrative_ontology:constraint_metric(ai_governance_legitimacy__magisterial_subsidiarity_reading, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__magisterial_subsidiarity_reading, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(ai_governance_legitimacy__magisterial_subsidiarity_reading, resistance, 0.71).

% --- Constraint claim ---
narrative_ontology:constraint_claim(ai_governance_legitimacy__magisterial_subsidiarity_reading, tangled_rope).
narrative_ontology:human_readable(ai_governance_legitimacy__magisterial_subsidiarity_reading, "Magisterial AI Governance via Catholic Social Doctrine").
narrative_ontology:topic_domain(ai_governance_legitimacy__magisterial_subsidiarity_reading, "theological_ethics/technology_governance/political_theology").

domain_priors:requires_active_enforcement(ai_governance_legitimacy__magisterial_subsidiarity_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(ai_governance_legitimacy__magisterial_subsidiarity_reading, '8733d214-213e-4b20-b08d-7b3f9f6ed2a6').
narrative_ontology:cs_kernel_codification('8733d214-213e-4b20-b08d-7b3f9f6ed2a6', formalized).
narrative_ontology:cs_authority_grounding('8733d214-213e-4b20-b08d-7b3f9f6ed2a6', lineage).
narrative_ontology:cs_interpretation_layer_present('8733d214-213e-4b20-b08d-7b3f9f6ed2a6').
narrative_ontology:cs_reading_relation('8733d214-213e-4b20-b08d-7b3f9f6ed2a6', ai_governance_legitimacy__technocratic_optimization_reading, forecloses).
narrative_ontology:cs_reading_relation('8733d214-213e-4b20-b08d-7b3f9f6ed2a6', ai_governance_legitimacy__democratic_pluralist_reading, influences).
narrative_ontology:cs_reading_relation('8733d214-213e-4b20-b08d-7b3f9f6ed2a6', ai_governance_legitimacy__market_libertarian_reading, forecloses).
narrative_ontology:cs_axiom('8733d214-213e-4b20-b08d-7b3f9f6ed2a6', foundational, technology_subordinate_to_human_dignity).
narrative_ontology:cs_axiom_status(technology_subordinate_to_human_dignity, holdable).
narrative_ontology:cs_axiom_grounding('8733d214-213e-4b20-b08d-7b3f9f6ed2a6', technology_subordinate_to_human_dignity, deontological).
narrative_ontology:cs_axiom('8733d214-213e-4b20-b08d-7b3f9f6ed2a6', foundational, magisterial_interpretive_authority_universal).
narrative_ontology:cs_axiom_status(magisterial_interpretive_authority_universal, holdable).
narrative_ontology:cs_axiom_grounding('8733d214-213e-4b20-b08d-7b3f9f6ed2a6', magisterial_interpretive_authority_universal, theological).
narrative_ontology:cs_axiom('8733d214-213e-4b20-b08d-7b3f9f6ed2a6', secondary, solidarity_mandates_benefit_redistribution).
narrative_ontology:cs_axiom_status(solidarity_mandates_benefit_redistribution, holdable).
narrative_ontology:cs_axiom_grounding('8733d214-213e-4b20-b08d-7b3f9f6ed2a6', solidarity_mandates_benefit_redistribution, deontological).
narrative_ontology:cs_reference_frame('8733d214-213e-4b20-b08d-7b3f9f6ed2a6', post_conciliar_social_magisterium).
narrative_ontology:cs_drift_state('8733d214-213e-4b20-b08d-7b3f9f6ed2a6', contemporary_pluralistic_context, gap(authority_erosion, substantial, false)).
narrative_ontology:cs_created_at('8733d214-213e-4b20-b08d-7b3f9f6ed2a6', '').
narrative_ontology:cs_kernel_id(ai_governance_legitimacy__magisterial_subsidiarity_reading, ai_governance_legitimacy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__magisterial_subsidiarity_reading, global_south_workers).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__magisterial_subsidiarity_reading, marginalized_populations).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__magisterial_subsidiarity_reading, traditional_families).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__magisterial_subsidiarity_reading, civil_society_advocates).
narrative_ontology:constraint_victim(ai_governance_legitimacy__magisterial_subsidiarity_reading, private_tech_monopolies).
narrative_ontology:constraint_victim(ai_governance_legitimacy__magisterial_subsidiarity_reading, military_industrial_complex).
narrative_ontology:constraint_victim(ai_governance_legitimacy__magisterial_subsidiarity_reading, extractive_finance_sector).
narrative_ontology:constraint_victim(ai_governance_legitimacy__magisterial_subsidiarity_reading, unaccountable_ai_developers).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Articulates and authoritatively interprets the principles of Catholic Social Doctrine that ground technology governance legitimacy. Issues encyclicals and teaching documents establishing subsidiarity, solidarity, common good, and universal destination of goods as non-negotiable criteria. Claims interpretive authority over what constitutes dignified technology deployment, but enforcement depends on voluntary adherence by states and civil society.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, magisterium, agenda_setter,
    institutional, civilizational, analytical, global).

% Stand to gain from governance frameworks that prioritize labor dignity, protect against algorithmic exploitation, and require technology to serve human flourishing rather than pure efficiency. Currently lack voice in technocratic or market-driven governance regimes. The constraint's subsidiarity principle would decentralize power to communities where they live; solidarity principle would redistribute benefits their labor generates.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, global_south_workers, beneficiary,
    powerless, biographical, trapped, global).

% Include refugees, disabled persons, indigenous communities, and economically excluded groups who bear disproportionate costs of AI deployment (surveillance, displacement, bias) while capturing minimal benefits. The constraint's emphasis on protection of the vulnerable and participatory governance would center their concerns in technology design. Universal destination of goods principle would entitle them to share in AI's productive capacity.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, marginalized_populations, beneficiary,
    powerless, biographical, trapped, global).

% Benefit from governance that subordinates technology to familial stability and intergenerational solidarity rather than market disruption or state surveillance. The constraint protects family autonomy against both corporate data extraction and technocratic social engineering. Subsidiarity principle supports their authority over children's digital formation; common good principle limits technology's atomizing effects.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, traditional_families, beneficiary,
    moderate, generational, constrained, national).

% Human rights organizations, labor unions, environmental groups, and ecclesial justice networks gain legitimacy framework and moral vocabulary for challenging technocratic and market governance. They translate Magisterial principles into policy advocacy, international law arguments, and grassroots organizing. They benefit from the constraint's authority claims but also do substantial enforcement work through civil pressure.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, civil_society_advocates, beneficiary,
    organized, generational, mobile, global).
narrative_ontology:stakeholder_secondary_role(ai_governance_legitimacy__magisterial_subsidiarity_reading, civil_society_advocates, agenda_setter).

% Face demands to subordinate profit maximization and innovation velocity to human dignity criteria, accept participatory oversight from affected communities, redistribute benefits to Global South and workers, and submit to transparency requirements that expose extractive practices. The constraint treats their current governance autonomy as illegitimate. They resist through regulatory capture, forum shopping to permissive jurisdictions, and framing dignity concerns as innovation barriers.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, private_tech_monopolies, payer,
    institutional, biographical, arbitrage, global).

% Autonomous weapons development, surveillance infrastructure, and AI-augmented warfare face categorical rejection under the constraint's framework. The Magisterial reading holds that technology subordination to human dignity forecloses uses that treat persons as targets or populations as data. They absorb costs through restricted R&D domains, international law exposure, and moral delegitimation of defense AI applications.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, military_industrial_complex, payer,
    institutional, generational, constrained, continental).

% Algorithmic trading, credit scoring, and financial AI that maximize returns without regard for dignified livelihoods are treated as illegitimate under solidarity and common good principles. The constraint demands finance serve real economy and human work, not speculative extraction. They face pressure to accept slower returns, distribute gains to workers and borrowers, and submit to participatory governance that limits algorithmic opacity.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, extractive_finance_sector, payer,
    institutional, biographical, arbitrage, global).

% Academic researchers and startups deploying AI without transparency, community consultation, or assessment of dignity impacts. The constraint requires they accept oversight from non-technical stakeholders, slow deployment for participatory review, and potentially halt work that fails subsidiarity or solidarity tests. They bear costs in velocity, autonomy, and competitive position against less scrupulous actors.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, unaccountable_ai_developers, payer,
    powerful, immediate, mobile, global).

% Government officials and policy experts who ground AI governance in efficiency, security, and aggregate welfare optimization. The constraint treats their authority claims as insufficient without subordination to dignity principles and participatory legitimacy. They are excluded from the interpretive process—the Magisterium claims direct authority over ethical criteria rather than delegating to technical expertise or democratic process alone.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, technocratic_state_planners, excluded,
    institutional, generational, constrained, national).

% International human rights law, secular ethics traditions, and non-Catholic moral frameworks that might ground technology governance. The constraint claims these are insufficient without grounding in Catholic Social Doctrine as authoritatively interpreted. They provide partial convergence on dignity and participation but lack the theological foundation the Magisterial reading treats as necessary for genuine legitimacy.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, secular_human_rights_frameworks, excluded,
    institutional, generational, analytical, global).
narrative_ontology:stakeholder_non_agent(ai_governance_legitimacy__magisterial_subsidiarity_reading, secular_human_rights_frameworks).

% Scholars examining how different religious and philosophical traditions ground technology governance claims. They analyze the Magisterial reading's interpretive authority structure, compare it to Protestant, Islamic, Buddhist, and secular frameworks, and assess whether any single tradition can claim universal governance authority in pluralistic contexts.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__magisterial_subsidiarity_reading, comparative_theology_observers, observer,
    analytical, civilizational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes shared ethical criteria for AI governance that protect human dignity, prevent exploitation, and ensure technology serves integral human development. Coordinates civil society, states, and institutions around subsidiarity, solidarity, common good, and universal destination of goods as non-negotiable principles.
% TRANSFER_FUNCTION: Moves governance authority from technocratic expertise and market mechanisms to Magisterial interpretation of Catholic Social Doctrine. Transfers AI benefits from concentrated corporate and military control to workers, Global South, families, and marginalized populations through mandated redistribution and participatory oversight.
% ABSENT_VOICES: Secular ethicists, non-Catholic religious traditions, democratic pluralists, and indigenous knowledge systems that might contest Catholic interpretive monopoly. They are structurally excluded by the claim that Catholic Social Doctrine—as interpreted by the Magisterium—provides the authoritative ground for legitimacy rather than one voice among many in pluralistic deliberation.
% DISAPPEARANCE_RATIONALE: If this constraint vanished, AI governance would revert to technocratic optimization or market libertarian frameworks that the encyclical explicitly rejects. Tech monopolies would regain autonomy over deployment priorities, military AI would expand unchecked, algorithmic extraction would continue without solidarity constraints, and vulnerable populations would lose the participatory protections and benefit redistribution the framework demands. Civil society advocates would lose moral vocabulary and authority claims for challenging purely secular governance regimes.
% FOUNDING_PROBLEM: Unregulated AI development concentrates power in technocratic and corporate hands, treats efficiency as supreme value over human dignity, excludes affected communities from governance, and generates benefits captured by elites while costs fall on workers and Global South. Pure market or state technocratic governance fails to subordinate technology to integral human flourishing.
% FOUNDING_PROBLEM_CORROBORATION: Civil society human rights organizations, labor unions, and Global South advocacy networks attest the founding problem persists and intensifies. Independent economic analysis documents AI benefit concentration and algorithmic exploitation. Secular human rights frameworks converge on participatory governance and dignity protection even while contesting Catholic interpretive authority—the problem is corroborated outside the Magisterium's own teaching.
narrative_ontology:disappearance_verdict(ai_governance_legitimacy__magisterial_subsidiarity_reading, world_rearranges).
narrative_ontology:founding_problem_status(ai_governance_legitimacy__magisterial_subsidiarity_reading, live).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(ai_governance_legitimacy__magisterial_subsidiarity_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(ai_governance_legitimacy__magisterial_subsidiarity_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(ai_governance_legitimacy__magisterial_subsidiarity_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(ai_governance_legitimacy__magisterial_subsidiarity_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(ai_governance_legitimacy__magisterial_subsidiarity_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is moderate-high (0.52) because the constraint imposes Catholic interpretive authority on governance questions that affect non-Catholic and secular populations, excludes alternative moral frameworks from foundational legitimacy claims, and demands substantial redistribution from corporate and military sectors without their consent. The coordination function (shared dignity criteria, participatory protections) is genuine but entangled with the extraction. Suppression is substantial (0.68) because technocratic and market readings are treated as categorically illegitimate rather than alternative frameworks to be deliberated among—the constraint forecloses rather than competes. Theater rises (0.42) as states and institutions offer symbolic adherence to dignity language while maintaining technocratic or market governance in practice. Accessibility collapse is moderate (0.48) because alternative governance frameworks remain intellectually available even as the Magisterial reading claims exclusive legitimacy. Resistance is high (0.71) from tech monopolies, secular ethicists, democratic pluralists, and non-Catholic traditions who contest Catholic interpretive monopoly.
 *
 * PERSPECTIVAL GAP:
 *   From the Magisterial seat, the constraint operates as legitimate coordination: Catholic Social Doctrine provides universal moral truth that grounds dignified governance, and interpretive authority is not extraction but service to human flourishing. From powerless beneficiary seats, the coordination function (dignity protection, participatory rights) is real and desperately needed, but the extraction (Catholic monopoly over legitimacy criteria) may be tolerated as price of protection or contested as imposing religious framework. From institutional payer seats (tech monopolies, military), the entire structure operates as illegitimate extraction—religious authority claims foreclosing market and technocratic governance that they view as legitimately pluralistic. From observer seats, the gap between coordination and extraction depends on whether any single tradition can claim universal governance authority in pluralistic contexts—the structural question the kernel contest instantiates.
 *
 * DIRECTIONALITY LOGIC:
 *   The Magisterium sits near the beneficiary end as agenda-setter: it collects no rents but accrues interpretive authority and institutional legitimacy from the constraint's operation. Global South workers and marginalized populations are structural beneficiaries (low d) receiving dignity protections and redistribution they currently lack. Civil society advocates are mixed beneficiaries (moderate d)—they gain moral vocabulary and authority claims but also bear enforcement costs. Private tech monopolies, military-industrial complex, and extractive finance are structural targets (high d)—they pay through subordination of autonomy, profit constraints, and transparency demands. Technocratic planners are excluded rather than coordinated; their exclusion is the interpretive authority claim itself.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint avoids mislabeling by explicitly acknowledging the entanglement: genuine coordination (subsidiarity protects local communities, solidarity redistributes benefits, common good criteria prevent exploitation) is structurally inseparable from substantial extraction (Catholic interpretive monopoly, foreclosure of secular and non-Catholic frameworks, exclusion of democratic pluralism from foundational legitimacy). This is textbook tangled_rope: both functions operate through the same Magisterial authority structure. A pure coordination reading would ignore the interpretive monopoly claim and exclusion of alternative frameworks. A pure extraction reading would ignore the real dignity protections and participatory governance the constraint establishes for vulnerable populations. The tangled_rope classification captures that both are structurally present and cannot be separated without dissolving the constraint.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    interpretive_authority_universality,
    'Can Catholic Social Doctrine—interpreted by a particular institutional hierarchy—legitimately claim universal governance authority over AI development affecting non-Catholic and secular populations?',
    'Comparative assessment of governance outcomes under Magisterial vs. pluralistic frameworks; examination of whether dignity protections require theological grounding or can be secured through secular human rights; analysis of whether interpretive monopoly is necessary for coordination or constitutes extractive exclusion of alternative moral traditions.',
    'If Magisterial authority is necessary for genuine dignity protection, extraction is justified as coordination cost. If dignity can be secured through pluralistic deliberation, the interpretive monopoly is pure extraction riding on genuine coordination function. If the question is irreducibly contested, the constraint remains tangled_rope with high observer-seat divergence.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(interpretive_authority_universality, conceptual, 'Whether Catholic interpretive authority over governance is universal coordination or extractive monopoly.').

omega_variable(
    subsidiarity_solidarity_tension,
    'Can subsidiarity (decentralized authority to families and local communities) and solidarity (mandated redistribution and global equity) be coherently combined, or do they pull in opposite directions—subsidiarity toward local autonomy, solidarity toward centralized enforcement?',
    'Natural experiments from jurisdictions attempting to implement both principles simultaneously; analysis of whether local communities accept solidarity constraints voluntarily or resist them as imposed extraction; examination of whether Magisterial interpretation resolves the tension or merely asserts both without structural reconciliation.',
    'If the principles are coherently combinable through Magisterial synthesis, coordination function is stronger. If they are structurally opposed, the constraint''s claimed coherence is theatrical and extractiveness rises as one principle is sacrificed to the other in practice.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(subsidiarity_solidarity_tension, empirical, 'Whether subsidiarity and solidarity are structurally compatible coordination principles or opposed commitments generating internal extraction.').

omega_variable(
    enforcement_civil_society_capture,
    'Is enforcement through ''moral suasion, civil society pressure, international law advocacy, and ecclesial witness'' sufficient to subordinate tech monopolies and military AI, or does reliance on voluntary adherence guarantee theatrical compliance while extractive practices continue?',
    'Tracking actual technology governance outcomes in contexts where civil society invokes Magisterial principles vs. contexts with hard regulatory enforcement; measuring gap between official adherence to dignity language and material constraints on corporate and military AI deployment.',
    'If soft enforcement secures genuine subordination, suppression measurement should fall as voluntary adherence rises. If soft enforcement produces only theatrical compliance, theater_ratio should rise and extractiveness should remain high as tech monopolies perform dignity language while maintaining extractive practices.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(enforcement_civil_society_capture, empirical, 'Whether civil society enforcement can subordinate concentrated power or generates theatrical compliance.').

omega_variable(
    kernel_reading_foreclosure,
    'Does this reading actually foreclose technocratic and market readings within a single governance framework, or do they coexist as competing claims with this reading attempting extraction through authority claims?',
    'Analysis of whether states and institutions can simultaneously honor Magisterial principles and technocratic/market logics, or whether the frameworks are logically incompatible within coherent policy. If simultaneous adherence is empirically common, the readings coexist and the Magisterial claim to foreclose them is itself extractive theater.',
    'If readings genuinely foreclose each other, the suppression measurement is justified as structural exclusion of incompatible frameworks. If they coexist in practice, suppression represents attempted extraction through authority claims rather than structural incompatibility, and extractiveness should be scored higher.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(kernel_reading_foreclosure, conceptual, 'Whether this reading structurally forecloses siblings or competes for authority while they coexist.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(ai_governance_legitimacy__magisterial_subsidiarity_reading, 0, 40).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(ai_g_tr_t0, ai_governance_legitimacy__magisterial_subsidiarity_reading, theater_ratio, 0, 0.25).
narrative_ontology:measurement(ai_g_tr_t10, ai_governance_legitimacy__magisterial_subsidiarity_reading, theater_ratio, 10, 0.3).
narrative_ontology:measurement(ai_g_tr_t20, ai_governance_legitimacy__magisterial_subsidiarity_reading, theater_ratio, 20, 0.35).
narrative_ontology:measurement(ai_g_tr_t30, ai_governance_legitimacy__magisterial_subsidiarity_reading, theater_ratio, 30, 0.39).
narrative_ontology:measurement(ai_g_tr_t40, ai_governance_legitimacy__magisterial_subsidiarity_reading, theater_ratio, 40, 0.42).

% Extraction over time
narrative_ontology:measurement(ai_g_be_t0, ai_governance_legitimacy__magisterial_subsidiarity_reading, base_extractiveness, 0, 0.38).
narrative_ontology:measurement(ai_g_be_t10, ai_governance_legitimacy__magisterial_subsidiarity_reading, base_extractiveness, 10, 0.42).
narrative_ontology:measurement(ai_g_be_t20, ai_governance_legitimacy__magisterial_subsidiarity_reading, base_extractiveness, 20, 0.47).
narrative_ontology:measurement(ai_g_be_t30, ai_governance_legitimacy__magisterial_subsidiarity_reading, base_extractiveness, 30, 0.5).
narrative_ontology:measurement(ai_g_be_t40, ai_governance_legitimacy__magisterial_subsidiarity_reading, base_extractiveness, 40, 0.52).

% Suppression requirement over time
narrative_ontology:measurement(ai_g_su_t0, ai_governance_legitimacy__magisterial_subsidiarity_reading, suppression_requirement, 0, 0.5).
narrative_ontology:measurement(ai_g_su_t10, ai_governance_legitimacy__magisterial_subsidiarity_reading, suppression_requirement, 10, 0.56).
narrative_ontology:measurement(ai_g_su_t20, ai_governance_legitimacy__magisterial_subsidiarity_reading, suppression_requirement, 20, 0.61).
narrative_ontology:measurement(ai_g_su_t30, ai_governance_legitimacy__magisterial_subsidiarity_reading, suppression_requirement, 30, 0.65).
narrative_ontology:measurement(ai_g_su_t40, ai_governance_legitimacy__magisterial_subsidiarity_reading, suppression_requirement, 40, 0.68).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(ai_governance_legitimacy__magisterial_subsidiarity_reading, identity_coordination).
narrative_ontology:affects_constraint(ai_governance_legitimacy__magisterial_subsidiarity_reading, ai_governance_legitimacy__technocratic_optimization_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__magisterial_subsidiarity_reading, ai_governance_legitimacy__democratic_pluralist_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__magisterial_subsidiarity_reading, ai_governance_legitimacy__market_libertarian_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the ai_governance_legitimacy kernel. The kernel decomposes because different moral traditions answer 'what grounds AI governance legitimacy' with structurally incompatible frameworks: Magisterial authority (this reading), technocratic expertise, democratic deliberation, or market voluntarism. Each reading instantiates a different constraint with different ε, different beneficiary/victim structures, and different enforcement mechanisms. They are linked as a constraint family because they address the same governance domain but cannot be reconciled into a single framework—the contest over interpretive authority IS the kernel.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

constraint_indexing:directionality_override(ai_governance_legitimacy__magisterial_subsidiarity_reading, institutional, 0.15).

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
