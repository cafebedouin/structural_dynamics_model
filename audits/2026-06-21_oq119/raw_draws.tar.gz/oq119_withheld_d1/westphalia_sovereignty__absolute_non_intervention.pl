% ============================================================================
% CONSTRAINT STORY: westphalia_sovereignty__absolute_non_intervention
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_westphalia_sovereignty__absolute_non_intervention, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: westphalia_sovereignty__absolute_non_intervention
 *   human_readable: Westphalian Sovereignty: Absolute Non-Intervention Reading
 *   domain: international_law/political_theory
 *
 * SUMMARY:
 *   The absolute non-intervention reading treats sovereignty as a categorical
 *   status: borders are inviolable regardless of what occurs within them.
 *   This reading emerged from the Peace of Westphalia and persisted through
 *   decolonization as the legal foundation of the UN system. It coordinates
 *   mutual restraint among states while systematically excluding populations
 *   facing state violence from international protection. The constraint is
 *   CLAIMED as tangled_rope (acknowledging both coordination and extraction)
 *   while the metrics describe substantially extractive, actively enforced
 *   operation with rising theater as the coordination justification weakens
 *   post-Cold War.
 *
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(westphalia_sovereignty__absolute_non_intervention, 0.82).
domain_priors:suppression_score(westphalia_sovereignty__absolute_non_intervention, 0.88).
domain_priors:theater_ratio(westphalia_sovereignty__absolute_non_intervention, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, extractiveness, 0.82).
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 0.88).
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, accessibility_collapse, 0.68).
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, resistance, 0.71).

% --- Constraint claim ---
narrative_ontology:constraint_claim(westphalia_sovereignty__absolute_non_intervention, tangled_rope).
narrative_ontology:human_readable(westphalia_sovereignty__absolute_non_intervention, "Westphalian Sovereignty: Absolute Non-Intervention Reading").
narrative_ontology:topic_domain(westphalia_sovereignty__absolute_non_intervention, "international_law/political_theory").

domain_priors:requires_active_enforcement(westphalia_sovereignty__absolute_non_intervention).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(westphalia_sovereignty__absolute_non_intervention, 'eb442056-f4f9-49f7-86a1-5221f63ec478').
narrative_ontology:cs_kernel_codification('eb442056-f4f9-49f7-86a1-5221f63ec478', formalized).
narrative_ontology:cs_authority_grounding('eb442056-f4f9-49f7-86a1-5221f63ec478', lineage).
narrative_ontology:cs_interpretation_layer_present('eb442056-f4f9-49f7-86a1-5221f63ec478').
narrative_ontology:cs_reading_relation('eb442056-f4f9-49f7-86a1-5221f63ec478', westphalia_sovereignty__conditional_responsibility, coexists_with).
narrative_ontology:cs_reading_relation('eb442056-f4f9-49f7-86a1-5221f63ec478', westphalia_sovereignty__graded_sovereignty, coexists_with).
narrative_ontology:cs_axiom('eb442056-f4f9-49f7-86a1-5221f63ec478', foundational, territorial_authority_categorical).
narrative_ontology:cs_axiom_status(territorial_authority_categorical, holdable).
narrative_ontology:cs_axiom_grounding('eb442056-f4f9-49f7-86a1-5221f63ec478', territorial_authority_categorical, conventional).
narrative_ontology:cs_axiom('eb442056-f4f9-49f7-86a1-5221f63ec478', foundational, domestic_conduct_irrelevant_to_sovereignty).
narrative_ontology:cs_axiom_status(domestic_conduct_irrelevant_to_sovereignty, holdable).
narrative_ontology:cs_axiom_grounding('eb442056-f4f9-49f7-86a1-5221f63ec478', domestic_conduct_irrelevant_to_sovereignty, conventional).
narrative_ontology:cs_reference_frame('eb442056-f4f9-49f7-86a1-5221f63ec478', peace_of_westphalia_territorial_settlement).
narrative_ontology:cs_drift_state('eb442056-f4f9-49f7-86a1-5221f63ec478', post_cold_war_humanitarian_era, gap(authority_erosion, substantial, false)).
narrative_ontology:cs_created_at('eb442056-f4f9-49f7-86a1-5221f63ec478', '').
narrative_ontology:cs_kernel_id(westphalia_sovereignty__absolute_non_intervention, westphalia_sovereignty).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__absolute_non_intervention, authoritarian_state_elites).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__absolute_non_intervention, sovereignty_maximalist_regimes).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__absolute_non_intervention, regional_hegemons).
narrative_ontology:constraint_victim(westphalia_sovereignty__absolute_non_intervention, populations_under_authoritarian_control).
narrative_ontology:constraint_victim(westphalia_sovereignty__absolute_non_intervention, ethnic_minorities_facing_state_violence).
narrative_ontology:constraint_victim(westphalia_sovereignty__absolute_non_intervention, political_dissidents).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__absolute_non_intervention, territorial_inviolability_doctrine).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__absolute_non_intervention, domestic_jurisdiction_supremacy).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Wield the doctrine to immunize domestic repression from external scrutiny or intervention. Invoke territorial inviolability at international forums to deflect human rights criticism. Their authority depends on the categorical barrier remaining absolute—any erosion threatens the regime's insulation from accountability.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, authoritarian_state_elites, beneficiary,
    institutional, biographical, constrained, national).

% Set the terms of international legal discourse around non-interference, blocking resolutions that would condition sovereignty on internal conduct. They coordinate through voting blocs at UN and regional bodies to preserve the absolute reading against conditional interpretations. Their collective action maintains the norm's enforcement.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, sovereignty_maximalist_regimes, agenda_setter,
    institutional, generational, mobile, global).

% Benefit from the doctrine both as shield (protecting their own sphere of influence from external interference) and as sword (delegitimizing rivals' interventions). They selectively invoke absolute sovereignty when convenient while violating it covertly when strategic interests demand.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, regional_hegemons, beneficiary,
    powerful, generational, arbitrage, continental).
narrative_ontology:stakeholder_secondary_role(westphalia_sovereignty__absolute_non_intervention, regional_hegemons, agenda_setter).

% Bear the direct cost of the doctrine: state violence against them is immunized as a domestic matter. External actors who might intervene are legally barred. Their only recourse is internal regime change or exile, both of which the regime actively suppresses. The constraint treats their suffering as a legitimate price of state sovereignty.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, populations_under_authoritarian_control, payer,
    powerless, biographical, trapped, national).

% Face systematic persecution that the international system classifies as internal affairs. Cross-border ethnic ties offer no protection because intervention on their behalf would violate sovereignty. The doctrine makes their persecution legally invisible at the international level while materially devastating at the domestic level.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, ethnic_minorities_facing_state_violence, payer,
    powerless, generational, trapped, regional).

% Organize against authoritarian rule knowing that external support is barred by the sovereignty doctrine. International human rights mechanisms can document but not prevent their suppression. Some escape to exile; most remain trapped in states that invoke territorial inviolability to justify their imprisonment or disappearance.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, political_dissidents, payer,
    moderate, biographical, constrained, national).

% Argue for conditional sovereignty—that mass atrocities forfeit territorial protection—but are structurally excluded from the legal framework this reading instantiates. They document abuses, lobby for intervention mandates, and theorize exceptions, but the absolute reading treats their position as illegitimate by definition.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, humanitarian_intervention_advocates, excluded,
    organized, generational, mobile, global).

% Analyze the contest between absolute and conditional sovereignty readings. Map the historical trajectory from Westphalia through decolonization to R2P. Recognize that the absolute reading persists not as natural law but as a constructed norm maintained by state coalitions whose authority it protects.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, international_legal_scholars, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Solves the collective action problem of interstate order: without a categorical barrier to intervention, every state faces continuous risk of foreign interference in domestic affairs, making stable borders and peaceful coexistence harder to sustain. The doctrine coordinates mutual restraint.
% TRANSFER_FUNCTION: Moves accountability for internal conduct from the international system to the territorial state exclusively. Populations under authoritarian rule bear the cost—their suffering is treated as a domestic matter—while state elites collect the benefit of insulation from external challenge.
% ABSENT_VOICES: Populations facing state violence and genocide have no standing in the interstate system that the doctrine constructs. Humanitarian intervention advocates are excluded from the authoritative interpretation forums. The normative architecture treats states as the only relevant parties.
% DISAPPEARANCE_RATIONALE: If the absolute non-intervention reading vanished, the international legal order would reorganize around conditional sovereignty or graded authority structures. Humanitarian intervention would shift from exceptional to routine; authoritarian regimes would lose their primary legal shield; regional hegemons' spheres of influence would face external contestation. State practice would realign rapidly.
% FOUNDING_PROBLEM: The Thirty Years' War demonstrated that religious and dynastic contestation with no settled principle of territorial authority produces sustained, system-wide violence. The Peace of Westphalia addressed this by granting rulers absolute authority within their borders as the price of interstate peace.
% FOUNDING_PROBLEM_CORROBORATION: Sovereignty maximalist regimes and some realist international relations scholars attest the founding problem remains live—that without absolute territorial inviolability, great powers would intervene continuously and destabilize the system. Humanitarian intervention advocates, populations facing state violence, and post-Cold War legal scholars attest the founding problem is dead—that the threat today is not interstate religious war but states weaponizing sovereignty to commit mass atrocities with impunity. Independent historical and legal analysis from outside the benefiting state coalitions supports the shifted-function reading.
narrative_ontology:disappearance_verdict(westphalia_sovereignty__absolute_non_intervention, world_rearranges).
narrative_ontology:founding_problem_status(westphalia_sovereignty__absolute_non_intervention, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(westphalia_sovereignty__absolute_non_intervention, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(westphalia_sovereignty__absolute_non_intervention, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(westphalia_sovereignty__absolute_non_intervention_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(westphalia_sovereignty__absolute_non_intervention, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(westphalia_sovereignty__absolute_non_intervention_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is high (0.82) because the doctrine immunizes authoritarian violence as a domestic matter—populations under repressive regimes pay the full cost of insulation with no alternative recourse. Suppression is higher still (0.88) because enforcement requires actively blocking humanitarian intervention mandates, suppressing cross-border ethnic advocacy, and delegitimizing conditional sovereignty interpretations. Theater is moderate (0.42): the interstate coordination function was genuine in the post-Westphalia and post-WWII eras, but contemporary state practice increasingly reveals the doctrine as a shield for mass atrocities rather than a genuine peace mechanism. Accessibility collapse is substantial (0.68): once a state establishes territorial control, alternative governance arrangements face categorical legal barriers. Resistance is high (0.71): humanitarian intervention advocates, populations facing violence, and post-Cold War legal reformers actively contest this reading, but sovereignty maximalist coalitions maintain enforcement.
 *
 * PERSPECTIVAL GAP:
 *   From the sovereignty maximalist seat, the constraint is essential coordination preventing great power interference and system-wide chaos. From the powerless populations seat, the same structure operates as enforced extraction—their suffering is made legally invisible to preserve state elite authority. From the regional hegemon seat, it is a manipulable tool: protection when convenient, ignored when strategic interests override. The engine computes these seat-divergent classifications from the structural asymmetry in power, exit options, and role.
 *
 * DIRECTIONALITY LOGIC:
 *   Authoritarian state elites and sovereignty maximalist regimes are the structural beneficiaries—they collect insulation from external accountability and set the international legal agenda to preserve categorical inviolability. Populations under authoritarian control, ethnic minorities facing state violence, and political dissidents are the targets—they bear the direct cost of immunized state violence with exit options structurally trapped or suppressed. Regional hegemons sit near the beneficiary end: they arbitrage the doctrine (invoking it as shield, violating it as sword) and face minimal domestic cost. The doctrine creates sharp directionality: those who control state apparatus benefit; those subject to state violence pay.
 *
 * MANDATROPHY ANALYSIS:
 *   The absolute non-intervention reading risks classification as pure snare if the coordination function is dismissed entirely. The tangled_rope designation acknowledges that interstate peace coordination was genuine historically and remains relevant for some state pairs, while recognizing that for populations under authoritarian rule the constraint operates as extraction—state violence is immunized, and victims have no international recourse. The mandate (preventing interstate religious war) has substantially attenuated; the trophy (elite insulation from accountability) has grown. The doctrine persists not because the founding problem is live but because beneficiary coalitions maintain enforcement.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    coordination_extraction_separability,
    'Is the interstate coordination function structurally separable from the authoritarian-insulation function, or does preventing great power interference necessarily immunize domestic atrocities?',
    'Natural experiment from regional systems that condition sovereignty on human rights compliance (e.g., EU membership criteria, African Union Article 4(h)): if interstate peace holds while humanitarian intervention becomes routine, the functions are separable.',
    'If separable, the absolute reading is extraction riding on coordination—a conditional sovereignty regime could preserve interstate peace while removing the atrocity shield. If inseparable, part of the measured extraction is the necessary cost of the coordination itself.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(coordination_extraction_separability, empirical, 'Whether interstate peace requires immunizing domestic conduct.').

omega_variable(
    westphalia_historical_construction,
    'Is the absolute non-intervention reading a natural-law feature of the interstate system, or a constructed norm that benefits state elites and could be revised without system collapse?',
    'Historical analysis of sovereignty''s evolution: if the doctrine shifted substantially from Westphalia through decolonization to R2P without system failure, it is constructed. If every deviation produced systemic breakdown, it approaches natural law.',
    'If constructed, the reading is a false summit—presented as inevitable but actually maintained by beneficiary coalitions. If natural law, the high extraction is inherent to interstate order.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(westphalia_historical_construction, conceptual, 'Whether absolute territorial inviolability is discovered or constructed.').

omega_variable(
    sibling_reading_contest,
    'Do the conditional_responsibility and graded_sovereignty sibling readings represent coherent alternative frameworks, or are they unstable exceptions that collapse back to absolute non-intervention?',
    'Track international legal practice over decades: if conditional sovereignty regimes (R2P, ICC jurisdiction) stabilize and expand, they are coherent alternatives. If they remain exceptional and contested, absolute non-intervention is the attractor.',
    'If siblings are coherent, this reading is one option in a contested kernel. If siblings collapse, this reading is the revealed structure of the interstate system and alternatives are unstable idealism.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(sibling_reading_contest, empirical, 'Whether alternative sovereignty readings can stabilize institutionally.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(westphalia_sovereignty__absolute_non_intervention, 0, 40).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(west_tr_t0, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 0, 0.22).
narrative_ontology:measurement(west_tr_t8, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 8, 0.27).
narrative_ontology:measurement(west_tr_t16, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 16, 0.32).
narrative_ontology:measurement(west_tr_t24, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 24, 0.36).
narrative_ontology:measurement(west_tr_t32, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 32, 0.39).
narrative_ontology:measurement(west_tr_t40, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 40, 0.42).

% Extraction over time
narrative_ontology:measurement(west_be_t0, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 0, 0.58).
narrative_ontology:measurement(west_be_t8, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 8, 0.64).
narrative_ontology:measurement(west_be_t16, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 16, 0.71).
narrative_ontology:measurement(west_be_t24, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 24, 0.76).
narrative_ontology:measurement(west_be_t32, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 32, 0.79).
narrative_ontology:measurement(west_be_t40, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 40, 0.82).

% Suppression requirement over time
narrative_ontology:measurement(west_su_t0, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 0, 0.72).
narrative_ontology:measurement(west_su_t8, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 8, 0.76).
narrative_ontology:measurement(west_su_t16, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 16, 0.79).
narrative_ontology:measurement(west_su_t24, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 24, 0.82).
narrative_ontology:measurement(west_su_t32, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 32, 0.85).
narrative_ontology:measurement(west_su_t40, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 40, 0.88).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:affects_constraint(westphalia_sovereignty__absolute_non_intervention, westphalia_sovereignty__conditional_responsibility).
narrative_ontology:affects_constraint(westphalia_sovereignty__absolute_non_intervention, westphalia_sovereignty__graded_sovereignty).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the westphalia_sovereignty kernel. The kernel—state sovereignty—decomposes into structurally distinct readings with different victim sets and beneficiary structures. The absolute_non_intervention reading treats territorial inviolability as categorical; conditional_responsibility conditions it on protecting populations; graded_sovereignty treats it as scalar capacity. These are not the same constraint viewed from different angles—they have different ε values, different enforcement mechanisms, and different classification outcomes.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
