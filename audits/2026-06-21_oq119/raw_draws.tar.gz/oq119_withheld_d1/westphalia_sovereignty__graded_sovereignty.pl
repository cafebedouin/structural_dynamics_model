% ============================================================================
% CONSTRAINT STORY: westphalia_sovereignty__graded_sovereignty
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_westphalia_sovereignty__graded_sovereignty, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: westphalia_sovereignty__graded_sovereignty
 *   human_readable: Graded Sovereignty Reading of Westphalian Order
 *   domain: international_law/political_theory
 *
 * SUMMARY:
 *   This constraint is the graded sovereignty reading of the Westphalian
 *   sovereignty kernel. Where the absolute non-intervention reading treats
 *   sovereignty as categorical territorial inviolability and the conditional
 *   responsibility reading treats it as forfeitable upon mass atrocities,
 *   this reading treats sovereignty as a scalar variable indexed to state
 *   capacity. High-capacity states (measured by governance indices,
 *   rule-of-law scores, institutional stability) enjoy full sovereignty
 *   protections; low-capacity states face diminished protections and
 *   heightened intervention legitimacy. The framework emerged in the 1990s as
 *   multilateral institutions sought doctrinal tools to address state
 *   collapse and humanitarian crises without abandoning sovereignty norms
 *   entirely. Over time, capacity metrics have become entrenched in aid
 *   conditionality, intervention doctrine, and diplomatic practice, creating
 *   a de facto hierarchy of states. The claim is tangled_rope (genuine
 *   coordination around state failure, asymmetric extraction from weak
 *   states) while metrics describe rising extraction and suppression as the
 *   framework matured—that divergence is the measurement.
 *
 * KEY AGENTS:
 *   - capacity_evaluation_institutions (institutional/arbitrage) — set the metrics that determine sovereignty tiers
 *   - high_capacity_states (institutional/arbitrage) — benefit from presumptive inviolability and intervention authority
 *   - intervention_justifying_coalitions (institutional/mobile) — invoke capacity deficits to legitimate selective intervention
 *   - low_capacity_states (powerless/trapped) — bear diminished sovereignty and external oversight
 *   - populations_subject_to_paternalistic_oversight (powerless/trapped) — experience dual extraction from weak states and external administrators
 *   - sovereignty_egalitarians (organized/constrained) — excluded voices arguing the framework entrenches colonial hierarchies
 *   - international_law_scholars (analytical/analytical) — observe the legitimacy shift and metric non-neutrality
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(westphalia_sovereignty__graded_sovereignty, 0.68).
domain_priors:suppression_score(westphalia_sovereignty__graded_sovereignty, 0.71).
domain_priors:theater_ratio(westphalia_sovereignty__graded_sovereignty, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, extractiveness, 0.68).
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, suppression_requirement, 0.71).
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, resistance, 0.62).

% --- Constraint claim ---
narrative_ontology:constraint_claim(westphalia_sovereignty__graded_sovereignty, tangled_rope).
narrative_ontology:human_readable(westphalia_sovereignty__graded_sovereignty, "Graded Sovereignty Reading of Westphalian Order").
narrative_ontology:topic_domain(westphalia_sovereignty__graded_sovereignty, "international_law/political_theory").

domain_priors:requires_active_enforcement(westphalia_sovereignty__graded_sovereignty).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(westphalia_sovereignty__graded_sovereignty, '9ce3ea10-8d49-421a-b8ff-7d9f97cfa42b').
narrative_ontology:cs_kernel_codification('9ce3ea10-8d49-421a-b8ff-7d9f97cfa42b', distributed).
narrative_ontology:cs_authority_grounding('9ce3ea10-8d49-421a-b8ff-7d9f97cfa42b', distributed).
narrative_ontology:cs_reading_relation('9ce3ea10-8d49-421a-b8ff-7d9f97cfa42b', westphalia_sovereignty__absolute_non_intervention, coexists_with).
narrative_ontology:cs_reading_relation('9ce3ea10-8d49-421a-b8ff-7d9f97cfa42b', westphalia_sovereignty__conditional_responsibility, coexists_with).
narrative_ontology:cs_axiom('9ce3ea10-8d49-421a-b8ff-7d9f97cfa42b', foundational, sovereignty_as_scalar_capacity).
narrative_ontology:cs_axiom_status(sovereignty_as_scalar_capacity, holdable).
narrative_ontology:cs_axiom_grounding('9ce3ea10-8d49-421a-b8ff-7d9f97cfa42b', sovereignty_as_scalar_capacity, empirically_contingent).
narrative_ontology:cs_axiom('9ce3ea10-8d49-421a-b8ff-7d9f97cfa42b', secondary, intervention_legitimacy_proportional_to_deficit).
narrative_ontology:cs_axiom_status(intervention_legitimacy_proportional_to_deficit, holdable).
narrative_ontology:cs_axiom_grounding('9ce3ea10-8d49-421a-b8ff-7d9f97cfa42b', intervention_legitimacy_proportional_to_deficit, instrumental).
narrative_ontology:cs_reference_frame('9ce3ea10-8d49-421a-b8ff-7d9f97cfa42b', formal_sovereign_equality).
narrative_ontology:cs_drift_state('9ce3ea10-8d49-421a-b8ff-7d9f97cfa42b', post_cold_war_capacity_institutionalization, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('9ce3ea10-8d49-421a-b8ff-7d9f97cfa42b', '').
narrative_ontology:cs_kernel_id(westphalia_sovereignty__graded_sovereignty, westphalia_sovereignty).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, capacity_evaluation_institutions).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, high_capacity_states).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, intervention_justifying_coalitions).
narrative_ontology:constraint_victim(westphalia_sovereignty__graded_sovereignty, low_capacity_states).
narrative_ontology:constraint_victim(westphalia_sovereignty__graded_sovereignty, populations_subject_to_paternalistic_oversight).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__graded_sovereignty, liberal_democratic_governance_superiority).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__graded_sovereignty, development_teleology).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Multilateral bodies and think tanks that establish metrics for state capacity (rule of law indices, governance scores, fragility assessments). They set the thresholds that determine which states are 'full' sovereigns versus candidates for external oversight. Their evaluation frameworks shape intervention legitimacy discourse and justify resource allocation decisions.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, capacity_evaluation_institutions, agenda_setter,
    institutional, generational, arbitrage, global).

% Western democracies and wealthy states consistently ranked at the high end of capacity metrics. They benefit from presumptive territorial inviolability while gaining legitimacy to intervene in lower-tier states. Their domestic arrangements become the implicit standard against which all sovereignty is measured.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, high_capacity_states, beneficiary,
    institutional, generational, arbitrage, global).

% Ad hoc coalitions (often led by high-capacity states) that invoke capacity deficits to legitimate humanitarian or stabilization interventions. The graded framework provides doctrinal cover for selective intervention—states can cite capacity metrics rather than admit strategic interest.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, intervention_justifying_coalitions, beneficiary,
    institutional, biographical, mobile, continental).
narrative_ontology:stakeholder_secondary_role(westphalia_sovereignty__graded_sovereignty, intervention_justifying_coalitions, agenda_setter).

% States labeled 'fragile,' 'failing,' or 'low-capacity' face diminished sovereignty protections. They are subject to conditionality regimes (aid tied to governance reforms), external monitoring, and heightened intervention vulnerability. Exit means improving capacity scores, but the evaluation metrics often reflect donor preferences rather than local legitimacy.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, low_capacity_states, payer,
    powerless, generational, trapped, national).

% Citizens in low-capacity states experience dual extraction: their own government's weakness and the external oversight justified by that weakness. International administrators, conditional aid programs, and intervention forces operate with reduced accountability because the state's low capacity score delegitimates local claims to self-determination.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, populations_subject_to_paternalistic_oversight, payer,
    powerless, biographical, trapped, local).

% Scholars, diplomats, and activists from the Global South who argue that graded sovereignty entrenches colonial hierarchies and that capacity deficits are often products of historical extraction by the same states now claiming evaluative authority. They advocate for categorical equality of sovereignty but are marginalized in institutional settings dominated by capacity discourse.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, sovereignty_egalitarians, excluded,
    organized, generational, constrained, global).

% Academic and legal analysts who trace how capacity-based frameworks shift sovereignty from a formal-legal status to a performance-evaluated privilege. They document the legitimacy effects, note the lack of neutral metrics, and observe how intervention selectivity persists despite ostensibly objective criteria.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, international_law_scholars, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a graduated alternative to binary sovereignty/anarchy: states with genuine capacity deficits can receive international support without triggering full sovereignty collapse, and truly failed states can be addressed without violating norms wholesale.
% TRANSFER_FUNCTION: Moves legitimacy to intervene from a blanket prohibition to a calibrated entitlement: high-capacity states gain authority to act in low-capacity contexts, while low-capacity states lose veto power over external involvement in proportion to their measured deficits.
% ABSENT_VOICES: Sovereignty egalitarians and postcolonial theorists who argue that capacity metrics encode donor preferences and that graded sovereignty recapitulates imperial hierarchies are structurally excluded from the institutions that set evaluation criteria. Their objections are heard but not incorporated into the governing framework.
% DISAPPEARANCE_RATIONALE: If this reading disappeared overnight and sovereignty reverted to a categorical binary, intervention legitimacy would shift abruptly—either toward blanket non-intervention (absolute reading) or toward atrocity-triggered thresholds (conditional responsibility reading). The institutional apparatus of capacity evaluation would lose its doctrinal anchor, aid conditionality regimes would require new justification, and the hierarchy of 'responsible' versus 'failing' states would collapse into formal equality.
% FOUNDING_PROBLEM: The post-Cold War proliferation of state collapse, civil war, and humanitarian crises created situations where neither absolute non-intervention (letting populations suffer) nor unlimited intervention (violating sovereignty norms) was tenable. Graded sovereignty emerged to bridge that dilemma by tying intervention legitimacy to observable state incapacity.
% FOUNDING_PROBLEM_CORROBORATION: High-capacity states and multilateral development institutions attest the problem remains live, citing ongoing fragile-state crises. Sovereignty egalitarians and historians of intervention attest the founding problem has been instrumentalized—capacity metrics now justify interventions driven by strategic interest, and the framework entrenches rather than resolves the North-South hierarchy. Independent legal scholarship documents both the genuine coordination need and the extractive overlay.
narrative_ontology:disappearance_verdict(westphalia_sovereignty__graded_sovereignty, world_rearranges).
narrative_ontology:founding_problem_status(westphalia_sovereignty__graded_sovereignty, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(westphalia_sovereignty__graded_sovereignty, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(westphalia_sovereignty__graded_sovereignty, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(westphalia_sovereignty__graded_sovereignty_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(westphalia_sovereignty__graded_sovereignty, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(westphalia_sovereignty__graded_sovereignty_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is substantial (0.68 at interval end) because capacity metrics are set by high-capacity states and reflect their governance models, creating a self-perpetuating hierarchy where donor preferences determine sovereignty protections. Suppression is high (0.71) because low-capacity states cannot exit the evaluation regime—refusing to participate delegitimates them further and triggers aid suspension. Theater ratio is moderate (0.42): capacity-building assistance is real, but a growing share of activity is performative compliance with evaluation criteria rather than addressing local legitimacy deficits. The measurement series shows rising extraction and suppression over the interval as the framework matured from crisis response to institutionalized hierarchy.
 *
 * PERSPECTIVAL GAP:
 *   The agenda-setter and beneficiary seats (evaluators and high-capacity states) experience this as genuine coordination solving the state-failure dilemma. The payer seats (low-capacity states, populations under oversight) experience the same structure as paternalistic extraction that entrenches their subordination. The engine computes this divergence from the structural asymmetry; the tangled_rope claim does not adjudicate which perception is 'correct.'
 *
 * DIRECTIONALITY LOGIC:
 *   Capacity-evaluation institutions and high-capacity states are structural beneficiaries (set the rules, enjoy presumptive protection, gain intervention authority—d near beneficiary end). Low-capacity states and their populations are targets (diminished sovereignty, oversight burdens, trapped by evaluation criteria—d near target end). Intervention-justifying coalitions benefit instrumentally (gain doctrinal cover) but operate at shorter time horizons. Sovereignty egalitarians are excluded rather than coordinated—their principled objection to hierarchy is the claim the framework suppresses.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint resolves mandatrophy by declaring both coordination and extraction: it genuinely coordinates international response to state collapse (the founding problem was real) AND extracts sovereignty protections from weak states in proportion to their deviation from donor-preferred governance models. The theater ratio tracks the shift from crisis response to institutionalized hierarchy—performative compliance with capacity metrics now consumes resources that could address local legitimacy gaps.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    metric_neutrality,
    'Are state capacity metrics neutral measures of governance effectiveness, or do they encode donor preferences and liberal-democratic institutional models?',
    'Comparative analysis of capacity scores against alternative legitimacy measures (popular support, service delivery, conflict resolution); historical tracing of which institutional arrangements correlate with high scores and whether those arrangements preceded or followed metric design.',
    'If metrics encode donor preferences, the measured capacity deficits are partly artifacts of the evaluation framework itself, and the graded sovereignty reading operates as extraction masked as coordination. If metrics are neutral, the hierarchy reflects genuine governance variation.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(metric_neutrality, empirical, 'Whether capacity metrics measure governance or encode donor ideology.').

omega_variable(
    intervention_selectivity,
    'Does capacity-based intervention legitimacy reduce or entrench selectivity—are interventions more consistent under graded sovereignty than under prior regimes, or do strategic interests still drive intervention with capacity metrics as post-hoc justification?',
    'Cross-case comparison of intervention decisions against capacity scores: if intervention correlates more strongly with strategic interest (resource access, alliance politics) than with capacity deficits, selectivity persists. If capacity deficits predict intervention independent of strategic factors, the framework reduces selectivity.',
    'If selectivity persists, graded sovereignty provides doctrinal cover for extraction-driven intervention rather than solving the coordination problem it claims to address. If selectivity declines, the coordination function is genuine.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(intervention_selectivity, empirical, 'Whether capacity metrics reduce or rationalize intervention selectivity.').

omega_variable(
    sovereignty_as_privilege_vs_right,
    'Is sovereignty a performed entitlement (states must demonstrate capacity to earn protection) or an inherent right (all states possess equal sovereignty regardless of internal arrangements)?',
    'Conceptual analysis: the question cannot be resolved empirically because it asks what sovereignty IS, not what correlates with it. Different normative frameworks produce different answers, and the graded reading''s answer (performed entitlement) is contested by the absolute and conditional readings.',
    'If sovereignty is inherent, graded sovereignty illegitimately subordinates weak states. If sovereignty is performed, the framework is a legitimate evolution of international order. The choice determines whether capacity metrics measure or constitute sovereignty deficits.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(sovereignty_as_privilege_vs_right, conceptual, 'Whether sovereignty is an inherent right or an earned privilege.').

omega_variable(
    committer_frame_kernel_delta,
    'What structural element distinguishes the graded_sovereignty reading from its sibling absolute_non_intervention and conditional_responsibility readings within the westphalia_sovereignty kernel?',
    'Reading comparison: absolute_non_intervention treats sovereignty as a binary legal status independent of state performance; conditional_responsibility treats it as a binary status with a discrete atrocity-triggered forfeiture threshold; graded_sovereignty treats it as a continuous variable indexed to capacity metrics. The delta is the shift from binary/threshold to scalar and the resulting hierarchy.',
    'If the graded reading is adopted, intervention legitimacy becomes a function of evaluated capacity rather than categorical prohibition or atrocity threshold. The hierarchy that results is the primary structural consequence differentiating this reading from its siblings.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(committer_frame_kernel_delta, conceptual, 'Structural difference between graded and sibling sovereignty readings.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(westphalia_sovereignty__graded_sovereignty, 0, 30).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(west_tr_t0, westphalia_sovereignty__graded_sovereignty, theater_ratio, 0, 0.22).
narrative_ontology:measurement(west_tr_t6, westphalia_sovereignty__graded_sovereignty, theater_ratio, 6, 0.27).
narrative_ontology:measurement(west_tr_t12, westphalia_sovereignty__graded_sovereignty, theater_ratio, 12, 0.32).
narrative_ontology:measurement(west_tr_t18, westphalia_sovereignty__graded_sovereignty, theater_ratio, 18, 0.36).
narrative_ontology:measurement(west_tr_t24, westphalia_sovereignty__graded_sovereignty, theater_ratio, 24, 0.39).
narrative_ontology:measurement(west_tr_t30, westphalia_sovereignty__graded_sovereignty, theater_ratio, 30, 0.42).

% Extraction over time
narrative_ontology:measurement(west_be_t0, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 0, 0.48).
narrative_ontology:measurement(west_be_t6, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 6, 0.52).
narrative_ontology:measurement(west_be_t12, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 12, 0.57).
narrative_ontology:measurement(west_be_t18, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 18, 0.62).
narrative_ontology:measurement(west_be_t24, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 24, 0.65).
narrative_ontology:measurement(west_be_t30, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 30, 0.68).

% Suppression requirement over time
narrative_ontology:measurement(west_su_t0, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 0, 0.54).
narrative_ontology:measurement(west_su_t6, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 6, 0.58).
narrative_ontology:measurement(west_su_t12, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 12, 0.62).
narrative_ontology:measurement(west_su_t18, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 18, 0.66).
narrative_ontology:measurement(west_su_t24, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 24, 0.69).
narrative_ontology:measurement(west_su_t30, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 30, 0.71).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(westphalia_sovereignty__graded_sovereignty, global_infrastructure).
narrative_ontology:affects_constraint(westphalia_sovereignty__graded_sovereignty, westphalia_sovereignty__absolute_non_intervention).
narrative_ontology:affects_constraint(westphalia_sovereignty__graded_sovereignty, westphalia_sovereignty__conditional_responsibility).

% DUAL FORMULATION NOTE:
% This constraint is one of three readings of the westphalia_sovereignty kernel. All three readings address the same question (what legitimates external interference in state affairs) but instantiate different normative frameworks with different ε values. The absolute reading treats sovereignty as categorical and assigns near-zero extraction (non-intervention is a rule). The conditional reading treats sovereignty as forfeitable at an atrocity threshold and assigns moderate extraction (atrocity determination is contestable but bounded). This graded reading treats sovereignty as scalar and assigns substantial extraction because capacity metrics encode donor preferences and create a self-perpetuating hierarchy. The three readings form a constraint family linked by network.affects_constraints.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
