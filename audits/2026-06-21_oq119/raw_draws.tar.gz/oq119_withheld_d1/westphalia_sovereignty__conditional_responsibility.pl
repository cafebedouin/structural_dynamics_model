% ============================================================================
% CONSTRAINT STORY: westphalia_sovereignty__conditional_responsibility
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2025-01-15
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_westphalia_sovereignty__conditional_responsibility, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: westphalia_sovereignty__conditional_responsibility
 *   human_readable: Responsibility to Protect (R2P) Doctrine
 *   domain: international_law/political_theory
 *
 * SUMMARY:
 *   Following the failures to prevent genocide in Rwanda (1994) and Bosnia
 *   (1995), the international community developed the Responsibility to
 *   Protect doctrine, formally endorsed at the 2005 UN World Summit. The
 *   doctrine holds that sovereignty is conditional: states earn territorial
 *   inviolability by protecting their populations from mass atrocities
 *   (genocide, ethnic cleansing, crimes against humanity, war crimes). When
 *   states manifestly fail this responsibility, the international community
 *   gains legitimate authority to intervene, including through military force
 *   as a last resort. The doctrine has been invoked in Libya (2011), Côte
 *   d'Ivoire (2011), and debated for Syria, Myanmar, and other cases. This is
 *   the CONDITIONAL_RESPONSIBILITY reading of the sovereignty kernel—one of
 *   three competing interpretations of what sovereignty means in the
 *   post-Westphalian order.
 *
 * KEY AGENTS:
 *   - humanitarian_intervention_coalitions: Primary agenda-setters (institutional/arbitrage) — determine when atrocity threshold is crossed and conduct interventions
 *   - global_governance_institutions: Co-agenda-setters (institutional/mobile) — gain adjudicative authority over sovereignty forfeiture
 *   - populations_under_atrocity_threat: Primary beneficiaries (powerless/trapped) — receive protection when doctrine is invoked successfully
 *   - targeted_state_governments: Primary payers (institutional/constrained) — lose territorial inviolability and face intervention
 *   - populations_subject_to_intervention_costs: Secondary payers (powerless/trapped) — bear collateral damage and post-intervention instability
 *   - non_intervening_states: Excluded voices (institutional/constrained) — object to selective application but lack adjudicative authority
 *   - international_legal_scholars: Observers (analytical/analytical) — document intervention patterns and assess doctrine's operation
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(westphalia_sovereignty__conditional_responsibility, 0.68).
domain_priors:suppression_score(westphalia_sovereignty__conditional_responsibility, 0.72).
domain_priors:theater_ratio(westphalia_sovereignty__conditional_responsibility, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, extractiveness, 0.68).
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, suppression_requirement, 0.72).
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, resistance, 0.71).

% --- Constraint claim ---
narrative_ontology:constraint_claim(westphalia_sovereignty__conditional_responsibility, tangled_rope).
narrative_ontology:human_readable(westphalia_sovereignty__conditional_responsibility, "Responsibility to Protect (R2P) Doctrine").
narrative_ontology:topic_domain(westphalia_sovereignty__conditional_responsibility, "international_law/political_theory").

domain_priors:requires_active_enforcement(westphalia_sovereignty__conditional_responsibility).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(westphalia_sovereignty__conditional_responsibility, 'b2cf4929-374a-486e-a87f-f97ac4b5d441').
narrative_ontology:cs_kernel_codification('b2cf4929-374a-486e-a87f-f97ac4b5d441', formalized).
narrative_ontology:cs_authority_grounding('b2cf4929-374a-486e-a87f-f97ac4b5d441', distributed).
narrative_ontology:cs_reading_relation('b2cf4929-374a-486e-a87f-f97ac4b5d441', westphalia_sovereignty__absolute_non_intervention, forecloses).
narrative_ontology:cs_reading_relation('b2cf4929-374a-486e-a87f-f97ac4b5d441', westphalia_sovereignty__graded_sovereignty, coexists_with).
narrative_ontology:cs_axiom('b2cf4929-374a-486e-a87f-f97ac4b5d441', foundational, sovereignty_conditional_on_population_protection).
narrative_ontology:cs_axiom_status(sovereignty_conditional_on_population_protection, holdable).
narrative_ontology:cs_axiom_grounding('b2cf4929-374a-486e-a87f-f97ac4b5d441', sovereignty_conditional_on_population_protection, deontological).
narrative_ontology:cs_axiom('b2cf4929-374a-486e-a87f-f97ac4b5d441', secondary, international_community_gains_intervention_authority).
narrative_ontology:cs_axiom_status(international_community_gains_intervention_authority, holdable).
narrative_ontology:cs_axiom_grounding('b2cf4929-374a-486e-a87f-f97ac4b5d441', international_community_gains_intervention_authority, conventional).
narrative_ontology:cs_reference_frame('b2cf4929-374a-486e-a87f-f97ac4b5d441', westphalian_territorial_inviolability).
narrative_ontology:cs_drift_state('b2cf4929-374a-486e-a87f-f97ac4b5d441', post_2005_world_summit_consensus, gap(authority_erosion, substantial, true)).
narrative_ontology:cs_created_at('b2cf4929-374a-486e-a87f-f97ac4b5d441', '').
narrative_ontology:cs_kernel_id(westphalia_sovereignty__conditional_responsibility, westphalia_sovereignty).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, humanitarian_intervention_coalitions).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, global_governance_institutions).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, populations_under_atrocity_threat).
narrative_ontology:constraint_victim(westphalia_sovereignty__conditional_responsibility, targeted_state_governments).
narrative_ontology:constraint_victim(westphalia_sovereignty__conditional_responsibility, populations_subject_to_intervention_costs).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Military coalitions (often led by Western powers) that invoke R2P to authorize intervention in states allegedly committing atrocities. They set operational definitions of 'mass atrocity,' determine when the threshold is crossed, and conduct military operations. Benefit from expanded mandate for force projection and institutional legitimacy for interventions that may serve strategic interests alongside humanitarian ones.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, humanitarian_intervention_coalitions, agenda_setter,
    institutional, biographical, arbitrage, global).

% UN Security Council, International Criminal Court, regional bodies like African Union. Gain adjudicative authority to determine when sovereignty is forfeit and intervention legitimate. Authority structure expands through each invocation of the doctrine, creating institutional momentum and precedent for supra-national oversight of domestic governance.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, global_governance_institutions, agenda_setter,
    institutional, generational, mobile, global).
narrative_ontology:stakeholder_secondary_role(westphalia_sovereignty__conditional_responsibility, global_governance_institutions, beneficiary).

% Civilians facing genocide, ethnic cleansing, crimes against humanity. The doctrine's beneficiaries in its stated rationale—protection arrives when intervention occurs and succeeds. Exit is structurally blocked by the same state apparatus the doctrine targets. Depend entirely on external actors recognizing the atrocity threshold and choosing to act.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, populations_under_atrocity_threat, beneficiary,
    powerless, immediate, trapped, national).

% Governments accused of failing their protective responsibility. Lose territorial inviolability; face sanctions, no-fly zones, armed intervention, or regime change. Cannot exit the international state system without ceasing to exist as states. Some are genuine atrocity regimes; others contest the accusation or argue the threshold was applied selectively.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, targeted_state_governments, payer,
    institutional, biographical, constrained, national).

% Civilian populations experiencing military intervention's collateral damage, prolonged instability, or post-intervention power vacuums. Not all members of 'populations_under_atrocity_threat'—some interventions protect one group while imposing costs on others, or intervention succeeds in ending atrocities but leaves governance collapse. Bear costs without choosing the intervention.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, populations_subject_to_intervention_costs, payer,
    powerless, biographical, trapped, national).

% States (particularly Global South and non-Western powers) that reject the doctrine as Western interventionism under humanitarian cover. Argue the threshold is applied selectively to weaker states while powerful states committing comparable acts face no sanction. Excluded from adjudicative authority—intervention decisions concentrate in Security Council permanent members and NATO coalitions.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, non_intervening_states, excluded,
    institutional, generational, constrained, global).

% Analyze whether R2P represents genuine evolution of sovereignty norms or selective erosion of Westphalian principles. Document intervention patterns, compare stated humanitarian rationales to actual case selection, assess whose populations receive protection and whose states face consequences. Provide empirical record for evaluating the doctrine's coordination versus extraction functions.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, international_legal_scholars, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Solves a collective action problem where populations face mass atrocities but no single state has both obligation and capacity to intervene. Establishes shared criteria for when sovereignty's protective shield is forfeit, enabling coordinated international response to genocide and crimes against humanity.
% TRANSFER_FUNCTION: Transfers adjudicative authority over territorial inviolability from sovereign states to international institutions and intervention coalitions. Moves decision-making power about legitimate use of force across borders from targeted states to external actors invoking humanitarian mandate.
% ABSENT_VOICES: Non-intervening states and populations in regions where comparable atrocities receive no intervention are structurally excluded. Their objections—that the doctrine is applied selectively, that intervention often serves intervener interests, that post-intervention costs are borne by those who had no voice in the decision—are dismissed as obstructing humanitarian imperatives or defending sovereignty absolutism.
% DISAPPEARANCE_RATIONALE: If the doctrine vanished: intervention coalitions would lose humanitarian legitimacy framing for force projection (world rearranges for them); populations under genuine atrocity would have no institutional pathway to protection (world rearranges for them); but the pattern of powerful states intervening in weaker states for mixed motives would likely persist under different rationales (world largely unchanged in practice). The contestation is whether R2P changes intervention patterns or merely re-labels them.
% FOUNDING_PROBLEM: The Rwandan genocide and Srebrenica massacre: mass atrocities occurring while international community invoked non-intervention norms, leaving populations with no protection despite clear evidence of systematic killing.
% FOUNDING_PROBLEM_CORROBORATION: Humanitarian organizations and genocide scholars attest the founding problem remains live—populations still face atrocities while international response is delayed or absent. Targeted state governments and non-intervening states attest the problem has been instrumentalized: R2P now authorizes interventions in cases far below the genocide threshold, applied selectively to geopolitically convenient targets. Independent analysis from international legal scholars shows mixed record: some genuine atrocity prevention, but also intervention in contested cases and non-intervention in clear cases where intervener interests don't align.
narrative_ontology:disappearance_verdict(westphalia_sovereignty__conditional_responsibility, contested).
narrative_ontology:founding_problem_status(westphalia_sovereignty__conditional_responsibility, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(westphalia_sovereignty__conditional_responsibility, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(westphalia_sovereignty__conditional_responsibility, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(westphalia_sovereignty__conditional_responsibility_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(westphalia_sovereignty__conditional_responsibility, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

:- end_tests(westphalia_sovereignty__conditional_responsibility_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is substantial (0.68 at interval end) because the doctrine transfers decision-making authority over territorial inviolability from all states to a small set of powerful states and institutions, and empirical record shows selective application—intervention occurs when it serves intervener interests, not consistently when atrocities occur. Suppression is high (0.72) because targeted states cannot exit the international system and non-intervening states' objections are systematically overridden as obstructing humanitarian imperatives. Theater ratio is moderate (0.42) and rising: the humanitarian rationale is genuine in some cases but increasingly used to legitimate interventions with mixed or primarily strategic motives. Accessibility collapse is moderate-low (0.48) because alternative sovereignty frameworks remain live options (absolute non-intervention, graded sovereignty), and resistance is substantial (0.71) because most of the world's states contest the doctrine's legitimacy and application. The measurements track accumulating extraction as the doctrine's institutional infrastructure hardens and its application becomes more routine.
 *
 * PERSPECTIVAL GAP:
 *   From the intervention coalition seat, this is genuine evolution of sovereignty toward human rights protection—a rope that solves the Rwanda problem. From the targeted state seat, it is selective erosion of sovereignty that powerful states weaponize against weaker ones—closer to snare. From the analytical seat, the mixed empirical record (some genuine atrocity prevention, some selective application, some post-intervention collapse) reveals the tangled_rope structure: coordination function and extraction function operating through the same institutional machinery, inseparable in practice.
 *
 * DIRECTIONALITY LOGIC:
 *   Humanitarian intervention coalitions and global governance institutions are structural beneficiaries—they gain expanded mandate and adjudicative authority. Populations under atrocity threat are intended beneficiaries but their actual benefit depends entirely on whether protection is delivered, which is selective. Targeted state governments are direct targets—they lose sovereignty and face intervention. Populations subject to intervention costs are secondary targets—they bear costs not from the atrocity the intervention addresses but from the intervention itself or its aftermath. The dual nature of 'populations' (some protected, others harmed) is why this is tangled_rope rather than pure snare—real coordination benefit exists but is inseparable from asymmetric extraction.
 *
 * MANDATROPHY ANALYSIS:
 *   The founding problem (genocide occurring while sovereignty norms block intervention) was real and the doctrine addresses it structurally. But the R5 genealogy interview reveals contested status: the doctrine's beneficiaries (intervention coalitions, global governance institutions) attest the problem remains live and their authority is needed; excluded voices (non-intervening states, populations experiencing intervention costs) attest the doctrine has drifted from atrocity prevention into legitimation for selective intervention. The mismatch between 'founding problem contested' and 'world rearranges if disappeared' (contested) flags potential capture—the arrangement persists through institutional momentum and serves beneficiary interests even where founding rationale is weak. This is not resolved mandatrophy (the coordination function is still partly operational) but accumulating extraction layered onto genuine coordination.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    threshold_determinacy,
    'Is the ''mass atrocity'' threshold that triggers sovereignty forfeiture objectively determinable, or does discretion in threshold application enable selective intervention serving intervener interests?',
    'Comparative analysis of intervention patterns: if intervention correlates strongly with atrocity severity and weakly with intervener strategic interests, threshold is determinate. If correlation inverts (weak on severity, strong on interests), threshold is discretionary cover.',
    'If threshold is genuinely determinate and consistently applied, measured extraction should be lower—the doctrine functions primarily as coordination. If threshold is discretionary, measured extraction is accurate and the doctrine enables legitimated extraction through humanitarian framing.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(threshold_determinacy, empirical, 'Whether atrocity threshold is objective rule or discretionary instrument').

omega_variable(
    coordination_extraction_separability,
    'Can the doctrine''s coordination function (enabling collective response to genocide) be separated from its extraction function (transferring adjudicative authority to powerful states), or are they structurally inseparable?',
    'Institutional design experiment: could alternative mechanisms (e.g., regional bodies with equal vote, algorithmic threshold triggers, mandatory intervention when criteria met) deliver the coordination benefit without concentrating authority? If separable alternatives exist but aren''t adopted, extraction is primary. If attempted alternatives fail to solve coordination problem, functions are inseparable.',
    'If separable, the doctrine is a snare using humanitarian cover for institutional extraction. If inseparable, it is genuinely tangled_rope where real coordination benefit cannot be obtained without accepting asymmetric authority structure.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(coordination_extraction_separability, conceptual, 'Whether coordination and extraction functions are structurally separable').

omega_variable(
    committer_frame_natural_vs_constructed,
    'Is conditional sovereignty a discovered evolution of international norms (responding to genuine moral imperative after Rwanda/Srebrenica), or a constructed doctrine that powerful states installed to legitimate existing intervention patterns?',
    'Historical analysis: did intervention patterns change after R2P adoption, or did R2P provide new framing for continuity? If patterns shifted (more intervention in non-strategic atrocity cases, less in strategic non-atrocity cases), doctrine reflects norm evolution. If patterns unchanged (intervention still correlates with strategic interest regardless of humanitarian situation), doctrine is constructed legitimation.',
    'If natural norm evolution, the CONDITIONAL_RESPONSIBILITY reading competes with ABSOLUTE_NON_INTERVENTION as genuine alternative interpretations of sovereignty. If constructed legitimation, this reading is better understood as institutional extraction masquerading as norm evolution, and the ''kernel contest'' itself may be asymmetric—absolute sovereignty as genuine norm, conditionality as beneficiary-serving construction.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(committer_frame_natural_vs_constructed, empirical, 'Whether conditional sovereignty is norm evolution or institutional construction').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(westphalia_sovereignty__conditional_responsibility, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(west_tr_t0, westphalia_sovereignty__conditional_responsibility, theater_ratio, 0, 0.25).
narrative_ontology:measurement(west_tr_t5, westphalia_sovereignty__conditional_responsibility, theater_ratio, 5, 0.28).
narrative_ontology:measurement(west_tr_t10, westphalia_sovereignty__conditional_responsibility, theater_ratio, 10, 0.33).
narrative_ontology:measurement(west_tr_t15, westphalia_sovereignty__conditional_responsibility, theater_ratio, 15, 0.37).
narrative_ontology:measurement(west_tr_t20, westphalia_sovereignty__conditional_responsibility, theater_ratio, 20, 0.4).
narrative_ontology:measurement(west_tr_t25, westphalia_sovereignty__conditional_responsibility, theater_ratio, 25, 0.42).

% Extraction over time
narrative_ontology:measurement(west_be_t0, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 0, 0.45).
narrative_ontology:measurement(west_be_t5, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 5, 0.52).
narrative_ontology:measurement(west_be_t10, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 10, 0.58).
narrative_ontology:measurement(west_be_t15, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 15, 0.63).
narrative_ontology:measurement(west_be_t20, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 20, 0.66).
narrative_ontology:measurement(west_be_t25, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 25, 0.68).

% Suppression requirement over time
narrative_ontology:measurement(west_su_t0, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 0, 0.55).
narrative_ontology:measurement(west_su_t5, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 5, 0.6).
narrative_ontology:measurement(west_su_t10, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 10, 0.64).
narrative_ontology:measurement(west_su_t15, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 15, 0.67).
narrative_ontology:measurement(west_su_t20, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 20, 0.7).
narrative_ontology:measurement(west_su_t25, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 25, 0.72).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(westphalia_sovereignty__conditional_responsibility, enforcement_mechanism).
narrative_ontology:affects_constraint(westphalia_sovereignty__conditional_responsibility, westphalia_sovereignty__absolute_non_intervention).
narrative_ontology:affects_constraint(westphalia_sovereignty__conditional_responsibility, westphalia_sovereignty__graded_sovereignty).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the westphalia_sovereignty kernel. The constraint family includes three readings: absolute_non_intervention (sovereignty as categorical barrier to external interference), conditional_responsibility (this reading: sovereignty forfeit through atrocity), and graded_sovereignty (sovereignty as scalar capacity). Each reading operates with different epsilon values because they instantiate different beneficiary structures and enforcement mechanisms. Conditional_responsibility has substantially higher extractiveness (0.68) than absolute_non_intervention (~0.35) because conditionality enables discretionary application, transferring adjudicative authority to intervention coalitions. Link absolute reading for the sovereignty-as-barrier baseline; link graded reading for the capacity-based alternative that also erodes Westphalian inviolability but through different logic.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
