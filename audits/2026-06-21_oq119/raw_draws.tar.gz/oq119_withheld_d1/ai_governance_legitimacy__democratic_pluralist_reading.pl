% ============================================================================
% CONSTRAINT STORY: ai_governance_legitimacy__democratic_pluralist_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-19
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_ai_governance_legitimacy__democratic_pluralist_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: ai_governance_legitimacy__democratic_pluralist_reading
 *   human_readable: Democratic Pluralist AI Governance (Deliberative Legitimacy Reading)
 *   domain: theological_ethics/technology_governance/political_theology
 *
 * SUMMARY:
 *   This constraint instantiates the democratic pluralist reading of AI
 *   governance legitimacy, one of four competing readings of the same kernel.
 *   The kernel question is: what grounds the authority to govern AI? This
 *   reading answers: democratic deliberation and consent under value
 *   pluralism. Legitimacy derives from inclusive public reason, not from
 *   technocratic expertise, market efficiency, or doctrinal interpretation.
 *   The Catholic encyclical's dignity framework contributes one voice among
 *   many but holds no interpretive monopoly. Minority rights and civil
 *   liberties operate as constitutional constraints on deliberative outcomes,
 *   not as preferences to be aggregated. The reading treats governance as
 *   scaffold: building participatory infrastructure for provisional consensus
 *   under reasonable disagreement, meant to transition toward
 *   institutionalized pluralist governance rather than persist indefinitely
 *   as emergency coordination.
 *
 * KEY AGENTS:
 *   - civil_society_organizations: Primary beneficiary (organized/mobile) — gain standing in governance deliberations
 *   - democratic_institutions: Agenda setter (institutional/constrained) — set procedural framework for deliberation
 *   - minority_rights_holders: Beneficiary (organized/constrained) — protected by civil liberties from majoritarian override
 *   - excluded_populations: Primary victim (powerless/trapped) — structurally excluded from deliberative processes
 *   - authoritarian_regime_subjects: Victim (powerless/trapped) — live under simulated deliberation
 *   - marginalized_voices: Victim (powerless/identity_locked) — formally included but structurally silenced
 *   - magisterial_authority: Excluded actor (institutional/constrained) — contributes but holds no monopoly
 *   - technocratic_experts: Excluded actor (powerful/mobile) — advisory role, subordinated to democratic process
 *   - political_theorists: Observer (analytical) — study gap between deliberative ideal and implementation
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(ai_governance_legitimacy__democratic_pluralist_reading, 0.42).
domain_priors:suppression_score(ai_governance_legitimacy__democratic_pluralist_reading, 0.38).
domain_priors:theater_ratio(ai_governance_legitimacy__democratic_pluralist_reading, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, extractiveness, 0.42).
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 0.38).
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, accessibility_collapse, 0.45).
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, resistance, 0.52).

% --- Constraint claim ---
narrative_ontology:constraint_claim(ai_governance_legitimacy__democratic_pluralist_reading, scaffold).
narrative_ontology:human_readable(ai_governance_legitimacy__democratic_pluralist_reading, "Democratic Pluralist AI Governance (Deliberative Legitimacy Reading)").
narrative_ontology:topic_domain(ai_governance_legitimacy__democratic_pluralist_reading, "theological_ethics/technology_governance/political_theology").

domain_priors:requires_active_enforcement(ai_governance_legitimacy__democratic_pluralist_reading).
narrative_ontology:has_sunset_clause(ai_governance_legitimacy__democratic_pluralist_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(ai_governance_legitimacy__democratic_pluralist_reading, 'c5896dae-ff86-4d6a-b510-765b337a6aa2').
narrative_ontology:cs_kernel_codification('c5896dae-ff86-4d6a-b510-765b337a6aa2', distributed).
narrative_ontology:cs_authority_grounding('c5896dae-ff86-4d6a-b510-765b337a6aa2', distributed).
narrative_ontology:cs_reading_relation('c5896dae-ff86-4d6a-b510-765b337a6aa2', ai_governance_legitimacy__magisterial_subsidiarity_reading, coexists_with).
narrative_ontology:cs_reading_relation('c5896dae-ff86-4d6a-b510-765b337a6aa2', ai_governance_legitimacy__technocratic_optimization_reading, influences).
narrative_ontology:cs_reading_relation('c5896dae-ff86-4d6a-b510-765b337a6aa2', ai_governance_legitimacy__market_libertarian_reading, coexists_with).
narrative_ontology:cs_axiom('c5896dae-ff86-4d6a-b510-765b337a6aa2', foundational, democratic_consent_grounds_legitimacy).
narrative_ontology:cs_axiom_status(democratic_consent_grounds_legitimacy, holdable).
narrative_ontology:cs_axiom_grounding('c5896dae-ff86-4d6a-b510-765b337a6aa2', democratic_consent_grounds_legitimacy, deontological).
narrative_ontology:cs_axiom('c5896dae-ff86-4d6a-b510-765b337a6aa2', foundational, no_comprehensive_doctrine_holds_monopoly).
narrative_ontology:cs_axiom_status(no_comprehensive_doctrine_holds_monopoly, holdable).
narrative_ontology:cs_axiom_grounding('c5896dae-ff86-4d6a-b510-765b337a6aa2', no_comprehensive_doctrine_holds_monopoly, conventional).
narrative_ontology:cs_axiom('c5896dae-ff86-4d6a-b510-765b337a6aa2', secondary, minority_rights_constrain_majority_will).
narrative_ontology:cs_axiom_status(minority_rights_constrain_majority_will, holdable).
narrative_ontology:cs_axiom_grounding('c5896dae-ff86-4d6a-b510-765b337a6aa2', minority_rights_constrain_majority_will, deontological).
narrative_ontology:cs_reference_frame('c5896dae-ff86-4d6a-b510-765b337a6aa2', rawlsian_public_reason_framework).
narrative_ontology:cs_drift_state('c5896dae-ff86-4d6a-b510-765b337a6aa2', contemporary_digital_governance_era, gap(practice_drift, substantial, true)).
narrative_ontology:cs_created_at('c5896dae-ff86-4d6a-b510-765b337a6aa2', '').
narrative_ontology:cs_kernel_id(ai_governance_legitimacy__democratic_pluralist_reading, ai_governance_legitimacy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__democratic_pluralist_reading, civil_society_organizations).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__democratic_pluralist_reading, democratic_institutions).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__democratic_pluralist_reading, minority_rights_holders).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__democratic_pluralist_reading, deliberative_publics).
narrative_ontology:constraint_victim(ai_governance_legitimacy__democratic_pluralist_reading, excluded_populations).
narrative_ontology:constraint_victim(ai_governance_legitimacy__democratic_pluralist_reading, authoritarian_regime_subjects).
narrative_ontology:constraint_victim(ai_governance_legitimacy__democratic_pluralist_reading, marginalized_voices).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Gain institutional standing in AI governance deliberations. Their participation is treated as legitimacy-conferring rather than consultative. They advocate for diverse stakeholder interests, monitor accountability mechanisms, and can appeal to judicial review when excluded.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, civil_society_organizations, beneficiary,
    organized, generational, mobile, global).

% Set the procedural framework for deliberative governance: who participates, what transparency requirements hold, how contestation is adjudicated. Their authority derives from electoral legitimacy and constitutional constraint, not from technical expertise or doctrinal fidelity.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, democratic_institutions, agenda_setter,
    institutional, generational, constrained, national).

% Protected by civil liberties frameworks from majoritarian override. Their claims enter deliberation with constitutional weight; pluralist procedures treat their dignity concerns as non-negotiable constraints on optimization, not as minority preferences to be outweighed.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, minority_rights_holders, beneficiary,
    organized, biographical, constrained, national).

% Citizens who participate in structured deliberative processes (citizen assemblies, participatory budgeting, public comment on regulatory rulemaking). Their input is treated as epistemically necessary for legitimate governance, not as stakeholder management.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, deliberative_publics, beneficiary,
    organized, biographical, mobile, regional).

% Populations structurally excluded from deliberative processes due to digital divides, literacy barriers, geographic isolation, or active suppression. They bear the costs of governance decisions made in their name but without their voice, and lack recourse to the procedural protections the framework provides.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, excluded_populations, payer,
    powerless, immediate, trapped, local).

% Live under regimes that adopt the procedural vocabulary of democratic deliberation while systematically excluding dissent. They pay the extraction twice: first through exclusion from real deliberation, second through legitimacy claims made on behalf of manufactured consensus.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, authoritarian_regime_subjects, payer,
    powerless, immediate, trapped, national).

% Groups whose participation in deliberation is formally permitted but structurally undermined by resource asymmetries, epistemic injustice, or cultural barriers. They attend the deliberative spaces but their claims are filtered through dominant framings that render their concerns illegible or dismissible.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, marginalized_voices, payer,
    powerless, biographical, identity_locked, local).

% The Catholic Magisterium contributes its dignity framework as one voice in pluralist deliberation, but holds no interpretive monopoly. Its claims are evaluated on public reason terms alongside other traditions, not granted authority by institutional standing. This reading treats the encyclical as a contribution, not a verdict.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, magisterial_authority, excluded,
    institutional, civilizational, constrained, global).

% Technical experts provide input on feasibility and consequences, but do not hold authority over normative priorities. Their role is advisory; the legitimacy of governance decisions derives from deliberative consent, not from expert optimization. They remain influential but are structurally subordinated to democratic process.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, technocratic_experts, excluded,
    powerful, biographical, mobile, global).

% Analyze whether deliberative procedures genuinely track public reason or devolve into elite consensus-building that marginalizes non-dominant voices. They study the gap between the procedural ideal and its implementation, documenting exclusions and epistemic injustices the framework claims to prevent.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, political_theorists, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Solves the legitimacy problem for governance of transformative technology under value pluralism: how to make binding decisions about AI when citizens hold incompatible comprehensive doctrines. Deliberative procedures convert value contestation into provisional consensus without requiring agreement on ultimate foundations.
% TRANSFER_FUNCTION: Moves normative authority from technical experts, market actors, and doctrinal traditions to structured public deliberation. Governance decisions are legitimated by inclusive deliberative process rather than by expertise, efficiency, or revealed truth. The transfer is from unilateral authority to shared reasoning.
% ABSENT_VOICES: Populations excluded by structural barriers (digital divides, literacy, resource asymmetries) and those under authoritarian regimes that simulate deliberation while suppressing dissent. They would object that deliberative ideals systematically fail to include them, making the legitimacy claims performative rather than real.
% DISAPPEARANCE_RATIONALE: If this constraint vanished, AI governance would revert to technocratic optimization (expert authority), magisterial interpretation (doctrinal authority), or market allocation (property rights). Democratic institutions would lose their claim to set normative constraints on technology; civil society would lose standing; minority protections would become optimization parameters rather than constitutional constraints. The governance landscape would reorganize around one of the foreclosed sibling readings.
% FOUNDING_PROBLEM: How to govern transformative technology legitimately under conditions of reasonable pluralism: citizens hold incompatible comprehensive doctrines (religious, secular, utilitarian) but must make binding collective decisions about AI's trajectory. Neither technocratic expertise nor any single tradition can claim universal authority.
% FOUNDING_PROBLEM_CORROBORATION: Political theorists across democratic theory traditions (deliberative democrats, liberal constitutionalists, republican pluralists) attest the problem remains unresolved. Civil society organizations document ongoing exclusions and epistemic injustices in existing governance structures. The problem's liveness is contested primarily by those who claim technocratic or doctrinal solutions, not by observers outside those benefiting positions.
narrative_ontology:disappearance_verdict(ai_governance_legitimacy__democratic_pluralist_reading, world_rearranges).
narrative_ontology:founding_problem_status(ai_governance_legitimacy__democratic_pluralist_reading, live).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(ai_governance_legitimacy__democratic_pluralist_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(ai_governance_legitimacy__democratic_pluralist_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(ai_governance_legitimacy__democratic_pluralist_reading_tests).
:- end_tests(ai_governance_legitimacy__democratic_pluralist_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is moderate (0.42) because deliberative procedures impose real costs on excluded populations — those shut out by structural barriers bear governance decisions made without their voice. Suppression is lower (0.38) because the constraint operates through electoral accountability and judicial review rather than direct coercion; exit from specific deliberations is possible, though exit from the governance regime itself is constrained. Theater ratio is moderate-low (0.28): the deliberative function is real, but a growing share of activity defends procedural legitimacy claims against charges of elite capture and exclusion. Accessibility collapse is moderate (0.45): alternative governance models (technocratic, doctrinal, market) remain conceptually available, but once deliberative legitimacy is institutionalized, transitions away require dismantling constitutional structures. Resistance is higher (0.52): the reading faces active contestation from technocrats (who claim expertise trumps deliberation), magisterial authority (who claim doctrinal interpretation grounds legitimacy), market actors (who claim voluntary exchange is sufficient), and excluded populations (who experience deliberation as performative). The claimed type is scaffold because the constraint builds transitional participatory infrastructure; the sunset clause is implicit in the transition from emergency coordination to institutionalized pluralist governance.
 *
 * PERSPECTIVAL GAP:
 *   The agenda-setter seat (democratic institutions) should compute as scaffold: building legitimate coordination infrastructure under value pluralism. The beneficiary seats (civil society, minority rights holders) should compute similarly: gaining real standing and protection. The victim seats (excluded populations, marginalized voices) should compute as snare: extraction through exclusion or performative inclusion, with no real exit. The excluded seats (magisterial authority, technocratic experts) should compute as victims of deliberate subordination, though their actual power and exit options moderate the effective extraction. The observer seat documents the gap between deliberative ideal and exclusionary practice, which is the core omega variable.
 *
 * DIRECTIONALITY LOGIC:
 *   Civil society organizations and democratic institutions are structural beneficiaries: they gain authority and standing under deliberative governance. Minority rights holders are protected beneficiaries: their dignity claims operate as constitutional constraints. Excluded populations, authoritarian regime subjects, and marginalized voices are the victims: they bear extraction through exclusion, simulated participation, or epistemic injustice. Magisterial authority and technocratic experts are excluded rather than coordinated: their authority is structurally subordinated to democratic process. The directionality derivation should place beneficiaries near d=0.2 (gain standing and protection), victims near d=0.75 (trapped in exclusion or silenced participation), and excluded actors near d=0.6 (lose authority they claim).
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint claims to solve legitimate governance under pluralism; the extraction it imposes falls on those excluded from the deliberative process. This is not pure mandatrophy (calling coordination extraction) because the coordination function is real: deliberative procedures do solve the problem of binding collective decisions under value disagreement for those actually included. But it is also not pure coordination (calling extraction coordination) because the exclusions are structural and systematic, not incidental. The constraint is scaffold: the deliberative infrastructure is meant to be transitional, expanding inclusion over time, with the sunset implied by the transition to fully institutionalized pluralist governance. The tension between ideal and practice is the constraint's central omega.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    deliberative_ideal_vs_exclusionary_practice,
    'Do deliberative procedures genuinely track inclusive public reason, or do they systematically reproduce exclusions through resource asymmetries, epistemic injustice, and gate-keeping that the procedural ideal denies?',
    'Empirical analysis of deliberative governance structures: who participates, whose claims are legible, which voices are filtered or dismissed. Audit participation by demographic, measure correlation between deliberative outcomes and pre-existing power structures, track appeals to judicial review by excluded groups.',
    'If deliberation systematically reproduces exclusions, the constraint''s extractiveness is higher than the ideal suggests and its scaffold claim is suspect: it would be building permanent procedural legitimacy for elite consensus rather than transitional infrastructure toward genuine inclusion. If deliberation robustly includes marginalized voices, the scaffold claim holds.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(deliberative_ideal_vs_exclusionary_practice, empirical, 'Whether deliberative procedures deliver inclusive public reason or reproduce structural exclusions.').

omega_variable(
    public_reason_vs_comprehensive_doctrines,
    'Can public reason genuinely remain neutral among comprehensive doctrines, or does the deliberative framework itself encode liberal commitments that subordinate non-liberal traditions?',
    'Conceptual analysis of what counts as ''public reason'' and which comprehensive doctrines can translate their claims into that vocabulary. If only liberal secular claims are legible as public reasons, the framework is not neutral but hegemonic.',
    'If public reason is hegemonic liberalism, the constraint''s claim to pluralist legitimacy is false: it would be imposing one comprehensive doctrine (liberalism) on others, making the extraction higher and the coordination function narrower. If public reason can genuinely accommodate diverse traditions, the pluralist claim holds.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(public_reason_vs_comprehensive_doctrines, conceptual, 'Whether public reason is neutral or hegemonically liberal.').

omega_variable(
    sunset_clause_vs_permanent_scaffold,
    'Is the deliberative infrastructure genuinely transitional (scaffold), or is it a permanent regime that will never sunset because the transition to ''full inclusion'' is indefinitely deferred?',
    'Track the constraint''s own justification over time: if deliberative structures cite perpetual incompleteness as reason to persist, the scaffold claim is suspect. If institutions declare procedural maturity and transition to routine governance, the scaffold claim holds.',
    'If the constraint persists indefinitely with no declared transition, it is not scaffold but rope or tangled_rope: the emergency framing legitimates extraction that has become permanent. The theater ratio would rise as ''building inclusion'' becomes cover for defending existing procedural authority.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(sunset_clause_vs_permanent_scaffold, empirical, 'Whether the scaffold transitions or persists indefinitely.').

omega_variable(
    committer_frame_reading_boundary,
    'Are these four readings genuinely distinct constraints with different ε values, or are they observer-relative framings of the same governance structure?',
    'Apply the ε-invariance test: if measuring this reading''s extraction one way gives ε≈0.42 (moderate) but measuring it from a magisterial frame gives ε≈0.65 (high), they are distinct constraints. If all readings collapse to the same metric profile, they are observer perspectives on one constraint.',
    'If readings are genuinely distinct, network analysis of their influence edges reveals which is winning institutional adoption. If they are observer perspectives, the kernel itself is the constraint and the readings are just interpretive commentary.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(committer_frame_reading_boundary, conceptual, 'Whether the reading decomposition is constraint-level or observer-level.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(ai_governance_legitimacy__democratic_pluralist_reading, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(ai_g_tr_t0, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 0, 0.22).
narrative_ontology:measurement(ai_g_tr_t5, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 5, 0.24).
narrative_ontology:measurement(ai_g_tr_t10, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 10, 0.25).
narrative_ontology:measurement(ai_g_tr_t15, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 15, 0.27).
narrative_ontology:measurement(ai_g_tr_t20, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 20, 0.28).
narrative_ontology:measurement(ai_g_tr_t25, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 25, 0.28).

% Extraction over time
narrative_ontology:measurement(ai_g_be_t0, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 0, 0.35).
narrative_ontology:measurement(ai_g_be_t5, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 5, 0.37).
narrative_ontology:measurement(ai_g_be_t10, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 10, 0.39).
narrative_ontology:measurement(ai_g_be_t15, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 15, 0.41).
narrative_ontology:measurement(ai_g_be_t20, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 20, 0.42).
narrative_ontology:measurement(ai_g_be_t25, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 25, 0.42).

% Suppression requirement over time
narrative_ontology:measurement(ai_g_su_t0, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 0, 0.32).
narrative_ontology:measurement(ai_g_su_t5, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 5, 0.34).
narrative_ontology:measurement(ai_g_su_t10, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 10, 0.36).
narrative_ontology:measurement(ai_g_su_t15, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 15, 0.37).
narrative_ontology:measurement(ai_g_su_t20, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 20, 0.38).
narrative_ontology:measurement(ai_g_su_t25, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 25, 0.38).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(ai_governance_legitimacy__democratic_pluralist_reading, identity_coordination).
narrative_ontology:affects_constraint(ai_governance_legitimacy__democratic_pluralist_reading, magisterial_subsidiarity_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__democratic_pluralist_reading, technocratic_optimization_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__democratic_pluralist_reading, market_libertarian_reading).

% DUAL FORMULATION NOTE:
% This constraint is one of four readings of the ai_governance_legitimacy kernel. All four readings answer the same kernel question (what grounds the authority to govern AI?) but produce different beneficiary/victim structures, different enforcement mechanisms, and different ε values. The readings are linked via network.affects_constraints because their institutional adoption is mutually exclusive: democratic institutions cannot simultaneously ground authority in deliberative consent (this reading), magisterial interpretation (sibling 1), technocratic optimization (sibling 2), and market exchange (sibling 3). The readings coexist as live positions held by competing actors, not as compatible governance layers.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
