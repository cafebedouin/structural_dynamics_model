% ============================================================================
% CONSTRAINT STORY: woman_category__intersex_accommodation_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_woman_category__intersex_accommodation_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: woman_category__intersex_accommodation_reading
 *   human_readable: Woman Category: Intersex Accommodation Reading
 *   domain: political_philosophy/law/social_policy/bioethics
 *
 * SUMMARY:
 *   This constraint instantiates one reading of the contested kernel 'what
 *   does woman mean as a category': the intersex accommodation reading. It
 *   holds that biological sex is not strictly binary and that category
 *   membership should acknowledge natural variations. The reading is grounded
 *   in medical documentation of intersex conditions but becomes extractive at
 *   its edges—particularly in elite sports where performance-relevant
 *   biological differences create competitive asymmetries. The constraint's
 *   extraction is domain-dependent: low in most policy contexts (small
 *   affected population, minimal material redistribution) but substantially
 *   higher in competitive athletics where intersex inclusion redistributes
 *   medals and sponsorships. The theater_ratio rises as advocacy increasingly
 *   frames all boundary-drawing as discrimination rather than addressing the
 *   genuine coordination problem of how to handle performance-relevant
 *   biological diversity in competition.
 *
 * KEY AGENTS:
 *   - people_with_intersex_variations: Primary beneficiaries (powerless/identity_locked) — gain recognition and inclusion
 *   - athletes_with_female_typical_biology: Payers in sports context (moderate/constrained) — bear competitive disadvantage
 *   - intersex_athletes: Dual position (powerless/identity_locked) — benefit from inclusion but pay social cost
 *   - binary_enforcement_regimes: Institutional payers (institutional/mobile) — forced to acknowledge complexity
 *   - inclusive_policy_frameworks: Institutional beneficiaries (institutional/mobile) — gain workable accommodation mechanism
 *   - medical_consensus_bodies: Observers (institutional/analytical) — provide empirical grounding
 *   - feminist_legal_scholars: Observers (organized/analytical) — divided on implications
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(woman_category__intersex_accommodation_reading, 0.42).
domain_priors:suppression_score(woman_category__intersex_accommodation_reading, 0.51).
domain_priors:theater_ratio(woman_category__intersex_accommodation_reading, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, extractiveness, 0.42).
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, suppression_requirement, 0.51).
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, resistance, 0.64).

% --- Constraint claim ---
narrative_ontology:constraint_claim(woman_category__intersex_accommodation_reading, rope).
narrative_ontology:human_readable(woman_category__intersex_accommodation_reading, "Woman Category: Intersex Accommodation Reading").
narrative_ontology:topic_domain(woman_category__intersex_accommodation_reading, "political_philosophy/law/social_policy/bioethics").

domain_priors:requires_active_enforcement(woman_category__intersex_accommodation_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(woman_category__intersex_accommodation_reading, '6573fe18-caad-489f-a8a7-823ee122a55f').
narrative_ontology:cs_kernel_codification('6573fe18-caad-489f-a8a7-823ee122a55f', distributed).
narrative_ontology:cs_authority_grounding('6573fe18-caad-489f-a8a7-823ee122a55f', distributed).
narrative_ontology:cs_reading_relation('6573fe18-caad-489f-a8a7-823ee122a55f', woman_category__sex_biology_reading, influences).
narrative_ontology:cs_reading_relation('6573fe18-caad-489f-a8a7-823ee122a55f', woman_category__gender_identity_reading, coexists_with).
narrative_ontology:cs_axiom('6573fe18-caad-489f-a8a7-823ee122a55f', foundational, sex_is_non_binary_spectrum).
narrative_ontology:cs_axiom_status(sex_is_non_binary_spectrum, holdable).
narrative_ontology:cs_axiom_grounding('6573fe18-caad-489f-a8a7-823ee122a55f', sex_is_non_binary_spectrum, empirically_contingent).
narrative_ontology:cs_axiom('6573fe18-caad-489f-a8a7-823ee122a55f', secondary, intersex_variations_warrant_inclusion).
narrative_ontology:cs_axiom_status(intersex_variations_warrant_inclusion, holdable).
narrative_ontology:cs_axiom_grounding('6573fe18-caad-489f-a8a7-823ee122a55f', intersex_variations_warrant_inclusion, deontological).
narrative_ontology:cs_reference_frame('6573fe18-caad-489f-a8a7-823ee122a55f', binary_sex_classification_baseline).
narrative_ontology:cs_drift_state('6573fe18-caad-489f-a8a7-823ee122a55f', contemporary_intersex_rights_era, gap(axiom_overriding, substantial, false)).
narrative_ontology:cs_created_at('6573fe18-caad-489f-a8a7-823ee122a55f', '').
narrative_ontology:cs_kernel_id(woman_category__intersex_accommodation_reading, woman_category).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(woman_category__intersex_accommodation_reading, people_with_intersex_variations).
narrative_ontology:constraint_beneficiary(woman_category__intersex_accommodation_reading, inclusive_policy_frameworks).
narrative_ontology:constraint_victim(woman_category__intersex_accommodation_reading, athletes_with_female_typical_biology).
narrative_ontology:constraint_victim(woman_category__intersex_accommodation_reading, binary_enforcement_regimes).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_beneficiary(woman_category__intersex_accommodation_reading, intersex_athletes).
narrative_ontology:constraint_victim(woman_category__intersex_accommodation_reading, intersex_athletes).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Have biological sex characteristics that do not fit binary male/female classification. Under this reading they are recognized as a natural variation of the sex spectrum and included in appropriate sex-based categories rather than forced into binary assignment or excluded entirely. Their biology is treated as real rather than pathologized or erased.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, people_with_intersex_variations, beneficiary,
    powerless, biographical, identity_locked, global).

% Compete in women's sports categories that under this reading include some intersex athletes with performance-relevant biological advantages (elevated endogenous testosterone, XY chromosomes with androgen sensitivity variations). They argue the accommodation creates competitive unfairness; their options are accepting the broader category, leaving elite sport, or advocating for subcategories.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, athletes_with_female_typical_biology, payer,
    moderate, biographical, constrained, global).

% Are included in women's sports under this reading rather than excluded or required to suppress their natural testosterone levels. They gain eligibility but carry the social cost of being framed as having unfair advantages, becoming flashpoints in the category-boundary dispute, and facing intense scrutiny of their bodies.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, intersex_athletes, beneficiary,
    powerless, biographical, identity_locked, global).
narrative_ontology:stakeholder_secondary_role(woman_category__intersex_accommodation_reading, intersex_athletes, payer).

% Administrative systems (sports federations, vital statistics agencies, single-sex institutions) built around strict binary sex classification. This reading requires them to create accommodation pathways for intersex variations, which imposes administrative complexity and forces acknowledgment that their founding binary is a simplification rather than a complete map of biological reality.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, binary_enforcement_regimes, payer,
    institutional, generational, mobile, national).

% Legal and policy regimes that adopt spectrum-aware sex classification. They gain a framework that handles intersex variations without erasure or forced assignment, avoiding human rights challenges while maintaining sex-based protections where they remain relevant.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, inclusive_policy_frameworks, beneficiary,
    institutional, generational, mobile, national).

% Document the biological reality that sex development occurs on a spectrum with multiple intersex variations. They provide the empirical grounding for this reading's claims about biological diversity while remaining agnostic about how policy should handle that diversity.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, medical_consensus_bodies, observer,
    institutional, generational, analytical, global).

% Analyze how different category definitions affect sex-based protections and women's material interests. They are divided on this reading: some support it as the only empirically honest framework; others worry it dissolves the category women's rights law was built to protect.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, feminist_legal_scholars, observer,
    organized, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a category definition that handles the empirical reality of intersex variations without forcing binary assignment, enabling policy frameworks to be both inclusive and sex-aware where biological sex remains policy-relevant.
% TRANSFER_FUNCTION: Shifts definitional authority and category inclusion from binary gatekeepers to spectrum-acknowledging frameworks; redistributes competitive opportunities in elite sport by including some intersex athletes in women's categories; imposes administrative complexity costs on binary enforcement regimes.
% ABSENT_VOICES: Detransitioners and women who experienced gender dysphoria but retained female biology are structurally peripheral to this reading's focus on intersex variations, yet they have stakes in how the boundary between sex-based and identity-based category membership is drawn.
% DISAPPEARANCE_RATIONALE: If this reading vanished, intersex people would be forced back into binary assignment or exclusion; sports federations would revert to stricter binary testosterone thresholds; policy frameworks would lose their mechanism for acknowledging biological diversity without abandoning sex-based analysis. Legal and administrative systems built around this accommodation would collapse back to binary enforcement.
% FOUNDING_PROBLEM: Binary sex classification erases or pathologizes people born with intersex variations, forcing them into categories that do not match their biology, excluding them from sex-segregated spaces and competitions entirely, or requiring medical intervention to conform to binary norms.
% FOUNDING_PROBLEM_CORROBORATION: Medical consensus bodies document the persistence of intersex variations and the harms of forced binary assignment. Human rights organizations outside the direct beneficiary group attest that binary erasure remains a live problem in vital statistics, sports eligibility, and access to sex-segregated services.
narrative_ontology:disappearance_verdict(woman_category__intersex_accommodation_reading, world_rearranges).
narrative_ontology:founding_problem_status(woman_category__intersex_accommodation_reading, live).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(woman_category__intersex_accommodation_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(woman_category__intersex_accommodation_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(woman_category__intersex_accommodation_reading_tests).
:- end_tests(woman_category__intersex_accommodation_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is moderate (0.42 at interval end) because the constraint's cost is concentrated in specific domains rather than diffuse. In most policy contexts extraction is negligible—birth certificates, healthcare access, and legal recognition accommodate intersex variations at low administrative cost to others. In elite sports extraction is substantially higher: the inclusion of some intersex athletes with performance advantages redistributes competitive opportunities from athletes with typical female biology, and that redistribution is zero-sum at the podium. Suppression is moderate (0.51) because the reading requires active enforcement against binary classification systems that would otherwise exclude or force assignment, but it does not require suppressing dissent about competitive fairness. Theater_ratio is low-moderate (0.28): the spectrum-of-sex claim is empirically grounded in medical literature, but advocacy increasingly treats any boundary-drawing as discriminatory rather than engaging with the coordination problem of how to handle performance-relevant variation. Accessibility_collapse is moderate-low (0.48): binary sex classification remains a widely available alternative cognitive framework. Resistance is moderate-high (0.64): the reading faces sustained opposition from both strict binary advocates and from athletes who experience competitive disadvantage.
 *
 * PERSPECTIVAL GAP:
 *   From the seat of people with intersex variations, this reading is genuine coordination solving a real problem—they exist, their biology is real, and binary erasure harms them. From the seat of athletes with typical female biology competing against intersex athletes with elevated testosterone, the same structure operates as extraction—their category is redefined in ways that disadvantage them, and their objections are framed as bigotry rather than as legitimate boundary disputes. The engine should compute this divergence from the structural data: low d for intersex beneficiaries, high d for affected athletes in competitive contexts.
 *
 * DIRECTIONALITY LOGIC:
 *   People with intersex variations are structural beneficiaries (gain recognition, d near 0.0). Athletes with female-typical biology in competitive contexts are targets when competing against intersex athletes with performance advantages (d toward 1.0 in that domain). Intersex athletes themselves are dual-positioned: beneficiaries of inclusion but targets of scrutiny and social cost (d near 0.4). Binary enforcement regimes are institutional payers forced to accommodate complexity (d ~0.6). The domain-dependence of extraction is critical: the same intersex person experiences this constraint as near-pure coordination in healthcare access but as substantially extractive in elite sport.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint has a genuine coordination function (acknowledging biological reality, avoiding forced assignment) but that function is entangled with extraction in specific domains. The rising extractiveness and theater_ratio over the measurement interval suggest mandate drift: as advocacy extends the reading from 'accommodate intersex variations' to 'any performance-based boundary in women's sport is discriminatory,' the extraction intensifies without solving new coordination problems. The analysis prevents mislabeling the accommodation as pure extraction (it solves a real problem for intersex people in most domains) while also preventing the cover-story that competitive-fairness objections are mere bigotry (they are responses to real material redistribution in zero-sum competition).
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    performance_advantage_boundary,
    'Where is the legitimate boundary between accommodating natural biological diversity and maintaining competitive fairness in women''s sports?',
    'Empirical: longitudinal performance data comparing intersex athletes with typical-female athletes across different testosterone ranges and chromosomal variations. Policy: stakeholder negotiation among affected athletes, sports medicine, and human rights bodies.',
    'If intersex variations with performance advantages are accommodated without limit, extraction from typical-female athletes intensifies and women''s sport becomes effectively an open category. If all performance-relevant intersex variations are excluded, the reading collapses back to binary enforcement. The boundary question is irreducible because it trades off inclusion against competitive fairness.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(performance_advantage_boundary, preference, 'Where to draw performance-fairness boundaries in intersex accommodation').

omega_variable(
    intersex_prevalence_and_policy_scope,
    'How does the prevalence of intersex variations affect the appropriate scope of policy accommodation?',
    'Empirical: updated epidemiological data on intersex variations disaggregated by type and policy-relevance. Conceptual: normative analysis of whether rare conditions warrant systemic category revision.',
    'If intersex variations are extremely rare (~0.02% for conditions with competitive-sport relevance), the case for revising binary frameworks weakens and targeted individual accommodation becomes preferable. If prevalence is higher or policy should accommodate all natural variation regardless of frequency, broader category revision is justified.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(intersex_prevalence_and_policy_scope, empirical, 'Whether intersex prevalence justifies systemic vs individual accommodation').

omega_variable(
    spectrum_framing_vs_bimodal_distribution,
    'Is biological sex best described as a spectrum or as a bimodal distribution with rare intermediate cases?',
    'Conceptual: analysis of sex-development pathways and statistical distributions. Framing: whether edge cases warrant treating the entire distribution as a spectrum or as a binary with accommodated exceptions.',
    'If sex is framed as spectrum, this reading becomes the empirically necessary framework and binary readings are false simplifications. If sex is bimodal with rare exceptions, binary frameworks remain valid with targeted accommodation for edge cases, and this reading over-reaches by treating exceptions as evidence against the binary itself.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(spectrum_framing_vs_bimodal_distribution, conceptual, 'Whether intersex variations refute binary sex or are exceptions to bimodal distribution').

omega_variable(
    committer_kernel_ambiguity,
    'Is the woman_category kernel a single contested commitment with three readings, or are the readings incommensurable such that they instantiate different kernels?',
    'Analysis of whether the readings share enough structural overlap to count as interpretations of one commitment or whether they are competing commitments that happen to use the same label.',
    'If they share a kernel, the committer frame correctly models the contest as readings-of-a-commitment and the engine can track authority drift and axiom contradictions within one commitment system. If they are separate kernels, the framework over-unifies them and should model them as competing constraints linked by network.affects_constraints rather than as cs_structure siblings.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(committer_kernel_ambiguity, conceptual, 'Whether sibling readings share one kernel or are separate commitments with a shared label').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(woman_category__intersex_accommodation_reading, 0, 20).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(woma_tr_t0, woman_category__intersex_accommodation_reading, theater_ratio, 0, 0.15).
narrative_ontology:measurement(woma_tr_t5, woman_category__intersex_accommodation_reading, theater_ratio, 5, 0.19).
narrative_ontology:measurement(woma_tr_t10, woman_category__intersex_accommodation_reading, theater_ratio, 10, 0.23).
narrative_ontology:measurement(woma_tr_t15, woman_category__intersex_accommodation_reading, theater_ratio, 15, 0.26).
narrative_ontology:measurement(woma_tr_t20, woman_category__intersex_accommodation_reading, theater_ratio, 20, 0.28).

% Extraction over time
narrative_ontology:measurement(woma_be_t0, woman_category__intersex_accommodation_reading, base_extractiveness, 0, 0.22).
narrative_ontology:measurement(woma_be_t5, woman_category__intersex_accommodation_reading, base_extractiveness, 5, 0.28).
narrative_ontology:measurement(woma_be_t10, woman_category__intersex_accommodation_reading, base_extractiveness, 10, 0.35).
narrative_ontology:measurement(woma_be_t15, woman_category__intersex_accommodation_reading, base_extractiveness, 15, 0.39).
narrative_ontology:measurement(woma_be_t20, woman_category__intersex_accommodation_reading, base_extractiveness, 20, 0.42).

% Suppression requirement over time
narrative_ontology:measurement(woma_su_t0, woman_category__intersex_accommodation_reading, suppression_requirement, 0, 0.35).
narrative_ontology:measurement(woma_su_t5, woman_category__intersex_accommodation_reading, suppression_requirement, 5, 0.41).
narrative_ontology:measurement(woma_su_t10, woman_category__intersex_accommodation_reading, suppression_requirement, 10, 0.46).
narrative_ontology:measurement(woma_su_t15, woman_category__intersex_accommodation_reading, suppression_requirement, 15, 0.49).
narrative_ontology:measurement(woma_su_t20, woman_category__intersex_accommodation_reading, suppression_requirement, 20, 0.51).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(woman_category__intersex_accommodation_reading, identity_coordination).
narrative_ontology:affects_constraint(woman_category__intersex_accommodation_reading, woman_category__sex_biology_reading).
narrative_ontology:affects_constraint(woman_category__intersex_accommodation_reading, woman_category__gender_identity_reading).

% DUAL FORMULATION NOTE:
% This constraint is one of three readings of the woman_category kernel. The intersex_accommodation reading holds biological sex is non-binary; sex_biology_reading holds strict binary XX/female-anatomy; gender_identity_reading decouples category from biology entirely. All three readings affect each other through the shared kernel: changes in any reading's authority or adoption alter the others' legitimacy conditions and policy space.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
