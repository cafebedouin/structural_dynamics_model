% ============================================================================
% CONSTRAINT STORY: waitangi_sovereignty_allocation__rangatiratanga_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_waitangi_sovereignty_allocation__rangatiratanga_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: waitangi_sovereignty_allocation__rangatiratanga_reading
 *   human_readable: Waitangi Treaty Rangatiratanga Reading: Māori Retained Full Authority
 *   domain: constitutional_law/indigenous_rights/post_colonial_governance
 *
 * SUMMARY:
 *   The Treaty of Waitangi (1840) was signed in both English and Māori, with
 *   critical differences between the texts. The Māori text uses 'tino
 *   rangatiratanga' (full authority/chieftainship) in Article II, which most
 *   Māori signatories understood as retaining their sovereignty over lands,
 *   forests, fisheries, and other taonga. The English text uses 'full
 *   exclusive and undisturbed possession,' which the Crown later interpreted
 *   as property rights subordinate to Crown sovereignty. This constraint
 *   models the rangatiratanga reading: the constitutional claim that Māori
 *   retained inherent authority and the Crown's kāwanatanga (governorship)
 *   was limited to British settlers. The reading grounds contemporary Māori
 *   claims for co-governance, resource management authority, and
 *   constitutional recognition of divided sovereignty. The constraint is
 *   CLAIMED as mountain (a natural feature of the constitutional order,
 *   emerging from the Treaty text itself) while the authored metrics describe
 *   substantial suppression (high enforcement required to deny it) and rising
 *   resistance (increasing Māori political mobilization around
 *   rangatiratanga). The divergence between claim and metrics is the
 *   measurement: a claimed natural law that requires active denial is exactly
 *   the pattern of a false summit or a suppressed constitutional truth.
 *
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(waitangi_sovereignty_allocation__rangatiratanga_reading, 0.21).
domain_priors:suppression_score(waitangi_sovereignty_allocation__rangatiratanga_reading, 0.73).
domain_priors:theater_ratio(waitangi_sovereignty_allocation__rangatiratanga_reading, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, extractiveness, 0.21).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 0.73).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, accessibility_collapse, 0.68).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, resistance, 0.81).

% --- Constraint claim ---
narrative_ontology:constraint_claim(waitangi_sovereignty_allocation__rangatiratanga_reading, mountain).
narrative_ontology:human_readable(waitangi_sovereignty_allocation__rangatiratanga_reading, "Waitangi Treaty Rangatiratanga Reading: Māori Retained Full Authority").
narrative_ontology:topic_domain(waitangi_sovereignty_allocation__rangatiratanga_reading, "constitutional_law/indigenous_rights/post_colonial_governance").

domain_priors:requires_active_enforcement(waitangi_sovereignty_allocation__rangatiratanga_reading).
domain_priors:emerges_naturally(waitangi_sovereignty_allocation__rangatiratanga_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(waitangi_sovereignty_allocation__rangatiratanga_reading, '62fa8489-d95c-4c62-ae35-6c273e5bf449').
narrative_ontology:cs_kernel_codification('62fa8489-d95c-4c62-ae35-6c273e5bf449', fixed_text).
narrative_ontology:cs_authority_grounding('62fa8489-d95c-4c62-ae35-6c273e5bf449', lineage).
narrative_ontology:cs_interpretation_layer_present('62fa8489-d95c-4c62-ae35-6c273e5bf449').
narrative_ontology:cs_reading_relation('62fa8489-d95c-4c62-ae35-6c273e5bf449', waitangi_sovereignty_allocation__crown_sovereignty_reading, forecloses).
narrative_ontology:cs_reading_relation('62fa8489-d95c-4c62-ae35-6c273e5bf449', waitangi_sovereignty_allocation__partnership_reading, influences).
narrative_ontology:cs_axiom('62fa8489-d95c-4c62-ae35-6c273e5bf449', foundational, tino_rangatiratanga_retained_full_authority).
narrative_ontology:cs_axiom_status(tino_rangatiratanga_retained_full_authority, holdable).
narrative_ontology:cs_axiom_grounding('62fa8489-d95c-4c62-ae35-6c273e5bf449', tino_rangatiratanga_retained_full_authority, conventional).
narrative_ontology:cs_axiom('62fa8489-d95c-4c62-ae35-6c273e5bf449', foundational, kawanatanga_limited_to_settler_governance).
narrative_ontology:cs_axiom_status(kawanatanga_limited_to_settler_governance, holdable).
narrative_ontology:cs_axiom_grounding('62fa8489-d95c-4c62-ae35-6c273e5bf449', kawanatanga_limited_to_settler_governance, conventional).
narrative_ontology:cs_axiom('62fa8489-d95c-4c62-ae35-6c273e5bf449', secondary, maori_text_governs_treaty_interpretation).
narrative_ontology:cs_axiom_status(maori_text_governs_treaty_interpretation, holdable).
narrative_ontology:cs_axiom_grounding('62fa8489-d95c-4c62-ae35-6c273e5bf449', maori_text_governs_treaty_interpretation, conventional).
narrative_ontology:cs_reference_frame('62fa8489-d95c-4c62-ae35-6c273e5bf449', maori_text_article_ii_original_understanding).
narrative_ontology:cs_drift_state('62fa8489-d95c-4c62-ae35-6c273e5bf449', contemporary_post_tribunal_era, gap(revival_pressure, substantial, true)).
narrative_ontology:cs_created_at('62fa8489-d95c-4c62-ae35-6c273e5bf449', '').
narrative_ontology:cs_kernel_id(waitangi_sovereignty_allocation__rangatiratanga_reading, waitangi_sovereignty_allocation).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__rangatiratanga_reading, maori_iwi_hapu).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__rangatiratanga_reading, indigenous_rights_advocates).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__rangatiratanga_reading, crown_sovereignty_apparatus).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__rangatiratanga_reading, settler_governance_structures).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Māori iwi and hapū assert tino rangatiratanga (full authority) over ancestral lands, resources, and taonga as retained in Article II of the Māori text. They maintain that kāwanatanga granted to the Crown was limited governorship over British settlers only, not sovereignty over Māori. This reading grounds claims for co-governance structures, resource management authority, and independent decision-making over tribal affairs. Exit is identity-locked: the claim is constitutive of Māori political identity and relationship to whenua.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, maori_iwi_hapu, beneficiary,
    organized, generational, identity_locked, national).

% The Crown's parliamentary sovereignty claim is fundamentally challenged by this reading. Westminster supremacy doctrine treats Parliament as having unlimited legislative authority; the rangatiratanga reading constrains that authority by recognizing a parallel Māori jurisdiction that Crown law cannot override. The apparatus bears the cost of jurisdictional limitation and co-governance requirements. Exit is constrained rather than trapped: the Crown could theoretically adopt this framework through constitutional reform, but doing so requires dismantling core sovereignty doctrine.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, crown_sovereignty_apparatus, payer,
    institutional, generational, constrained, national).

% Non-Māori governing institutions (local councils, regional authorities, resource management bodies) operate under the assumption of unified Crown sovereignty. The rangatiratanga reading requires power-sharing, co-governance, or ceding authority over resources and lands to iwi/hapū. They bear the cost of jurisdictional uncertainty and institutional restructuring. Many resist through legal challenges and political pressure, arguing for constitutional clarity under Crown sovereignty.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, settler_governance_structures, payer,
    powerful, biographical, constrained, national).

% International indigenous rights movements and legal scholars cite the rangatiratanga reading as exemplifying UN Declaration on Rights of Indigenous Peoples principles: indigenous self-determination, free prior informed consent, and cultural sovereignty. They benefit from the precedent it sets for treaty interpretation favoring indigenous-language texts and challenging settler sovereignty claims. Mobile exit: their commitment is ideological rather than identity-constitutive.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, indigenous_rights_advocates, beneficiary,
    moderate, generational, mobile, global).

% The Waitangi Tribunal adjudicates Treaty claims and has increasingly endorsed rangatiratanga principles in its findings, though its recommendations are not binding on Parliament. It hears evidence from all parties, commissions historical and linguistic analysis, and produces reports that shape public discourse without directly constraining Crown legislative authority. Analytical seat: interprets the constraint without being bound by any particular reading.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, waitangi_tribunal, observer,
    institutional, generational, analytical, national).

% New Zealand's legal profession and judiciary are divided on the constitutional status of the Treaty and which textual reading should govern. Some judges incorporate Treaty principles into common law; others defer to parliamentary sovereignty. The establishment observes competing constitutional visions without consensus, producing case law that reflects the ongoing contest rather than resolving it.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__rangatiratanga_reading, constitutional_legal_establishment, observer,
    institutional, generational, analytical, national).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes the foundational allocation of authority between Crown and Māori: who has jurisdiction over whom, what lands, what resources. Solves the coordination problem of multiple sovereignties sharing territory by defining bounded spheres of authority.
% TRANSFER_FUNCTION: Transfers recognition of legitimate authority from a unified Crown sovereignty model to a divided sovereignty framework where Māori retain tino rangatiratanga. The Crown's claim to govern Māori affairs without consent is structurally challenged; resources and decision-making authority over traditional territories flow back toward iwi/hapū.
% ABSENT_VOICES: The Treaty was negotiated and signed in 1840 with some iwi but not all; many Māori never ceded sovereignty and were later subjected to Crown authority through confiscation and force. Their descendants carry the structural exclusion from the original compact. Additionally, contemporary Māori who live outside traditional iwi/hapū structures or who hold different views on sovereignty are underrepresented in formal Treaty discourse, which centers iwi leadership.
% DISAPPEARANCE_RATIONALE: If this reading vanished—if tino rangatiratanga ceased to be a live constitutional claim—Māori authority over lands and resources would collapse entirely into Crown jurisdiction. Co-governance structures would lose their Treaty foundation, resource claims would be resolved under Crown law alone, and the post-colonial constitutional order would revert to unitary Westminster sovereignty. Conversely, if the rangatiratanga reading became universally accepted, Crown sovereignty would be bounded and New Zealand's governance would fundamentally restructure around dual authority.
% FOUNDING_PROBLEM: In 1840, Māori chiefs and the British Crown faced the problem of establishing peaceful coexistence and legitimate governance in Aotearoa. British settlers were arriving in increasing numbers with no clear legal framework; inter-tribal conflict and settler lawlessness threatened stability. The Treaty was presented as a compact to establish order: Crown governorship over settlers, Māori retention of authority over their own affairs and lands.
% FOUNDING_PROBLEM_CORROBORATION: Māori signatories and their descendants attest that the founding problem—establishing peaceful shared governance while protecting Māori authority—remains unresolved because the Crown breached the Treaty through land confiscation and unilateral sovereignty assertion. The Crown attests the founding problem is resolved: governance is unified under parliamentary sovereignty and Māori interests are protected through Treaty principles incorporated into statute. The Waitangi Tribunal's historical reports (produced by historians outside the direct beneficiary set) corroborate that the Māori-text reading of Article II was the version most signatories understood, but also document that Crown practice immediately diverged from that understanding, treating the Treaty as ceding full sovereignty.
narrative_ontology:disappearance_verdict(waitangi_sovereignty_allocation__rangatiratanga_reading, world_rearranges).
narrative_ontology:founding_problem_status(waitangi_sovereignty_allocation__rangatiratanga_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(waitangi_sovereignty_allocation__rangatiratanga_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(waitangi_sovereignty_allocation__rangatiratanga_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(waitangi_sovereignty_allocation__rangatiratanga_reading_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, ExtMetricName, E),
    domain_priors:suppression_score(waitangi_sovereignty_allocation__rangatiratanga_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(waitangi_sovereignty_allocation__rangatiratanga_reading),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__rangatiratanga_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(waitangi_sovereignty_allocation__rangatiratanga_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is low (0.21) because the reading itself does not extract—it BLOCKS extraction by limiting Crown jurisdiction. The extraction measured here is the cost imposed on Māori by the reading's non-recognition: resources and authority that would flow to iwi/hapū under this reading instead flow to Crown agencies. Suppression is high (0.73, declining slightly over the interval) because maintaining Crown sovereignty against the rangatiratanga claim requires continuous legal, political, and institutional denial—Treaty Tribunal recommendations are ignored, co-governance proposals are resisted, and the constitutional order treats parliamentary sovereignty as unchallengeable despite the Māori text. Theater is moderate-to-high initially (0.65) and declining (0.42 at interval end): early Treaty commemorations and Crown rhetoric acknowledged Māori as Treaty partners while denying substantive sovereignty; over time, co-governance structures, Treaty settlements, and Māori-language revitalization have made the rangatiratanga reading more operationally real and less merely symbolic. The theater decline reflects the reading moving from performative acknowledgment to structural implementation. Accessibility collapse is moderate-high (0.68): once you understand the Māori text and the principle of interpreting treaties in favor of indigenous understanding, the rangatiratanga reading becomes compelling and alternatives appear as bad faith. Resistance is very high (0.81): Māori political movements, legal challenges, protests, and iwi assertions of authority actively contest Crown sovereignty claims.
 *
 * PERSPECTIVAL GAP:
 *   From the Māori beneficiary seat, this reading is the natural and correct interpretation of the Treaty they signed—tino rangatiratanga meant what it said, and the English text's divergence is the Crown's problem, not theirs. The constraint should barely register as a constraint at all; it is simply the constitutional truth suppressed by colonial power. From the Crown apparatus seat, the reading operates as a destabilizing challenge to the foundational constitutional settlement—it calls into question 180 years of parliamentary sovereignty and threatens the legal stability of every statute, every land title, and every governance structure. The engine should compute the Māori seat as experiencing low-to-negligible extraction (the reading itself does not extract from them; its denial does) and the Crown seat as experiencing the reading as highly extractive (it constrains their authority). The Waitangi Tribunal observes both positions and produces recommendations that increasingly favor the rangatiratanga reading, but lacks binding authority to resolve the contest.
 *
 * DIRECTIONALITY LOGIC:
 *   Māori iwi and hapū are structural beneficiaries: the reading recognizes their inherent authority and constrains Crown jurisdiction over them—low directionality, subsidy-side. The Crown sovereignty apparatus and settler governance structures are targets: the reading limits their jurisdiction and requires power-sharing—high directionality, extraction-side. Indigenous rights advocates benefit incidentally without being the primary rights-holders—low-to-moderate directionality. The Waitangi Tribunal and legal establishment are analytical observers.
 *
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    textual_authority_ambiguity,
    'When two treaty texts signed simultaneously differ on the core question of sovereignty, which text governs? The English text or the Māori text that most signatories understood?',
    'International treaty law (Vienna Convention) and indigenous rights doctrine both establish that treaties should be interpreted in the language the indigenous party understood and in favor of indigenous rights when ambiguous. New Zealand courts have not definitively adopted this principle for the Treaty''s constitutional status. Resolution would require either binding judicial declaration or constitutional convention adopting the Māori text as authoritative.',
    'If the Māori text is held authoritative, the rangatiratanga reading becomes the correct constitutional interpretation and Crown sovereignty doctrine is fundamentally constrained. If the English text governs, the Crown sovereignty reading holds and rangatiratanga becomes a moral claim without constitutional force. If both texts are held equally authoritative, the partnership reading—navigating between them—gains structural support.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(textual_authority_ambiguity, conceptual, 'Which treaty text has constitutional authority when they conflict').

omega_variable(
    natural_law_or_constructed_claim,
    'Is the rangatiratanga reading a natural feature of the constitutional order—an inherent truth that emerges from the Treaty text and Māori tikanga—or is it a constructed political claim advanced by Māori movements in response to colonization?',
    'This omega cannot be fully resolved because it depends on whether constitutional meaning is discovered (natural law originalism) or constructed (political contestation). However, historical and linguistic evidence can establish what the Māori signatories understood in 1840, which grounds the reading''s claim to be the original constitutional settlement even if not a timeless natural law.',
    'If the reading is treated as natural law—the true constitutional meaning waiting to be recognized—then the Crown''s sovereignty doctrine is a 180-year error that should be corrected. If the reading is treated as constructed—a legitimate but historically contingent political project—then the constitutional order can accommodate it through negotiated power-sharing without delegitimizing the Crown''s historical sovereignty. The former framing supports stronger Māori authority claims; the latter supports incremental co-governance.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(natural_law_or_constructed_claim, conceptual, 'Whether rangatiratanga is discovered constitutional truth or constructed political claim').

omega_variable(
    sovereignty_divisibility,
    'Can sovereignty be divided between two authorities sharing territory, or is sovereignty by definition unitary and exclusive?',
    'Comparative constitutional analysis of federations, indigenous self-government arrangements (Canada, US, Australia), and historical examples of shared sovereignty (Holy Roman Empire, condominium arrangements). Legal theorists are divided; the question is partly empirical (can it work?) and partly conceptual (what does ''sovereignty'' mean?).',
    'If sovereignty is divisible, the rangatiratanga and crown_sovereignty readings can both be partially true: Māori have sovereignty over some domains, Crown over others. If sovereignty is indivisible, one reading must give way to the other, or the partnership reading must reframe the relationship as non-sovereign (Treaty partnership, fiduciary duty) rather than dual sovereignty.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(sovereignty_divisibility, conceptual, 'Whether sovereignty can be structurally divided or is necessarily unitary').

omega_variable(
    beneficiary_capture_of_natural_law_claim,
    'Does the rangatiratanga reading''s structural benefit to Māori indicate it is a constructed claim serving their interests, rather than a neutral constitutional interpretation? Or is the benefit incidental to the reading being correct?',
    'Distinguish between readings that happen to benefit a party and readings that were constructed to benefit them. Historical evidence shows the rangatiratanga reading predates modern Māori political movements—it was the understanding of signatories in 1840, documented by missionaries and early colonial observers. The reading benefits Māori because it is the Treaty they signed, not because it was invented to benefit them later. However, the reading''s contemporary political salience is inseparable from Māori resistance to colonization.',
    'If the reading is dismissed as self-serving, its constitutional claim weakens—it becomes one political position among many. If the reading is recognized as historically grounded despite benefiting Māori, it has stronger constitutional legitimacy—the Crown''s divergence from it becomes the problem, not Māori''s assertion of it.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(beneficiary_capture_of_natural_law_claim, empirical, 'Whether Māori benefit from the reading indicates it is constructed or incidental to its correctness').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(waitangi_sovereignty_allocation__rangatiratanga_reading, 0, 180).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(wait_tr_t0, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 0, 0.65).
narrative_ontology:measurement_basis(wait_tr_t0, observed).
narrative_ontology:measurement(wait_tr_t30, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 30, 0.62).
narrative_ontology:measurement_basis(wait_tr_t30, observed).
narrative_ontology:measurement(wait_tr_t60, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 60, 0.58).
narrative_ontology:measurement_basis(wait_tr_t60, observed).
narrative_ontology:measurement(wait_tr_t90, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 90, 0.52).
narrative_ontology:measurement_basis(wait_tr_t90, observed).
narrative_ontology:measurement(wait_tr_t120, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 120, 0.47).
narrative_ontology:measurement_basis(wait_tr_t120, observed).
narrative_ontology:measurement(wait_tr_t150, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 150, 0.44).
narrative_ontology:measurement_basis(wait_tr_t150, observed).
narrative_ontology:measurement(wait_tr_t180, waitangi_sovereignty_allocation__rangatiratanga_reading, theater_ratio, 180, 0.42).
narrative_ontology:measurement_basis(wait_tr_t180, observed).

% Extraction over time
narrative_ontology:measurement(wait_be_t0, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 0, 0.15).
narrative_ontology:measurement_basis(wait_be_t0, observed).
narrative_ontology:measurement(wait_be_t30, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 30, 0.16).
narrative_ontology:measurement_basis(wait_be_t30, observed).
narrative_ontology:measurement(wait_be_t60, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 60, 0.17).
narrative_ontology:measurement_basis(wait_be_t60, observed).
narrative_ontology:measurement(wait_be_t90, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 90, 0.18).
narrative_ontology:measurement_basis(wait_be_t90, observed).
narrative_ontology:measurement(wait_be_t120, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 120, 0.19).
narrative_ontology:measurement_basis(wait_be_t120, observed).
narrative_ontology:measurement(wait_be_t150, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 150, 0.2).
narrative_ontology:measurement_basis(wait_be_t150, observed).
narrative_ontology:measurement(wait_be_t180, waitangi_sovereignty_allocation__rangatiratanga_reading, base_extractiveness, 180, 0.21).
narrative_ontology:measurement_basis(wait_be_t180, observed).

% Suppression requirement over time
narrative_ontology:measurement(wait_su_t0, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 0, 0.85).
narrative_ontology:measurement_basis(wait_su_t0, observed).
narrative_ontology:measurement(wait_su_t30, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 30, 0.83).
narrative_ontology:measurement_basis(wait_su_t30, observed).
narrative_ontology:measurement(wait_su_t60, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 60, 0.81).
narrative_ontology:measurement_basis(wait_su_t60, observed).
narrative_ontology:measurement(wait_su_t90, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 90, 0.79).
narrative_ontology:measurement_basis(wait_su_t90, observed).
narrative_ontology:measurement(wait_su_t120, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 120, 0.77).
narrative_ontology:measurement_basis(wait_su_t120, observed).
narrative_ontology:measurement(wait_su_t150, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 150, 0.75).
narrative_ontology:measurement_basis(wait_su_t150, observed).
narrative_ontology:measurement(wait_su_t180, waitangi_sovereignty_allocation__rangatiratanga_reading, suppression_requirement, 180, 0.73).
narrative_ontology:measurement_basis(wait_su_t180, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(waitangi_sovereignty_allocation__rangatiratanga_reading, identity_coordination).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__rangatiratanga_reading, waitangi_sovereignty_allocation__crown_sovereignty_reading).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__rangatiratanga_reading, waitangi_sovereignty_allocation__partnership_reading).

% DUAL FORMULATION NOTE:
% This constraint is part of the waitangi_sovereignty_allocation constraint family, which decomposes the Treaty of Waitangi's contested sovereignty allocation into three distinct readings. The rangatiratanga_reading (this constraint) asserts divided sovereignty with Māori retaining tino rangatiratanga; the crown_sovereignty_reading asserts unified Crown sovereignty; the partnership_reading navigates between them by treating the Treaty as establishing an ongoing partnership obligation. All three readings are live positions in New Zealand constitutional discourse; none has definitively won. The ε values differ substantially because the same textual and institutional structure extracts differently depending on which reading governs: rangatiratanga_reading constrains Crown authority (low extraction from Māori, high suppression by Crown); crown_sovereignty_reading affirms Crown authority (high extraction from Māori, low suppression by Crown); partnership_reading requires negotiation and consultation (moderate extraction, moderate suppression). Network edges flow from this reading to both siblings because the rangatiratanga claim—if accepted—would structurally constrain both the Crown sovereignty doctrine and the partnership framework's scope.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
