% ============================================================================
% CONSTRAINT STORY: ai_governance_legitimacy__market_libertarian_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_ai_governance_legitimacy__market_libertarian_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: ai_governance_legitimacy__market_libertarian_reading
 *   human_readable: Market Libertarian AI Governance Legitimacy Reading
 *   domain: theological_ethics/technology_governance/political_theology
 *
 * SUMMARY:
 *   This constraint is one reading of the contested kernel
 *   'ai_governance_legitimacy' — the question of which principles
 *   legitimately govern AI development and whose authority interprets those
 *   principles. The market libertarian reading asserts property rights and
 *   voluntary exchange as pre-political foundations, treating collective
 *   mandates (including the encyclical's solidarity demands) as illegitimate
 *   coercion. Siblings: the magisterial reading subordinates economic freedom
 *   to Catholic Social Doctrine; the technocratic reading treats ethical
 *   constraints as optimization parameters; the democratic pluralist reading
 *   grounds legitimacy in inclusive public reason. This reading claims
 *   mountain status (property rights as natural law) while the structural
 *   data shows identifiable beneficiaries and victims — the claim/metric gap
 *   is the measurement the corpus exists to take.
 *
 * KEY AGENTS:
 *   - tech_entrepreneurs: Primary beneficiary (powerful/arbitrage) — collect innovation returns under minimal constraint
 *   - venture_investors: Primary beneficiary (powerful/arbitrage) — capital gains compound when regulation is minimal
 *   - high_autonomy_professionals: Beneficiary (powerful/mobile) — bargaining power protects them; benefit from rapid AI deployment
 *   - precarious_workers: Primary victim (powerless/trapped) — bear adjustment costs without compensating gains
 *   - coordination_dependent_communities: Primary victim (powerless/trapped) — externalities and displacement with no mechanism for redress
 *   - monopsony_labor_markets: Victim (powerless/constrained) — structural asymmetry means 'voluntary exchange' operates as extraction
 *   - catholic_social_teaching_adherents: Excluded voice (organized/analytical) — their normative framework is ruled inadmissible by this reading's axioms
 *   - regulatory_institutions: Observer (institutional/analytical) — adjudicate competing legitimacy claims
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(ai_governance_legitimacy__market_libertarian_reading, 0.28).
domain_priors:suppression_score(ai_governance_legitimacy__market_libertarian_reading, 0.32).
domain_priors:theater_ratio(ai_governance_legitimacy__market_libertarian_reading, 0.15).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, extractiveness, 0.28).
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 0.32).
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 0.15).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, accessibility_collapse, 0.72).
narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, resistance, 0.58).

% --- Constraint claim ---
narrative_ontology:constraint_claim(ai_governance_legitimacy__market_libertarian_reading, mountain).
narrative_ontology:human_readable(ai_governance_legitimacy__market_libertarian_reading, "Market Libertarian AI Governance Legitimacy Reading").
narrative_ontology:topic_domain(ai_governance_legitimacy__market_libertarian_reading, "theological_ethics/technology_governance/political_theology").

domain_priors:emerges_naturally(ai_governance_legitimacy__market_libertarian_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(ai_governance_legitimacy__market_libertarian_reading, '51b62068-dc26-4630-b14f-1e3d6c50c9e1').
narrative_ontology:cs_kernel_codification('51b62068-dc26-4630-b14f-1e3d6c50c9e1', distributed).
narrative_ontology:cs_authority_grounding('51b62068-dc26-4630-b14f-1e3d6c50c9e1', distributed).
narrative_ontology:cs_reading_relation('51b62068-dc26-4630-b14f-1e3d6c50c9e1', ai_governance_legitimacy__magisterial_subsidiarity_reading, forecloses).
narrative_ontology:cs_reading_relation('51b62068-dc26-4630-b14f-1e3d6c50c9e1', ai_governance_legitimacy__technocratic_optimization_reading, coexists_with).
narrative_ontology:cs_reading_relation('51b62068-dc26-4630-b14f-1e3d6c50c9e1', ai_governance_legitimacy__democratic_pluralist_reading, coexists_with).
narrative_ontology:cs_axiom('51b62068-dc26-4630-b14f-1e3d6c50c9e1', foundational, property_rights_prepolitical_foundation).
narrative_ontology:cs_axiom_status(property_rights_prepolitical_foundation, holdable).
narrative_ontology:cs_axiom_grounding('51b62068-dc26-4630-b14f-1e3d6c50c9e1', property_rights_prepolitical_foundation, deontological).
narrative_ontology:cs_axiom('51b62068-dc26-4630-b14f-1e3d6c50c9e1', foundational, solidarity_demands_constitute_coercion).
narrative_ontology:cs_axiom_status(solidarity_demands_constitute_coercion, holdable).
narrative_ontology:cs_axiom_grounding('51b62068-dc26-4630-b14f-1e3d6c50c9e1', solidarity_demands_constitute_coercion, deontological).
narrative_ontology:cs_axiom('51b62068-dc26-4630-b14f-1e3d6c50c9e1', secondary, voluntary_exchange_sufficient_legitimacy).
narrative_ontology:cs_axiom_status(voluntary_exchange_sufficient_legitimacy, holdable).
narrative_ontology:cs_axiom_grounding('51b62068-dc26-4630-b14f-1e3d6c50c9e1', voluntary_exchange_sufficient_legitimacy, conventional).
narrative_ontology:cs_reference_frame('51b62068-dc26-4630-b14f-1e3d6c50c9e1', lockean_property_framework).
narrative_ontology:cs_drift_state('51b62068-dc26-4630-b14f-1e3d6c50c9e1', contemporary_stakeholder_capitalism_era, gap(repudiation_pressure, substantial, false)).
narrative_ontology:cs_created_at('51b62068-dc26-4630-b14f-1e3d6c50c9e1', '').
narrative_ontology:cs_kernel_id(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__market_libertarian_reading, tech_entrepreneurs).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__market_libertarian_reading, venture_investors).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__market_libertarian_reading, high_autonomy_professionals).
narrative_ontology:constraint_victim(ai_governance_legitimacy__market_libertarian_reading, precarious_workers).
narrative_ontology:constraint_victim(ai_governance_legitimacy__market_libertarian_reading, coordination_dependent_communities).
narrative_ontology:constraint_victim(ai_governance_legitimacy__market_libertarian_reading, monopsony_labor_markets).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Build AI systems within a framework that treats property rights and voluntary exchange as foundational. Operate with minimal regulatory overhead, choosing jurisdictions and contracting structures that maximize innovation speed. Face competition but minimal collective constraint on their design choices. Exit to alternative jurisdictions or pivot to alternative technologies when local conditions become unfavorable.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, tech_entrepreneurs, beneficiary,
    powerful, biographical, arbitrage, global).

% Allocate capital to AI ventures under governance structures that prioritize contract enforcement and property security over collective mandates. Portfolio diversification and jurisdictional arbitrage insulate them from localized regulatory risk. Gains compound when innovation is rapid and unencumbered; losses are limited by exit options and contractual protections.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, venture_investors, beneficiary,
    powerful, biographical, arbitrage, global).

% Skilled workers with scarce expertise and high bargaining power. Contract directly with employers or platforms under terms they negotiate individually. Benefit from rapid AI deployment that increases demand for their skills. Exit to competitors or alternative markets when terms deteriorate. Experience the constraint as protection of their individual agency against collective mandates.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, high_autonomy_professionals, beneficiary,
    powerful, biographical, mobile, global).

% Workers whose labor is substitutable or facing automation pressure. Lack the bargaining power to negotiate favorable terms individually. Depend on collective action or regulation to secure dignified working conditions, but this reading treats such interventions as illegitimate coercion. Experience rapid AI deployment as destabilization without compensating gains. Exit options are nominal: alternative employers face the same pressures, and retraining is costly and uncertain.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, precarious_workers, payer,
    powerless, immediate, trapped, national).

% Communities whose well-being depends on solving collective-action problems that market mechanisms alone do not address: environmental externalities from AI infrastructure, loss of local industries to automation, erosion of social cohesion when economic displacement is rapid. This reading provides no mechanism for addressing these harms except individual exit, which is structurally infeasible for place-bound communities. The constraint's operation systematically privileges mobile capital over rooted populations.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, coordination_dependent_communities, payer,
    powerless, generational, trapped, local).

% Workers in regions dominated by one or few major employers deploying AI systems. Theoretical exit options exist but are costly: relocation, occupational switching, accepting lower wages elsewhere. In practice, the dominant employer sets terms unilaterally. This reading treats the employment relationship as voluntary exchange, but the structural asymmetry means workers bear adjustment costs while employers capture productivity gains. Resistance is suppressed by the threat of replacement or relocation.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, monopsony_labor_markets, payer,
    powerless, biographical, constrained, regional).

% Hold that economic freedom must be subordinated to common good as defined through solidarity, subsidiarity, and the universal destination of goods. This reading excludes them from the legitimacy conversation by treating their framework as category error: solidarity demands are reframed as coercion, common-good appeals as attempts to violate property rights. Their voice is structurally inadmissible because the reading's axioms foreclose the normative authority they claim.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, catholic_social_teaching_adherents, excluded,
    organized, civilizational, analytical, global).

% Governments and international bodies tasked with AI governance. Observe the distributional consequences of minimal-regulation regimes, the accumulation of power in private hands, and the coordination failures market mechanisms leave unaddressed. Must adjudicate competing legitimacy claims: property rights as foundational versus collective mandates as legitimate expressions of democratic authority. Their decisions shape which reading prevails in practice.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__market_libertarian_reading, regulatory_institutions, observer,
    institutional, generational, analytical, national).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes property rights and contract enforcement as the foundational mechanism for organizing AI development and deployment. Solves the problem of allocating scarce resources and incentivizing innovation by treating market exchange as the legitimate coordinating process.
% TRANSFER_FUNCTION: Moves returns from AI innovation to those who own the systems, hold the intellectual property, and possess scarce complementary skills. Diffuses adjustment costs and externalities to those without exit options or bargaining power.
% ABSENT_VOICES: Catholic social teaching adherents, labor organizers, and place-bound communities are structurally excluded. They would argue for collective oversight, mandatory sharing of gains, and protection of the vulnerable, but this reading treats such interventions as illegitimate interference with voluntary exchange.
% DISAPPEARANCE_RATIONALE: If this reading's axioms disappeared overnight, AI governance would reorganize around different legitimacy principles. Governments would assert collective oversight authority, labor would demand participation in governance structures, and distributional questions currently treated as outside the scope of legitimate political action would become central. Investment patterns would shift, innovation trajectories would change, and the distribution of AI's gains and costs would be contested through democratic processes rather than market outcomes.
% FOUNDING_PROBLEM: Pre-political chaos in AI development: no clear property rights over training data or model weights, no predictable contract enforcement for AI services, no mechanism to incentivize long-term investment without fear of arbitrary state appropriation. Market actors needed stable rules to coordinate investment and innovation.
% FOUNDING_PROBLEM_CORROBORATION: Tech entrepreneurs and investors attest the problem is live: they cite regulatory uncertainty and state intervention as ongoing threats to innovation. Legal scholars and political theologians outside the beneficiary set attest the founding problem was never primarily about property clarity but about who holds legitimate authority to set AI governance principles; the property-rights framing is itself a contested claim, not a discovered natural fact.
narrative_ontology:disappearance_verdict(ai_governance_legitimacy__market_libertarian_reading, world_rearranges).
narrative_ontology:founding_problem_status(ai_governance_legitimacy__market_libertarian_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(ai_governance_legitimacy__market_libertarian_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(ai_governance_legitimacy__market_libertarian_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(ai_governance_legitimacy__market_libertarian_reading_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, ExtMetricName, E),
    domain_priors:suppression_score(ai_governance_legitimacy__market_libertarian_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(ai_governance_legitimacy__market_libertarian_reading),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__market_libertarian_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(ai_governance_legitimacy__market_libertarian_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is low-moderate (0.28) because the constraint genuinely coordinates investment and innovation through property rights, but the coordination benefits accrue asymmetrically: entrepreneurs and investors capture productivity gains while precarious workers and place-bound communities bear uncompensated adjustment costs. Suppression is low-moderate (0.32) because enforcement is primarily reputational and contractual rather than coercive state power, but the suppression operates at the level of foreclosing alternative legitimacy claims: solidarity-based governance is treated as category error, not as a competing legitimate framework. Theater is low (0.15): the property-rights apparatus is functional, not performative. Accessibility collapse is high (0.72) because once you accept property rights as foundational, alternative legitimacy principles become structurally inadmissible. Resistance is moderate-high (0.58) because labor, religious institutions, and democratic movements actively contest the reading's axioms. The measurements show modest accumulation over the interval as distributional asymmetries compound.
 *
 * PERSPECTIVAL GAP:
 *   The beneficiary seats and victim seats will compute radically different types. From the entrepreneur/investor position, the constraint is genuine coordination enabling innovation; from the precarious-worker or place-bound-community position, it operates as extraction masquerading as natural law. The engine computes this divergence from the structural data. The reading claims mountain status (property rights as pre-political), but the presence of identifiable beneficiaries and asymmetric exit options flags it for false-summit evaluation. The omega variables document the irreducible uncertainties: whether property rights are discovered natural facts or constructed institutional choices, and whether the coordination function is separable from the distributional asymmetry.
 *
 * DIRECTIONALITY LOGIC:
 *   Tech entrepreneurs, investors, and high-autonomy professionals are structural beneficiaries: the constraint protects their returns and agency (d near the beneficiary end). Precarious workers, coordination-dependent communities, and monopsony labor markets are structural victims: they bear costs without compensating gains and lack exit options (d near the target end). Catholic social teaching adherents are excluded rather than coordinated: their legitimacy framework is foreclosed by the reading's axioms. Regulatory institutions sit at the analytical position, observing the distributional consequences and adjudicating legitimacy claims.
 *
 * MANDATROPHY ANALYSIS:
 *   The founding problem (pre-political chaos requiring property clarity) is contested: beneficiaries attest it remains live, while external observers attest the property-rights framing is itself a contested normative claim. The disappearance verdict is 'world_rearranges' because AI governance would reorganize around different legitimacy principles if this reading lost authoritative status. The R5 mismatch (contested founding problem + world-rearranges verdict) signals potential capture: the arrangement persists by foreclosing alternative legitimacy frameworks, not because the founding problem remains unresolved. The classification challenge is precisely that the reading presents distributional choices as natural law: solidarity demands are reframed as coercion, common-good appeals as property violations. The framework's job is to measure where that naturalization claim sits relative to the structural asymmetries.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    property_rights_naturality,
    'Are property rights in AI systems pre-political natural facts (as this reading claims), or are they constructed institutional choices that can be legitimately revised through collective decision-making?',
    'Historical and comparative analysis of property regimes: if property rules vary across jurisdictions and eras in response to collective decisions about distributive justice, they are constructed. If they persist invariantly regardless of institutional structure, they are natural. Philosophical analysis of whether ''voluntary exchange'' is meaningful when exit options are structurally asymmetric.',
    'If property rights are constructed, the reading''s mountain claim collapses and it reclassifies as a tangled_rope or snare — genuine coordination function layered with asymmetric extraction. If they are natural, the asymmetric distribution is a fact about reality rather than an extractive design choice.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(property_rights_naturality, conceptual, 'Whether property rights in AI are natural law or constructed institutional choice').

omega_variable(
    coordination_distribution_separability,
    'Is the coordination function (property clarity enabling investment) structurally separable from the distributional asymmetry (gains to capital, costs to labor), or are they necessarily coupled in this governance structure?',
    'Comparative analysis of alternative governance regimes: if jurisdictions achieve similar innovation rates with different distributional outcomes (e.g., mandatory profit-sharing, labor participation in governance), the functions are separable. If all attempts to redistribute gains reduce innovation, they are coupled.',
    'If separable, the measured extraction is avoidable and the constraint is a policy choice masquerading as natural law. If inseparable, part of the extraction is the inherent cost of the coordination itself, supporting the reading''s claim that solidarity demands would destroy the coordination function.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(coordination_distribution_separability, empirical, 'Whether coordination and extraction are structurally separable in this governance regime').

omega_variable(
    exit_voluntariness_threshold,
    'At what level of structural asymmetry does ''voluntary exchange'' cease to be meaningfully voluntary? When does the absence of exit options transform a market relationship into extraction?',
    'Philosophical analysis of consent under constraint, informed by empirical data on labor mobility, relocation costs, and monopsony power. Cross-disciplinary integration of economic theory (exit costs, bargaining power) and ethical theory (meaningful consent, structural coercion).',
    'If structural asymmetry above a threshold invalidates claims of voluntariness, many relationships this reading treats as legitimate exchange reclassify as coercive extraction. If voluntariness is binary (any exit option suffices), the reading''s framing holds. The threshold question determines whether the constraint''s victim set is a design bug or a category error in the observer''s framing.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(exit_voluntariness_threshold, conceptual, 'Threshold at which structural asymmetry invalidates voluntariness claims').

omega_variable(
    solidarity_coercion_boundary,
    'Are the encyclical''s solidarity demands illegitimate coercion (as this reading claims), or are they legitimate expressions of collective authority over economic structures that affect the common good?',
    'Theological and political-philosophical analysis of the grounds for collective authority: whether common-good claims can override property rights, and under what conditions. Comparative analysis of jurisdictions that enforce solidarity-based constraints versus minimal-regulation regimes.',
    'If solidarity demands are legitimate, this reading is a false summit — a constructed constraint claiming natural-law status to foreclose democratic contestation. If they are coercive, the reading''s axioms hold and the encyclical''s framework is the one making category errors. The boundary question determines which reading''s legitimacy framework is authoritative.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(solidarity_coercion_boundary, preference, 'Whether solidarity demands are legitimate collective authority or illegitimate coercion').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(ai_governance_legitimacy__market_libertarian_reading, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(ai_g_tr_t0, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 0, 0.1).
narrative_ontology:measurement(ai_g_tr_t5, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 5, 0.11).
narrative_ontology:measurement(ai_g_tr_t10, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 10, 0.12).
narrative_ontology:measurement(ai_g_tr_t15, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 15, 0.13).
narrative_ontology:measurement(ai_g_tr_t20, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 20, 0.14).
narrative_ontology:measurement(ai_g_tr_t25, ai_governance_legitimacy__market_libertarian_reading, theater_ratio, 25, 0.15).

% Extraction over time
narrative_ontology:measurement(ai_g_be_t0, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 0, 0.18).
narrative_ontology:measurement(ai_g_be_t5, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 5, 0.21).
narrative_ontology:measurement(ai_g_be_t10, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 10, 0.24).
narrative_ontology:measurement(ai_g_be_t15, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 15, 0.26).
narrative_ontology:measurement(ai_g_be_t20, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 20, 0.27).
narrative_ontology:measurement(ai_g_be_t25, ai_governance_legitimacy__market_libertarian_reading, base_extractiveness, 25, 0.28).

% Suppression requirement over time
narrative_ontology:measurement(ai_g_su_t0, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 0, 0.25).
narrative_ontology:measurement(ai_g_su_t5, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 5, 0.27).
narrative_ontology:measurement(ai_g_su_t10, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 10, 0.29).
narrative_ontology:measurement(ai_g_su_t15, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 15, 0.3).
narrative_ontology:measurement(ai_g_su_t20, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 20, 0.31).
narrative_ontology:measurement(ai_g_su_t25, ai_governance_legitimacy__market_libertarian_reading, suppression_requirement, 25, 0.32).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(ai_governance_legitimacy__market_libertarian_reading, resource_allocation).
narrative_ontology:affects_constraint(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy__magisterial_subsidiarity_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy__technocratic_optimization_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__market_libertarian_reading, ai_governance_legitimacy__democratic_pluralist_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the ai_governance_legitimacy kernel. All four readings share the same base question (what grounds AI governance legitimacy) but decompose into distinct constraints because they assert different axioms about property rights, authority sources, and the legitimacy of collective mandates. The ε values differ: this reading has low extraction (0.28) because it genuinely coordinates innovation through property rights, while the magisterial reading has higher extraction due to enforcement overhead and the technocratic reading has moderate extraction from optimization-driven externalities. Each reading is ε-invariant within its own framing; the kernel contest is precisely about which framing is authoritative.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
