% ============================================================================
% CONSTRAINT STORY: woman_category__intersex_accommodation_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-01-15
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_woman_category__intersex_accommodation_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: woman_category__intersex_accommodation_reading
 *   human_readable: Woman Category: Intersex Accommodation Reading
 *   domain: political_philosophy/law/social_policy/bioethics
 *
 * SUMMARY:
 *   This constraint is the intersex accommodation reading of the contested
 *   woman-category kernel. It defines category membership by acknowledging
 *   biological sex as a non-binary spectrum: 'woman' includes people with
 *   typical female biology plus intersex variations that do not fit the male
 *   category. The reading emerged from developmental biology and intersex
 *   advocacy to challenge the binary enforcement that both the sex-biology
 *   reading and (in different ways) the gender-identity reading depend on.
 *   The constraint is claimed as mountain (a reading of biological reality)
 *   but operates with moderate extraction and suppression in domains where
 *   binary categorical boundaries are enforced — elite sports being the
 *   highest-extraction zone (the Semenya case). The claim/metric gap is
 *   structural to the kernel contest: the accommodation reading asserts it
 *   reflects natural biological variation; the metrics measure the costs its
 *   institutional adoption imposes on people at the categorical boundary and
 *   on institutions built around binary frameworks.
 *
 * KEY AGENTS:
 *   - intersex_athletes: Primary victims (powerless/identity_locked) — face categorical exclusion or coerced medical intervention to compete
 *   - people_with_dsd_conditions: Victims (powerless/identity_locked) — live at the boundary binary systems draw; experience coerced normalization and categorical precarity
 *   - sports_governing_bodies: Agenda setters (institutional/mobile) — enforce binary eligibility rules; resist accommodation framing
 *   - medical_researchers: Beneficiaries (institutional/mobile) — their empirical work on sex spectrum gains policy relevance
 *   - intersex_advocacy_organizations: Beneficiaries (organized/mobile) — gain political traction when intersex is framed as natural variation
 *   - binary_enforcement_advocates: Excluded (organized/mobile) — structurally excluded from medical standards venues where accommodation reading has foothold
 *   - bioethicists: Observers (institutional/analytical) — map trade-offs between categorical clarity and biological accuracy
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(woman_category__intersex_accommodation_reading, 0.28).
domain_priors:suppression_score(woman_category__intersex_accommodation_reading, 0.42).
domain_priors:theater_ratio(woman_category__intersex_accommodation_reading, 0.15).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, extractiveness, 0.28).
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, suppression_requirement, 0.42).
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, theater_ratio, 0.15).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, accessibility_collapse, 0.68).
narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, resistance, 0.55).

% --- Constraint claim ---
narrative_ontology:constraint_claim(woman_category__intersex_accommodation_reading, mountain).
narrative_ontology:human_readable(woman_category__intersex_accommodation_reading, "Woman Category: Intersex Accommodation Reading").
narrative_ontology:topic_domain(woman_category__intersex_accommodation_reading, "political_philosophy/law/social_policy/bioethics").

domain_priors:requires_active_enforcement(woman_category__intersex_accommodation_reading).
domain_priors:emerges_naturally(woman_category__intersex_accommodation_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(woman_category__intersex_accommodation_reading, '477c53da-32c7-4132-848b-7df08bb32af2').
narrative_ontology:cs_kernel_codification('477c53da-32c7-4132-848b-7df08bb32af2', distributed).
narrative_ontology:cs_authority_grounding('477c53da-32c7-4132-848b-7df08bb32af2', distributed).
narrative_ontology:cs_reading_relation('477c53da-32c7-4132-848b-7df08bb32af2', woman_category__sex_biology_reading, influences).
narrative_ontology:cs_reading_relation('477c53da-32c7-4132-848b-7df08bb32af2', woman_category__gender_identity_reading, coexists_with).
narrative_ontology:cs_axiom('477c53da-32c7-4132-848b-7df08bb32af2', foundational, sex_is_biologically_continuous_spectrum).
narrative_ontology:cs_axiom_status(sex_is_biologically_continuous_spectrum, holdable).
narrative_ontology:cs_axiom_grounding('477c53da-32c7-4132-848b-7df08bb32af2', sex_is_biologically_continuous_spectrum, empirically_contingent).
narrative_ontology:cs_axiom('477c53da-32c7-4132-848b-7df08bb32af2', secondary, categorical_accommodation_reduces_intersex_harm).
narrative_ontology:cs_axiom_status(categorical_accommodation_reduces_intersex_harm, holdable).
narrative_ontology:cs_axiom_grounding('477c53da-32c7-4132-848b-7df08bb32af2', categorical_accommodation_reduces_intersex_harm, empirically_contingent).
narrative_ontology:cs_reference_frame('477c53da-32c7-4132-848b-7df08bb32af2', bimodal_binary_baseline).
narrative_ontology:cs_drift_state('477c53da-32c7-4132-848b-7df08bb32af2', contemporary_spectrum_recognition_era, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('477c53da-32c7-4132-848b-7df08bb32af2', '').
narrative_ontology:cs_kernel_id(woman_category__intersex_accommodation_reading, woman_category).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(woman_category__intersex_accommodation_reading, medical_researchers).
narrative_ontology:constraint_beneficiary(woman_category__intersex_accommodation_reading, intersex_advocacy_organizations).
narrative_ontology:constraint_victim(woman_category__intersex_accommodation_reading, intersex_athletes).
narrative_ontology:constraint_victim(woman_category__intersex_accommodation_reading, people_with_dsd_conditions).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Elite athletes with naturally occurring intersex variations (5-alpha reductase deficiency, partial androgen insensitivity) face categorical exclusion from women's competition unless they undergo medical intervention. The Semenya case establishes the pattern: athletic career depends on accepting testosterone suppression or reclassification. Exit means abandoning competitive sport entirely; the identity lock is biological — they cannot change the endocrinology they were born with.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, intersex_athletes, payer,
    powerless, biographical, identity_locked, global).

% People with differences of sex development live at the boundary the binary enforcement draws. Medical systems, legal identity frameworks, and social institutions demand categorical placement (M or F); intersex variations that fit neither cleanly face coerced surgical normalization in infancy, contested legal status, and ongoing categorical precarity. The suppression is internalized: many grow up believing their biology is pathological rather than a natural variation.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, people_with_dsd_conditions, payer,
    powerless, biographical, identity_locked, global).

% Set eligibility rules for women's competition. They justify binary enforcement as necessary to preserve fair competition and protect the women's category from male-typical advantage. The accommodation reading challenges their foundational premise: if sex is a spectrum, the binary boundary is a policy choice dressed as biological necessity. They resist the accommodation framing because it would require rewriting decades of eligibility architecture.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, sports_governing_bodies, agenda_setter,
    institutional, generational, mobile, global).

% Endocrinologists and developmental biologists whose empirical work documents the full distribution of sex characteristics benefit from the accommodation reading: their data on DSDs, androgen receptor variation, and chromosomal mosaicism gains policy relevance. The reading vindicates decades of research showing sex development as multifactorial rather than binary, elevating evidence that binary enforcement frameworks marginalize.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, medical_researchers, beneficiary,
    institutional, generational, mobile, global).

% Organizations working against nonconsensual infant surgery and for intersex legal recognition gain political traction when the accommodation reading frames intersex as natural variation rather than disorder. Policy venues treating sex as a spectrum reduce the justification for surgical normalization and support legal frameworks that recognize intersex status directly.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, intersex_advocacy_organizations, beneficiary,
    organized, generational, mobile, global).

% Groups whose political position depends on maintaining strict sex-binary categories (certain feminist coalitions, religious-conservative organizations) are structurally excluded from policy venues that adopt the accommodation framework. Their objection is that spectrum models collapse the woman category they organized to defend; they are present in legislatures but absent from medical standards bodies where the accommodation reading has institutional foothold.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, binary_enforcement_advocates, excluded,
    organized, biographical, mobile, national).

% Analyze the trade-offs between categorical clarity and biological accuracy. They document the costs the binary enforcement imposes on people at the boundary (nonconsensual surgery, coerced medication, categorical exclusion) and the costs the accommodation reading would impose on institutions built around binary classification (rewriting legal codes, redesigning competition structures). Their work does not adjudicate which reading is correct but maps what each reading makes visible or suppresses.
narrative_ontology:constraint_stakeholder(woman_category__intersex_accommodation_reading, bioethicists, observer,
    institutional, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a categorical framework that acknowledges the empirical reality of sex as a bimodal but continuous spectrum while maintaining functional boundaries for law, medicine, and social organization where categorical placement is required.
% TRANSFER_FUNCTION: Moves institutional legitimacy and research funding from binary enforcement frameworks to intersex accommodation models; moves the burden of categorical precarity from intersex individuals to the institutions that must redesign around spectrum acknowledgment.
% ABSENT_VOICES: Binary enforcement advocates whose political coalitions depend on strict categorical boundaries are structurally excluded from medical standards bodies where the accommodation reading has gained institutional foothold. They argue in legislatures but are absent from the research and clinical venues where the spectrum model is consolidated.
% DISAPPEARANCE_RATIONALE: If this categorical framework vanished, intersex athletes would face different eligibility rules (either stricter binary enforcement or identity-based inclusion), medical practice around DSD conditions would shift (either toward surgical normalization or full self-determination), and legal systems would adopt one of the sibling readings. Sports governing bodies, advocacy organizations, and clinical guidelines would reorganize around whichever framework filled the vacuum.
% FOUNDING_PROBLEM: Binary sex classification systems that emerged from 19th-century biology failed to account for the empirically documented range of intersex variations, producing systematic harm (nonconsensual surgery, legal non-recognition, categorical exclusion) for people whose biology did not fit the binary. The accommodation reading was constructed to correct that by incorporating spectrum models from developmental biology.
% FOUNDING_PROBLEM_CORROBORATION: Medical societies (Endocrine Society, American Academy of Pediatrics), intersex advocacy groups, and bioethics bodies attest the founding problem remains live: binary enforcement still drives nonconsensual interventions and categorical exclusion. Historical medical literature and longitudinal studies of intersex individuals document the harms. The corroboration comes from parties outside the direct beneficiaries (clinical researchers who do not benefit politically from the accommodation reading but report the empirical distribution).
narrative_ontology:disappearance_verdict(woman_category__intersex_accommodation_reading, world_rearranges).
narrative_ontology:founding_problem_status(woman_category__intersex_accommodation_reading, live).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(woman_category__intersex_accommodation_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(woman_category__intersex_accommodation_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(woman_category__intersex_accommodation_reading_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, ExtMetricName, E),
    domain_priors:suppression_score(woman_category__intersex_accommodation_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(woman_category__intersex_accommodation_reading),
    narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(woman_category__intersex_accommodation_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(woman_category__intersex_accommodation_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is moderate-low (0.28) because the accommodation reading imposes costs on a small population (intersex individuals, ~1.7% of births) and institutional redesign costs on binary-dependent systems, but does not extract rents systematically. Suppression is moderate (0.42) because binary enforcement in sports and legal identity actively excludes intersex variations, but suppression is domain-specific rather than universal. Theater is low (0.15): the medical evidence for sex spectrum is robust; most performative activity is in political venues resisting the evidence. Accessibility collapse is moderate-high (0.68): once the spectrum model is understood, strict binary alternatives lose empirical grounding, but policy inertia and binary-dependent institutions keep alternatives alive. Resistance is moderate-high (0.55): binary enforcement advocates and institutions built around binary frameworks actively resist the accommodation reading. The measurement grid shows modest drift over 25 years as the accommodation reading gained institutional foothold in medical guidelines but met intensifying resistance in sports and political venues.
 *
 * PERSPECTIVAL GAP:
 *   The powerless victim seats (intersex athletes, people with DSD conditions) should compute the constraint as extractive and coercive: it denies their natural biology legitimacy unless they accept medical intervention or categorical reclassification. The institutional beneficiary seats (medical researchers) should compute it as coordinating: it aligns policy with empirical evidence. The agenda-setter seat (sports governing bodies) should compute it as imposed burden: it forces redesign of competition structures. The observer seat sees all three perspectives and the trade-offs between them. The engine computes this divergence from the structural data; the mountain claim does not adjudicate it.
 *
 * DIRECTIONALITY LOGIC:
 *   Intersex athletes and people with DSD conditions are structural victims: the constraint (when enforced through binary eligibility rules) extracts from them via categorical exclusion and coerced intervention. They are identity-locked because exit means denying their own biology. Sports governing bodies are agenda setters with mobile exit — they enforce the binary boundary and could adopt the accommodation framework but resist because it would require rewriting institutional architecture. Medical researchers and intersex advocacy organizations are beneficiaries: the accommodation reading elevates their work and political claims without extracting from them. Binary enforcement advocates are excluded from the venues where the accommodation reading has institutional power. The directionality computation should produce high d (near 1.0) for the victim seats, low d for beneficiaries, and intermediate d for agenda setters who face institutional redesign costs.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint's mandate (acknowledging sex spectrum to reduce harm to intersex individuals) remains live: nonconsensual infant surgery, legal non-recognition, and sports exclusion persist wherever binary enforcement dominates. The accommodation reading has not outlived its function. However, extraction is rising modestly because the institutional adoption of spectrum models in medical guidelines creates secondary costs (legal code redesign, competition structure changes) that fall on institutions and adjacent populations rather than solving only the founding problem. The gap between 'natural biological variation' (the claim) and 'moderate extraction in enforcement domains' (the metrics) is the mandatrophy signature the engine measures.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    natural_variation_vs_policy_construction,
    'Is the sex spectrum a natural biological fact that policy should acknowledge, or is the accommodation reading itself a constructed framework that benefits certain political coalitions at the expense of binary clarity?',
    'Empirical: longitudinal studies of untreated intersex individuals, cross-cultural analysis of sex categorization systems, and historical medical literature on DSD conditions would establish whether spectrum models better predict outcomes than binary enforcement. Conceptual: philosophical analysis of whether ''natural'' includes rare variations or only modal cases.',
    'If the spectrum is natural, the accommodation reading is a mountain correcting binary enforcement''s systematic error, and extraction on intersex individuals is unjustified. If the spectrum model is a constructed framework, the constraint is a tangled rope: genuine coordination function (reducing harm to intersex individuals) coupled with extraction (imposing institutional redesign costs and undermining binary-dependent political coalitions).',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(natural_variation_vs_policy_construction, empirical, 'Whether sex spectrum is biological fact or policy construction').

omega_variable(
    committer_kernel_reading,
    'This constraint is the intersex_accommodation reading of the woman_category kernel. How does choosing this reading over its siblings (sex_biology_reading, gender_identity_reading) change the victim set and extractiveness profile?',
    'Comparative analysis: the sex_biology reading''s victim set is transgender women (excluded by chromosomal criteria); the gender_identity reading''s victim set is natal females in sex-segregated spaces who object to inclusion of males; the intersex_accommodation reading''s victim set is intersex individuals coerced into binary categories. Each reading produces a different distribution of costs.',
    'The reading choice determines who is categorically included, who is excluded, and who bears redesign costs. The accommodation reading uniquely centers the empirical reality of intersex variations but imposes costs on institutions built around binary enforcement. Sibling readings shift those costs to different populations.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(committer_kernel_reading, conceptual, 'How reading choice within the woman_category kernel redistributes extraction').

omega_variable(
    sports_domain_concentration,
    'Why does extraction concentrate in elite sports when intersex individuals are a small population in most other domains?',
    'Domain-specific analysis: elite sports uniquely combines (1) categorical boundaries with high stakes (Olympic medals, professional contracts), (2) performance advantages from androgen exposure that intersex variations produce, and (3) binary eligibility rules that exclude variations rather than accommodating them. Most other domains (legal identity, medical care, social recognition) have lower stakes or more flexible boundaries.',
    'If extraction is domain-specific rather than inherent to the accommodation reading, the constraint''s overall extractiveness is lower than the sports cases suggest, and policy solutions could be domain-targeted (spectrum accommodation in law and medicine, eligibility redesign in sports) rather than universal binary enforcement.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(sports_domain_concentration, empirical, 'Why sports governance extracts more than other policy domains').

omega_variable(
    suppression_mechanism_internalized,
    'Is the suppression intersex individuals experience structural (external barriers to categorical recognition) or internalized (believing their biology is pathological)?',
    'Post-recognition suppression trajectory: if intersex individuals in jurisdictions with legal spectrum recognition still report categorical precarity and medicalized self-concept, the suppression is partly internalized. If precarity resolves with legal recognition, it was structural.',
    'If internalized, the constraint''s effective suppression is higher than structural measures suggest: the target carries the suppression after external barriers are removed. This would support higher therapeutic and social resources for intersex individuals even after legal frameworks accommodate spectrum models.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(suppression_mechanism_internalized, empirical, 'Structural vs internalized suppression for intersex individuals').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(woman_category__intersex_accommodation_reading, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(woma_tr_t0, woman_category__intersex_accommodation_reading, theater_ratio, 0, 0.08).
narrative_ontology:measurement(woma_tr_t5, woman_category__intersex_accommodation_reading, theater_ratio, 5, 0.1).
narrative_ontology:measurement(woma_tr_t10, woman_category__intersex_accommodation_reading, theater_ratio, 10, 0.11).
narrative_ontology:measurement(woma_tr_t15, woman_category__intersex_accommodation_reading, theater_ratio, 15, 0.13).
narrative_ontology:measurement(woma_tr_t20, woman_category__intersex_accommodation_reading, theater_ratio, 20, 0.14).
narrative_ontology:measurement(woma_tr_t25, woman_category__intersex_accommodation_reading, theater_ratio, 25, 0.15).

% Extraction over time
narrative_ontology:measurement(woma_be_t0, woman_category__intersex_accommodation_reading, base_extractiveness, 0, 0.15).
narrative_ontology:measurement(woma_be_t5, woman_category__intersex_accommodation_reading, base_extractiveness, 5, 0.18).
narrative_ontology:measurement(woma_be_t10, woman_category__intersex_accommodation_reading, base_extractiveness, 10, 0.21).
narrative_ontology:measurement(woma_be_t15, woman_category__intersex_accommodation_reading, base_extractiveness, 15, 0.24).
narrative_ontology:measurement(woma_be_t20, woman_category__intersex_accommodation_reading, base_extractiveness, 20, 0.26).
narrative_ontology:measurement(woma_be_t25, woman_category__intersex_accommodation_reading, base_extractiveness, 25, 0.28).

% Suppression requirement over time
narrative_ontology:measurement(woma_su_t0, woman_category__intersex_accommodation_reading, suppression_requirement, 0, 0.3).
narrative_ontology:measurement(woma_su_t5, woman_category__intersex_accommodation_reading, suppression_requirement, 5, 0.33).
narrative_ontology:measurement(woma_su_t10, woman_category__intersex_accommodation_reading, suppression_requirement, 10, 0.36).
narrative_ontology:measurement(woma_su_t15, woman_category__intersex_accommodation_reading, suppression_requirement, 15, 0.39).
narrative_ontology:measurement(woma_su_t20, woman_category__intersex_accommodation_reading, suppression_requirement, 20, 0.41).
narrative_ontology:measurement(woma_su_t25, woman_category__intersex_accommodation_reading, suppression_requirement, 25, 0.42).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(woman_category__intersex_accommodation_reading, identity_coordination).
narrative_ontology:boltzmann_floor_override(woman_category__intersex_accommodation_reading, 0.08).
narrative_ontology:affects_constraint(woman_category__intersex_accommodation_reading, woman_category__sex_biology_reading).
narrative_ontology:affects_constraint(woman_category__intersex_accommodation_reading, woman_category__gender_identity_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the woman_category kernel, which decomposes into three structurally distinct constraints (readings) because different frameworks for category membership produce incompatible victim sets and extractiveness profiles. The sex_biology reading enforces chromosomal binary and excludes transgender women; the gender_identity reading makes identity determinative and produces conflict in sex-segregated spaces; the intersex_accommodation reading acknowledges biological spectrum and extracts from intersex individuals in binary-enforcement domains. All three readings are linked via network.affects_constraints because they compete in the same policy venues and changes to one reading's institutional adoption shift the feasibility landscape for the others.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
