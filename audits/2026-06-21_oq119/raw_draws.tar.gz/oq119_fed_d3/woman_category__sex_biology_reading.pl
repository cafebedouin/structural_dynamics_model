% ============================================================================
% CONSTRAINT STORY: woman_category__sex_biology_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-01-15
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_woman_category__sex_biology_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: woman_category__sex_biology_reading
 *   human_readable: Woman Category: Sex-Biology Reading
 *   domain: political_philosophy/law/social_policy/bioethics
 *
 * SUMMARY:
 *   This constraint instantiates the sex-biology reading of the contested
 *   'woman' category kernel. The reading ties category membership to
 *   chromosomal sex and typical female reproductive anatomy, excluding
 *   transgender women and rendering intersex people's status ambiguous.
 *   Advocates present it as a neutral recognition of biological reality;
 *   critics read it as constructed boundary-drawing that harms vulnerable
 *   populations. The constraint is CLAIMED as mountain (advocates frame it as
 *   natural law) but the metrics describe substantial extraction and active
 *   enforcement — the engine measures that divergence.
 *
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(woman_category__sex_biology_reading, 0.68).
domain_priors:suppression_score(woman_category__sex_biology_reading, 0.72).
domain_priors:theater_ratio(woman_category__sex_biology_reading, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, extractiveness, 0.68).
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, suppression_requirement, 0.72).
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, accessibility_collapse, 0.71).
narrative_ontology:constraint_metric(woman_category__sex_biology_reading, resistance, 0.79).

% --- Constraint claim ---
narrative_ontology:constraint_claim(woman_category__sex_biology_reading, mountain).
narrative_ontology:human_readable(woman_category__sex_biology_reading, "Woman Category: Sex-Biology Reading").
narrative_ontology:topic_domain(woman_category__sex_biology_reading, "political_philosophy/law/social_policy/bioethics").

domain_priors:requires_active_enforcement(woman_category__sex_biology_reading).
domain_priors:emerges_naturally(woman_category__sex_biology_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(woman_category__sex_biology_reading, 'b53b3a68-dd0d-41f3-bf9c-851daeac3c0a').
narrative_ontology:cs_kernel_codification('b53b3a68-dd0d-41f3-bf9c-851daeac3c0a', distributed).
narrative_ontology:cs_authority_grounding('b53b3a68-dd0d-41f3-bf9c-851daeac3c0a', distributed).
narrative_ontology:cs_reading_relation('b53b3a68-dd0d-41f3-bf9c-851daeac3c0a', woman_category__gender_identity_reading, coexists_with).
narrative_ontology:cs_reading_relation('b53b3a68-dd0d-41f3-bf9c-851daeac3c0a', woman_category__intersex_accommodation_reading, influences).
narrative_ontology:cs_axiom('b53b3a68-dd0d-41f3-bf9c-851daeac3c0a', foundational, sex_is_chromosomally_binary).
narrative_ontology:cs_axiom_status(sex_is_chromosomally_binary, holdable).
narrative_ontology:cs_axiom_grounding('b53b3a68-dd0d-41f3-bf9c-851daeac3c0a', sex_is_chromosomally_binary, empirically_contingent).
narrative_ontology:cs_axiom('b53b3a68-dd0d-41f3-bf9c-851daeac3c0a', foundational, category_membership_requires_biological_correspondence).
narrative_ontology:cs_axiom_status(category_membership_requires_biological_correspondence, holdable).
narrative_ontology:cs_axiom_grounding('b53b3a68-dd0d-41f3-bf9c-851daeac3c0a', category_membership_requires_biological_correspondence, conventional).
narrative_ontology:cs_reference_frame('b53b3a68-dd0d-41f3-bf9c-851daeac3c0a', chromosomal_sex_binary).
narrative_ontology:cs_drift_state('b53b3a68-dd0d-41f3-bf9c-851daeac3c0a', contemporary_gender_rights_era, gap(repudiation_pressure, substantial, false)).
narrative_ontology:cs_created_at('b53b3a68-dd0d-41f3-bf9c-851daeac3c0a', '').
narrative_ontology:cs_kernel_id(woman_category__sex_biology_reading, woman_category).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(woman_category__sex_biology_reading, sex_segregation_advocates).
narrative_ontology:constraint_beneficiary(woman_category__sex_biology_reading, womens_sport_fairness_advocates).
narrative_ontology:constraint_beneficiary(woman_category__sex_biology_reading, sex_based_data_systems).
narrative_ontology:constraint_victim(woman_category__sex_biology_reading, transgender_women).
narrative_ontology:constraint_victim(woman_category__sex_biology_reading, intersex_people_assigned_female).
narrative_ontology:constraint_vindicates(woman_category__sex_biology_reading, sex_immutability_doctrine).
narrative_ontology:constraint_vindicates(woman_category__sex_biology_reading, binary_sex_model).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Advocate for maintaining sex-based categories in law, policy, and institutional practice. Frame the biology reading as protecting women's spaces, sports, and statistical integrity. Author legislative proposals requiring biological-sex documentation for category access. Benefit from the reading's codification by having their preferred boundary enforced.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, sex_segregation_advocates, agenda_setter,
    organized, generational, mobile, national).

% Athletes and organizations arguing that female sports categories must exclude those who underwent male puberty to preserve competitive fairness. The biology reading directly supports their claims by tying category membership to chromosomal and developmental biology rather than identity. Benefit from sports governing bodies adopting biological-sex eligibility.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, womens_sport_fairness_advocates, beneficiary,
    organized, biographical, constrained, global).

% Census bureaus, medical research institutions, and violence-against-women data collectors that track sex as a biological variable. The biology reading maintains their established data categories and measurement instruments; identity-based definitions would require rebuilding decades of longitudinal datasets.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, sex_based_data_systems, beneficiary,
    institutional, generational, constrained, national).

% Excluded from women's spaces, sports, and legal protections under the biology reading despite living as women and often undergoing medical transition. The constraint treats their identity claims as definitionally invalid. They bear direct costs: exclusion from facilities, athletic competition, violence shelters, and statistical visibility as women. Exit means either accepting male categorization (which conflicts with lived identity) or functioning outside the sex-segregated system entirely.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, transgender_women, payer,
    powerless, biographical, identity_locked, local).

% Assigned female at birth, raised as girls, but possess chromosomal or anatomical variations that do not fit the XX/typical-anatomy standard. The biology reading renders their status ambiguous or excludes them despite lifelong female social position. Face verification demands and potential disqualification from women's categories when variation is discovered. No exit: cannot change biology, cannot adopt male category without abandoning entire social history.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, intersex_people_assigned_female, payer,
    powerless, biographical, trapped, local).

% Endocrinology, genetics, and sports medicine bodies that study sex development and athletic performance. Provide empirical evidence on chromosomal variation, hormonal effects, and performance advantages. Their research is cited by both advocates and critics of the biology reading; they do not enforce category boundaries but their findings shape the debate.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, medical_professional_associations, observer,
    institutional, generational, analytical, global).

% Civil rights organizations arguing that biological-sex categorization in law violates equal protection and discriminates against transgender people. Structurally excluded from setting the terms of the debate in jurisdictions where the biology reading is legally codified. Would reframe category membership around identity and social participation rather than chromosomes.
narrative_ontology:constraint_stakeholder(woman_category__sex_biology_reading, legal_equality_advocates, excluded,
    organized, generational, constrained, national).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a stable, verifiable boundary for sex-segregated spaces, sports, medical research, and legal protections. Solves the categorization problem by tying membership to measurable biological features rather than subjective claims.
% TRANSFER_FUNCTION: Transfers access to women's spaces, competitive opportunities, legal protections, and statistical representation away from transgender women and intersex people, consolidating those resources for people with typical female biology. The advocates setting the boundary do not pay its costs.
% ABSENT_VOICES: Transgender women and intersex advocacy organizations are structurally excluded from the boundary-setting process in jurisdictions that codify the biology reading. Legal equality advocates who challenge the reading on anti-discrimination grounds are present in litigation but not in the legislative drafting.
% DISAPPEARANCE_RATIONALE: If the biology reading disappeared overnight, transgender women would enter women's spaces and sports without chromosomal verification; intersex people would no longer face ambiguous status; sex-based data systems would need to decide whether to track identity or biology; sports governing bodies would redesign eligibility rules; violence-against-women shelters would revise admission policies. The entire architecture of sex-segregated institutions would reorganize around a different boundary principle.
% FOUNDING_PROBLEM: Sex-segregated institutions historically formed to address physical vulnerability, reproductive health needs, and athletic performance differences between males and females. The biology reading grounds those separations in the same chromosomal and anatomical features that produced the original differences.
% FOUNDING_PROBLEM_CORROBORATION: Advocates of the biology reading attest the founding problem remains live: physical differences persist, athletic advantages from male puberty are measurable, and statistical conflation of sex and identity undermines health research. Medical professional associations confirm measurable physical differences but diverge on whether those differences require categorical exclusion. Legal equality advocates attest the founding problem is overridden by anti-discrimination principles and that social gender categories serve the protective function more justly. Legislative testimony and court briefs from outside the sex-segregation advocacy coalition document the contested status.
narrative_ontology:disappearance_verdict(woman_category__sex_biology_reading, world_rearranges).
narrative_ontology:founding_problem_status(woman_category__sex_biology_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(woman_category__sex_biology_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(woman_category__sex_biology_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(woman_category__sex_biology_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(woman_category__sex_biology_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(woman_category__sex_biology_reading, ExtMetricName, E),
    domain_priors:suppression_score(woman_category__sex_biology_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(woman_category__sex_biology_reading),
    narrative_ontology:constraint_metric(woman_category__sex_biology_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(woman_category__sex_biology_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(woman_category__sex_biology_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is substantial (0.68) because the constraint allocates access to sex-segregated resources asymmetrically: people with typical female biology retain access while transgender women and some intersex people lose it, and the loss is concentrated on powerless, identity-locked populations. Suppression is high (0.72) because the reading's persistence depends on active legal codification, documentation requirements, and enforcement against identity-based claims. Theater is moderate-low (0.28): chromosomal verification and anatomical standards are real boundary mechanisms, but enforcement increasingly focuses on preventing transgender access rather than on protecting the coordination function. Accessibility collapse is high (0.71) because once the biology frame is adopted, alternative definitions (identity, social role) are structurally inadmissible. Resistance is high (0.79) because transgender advocacy, legal equality organizations, and intersex communities actively challenge the reading through litigation, protest, and counter-legislative campaigns.
 *
 * PERSPECTIVAL GAP:
 *   From the agenda-setter seat, the constraint is a natural boundary grounded in measurable biology — no extraction, just recognition. From the transgender-women seat, the same structure operates as enforced exclusion: identity-locked exit, high suppression, substantial extraction of access and recognition. The engine computes this divergence from the exit-options and beneficiary/victim declarations; the claim does not adjudicate it.
 *
 * DIRECTIONALITY LOGIC:
 *   Sex-segregation advocates and sport-fairness organizations are beneficiaries: they set the boundary and benefit from its enforcement without bearing its costs. Transgender women and intersex people are targets: excluded from the category, identity-locked or trapped with no exit, concentrated costs. Data systems benefit incidentally (maintain existing infrastructure) without driving enforcement. The divergence in computed seat types (beneficiary seats → rope-like; target seats → snare-like) is the structural feature the engine exists to detect.
 *
 * MANDATROPHY ANALYSIS:
 *   The founding problem (sex-segregated protections for physical vulnerability and athletic fairness) is genuinely contested. Advocates attest it remains live and biology is the appropriate boundary; critics attest the protective function is better served by identity-inclusive definitions and that chromosomal boundaries produce new harms. The mandatrophy question is whether the biology reading's exclusionary effects are necessary costs of maintaining the founding protections, or whether the reading has become a vehicle for denying transgender identity independent of the original coordination problem. The measurements show extraction accumulating over the interval as enforcement intensifies around transgender exclusion specifically.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    natural_law_vs_constructed_boundary,
    'Is the chromosomal/anatomical definition of ''woman'' a recognition of pre-social biological fact, or a normative choice about which biological features count as definitional?',
    'Cross-cultural and historical analysis of category boundaries: if chromosomal boundaries are universal and invariant, the natural-law framing holds; if boundaries vary by culture and shift with institutional needs, the constructed framing holds. Medical evidence on intersex variation and chromosomal mosaicism bears on whether biology itself provides a binary boundary.',
    'If natural law, the exclusion of transgender women is a recognition of reality and extraction measures only the cost of boundary maintenance. If constructed, the reading is one choice among alternatives and the measured extraction represents asymmetric harm imposed by the choice. Shifts the baseline for Boltzmann compliance and FSM evaluation.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(natural_law_vs_constructed_boundary, conceptual, 'Whether the biology reading reflects discovered natural law or constructed norm.').

omega_variable(
    sibling_reading_foreclosure,
    'Does adopting the biology reading logically foreclose the identity reading, or can both readings coexist as live positions for different institutional contexts?',
    'Institutional practice observation: jurisdictions that apply biology in sports but identity in legal gender recognition demonstrate coexistence; jurisdictions that codify one reading and prohibit the other demonstrate foreclosure. The question is whether the readings are mutually exclusive commitments or context-dependent applications.',
    'If the readings foreclose each other, one must be abandoned for policy coherence and the contest is winner-take-all. If they coexist, hybrid institutional arrangements are viable and the contest is about domain-specific fitness rather than universal truth.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(sibling_reading_foreclosure, conceptual, 'Whether the biology and identity readings can coexist or logically exclude each other.').

omega_variable(
    intersex_boundary_ambiguity,
    'Where does the biology reading place intersex people with chromosomal or anatomical variation? Are they included in the woman category, excluded, or rendered categorically ambiguous?',
    'Examination of legislative and institutional definitions: whether intersex variations trigger disqualification, case-by-case adjudication, or automatic inclusion. Sports eligibility rulings for intersex athletes and legal documentation policies for intersex individuals provide empirical evidence.',
    'If intersex people are systematically excluded, the victim set expands and extraction increases. If accommodated, the biology reading is internally more complex than the binary model suggests. If ambiguous, the constraint generates secondary enforcement costs and identity instability for intersex populations.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(intersex_boundary_ambiguity, empirical, 'How the biology reading handles intersex biological variation.').

omega_variable(
    performance_advantage_magnitude,
    'What is the magnitude and persistence of athletic performance advantages from male puberty, and do those advantages justify categorical exclusion or can they be mitigated hormonally?',
    'Longitudinal sports medicine studies measuring strength, speed, and endurance in transgender women athletes before and after hormone therapy, compared to cisgender women athletes. Meta-analysis of competition results in jurisdictions allowing transgender participation.',
    'If advantages are large and persistent, the biology reading''s exclusion in sports is supported by fairness grounds and extraction is lower. If advantages are small or eliminated by hormone therapy, exclusion is not justified by performance and measured extraction reflects pure boundary enforcement.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(performance_advantage_magnitude, empirical, 'Whether male-puberty performance advantages justify sports exclusion.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(woman_category__sex_biology_reading, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(woma_tr_t0, woman_category__sex_biology_reading, theater_ratio, 0, 0.12).
narrative_ontology:measurement(woma_tr_t5, woman_category__sex_biology_reading, theater_ratio, 5, 0.15).
narrative_ontology:measurement(woma_tr_t10, woman_category__sex_biology_reading, theater_ratio, 10, 0.19).
narrative_ontology:measurement(woma_tr_t15, woman_category__sex_biology_reading, theater_ratio, 15, 0.23).
narrative_ontology:measurement(woma_tr_t20, woman_category__sex_biology_reading, theater_ratio, 20, 0.26).
narrative_ontology:measurement(woma_tr_t25, woman_category__sex_biology_reading, theater_ratio, 25, 0.28).

% Extraction over time
narrative_ontology:measurement(woma_be_t0, woman_category__sex_biology_reading, base_extractiveness, 0, 0.42).
narrative_ontology:measurement(woma_be_t5, woman_category__sex_biology_reading, base_extractiveness, 5, 0.48).
narrative_ontology:measurement(woma_be_t10, woman_category__sex_biology_reading, base_extractiveness, 10, 0.55).
narrative_ontology:measurement(woma_be_t15, woman_category__sex_biology_reading, base_extractiveness, 15, 0.61).
narrative_ontology:measurement(woma_be_t20, woman_category__sex_biology_reading, base_extractiveness, 20, 0.65).
narrative_ontology:measurement(woma_be_t25, woman_category__sex_biology_reading, base_extractiveness, 25, 0.68).

% Suppression requirement over time
narrative_ontology:measurement(woma_su_t0, woman_category__sex_biology_reading, suppression_requirement, 0, 0.48).
narrative_ontology:measurement(woma_su_t5, woman_category__sex_biology_reading, suppression_requirement, 5, 0.54).
narrative_ontology:measurement(woma_su_t10, woman_category__sex_biology_reading, suppression_requirement, 10, 0.61).
narrative_ontology:measurement(woma_su_t15, woman_category__sex_biology_reading, suppression_requirement, 15, 0.66).
narrative_ontology:measurement(woma_su_t20, woman_category__sex_biology_reading, suppression_requirement, 20, 0.69).
narrative_ontology:measurement(woma_su_t25, woman_category__sex_biology_reading, suppression_requirement, 25, 0.72).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(woman_category__sex_biology_reading, identity_coordination).
narrative_ontology:affects_constraint(woman_category__sex_biology_reading, woman_category__gender_identity_reading).
narrative_ontology:affects_constraint(woman_category__sex_biology_reading, woman_category__intersex_accommodation_reading).

% DUAL FORMULATION NOTE:
% This constraint is one of three readings of the woman_category kernel. The readings differ on the definitional criterion for category membership: biology (chromosomes/anatomy), identity (self-identification), or spectrum accommodation (intersex inclusion). All three readings share the same institutional domain (law, sports, data systems) but produce different victim sets and extractiveness profiles. The kernel decomposition follows ε-invariance: each reading is a structurally distinct constraint with its own stable ε, linked via network.affects_constraints.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
