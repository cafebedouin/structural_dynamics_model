% ============================================================================
% CONSTRAINT STORY: waitangi_sovereignty_allocation__partnership_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_waitangi_sovereignty_allocation__partnership_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: waitangi_sovereignty_allocation__partnership_reading
 *   human_readable: Treaty of Waitangi Partnership Doctrine
 *   domain: constitutional/indigenous_rights/post_colonial_governance
 *
 * SUMMARY:
 *   The Treaty of Waitangi partnership reading holds that the 1840 Treaty
 *   established an ongoing relationship requiring Crown consultation with and
 *   active protection of Māori interests, despite textual ambiguity between
 *   English and Māori versions. This reading emerged through judicial
 *   development of Treaty principles doctrine from the 1980s onward,
 *   operationalized through consultation requirements, settlement
 *   negotiations, and principles-based administrative review. It competes
 *   with a Crown sovereignty reading (complete Article I cession establishing
 *   Westminster supremacy) and a rangatiratanga reading (Māori text retained
 *   full authority, Crown gained only governorship over settlers). The
 *   constraint is CLAIMED as mountain — a foundational constitutional feature
 *   discovered through Treaty interpretation — while the metrics describe
 *   moderately extractive operation with identifiable beneficiaries, active
 *   enforcement requirements, and rising theatrical components. The engine
 *   will measure whether the constraint's structural properties support
 *   natural-law classification or whether beneficiary concentration and
 *   enforcement dependence indicate constructed coordination.
 *
 * KEY AGENTS:
 *   - Crown Government: Institutional agenda-setter (institutional/constrained) — administers principles doctrine, retains parliamentary sovereignty, benefits from legitimacy
 *   - Māori Communities: Organized beneficiary/payer (organized/identity_locked) — gain consultation rights and settlements, bear procedural costs without veto power
 *   - Treaty Settlement Negotiators: Organized beneficiary (organized/mobile) — professional class managing settlement infrastructure
 *   - Dispossessed Iwi: Moderate payer (moderate/identity_locked) — unresolved claims, protracted processes, outcomes bounded by Crown limits
 *   - Resource Industry Actors: Powerful payer (powerful/constrained) — consultation delays and costs, geographically fixed projects
 *   - Rangatiratanga Advocates: Moderate excluded (moderate/identity_locked) — full-authority reading excluded from authoritative interpretation
 *   - Constitutional Scholars: Analytical observer (analytical/analytical) — document gap between rhetoric and substantive outcomes
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(waitangi_sovereignty_allocation__partnership_reading, 0.42).
domain_priors:suppression_score(waitangi_sovereignty_allocation__partnership_reading, 0.38).
domain_priors:theater_ratio(waitangi_sovereignty_allocation__partnership_reading, 0.31).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, extractiveness, 0.42).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 0.38).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 0.31).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, accessibility_collapse, 0.68).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, resistance, 0.52).

% --- Constraint claim ---
narrative_ontology:constraint_claim(waitangi_sovereignty_allocation__partnership_reading, mountain).
narrative_ontology:human_readable(waitangi_sovereignty_allocation__partnership_reading, "Treaty of Waitangi Partnership Doctrine").
narrative_ontology:topic_domain(waitangi_sovereignty_allocation__partnership_reading, "constitutional/indigenous_rights/post_colonial_governance").

domain_priors:requires_active_enforcement(waitangi_sovereignty_allocation__partnership_reading).
domain_priors:emerges_naturally(waitangi_sovereignty_allocation__partnership_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(waitangi_sovereignty_allocation__partnership_reading, 'aba2fd3e-572a-4ad0-a2a3-d3c461a07cb0').
narrative_ontology:cs_kernel_codification('aba2fd3e-572a-4ad0-a2a3-d3c461a07cb0', fixed_text).
narrative_ontology:cs_authority_grounding('aba2fd3e-572a-4ad0-a2a3-d3c461a07cb0', lineage).
narrative_ontology:cs_interpretation_layer_present('aba2fd3e-572a-4ad0-a2a3-d3c461a07cb0').
narrative_ontology:cs_reading_relation('aba2fd3e-572a-4ad0-a2a3-d3c461a07cb0', waitangi_sovereignty_allocation__crown_sovereignty_reading, coexists_with).
narrative_ontology:cs_reading_relation('aba2fd3e-572a-4ad0-a2a3-d3c461a07cb0', waitangi_sovereignty_allocation__rangatiratanga_reading, coexists_with).
narrative_ontology:cs_axiom('aba2fd3e-572a-4ad0-a2a3-d3c461a07cb0', foundational, treaty_partnership_ongoing_obligation).
narrative_ontology:cs_axiom_status(treaty_partnership_ongoing_obligation, holdable).
narrative_ontology:cs_axiom_grounding('aba2fd3e-572a-4ad0-a2a3-d3c461a07cb0', treaty_partnership_ongoing_obligation, deontological).
narrative_ontology:cs_axiom('aba2fd3e-572a-4ad0-a2a3-d3c461a07cb0', secondary, good_faith_consultation_required).
narrative_ontology:cs_axiom_status(good_faith_consultation_required, holdable).
narrative_ontology:cs_axiom_grounding('aba2fd3e-572a-4ad0-a2a3-d3c461a07cb0', good_faith_consultation_required, conventional).
narrative_ontology:cs_reference_frame('aba2fd3e-572a-4ad0-a2a3-d3c461a07cb0', treaty_partnership_emergence_1980s).
narrative_ontology:cs_drift_state('aba2fd3e-572a-4ad0-a2a3-d3c461a07cb0', contemporary_consultation_era, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('aba2fd3e-572a-4ad0-a2a3-d3c461a07cb0', '').
narrative_ontology:cs_kernel_id(waitangi_sovereignty_allocation__partnership_reading, waitangi_sovereignty_allocation).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__partnership_reading, crown_government).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__partnership_reading, maori_communities).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__partnership_reading, treaty_settlement_negotiators).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__partnership_reading, dispossessed_iwi).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__partnership_reading, resource_industry_actors).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__partnership_reading, maori_communities).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Administers the principles doctrine through legislation and executive policy, frames consultation requirements, negotiates Treaty settlements. Benefits from legitimacy the partnership framework confers on post-colonial governance while retaining parliamentary sovereignty as ultimate legal authority. Consultation obligations constrain unilateral action but do not bind Parliament's legislative supremacy.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, crown_government, agenda_setter,
    institutional, generational, constrained, national).
narrative_ontology:stakeholder_secondary_role(waitangi_sovereignty_allocation__partnership_reading, crown_government, beneficiary).

% Gain consultation rights, settlement redress, and Treaty principles as interpretive tools in administrative and lower-court proceedings. Bear the cost of engaging complex consultation processes with uncertain binding force, and live with resource decisions made under procedures that acknowledge but do not grant veto power. Identity-locked because tino rangatiratanga and connection to whenua constitute the community's foundational self-conception.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, maori_communities, beneficiary,
    organized, generational, identity_locked, national).
narrative_ontology:stakeholder_secondary_role(waitangi_sovereignty_allocation__partnership_reading, maori_communities, payer).

% Professionals who manage the settlement process, drafting agreements that operationalize partnership through specific redress packages. Benefit from the ongoing demand for negotiation expertise and settlement infrastructure. Mobile because their expertise transfers across institutional contexts.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, treaty_settlement_negotiators, beneficiary,
    organized, biographical, mobile, national).

% Groups whose historical land and resource claims remain unresolved or inadequately redressed. Pay the cost of engaging protracted settlement processes with outcomes bounded by Crown fiscal limits and political will. Consultation does not restore substantive authority lost through colonial confiscation. Identity-locked for the same reasons as broader Māori communities.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, dispossessed_iwi, payer,
    moderate, generational, identity_locked, regional).

% Face consultation requirements and potential settlement obligations that add procedural delay and cost to resource extraction projects. Constrained exit because projects are geographically fixed and require regulatory approval under the principles framework, but possess capital mobility across jurisdictions.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, resource_industry_actors, payer,
    powerful, biographical, constrained, national).

% Argue the Māori-text Article II retained full authority and that partnership doctrine dilutes tino rangatiratanga into consultation rights. Structurally excluded from the principles framework's authoritative interpretation, which is set by Crown courts applying Crown law.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, rangatiratanga_advocates, excluded,
    moderate, civilizational, identity_locked, national).

% Analyze whether partnership doctrine represents genuine bi-cultural constitutional evolution or Crown domestication of Treaty obligations. Document the gap between consultation rhetoric and substantive power-sharing outcomes.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__partnership_reading, constitutional_scholars, observer,
    analytical, generational, analytical, national).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes a normative and procedural framework for Crown-Māori relations in a post-colonial polity where neither complete assimilation nor separate sovereignty proved stable: ongoing consultation, good-faith engagement, and settlement redress coordinate competing claims to authority and resources.
% TRANSFER_FUNCTION: Moves fiscal resources from Crown to iwi through settlements, procedural power from unilateral Crown action to consultation processes, and interpretive authority from raw parliamentary sovereignty to principles-mediated administrative law, while maintaining Crown legal supremacy as the ultimate bound.
% ABSENT_VOICES: Rangatiratanga advocates who read the Māori text as retaining full authority are structurally excluded from authoritative interpretation, which occurs in Crown courts under Crown constitutional law. Their reading is acknowledged as historically grounded but not adopted as binding law.
% DISAPPEARANCE_RATIONALE: If partnership doctrine and consultation obligations vanished, Crown could govern unilaterally without Treaty constraint, iwi would lose settlement infrastructure and principles-based judicial review, resource conflicts would revert to raw political contestation, and the legitimacy framework for post-colonial governance would collapse, forcing either full assimilation policy or renewed sovereignty litigation.
% FOUNDING_PROBLEM: British colonization created competing sovereignty claims: Crown asserted complete sovereignty via English-text Article I cession; Māori understood Article II as retaining rangatiratanga. Neither unilateral Crown rule nor separate sovereignty proved institutionally stable by mid-20th century.
% FOUNDING_PROBLEM_CORROBORATION: The founding sovereignty contest is live: ongoing Treaty settlements, active litigation over consultation adequacy, and rangatiratanga movements attest the claims remain unreconciled. Constitutional scholars outside the settlement apparatus document this as persistent structural ambiguity, not resolved by partnership doctrine but managed through it.
narrative_ontology:disappearance_verdict(waitangi_sovereignty_allocation__partnership_reading, world_rearranges).
narrative_ontology:founding_problem_status(waitangi_sovereignty_allocation__partnership_reading, live).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(waitangi_sovereignty_allocation__partnership_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(waitangi_sovereignty_allocation__partnership_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(waitangi_sovereignty_allocation__partnership_reading_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, ExtMetricName, E),
    domain_priors:suppression_score(waitangi_sovereignty_allocation__partnership_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(waitangi_sovereignty_allocation__partnership_reading),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__partnership_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(waitangi_sovereignty_allocation__partnership_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is moderate (0.42) because consultation requirements impose real procedural costs on resource decisions and Crown action, while settlement payments transfer fiscal resources, but the framework preserves Crown legal supremacy and bounds outcomes by Crown fiscal and political limits. Suppression is moderate-low (0.38, declining) because the doctrine operates through administrative procedure and lower-court interpretation rather than raw coercion, though rangatiratanga alternatives are structurally excluded from authoritative interpretation. Theater ratio is moderate-low but rising (0.18→0.31) as consultation processes become routinized ritual with uncertain binding force — 'good faith engagement' increasingly describes procedural compliance rather than substantive power-sharing. Accessibility collapse is moderate-high (0.68) because the partnership framework has become the authoritative interpretation in Crown law, but competing readings (full sovereignty, full rangatiratanga) remain live in political discourse. Resistance is moderate (0.52) from rangatiratanga advocates who reject consultation as adequate and from industry actors bearing procedural costs. The temporal series shows gradual extraction accumulation and theater drift as consultation infrastructure matures while substantive authority remains bounded.
 *
 * PERSPECTIVAL GAP:
 *   From Crown institutional position, partnership doctrine is genuine constitutional evolution reconciling competing sovereignty claims through principled engagement. From dispossessed iwi and rangatiratanga advocate positions, the same structure operates as Crown domestication of Treaty obligations: consultation without veto, settlement bounded by Crown fiscal limits, principles doctrine that acknowledges rangatiratanga rhetorically while preserving Westminster supremacy substantively. The measurement gap between claimed natural-law status and authored structural metrics (beneficiary concentration, enforcement requirements, rising theater) is the detection target.
 *
 * DIRECTIONALITY LOGIC:
 *   Crown government sits near beneficiary end: administers the framework, collects legitimacy for post-colonial governance, retains ultimate legal authority. Māori communities are mixed: gain consultation rights and settlement infrastructure (beneficiary signals) but bear procedural costs without veto power and live with bounded outcomes (payer signals) — the identity-locked exit option pushes effective extraction upward because whenua connection is constitutive. Treaty settlement negotiators are clear beneficiaries: professional class sustained by ongoing settlement demand, mobile exit. Dispossessed iwi are clear payers: protracted processes, inadequate redress, identity-locked. Resource industry actors are payers: consultation delays, fiscal costs, constrained by geography. Rangatiratanga advocates are structurally excluded rather than coordinated.
 *
 * MANDATROPHY ANALYSIS:
 *   Partnership doctrine presents as inevitable constitutional feature discovered through Treaty interpretation ('the Treaty itself requires this'), but the structure benefits identifiable parties (Crown legitimacy, settlement negotiator infrastructure, selective iwi redress) while excluding rangatiratanga alternatives from authoritative interpretation. The founding problem (competing sovereignty claims) remains live rather than resolved, and the constraint's operation depends on active judicial maintenance and settlement apparatus rather than spontaneous coordination. This suggests the doctrine coordinates real post-colonial governance challenges while also serving Crown institutional interests in bounded accommodation.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    natural_law_vs_institutional_construction,
    'Is partnership doctrine a natural constitutional feature emergent from Treaty text and tikanga Māori, or a Crown institutional construction that domesticates Treaty obligations into manageable consultation procedures?',
    'Comparative constitutional analysis of other post-colonial treaty frameworks, historical investigation of judicial doctrine development showing institutional incentives, and analysis of consultation outcomes relative to rangatiratanga claims.',
    'If natural law, the constraint''s beneficiary concentration and enforcement requirements are inherent costs of coordinating genuine bi-cultural governance. If constructed, the same features indicate Crown extraction of legitimacy while retaining substantive power.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(natural_law_vs_institutional_construction, conceptual, 'Whether partnership doctrine emerges naturally or serves Crown institutional interests.').

omega_variable(
    consultation_vs_substantive_authority,
    'Does consultation without veto power constitute meaningful authority-sharing, or is it procedural theater that preserves Crown decision-making supremacy?',
    'Longitudinal analysis of consultation outcomes: what proportion of substantive decisions change based on Māori input versus formal engagement without outcome alteration. Case studies of major resource decisions.',
    'If consultation produces substantive changes, theater ratio is understated and coordination function is genuine. If consultation rarely alters outcomes, theater ratio is understated in opposite direction and extraction is higher.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(consultation_vs_substantive_authority, empirical, 'Whether consultation procedures deliver substantive power-sharing or procedural legitimation.').

omega_variable(
    settlement_adequacy_vs_bounded_redress,
    'Are Treaty settlement packages adequate redress for historical dispossession, or are they Crown-bounded compromises that trade comprehensive claims for fiscal limits?',
    'Economic analysis comparing settlement amounts to documented land values and resource losses, iwi testimony on settlement negotiation constraints, comparison to other post-colonial redress frameworks.',
    'If settlements are adequate, the constraint genuinely resolves founding problem claims. If bounded by Crown fiscal and political limits rather than claim adequacy, extraction is higher and unresolved claims persist.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(settlement_adequacy_vs_bounded_redress, empirical, 'Whether settlements constitute adequate redress or bounded compromise.').

omega_variable(
    rangatiratanga_reading_foreclosure,
    'Is the partnership reading''s dominance in Crown law the result of superior interpretive coherence, or institutional foreclosure of rangatiratanga alternatives through control of authoritative interpretation venues?',
    'Analysis of which interpretive venues (Crown courts vs. tikanga-based fora) produce which readings, historical documentation of rangatiratanga advocacy suppression or accommodation, comparative treaty interpretation in jurisdictions with different institutional arrangements.',
    'If partnership reading prevails through interpretive superiority, its accessibility collapse reflects genuine coordination superiority. If through institutional control, accessibility collapse reflects suppression of alternatives.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(rangatiratanga_reading_foreclosure, conceptual, 'Whether partnership doctrine prevails through coherence or institutional foreclosure.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(waitangi_sovereignty_allocation__partnership_reading, 0, 50).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(wait_tr_t0, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 0, 0.18).
narrative_ontology:measurement_basis(wait_tr_t0, observed).
narrative_ontology:measurement(wait_tr_t10, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 10, 0.21).
narrative_ontology:measurement_basis(wait_tr_t10, observed).
narrative_ontology:measurement(wait_tr_t20, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 20, 0.24).
narrative_ontology:measurement_basis(wait_tr_t20, observed).
narrative_ontology:measurement(wait_tr_t30, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 30, 0.27).
narrative_ontology:measurement_basis(wait_tr_t30, observed).
narrative_ontology:measurement(wait_tr_t40, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 40, 0.29).
narrative_ontology:measurement_basis(wait_tr_t40, observed).
narrative_ontology:measurement(wait_tr_t50, waitangi_sovereignty_allocation__partnership_reading, theater_ratio, 50, 0.31).
narrative_ontology:measurement_basis(wait_tr_t50, observed).

% Extraction over time
narrative_ontology:measurement(wait_be_t0, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 0, 0.28).
narrative_ontology:measurement_basis(wait_be_t0, observed).
narrative_ontology:measurement(wait_be_t10, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 10, 0.32).
narrative_ontology:measurement_basis(wait_be_t10, observed).
narrative_ontology:measurement(wait_be_t20, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 20, 0.36).
narrative_ontology:measurement_basis(wait_be_t20, observed).
narrative_ontology:measurement(wait_be_t30, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 30, 0.39).
narrative_ontology:measurement_basis(wait_be_t30, observed).
narrative_ontology:measurement(wait_be_t40, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 40, 0.41).
narrative_ontology:measurement_basis(wait_be_t40, observed).
narrative_ontology:measurement(wait_be_t50, waitangi_sovereignty_allocation__partnership_reading, base_extractiveness, 50, 0.42).
narrative_ontology:measurement_basis(wait_be_t50, observed).

% Suppression requirement over time
narrative_ontology:measurement(wait_su_t0, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 0, 0.52).
narrative_ontology:measurement_basis(wait_su_t0, observed).
narrative_ontology:measurement(wait_su_t10, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 10, 0.48).
narrative_ontology:measurement_basis(wait_su_t10, observed).
narrative_ontology:measurement(wait_su_t20, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 20, 0.44).
narrative_ontology:measurement_basis(wait_su_t20, observed).
narrative_ontology:measurement(wait_su_t30, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 30, 0.41).
narrative_ontology:measurement_basis(wait_su_t30, observed).
narrative_ontology:measurement(wait_su_t40, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 40, 0.39).
narrative_ontology:measurement_basis(wait_su_t40, observed).
narrative_ontology:measurement(wait_su_t50, waitangi_sovereignty_allocation__partnership_reading, suppression_requirement, 50, 0.38).
narrative_ontology:measurement_basis(wait_su_t50, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(waitangi_sovereignty_allocation__partnership_reading, identity_coordination).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__partnership_reading, waitangi_sovereignty_allocation__crown_sovereignty_reading).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__partnership_reading, waitangi_sovereignty_allocation__rangatiratanga_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the waitangi_sovereignty_allocation kernel. The three sibling readings share the same historical Treaty and constitutional context but instantiate structurally distinct constraints with different beneficiary/victim structures, different enforcement mechanisms, and different ε values. Partnership reading: moderate extraction through consultation procedures and bounded settlements. Crown sovereignty reading: low extraction from Crown perspective (affirms existing authority), high from dispossessed perspective (forecloses alternative claims). Rangatiratanga reading: low extraction (affirms retained authority), structurally excluded from authoritative interpretation in Crown law.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
