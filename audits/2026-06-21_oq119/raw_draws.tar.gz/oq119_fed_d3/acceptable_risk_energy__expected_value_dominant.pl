% ============================================================================
% CONSTRAINT STORY: acceptable_risk_energy__expected_value_dominant
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-12
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_acceptable_risk_energy__expected_value_dominant, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: acceptable_risk_energy__expected_value_dominant
 *   human_readable: Expected Value Maximization Framework for Energy Risk Assessment
 *   domain: risk_assessment/energy_policy/decision_theory
 *
 * SUMMARY:
 *   Energy policy institutions adopt expected utility maximization as the
 *   standard for acceptable risk, operationalized through mortality-per-TWh
 *   metrics. All energy pathway deaths—fossil fuel air pollution, mining
 *   accidents, nuclear disasters—are converted to expected values by
 *   multiplying harm by probability and summed into aggregate welfare
 *   functions. This reading treats expected-value dominance as the
 *   mathematically correct approach to risk comparison, a neutral
 *   optimization framework emerging from decision theory itself. The
 *   constraint is CLAIMED as mountain (foundational decision-theoretic
 *   principle) while metrics describe substantially extractive operation with
 *   identifiable beneficiaries—the engine measures that divergence.
 *
 * KEY AGENTS:
 *   - expected_value_policy_institutions: Agenda-setter (institutional/mobile) — controls the analytical framework and defines acceptable risk
 *   - fossil_fuel_industry: Beneficiary (powerful/constrained) — gains from diffuse mortality being competitive once catastrophic risk is discounted
 *   - nuclear_safety_authorities: Beneficiary (institutional/constrained) — vindicates nuclear expansion through probability-weighted safety
 *   - fossil_pathway_affected_populations: Victim (powerless/trapped) — bears continuous distributed deaths counted with full weight
 *   - low_probability_catastrophe_bearers: Victim (powerless/trapped) — potential catastrophic harm discounted to insignificance
 *   - catastrophic_risk_theorists: Excluded (moderate/mobile) — alternative frameworks systematically barred from policy adoption
 *   - energy_economists: Observer (organized/analytical) — produces the mortality data feeding the framework
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(acceptable_risk_energy__expected_value_dominant, 0.68).
domain_priors:suppression_score(acceptable_risk_energy__expected_value_dominant, 0.76).
domain_priors:theater_ratio(acceptable_risk_energy__expected_value_dominant, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, extractiveness, 0.68).
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, suppression_requirement, 0.76).
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, accessibility_collapse, 0.71).
narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, resistance, 0.58).

% --- Constraint claim ---
narrative_ontology:constraint_claim(acceptable_risk_energy__expected_value_dominant, mountain).
narrative_ontology:human_readable(acceptable_risk_energy__expected_value_dominant, "Expected Value Maximization Framework for Energy Risk Assessment").
narrative_ontology:topic_domain(acceptable_risk_energy__expected_value_dominant, "risk_assessment/energy_policy/decision_theory").

domain_priors:requires_active_enforcement(acceptable_risk_energy__expected_value_dominant).
domain_priors:emerges_naturally(acceptable_risk_energy__expected_value_dominant).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(acceptable_risk_energy__expected_value_dominant, '8c59b75b-03f3-4e68-ae56-393fdd48c461').
narrative_ontology:cs_kernel_codification('8c59b75b-03f3-4e68-ae56-393fdd48c461', formalized).
narrative_ontology:cs_authority_grounding('8c59b75b-03f3-4e68-ae56-393fdd48c461', expertise).
narrative_ontology:cs_interpretation_layer_present('8c59b75b-03f3-4e68-ae56-393fdd48c461').
narrative_ontology:cs_reading_relation('8c59b75b-03f3-4e68-ae56-393fdd48c461', acceptable_risk_energy__catastrophic_tail_dominant, coexists_with).
narrative_ontology:cs_reading_relation('8c59b75b-03f3-4e68-ae56-393fdd48c461', acceptable_risk_energy__option_value_preserving, coexists_with).
narrative_ontology:cs_axiom('8c59b75b-03f3-4e68-ae56-393fdd48c461', foundational, probability_weighted_aggregate_harm_optimization).
narrative_ontology:cs_axiom_status(probability_weighted_aggregate_harm_optimization, holdable).
narrative_ontology:cs_axiom_grounding('8c59b75b-03f3-4e68-ae56-393fdd48c461', probability_weighted_aggregate_harm_optimization, empirically_contingent).
narrative_ontology:cs_axiom('8c59b75b-03f3-4e68-ae56-393fdd48c461', foundational, catastrophic_tail_probability_discounting).
narrative_ontology:cs_axiom_status(catastrophic_tail_probability_discounting, holdable).
narrative_ontology:cs_axiom_grounding('8c59b75b-03f3-4e68-ae56-393fdd48c461', catastrophic_tail_probability_discounting, empirically_contingent).
narrative_ontology:cs_reference_frame('8c59b75b-03f3-4e68-ae56-393fdd48c461', expected_utility_maximization_standard).
narrative_ontology:cs_drift_state('8c59b75b-03f3-4e68-ae56-393fdd48c461', post_fukushima_reassessment, gap(axiom_overriding, substantial, false)).
narrative_ontology:cs_created_at('8c59b75b-03f3-4e68-ae56-393fdd48c461', '').
narrative_ontology:cs_kernel_id(acceptable_risk_energy__expected_value_dominant, acceptable_risk_energy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__expected_value_dominant, expected_value_policy_institutions).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__expected_value_dominant, fossil_fuel_industry).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__expected_value_dominant, nuclear_safety_authorities).
narrative_ontology:constraint_victim(acceptable_risk_energy__expected_value_dominant, fossil_pathway_affected_populations).
narrative_ontology:constraint_victim(acceptable_risk_energy__expected_value_dominant, low_probability_catastrophe_bearers).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__expected_value_dominant, expected_utility_maximization_doctrine).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__expected_value_dominant, aggregate_welfare_standard).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Design energy policy frameworks using mortality-per-TWh as the optimization target. Justify decisions by converting all pathways to expected deaths and minimizing the aggregate. Control the analytical apparatus that produces risk comparisons and defines acceptable risk. Present this framework as decision-theoretically optimal and scientifically grounded.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, expected_value_policy_institutions, agenda_setter,
    institutional, generational, mobile, global).

% Benefits from a framework that distributes coal and gas mortality across large denominators—deaths from air pollution and mining accidents are real but diffuse, entering the calculation as incremental statistical deaths rather than identifiable catastrophic events. The expected-value lens makes fossil pathways appear competitive against nuclear once catastrophic tail risk is probability-discounted.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, fossil_fuel_industry, beneficiary,
    powerful, biographical, constrained, global).

% Benefit when low-probability reactor accidents are probability-weighted into negligible expected harm, making nuclear appear safer than fossil in mortality-per-TWh terms. This reading vindicates continued nuclear operation and expansion despite public fear of catastrophic failure. Their professional identity is constituted through maintaining nuclear as the safest option under expected-value accounting.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, nuclear_safety_authorities, beneficiary,
    institutional, generational, constrained, national).

% Bear the actual distributed deaths from air pollution, mining disasters, and climate impacts that enter the expected-value calculation with full weight. These deaths are statistically predictable and happen continuously. They have no exit from the energy system that generates these harms and no voice in the framework that treats their deaths as acceptable costs of energy production.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, fossil_pathway_affected_populations, payer,
    powerless, biographical, trapped, regional).

% Would bear the concentrated catastrophic harm if a low-probability nuclear accident, reactor meltdown, or spent fuel disaster occurs. Under expected-value framing their potential harm is discounted to near-zero by multiplying severity by tiny probability. They cannot exit the proximity to nuclear facilities and their objections are dismissed as innumerate fear.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, low_probability_catastrophe_bearers, payer,
    powerless, civilizational, trapped, regional).

% Argue that expected-value maximization is inappropriate for decisions involving low-probability civilizational-scale catastrophes—that tail risks and option value matter beyond their probability-weighted contribution. They are systematically excluded from policy-setting institutions that have adopted expected utility as the standard. Their framework would elevate catastrophic scenarios and uncertainty itself as decision factors.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, catastrophic_risk_theorists, excluded,
    moderate, civilizational, mobile, global).

% Produce the mortality-per-TWh calculations that feed this framework. They measure deaths, estimate probabilities, and compute expected harms across energy pathways. Some are embedded in institutions that benefit from expected-value dominance; others document its limitations and the normative choices embedded in the metric.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__expected_value_dominant, energy_economists, observer,
    organized, biographical, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a single commensurable metric for comparing heterogeneous energy risks: mortality-per-TWh converts diverse harms—air pollution deaths, mining accidents, reactor failures—into one unit for policy optimization.
% TRANSFER_FUNCTION: Transfers legitimacy and policy priority from energy pathways with concentrated catastrophic risk to pathways with diffuse continuous mortality, and from populations bearing tail risk to those analyzing aggregate statistics.
% ABSENT_VOICES: Future generations who would bear long-duration catastrophic outcomes, populations proximate to potential catastrophic events whose harm is probability-discounted, and theorists who reject expected-value maximization for civilizational decisions are systematically absent from the framework's construction.
% DISAPPEARANCE_RATIONALE: Policy institutions would claim energy decisions become incoherent without a unifying optimization target—no way to compare disparate risks. Critics would claim alternative frameworks (minimax regret, precautionary principles, option value preservation) are equally coherent and energy policy would reorganize around explicitly acknowledged normative disagreement rather than pretending to optimize a neutral metric.
% FOUNDING_PROBLEM: Energy policy requires comparing fundamentally different types of harm across technologies—how to weigh continuous incremental deaths against rare catastrophic failures, local pollution against global climate risk, immediate harm against long-duration consequences.
% FOUNDING_PROBLEM_CORROBORATION: All parties—including critics of expected-value dominance—acknowledge the founding problem persists. Energy economists and catastrophic risk theorists outside the benefiting institutions corroborate that the comparison problem is real; their dispute is whether expected-value maximization is the appropriate solution or a constructed choice that advantages certain pathways.
narrative_ontology:disappearance_verdict(acceptable_risk_energy__expected_value_dominant, contested).
narrative_ontology:founding_problem_status(acceptable_risk_energy__expected_value_dominant, live).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(acceptable_risk_energy__expected_value_dominant, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(acceptable_risk_energy__expected_value_dominant, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(acceptable_risk_energy__expected_value_dominant_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(acceptable_risk_energy__expected_value_dominant, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, ExtMetricName, E),
    domain_priors:suppression_score(acceptable_risk_energy__expected_value_dominant, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(acceptable_risk_energy__expected_value_dominant),
    narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(acceptable_risk_energy__expected_value_dominant, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(acceptable_risk_energy__expected_value_dominant_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is high (0.68) because the framework systematically advantages pathways with diffuse mortality over those with concentrated tail risk, benefiting specific industries and institutions whose legitimacy depends on this particular risk accounting. Suppression is higher (0.76) because alternative risk frameworks—minimax, precautionary principles, option-value preservation—are actively excluded from policy institutions despite being decision-theoretically coherent. Theater ratio is moderate (0.42): the mortality-per-TWh calculations are real empirical work, but a growing share of analytical effort defends the expected-value frame itself rather than improving risk measurement. Accessibility collapse is high (0.71) because once expected utility is adopted as the standard, alternative frameworks appear as innumerate or irrational. Resistance is substantial (0.58) from populations bearing discounted catastrophic risk and from theorists arguing expected-value maximization is inappropriate for civilizational decisions.
 *
 * PERSPECTIVAL GAP:
 *   From the agenda-setter seat, expected-value maximization is the mathematically correct approach to risk—neutral application of decision theory. From the trapped payer seats bearing actual continuous deaths or discounted catastrophic risk, the same framework operates as a constructed choice that systematically underweights their harm. From the excluded seat, the framework is one reading among several decision-theoretically valid approaches, elevated to natural law by institutions it advantages. The engine computes these divergences from structural position; the mountain claim does not adjudicate them.
 *
 * DIRECTIONALITY LOGIC:
 *   Policy institutions are structural beneficiaries—the framework vindicates their authority to optimize energy systems and dismisses objections as decision-theoretically confused. Fossil and nuclear industries benefit asymmetrically: fossil gains from diffuse mortality being probability-diluted across large energy production, nuclear gains from catastrophic risk being probability-discounted. Populations bearing continuous distributed deaths are full targets—their harm enters with probability 1.0. Populations bearing potential catastrophic harm are targets whose harm is structurally minimized by the probability discount. Catastrophic risk theorists are excluded rather than coordinated—their alternative frameworks would destabilize the beneficiaries' legitimacy.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint presents as neutral mathematical optimization—expected utility theory applied to energy policy. But expected-value dominance is one normative choice among several coherent decision frameworks. The mandate (compare energy risks) has not outlived its function, but the particular solution (minimize probability-weighted aggregate harm) advantages identifiable parties: industries with diffuse mortality profiles, institutions whose authority rests on claiming neutral optimization, and nuclear advocates whose safety case depends on discounting tail risk. The theater ratio rises as more analytical effort goes to defending expected-value framing against alternatives rather than improving underlying mortality measurements. Resistance comes from those whose harm is structurally minimized and from theorists proposing equally rigorous alternatives. This is not a mandatrophy (the risk comparison problem persists) but a contested solution space where one reading has captured institutional authority.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    decision_theory_naturalization,
    'Is expected utility maximization a neutral mathematical framework for risk comparison, or a normative choice that advantages certain risk profiles over others?',
    'Demonstration that alternative decision frameworks (minimax regret, precautionary principles, lexicographic preferences) produce systematically different energy pathway rankings, combined with philosophical analysis of whether any single framework can be decision-theoretically privileged for all risk contexts.',
    'If expected-value maximization is one choice among several coherent frameworks, the constraint is constructed rather than natural—its adoption advantages identifiable beneficiaries. If it is uniquely decision-theoretically sound, the mountain claim is vindicated and asymmetric impacts are inherent to rational policy.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(decision_theory_naturalization, conceptual, 'Whether expected utility dominance is mathematical necessity or constructed choice in contested normative space').

omega_variable(
    catastrophic_probability_estimation,
    'Are the probability estimates used to discount catastrophic nuclear events empirically grounded or systematically biased by institutional incentives to minimize tail risk?',
    'Independent analysis of how nuclear accident probabilities are derived—comparison of industry estimates, regulatory estimates, and post-accident Bayesian updates; examination of whether probability estimates systematically declined as nuclear advocacy intensified.',
    'If catastrophic probabilities are systematically underestimated, the expected-value calculation itself is corrupted by beneficiary influence and the framework''s claim to neutral optimization fails. If probabilities are empirically sound, low expected harm from nuclear is genuine.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(catastrophic_probability_estimation, empirical, 'Whether probability inputs to expected-value calculation are empirically sound or beneficiary-influenced').

omega_variable(
    mortality_commensurability,
    'Is mortality-per-TWh a neutral common unit for comparing energy risks, or does converting diverse harms to a single metric embed normative choices about what kinds of deaths matter?',
    'Ethical analysis of whether aggregating continuous distributed deaths (air pollution) with rare catastrophic deaths (reactor meltdown) into one sum treats fundamentally different harms as commensurable when they differ in concentration, voluntariness, and reversibility.',
    'If mortality-per-TWh is constructed aggregation that erases morally relevant differences between harm types, the metric itself advantages diffuse-harm pathways regardless of total deaths. If all deaths are commensurable, aggregate minimization is neutral.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(mortality_commensurability, conceptual, 'Whether aggregating heterogeneous mortality into one metric is neutral measurement or normative choice').

omega_variable(
    institutional_path_dependence,
    'Did policy institutions adopt expected-value dominance because it is decision-theoretically superior, or because early adoption by nuclear-advocating bodies created path dependence that locked out alternative frameworks?',
    'Historical analysis of when and by whom mortality-per-TWh became the standard metric; examination of whether institutions with pre-existing nuclear commitments were early adopters and whether they actively suppressed alternative risk frameworks.',
    'If expected-value dominance spread through institutional path dependence rather than decision-theoretic superiority, the framework''s naturalization is a historical artifact of beneficiary influence. If adoption tracks decision-theoretic consensus independent of beneficiary pressure, the mountain claim is supported.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(institutional_path_dependence, empirical, 'Whether framework dominance arose from decision-theoretic merit or institutional path dependence').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(acceptable_risk_energy__expected_value_dominant, 0, 40).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(acce_tr_t0, acceptable_risk_energy__expected_value_dominant, theater_ratio, 0, 0.28).
narrative_ontology:measurement(acce_tr_t8, acceptable_risk_energy__expected_value_dominant, theater_ratio, 8, 0.32).
narrative_ontology:measurement(acce_tr_t16, acceptable_risk_energy__expected_value_dominant, theater_ratio, 16, 0.36).
narrative_ontology:measurement(acce_tr_t24, acceptable_risk_energy__expected_value_dominant, theater_ratio, 24, 0.38).
narrative_ontology:measurement(acce_tr_t32, acceptable_risk_energy__expected_value_dominant, theater_ratio, 32, 0.4).
narrative_ontology:measurement(acce_tr_t40, acceptable_risk_energy__expected_value_dominant, theater_ratio, 40, 0.42).

% Extraction over time
narrative_ontology:measurement(acce_be_t0, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 0, 0.52).
narrative_ontology:measurement(acce_be_t8, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 8, 0.56).
narrative_ontology:measurement(acce_be_t16, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 16, 0.61).
narrative_ontology:measurement(acce_be_t24, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 24, 0.64).
narrative_ontology:measurement(acce_be_t32, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 32, 0.66).
narrative_ontology:measurement(acce_be_t40, acceptable_risk_energy__expected_value_dominant, base_extractiveness, 40, 0.68).

% Suppression requirement over time
narrative_ontology:measurement(acce_su_t0, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 0, 0.64).
narrative_ontology:measurement(acce_su_t8, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 8, 0.67).
narrative_ontology:measurement(acce_su_t16, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 16, 0.7).
narrative_ontology:measurement(acce_su_t24, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 24, 0.72).
narrative_ontology:measurement(acce_su_t32, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 32, 0.74).
narrative_ontology:measurement(acce_su_t40, acceptable_risk_energy__expected_value_dominant, suppression_requirement, 40, 0.76).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(acceptable_risk_energy__expected_value_dominant, information_standard).
narrative_ontology:affects_constraint(acceptable_risk_energy__expected_value_dominant, acceptable_risk_energy__catastrophic_tail_dominant).
narrative_ontology:affects_constraint(acceptable_risk_energy__expected_value_dominant, acceptable_risk_energy__option_value_preserving).

% DUAL FORMULATION NOTE:
% Part of acceptable_risk_energy kernel family. This constraint instantiates the expected_value_dominant reading. Sibling constraints instantiate catastrophic_tail_dominant and option_value_preserving readings. All three readings share the founding problem (comparing heterogeneous energy risks) but operationalize acceptable risk through incompatible frameworks. Expected-value dominance produces different victim sets and beneficiary structures than tail-risk or option-value frameworks because it systematically discounts low-probability catastrophic harm.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
