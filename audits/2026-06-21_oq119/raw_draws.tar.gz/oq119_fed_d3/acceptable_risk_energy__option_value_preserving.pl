% ============================================================================
% CONSTRAINT STORY: acceptable_risk_energy__option_value_preserving
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_acceptable_risk_energy__option_value_preserving, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: acceptable_risk_energy__option_value_preserving
 *   human_readable: Option-Value-Preserving Energy Risk Assessment
 *   domain: risk_assessment/energy_policy/decision_theory
 *
 * SUMMARY:
 *   Energy policy under deep uncertainty can be framed through multiple risk
 *   lenses. The option-value-preserving reading treats acceptable risk as
 *   maintaining multiple generation pathways simultaneously to preserve
 *   decision flexibility before long-term costs and technological feasibility
 *   are fully known. This reading grounds itself in real-options reasoning
 *   and Knightian uncertainty—the claim that energy-system outcomes are not
 *   merely probabilistically uncertain but fundamentally unpredictable. The
 *   constraint is CLAIMED as mountain (a foundational feature of rational
 *   decision-making under irreversible uncertainty) while the authored
 *   metrics describe moderate extraction, active enforcement, and rising
 *   suppression—the divergence is the measurement the framework exists to
 *   take.
 *
 * KEY AGENTS:
 *   - energy_portfolio_managers: Agenda-setters (institutional/mobile) who design national energy strategy and benefit from maintaining diverse dispatch options
 *   - industrial_consumers: Beneficiaries (organized/constrained) who gain from supply reliability and price stability under portfolio diversity
 *   - future_generations: Beneficiaries (powerless/trapped) who inherit maintained optionality but also accumulating climate and waste costs
 *   - climate_activists: Payers (organized/constrained) whose transition urgency is treated as one tail to hedge against rather than a planning mandate
 *   - nuclear_phase_out_advocates: Payers (organized/constrained) whose closure advocacy is blocked by the option-value framework
 *   - communities_near_existing_facilities: Payers (powerless/trapped) who bear localized health and environmental costs of kept-open facilities
 *   - renewable_energy_advocates: Excluded (organized/constrained) whose accelerated single-pathway position is structurally outside the framework's uncertainty premise
 *   - decision_theorists: Observers (analytical/analytical) who study the framework's distributional effects and framing power
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(acceptable_risk_energy__option_value_preserving, 0.38).
domain_priors:suppression_score(acceptable_risk_energy__option_value_preserving, 0.52).
domain_priors:theater_ratio(acceptable_risk_energy__option_value_preserving, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, extractiveness, 0.38).
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, suppression_requirement, 0.52).
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, accessibility_collapse, 0.42).
narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, resistance, 0.58).

% --- Constraint claim ---
narrative_ontology:constraint_claim(acceptable_risk_energy__option_value_preserving, mountain).
narrative_ontology:human_readable(acceptable_risk_energy__option_value_preserving, "Option-Value-Preserving Energy Risk Assessment").
narrative_ontology:topic_domain(acceptable_risk_energy__option_value_preserving, "risk_assessment/energy_policy/decision_theory").

domain_priors:requires_active_enforcement(acceptable_risk_energy__option_value_preserving).
domain_priors:emerges_naturally(acceptable_risk_energy__option_value_preserving).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(acceptable_risk_energy__option_value_preserving, '9e3c3cce-4b11-4085-a135-9861074f1f3b').
narrative_ontology:cs_kernel_codification('9e3c3cce-4b11-4085-a135-9861074f1f3b', distributed).
narrative_ontology:cs_authority_grounding('9e3c3cce-4b11-4085-a135-9861074f1f3b', expertise).
narrative_ontology:cs_interpretation_layer_present('9e3c3cce-4b11-4085-a135-9861074f1f3b').
narrative_ontology:cs_reading_relation('9e3c3cce-4b11-4085-a135-9861074f1f3b', acceptable_risk_energy__catastrophic_tail_dominant, coexists_with).
narrative_ontology:cs_reading_relation('9e3c3cce-4b11-4085-a135-9861074f1f3b', acceptable_risk_energy__expected_value_dominant, coexists_with).
narrative_ontology:cs_axiom('9e3c3cce-4b11-4085-a135-9861074f1f3b', foundational, irreducible_uncertainty_justifies_option_preservation).
narrative_ontology:cs_axiom_status(irreducible_uncertainty_justifies_option_preservation, holdable).
narrative_ontology:cs_axiom_grounding('9e3c3cce-4b11-4085-a135-9861074f1f3b', irreducible_uncertainty_justifies_option_preservation, empirically_contingent).
narrative_ontology:cs_axiom('9e3c3cce-4b11-4085-a135-9861074f1f3b', secondary, flexibility_value_exceeds_delay_costs).
narrative_ontology:cs_axiom_status(flexibility_value_exceeds_delay_costs, holdable).
narrative_ontology:cs_axiom_grounding('9e3c3cce-4b11-4085-a135-9861074f1f3b', flexibility_value_exceeds_delay_costs, instrumental).
narrative_ontology:cs_reference_frame('9e3c3cce-4b11-4085-a135-9861074f1f3b', knightian_uncertainty_irreversibility_portfolio_theory).
narrative_ontology:cs_drift_state('9e3c3cce-4b11-4085-a135-9861074f1f3b', post_renewable_cost_decline_era, gap(axiom_overriding, substantial, false)).
narrative_ontology:cs_created_at('9e3c3cce-4b11-4085-a135-9861074f1f3b', '').
narrative_ontology:cs_kernel_id(acceptable_risk_energy__option_value_preserving, acceptable_risk_energy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__option_value_preserving, energy_portfolio_managers).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__option_value_preserving, industrial_consumers).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__option_value_preserving, future_generations).
narrative_ontology:constraint_victim(acceptable_risk_energy__option_value_preserving, climate_activists).
narrative_ontology:constraint_victim(acceptable_risk_energy__option_value_preserving, nuclear_phase_out_advocates).
narrative_ontology:constraint_victim(acceptable_risk_energy__option_value_preserving, communities_near_existing_facilities).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__option_value_preserving, knightian_uncertainty_real_options_doctrine).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__option_value_preserving, portfolio_theory_irreversibility).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Design and maintain national energy strategies balancing multiple generation sources. They frame keeping both nuclear and fossil capacity online as prudent hedging against technological, geopolitical, and climate uncertainty. They benefit from having multiple dispatch options and avoid being locked into a single pathway that might prove infeasible or prohibitively expensive under future conditions.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, energy_portfolio_managers, agenda_setter,
    institutional, generational, mobile, national).

% Require reliable baseload power at predictable costs. They benefit from portfolio diversity reducing price volatility and supply disruption risk. The option-value framework protects them from scenarios where rapid closure of conventional sources forces energy costs sharply upward or introduces reliability gaps that renewables alone cannot yet fill.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, industrial_consumers, beneficiary,
    organized, biographical, constrained, national).

% Inherit whatever energy infrastructure and climate state current decisions produce. They benefit from maintained optionality: if one pathway proves unexpectedly harmful or another unexpectedly viable, the option to pivot remains. Premature closure of pathways forecloses choices they would need under conditions we cannot predict.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, future_generations, beneficiary,
    powerless, civilizational, trapped, global).

% Advocate for immediate fossil fuel phase-out to minimize climate risk. The option-preservation framing treats their urgency as one tail to hedge against rather than a definitive mandate, which delays the transition they argue is necessary. They bear the cost of continued emissions while portfolio managers wait for uncertainty to resolve.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, climate_activists, payer,
    organized, generational, constrained, global).

% Advocate for closing nuclear facilities based on accident risk and waste concerns. The option-value framework treats nuclear as a hedge worth keeping available, which blocks their preferred immediate closure. They bear ongoing anxiety about catastrophic accident risk and waste accumulation while the framework frames keeping that pathway open as rational uncertainty management.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, nuclear_phase_out_advocates, payer,
    organized, generational, constrained, national).

% Live with the localized environmental and health risks of fossil and nuclear facilities that the portfolio framework keeps operating. They bear the direct costs—air pollution, accident risk, waste storage proximity—while the option-value calculus treats these as acceptable distributed harms worth incurring to preserve national flexibility.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, communities_near_existing_facilities, payer,
    powerless, biographical, trapped, local).

% Argue that aggressive renewable deployment with storage makes the conventional-pathway hedge unnecessary. Their position is structurally excluded by the framework's core premise: that uncertainty is deep enough to justify maintaining all pathways. They would advocate for accelerated single-pathway commitment if their voice were weighted equally in the risk calculus.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, renewable_energy_advocates, excluded,
    organized, generational, constrained, global).

% Study how real-options reasoning under Knightian uncertainty applies to irreversible infrastructure decisions. They observe that the option-value framework privileges a specific uncertainty framing—one where maintaining flexibility is rational—and note that this framing itself distributes costs asymmetrically across stakeholders with different time horizons and risk exposures.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__option_value_preserving, decision_theorists, observer,
    analytical, civilizational, analytical, universal).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Coordinates energy policy under deep uncertainty by maintaining multiple generation pathways simultaneously, preventing premature lock-in to any single technology before long-term viability and externality costs are fully known.
% TRANSFER_FUNCTION: Transfers localized environmental and health costs from conventional facilities to nearby communities, and transfers climate-transition delay costs to climate-concerned constituencies, in exchange for national-level supply reliability and flexibility for industrial consumers and portfolio managers.
% ABSENT_VOICES: Renewable-only transition advocates and those prioritizing immediate climate action over optionality are structurally excluded—their position is treated as one tail to hedge against rather than a central planning assumption.
% DISAPPEARANCE_RATIONALE: If this risk framework disappeared, energy policy would reorganize around either aggressive single-pathway commitment (renewable-only or nuclear-heavy strategies) or expected-value optimization (mortality-per-TWh metrics driving coal phase-out). Portfolio managers would lose their primary justification for maintaining diverse baseload capacity, and the constituencies currently bearing localized costs would gain leverage to demand facility closure.
% FOUNDING_PROBLEM: Mid-20th-century energy planning faced genuine technological uncertainty across coal, nuclear, hydro, and emerging renewables, with no clear winner and irreversible infrastructure commitments required decades before outcomes would be known.
% FOUNDING_PROBLEM_CORROBORATION: Portfolio managers and industrial planning bodies attest the founding problem remains live, citing continued uncertainty about renewable storage scalability, nuclear fusion viability, and climate scenario severity. Climate scientists and renewable technology analysts—from outside the benefiting industrial-planning complex—attest the technological uncertainty has substantially resolved in favor of renewable pathways, and that the option-value framework now primarily serves to delay transition rather than manage genuine irreducible uncertainty.
narrative_ontology:disappearance_verdict(acceptable_risk_energy__option_value_preserving, world_rearranges).
narrative_ontology:founding_problem_status(acceptable_risk_energy__option_value_preserving, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(acceptable_risk_energy__option_value_preserving, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(acceptable_risk_energy__option_value_preserving, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(acceptable_risk_energy__option_value_preserving_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, ExtMetricName, E),
    domain_priors:suppression_score(acceptable_risk_energy__option_value_preserving, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(acceptable_risk_energy__option_value_preserving),
    narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(acceptable_risk_energy__option_value_preserving, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(acceptable_risk_energy__option_value_preserving_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is moderate (0.38) because the framework distributes real costs—localized pollution, accident risk, climate transition delay—to specific constituencies while concentrating flexibility benefits with portfolio managers and industrial consumers. Suppression is moderate-high (0.52) because maintaining the framework requires actively marginalizing both climate-urgency advocates and nuclear-closure advocates, treating both as 'extremes' whose positions would foreclose options. Theater ratio is moderate-low (0.28) because genuine technological uncertainty existed historically, but a growing share of option-value rhetoric now defends status-quo facility operation rather than managing irreducible unknowns. Accessibility collapse is moderate-low (0.42) because alternative risk frameworks—expected-value optimization, catastrophic-tail prioritization—remain intellectually available and policy-contested. Resistance is moderate-high (0.58) because both excluded constituencies actively contest the framework's distributional effects and uncertainty premises. The measurement series shows all three metrics rising over the 40-year interval as renewable technology matured and climate science converged, yet the option-value framework persisted and intensified its suppression of single-pathway advocacy.
 *
 * PERSPECTIVAL GAP:
 *   From the portfolio-manager seat, the constraint operates as genuine rational hedging—keeping options open under irreducible uncertainty is decision-theoretically sound and benefits future flexibility. From the climate-activist and community-payer seats, the same structure operates as enforced extraction: real present harms (emissions, pollution, accident risk) are imposed to preserve an optionality that primarily benefits institutional actors with mobile capital. The engine computes this seat-divergence from the structural data; the authored mountain claim does not adjudicate it.
 *
 * DIRECTIONALITY LOGIC:
 *   Portfolio managers are structural beneficiaries (collect decision flexibility, mobile exit from any particular facility). Industrial consumers benefit from reliability and price stability. Future generations are positioned as beneficiaries in the framework's own rhetoric but also bear accumulating irreversible costs—a genuinely ambiguous directionality the omega variables address. Climate activists, nuclear-closure advocates, and facility-adjacent communities are clear payers: they bear the costs the framework distributes to preserve national flexibility. Renewable advocates are excluded rather than coordinated. Decision theorists occupy the analytical seat.
 *
 * MANDATROPHY ANALYSIS:
 *   The framework's mandate—preserve flexibility under deep uncertainty—remains live in the portfolio managers' framing but is increasingly contested by climate science convergence and renewable cost-decline data. The Mandatrophy question is whether the option-value premise still tracks genuine irreducible uncertainty or now primarily serves to justify delay. The measurements show extraction and suppression rising as the technological and climate-science pictures clarified, which is the opposite trajectory a purely coordination-driven framework would show.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    uncertainty_resolution_timing,
    'Has the deep technological uncertainty that originally justified the option-value framework been substantially resolved by renewable cost decline and climate science convergence, or does irreducible uncertainty remain sufficient to justify maintaining all pathways?',
    'Independent meta-analysis of renewable grid-integration studies, storage cost trajectories, and climate model convergence. If renewable-plus-storage pathways now show comparable or lower long-term cost and risk than fossil-plus-nuclear portfolios under most scenarios, the founding uncertainty has resolved.',
    'If uncertainty has resolved, the framework''s continued operation is extractive capture rather than rational hedging—it imposes present harms to preserve an optionality no longer justified by the information state. If uncertainty remains irreducible, the framework''s distributional effects are the price of genuine prudence.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(uncertainty_resolution_timing, empirical, 'Whether the founding deep uncertainty has been resolved by subsequent evidence.').

omega_variable(
    future_generations_directionality,
    'Are future generations net beneficiaries of maintained energy-pathway optionality, or net victims of the accumulating irreversible costs (climate change, nuclear waste, fossil infrastructure lock-in) that maintaining those options imposes?',
    'Intergenerational accounting that compares the option value of maintained flexibility against the irreversible costs imposed by delay. The resolution depends on discount rates, climate scenario likelihoods, and technological breakthrough probabilities—all of which are contested.',
    'If future generations are net victims, the framework''s rhetoric of prudent hedging is a cover story for present-generation extraction from the future. If they are net beneficiaries, the framework genuinely serves civilizational-scale coordination despite its present distributional costs.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(future_generations_directionality, preference, 'Net directionality for future generations under the option-value framework.').

omega_variable(
    naturalness_vs_constructed_framing,
    'Is the option-value-preserving risk framework a natural feature of rational decision-making under Knightian uncertainty (mountain), or a constructed framing that benefits institutional actors with mobile capital by deferring irreversible commitments (tangled rope or snare)?',
    'Cross-domain analysis: do other high-stakes irreversible decisions under uncertainty (biosecurity, geoengineering, AI development) converge on option-preservation as the natural risk framework, or do they adopt alternative framings (precautionary principle, expected-value optimization, catastrophic-tail prioritization) depending on who controls the framing?',
    'If the framework is natural, its distributional effects are unavoidable costs of rational hedging. If it is constructed, the mountain claim is a false summit—the framework''s apparent rationality legitimizes extraction from powerless constituencies to benefit mobile institutional actors.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(naturalness_vs_constructed_framing, conceptual, 'Whether the option-value framework is a natural feature of rational uncertainty management or a constructed framing that distributes costs asymmetrically.').

omega_variable(
    committer_frame_kernel_ambiguity,
    'Are the three declared readings of the acceptable_risk_energy kernel truly distinct ε-invariant constraints, or are they observer-relative framings of a single contested constraint whose ε depends on which reading the observer adopts?',
    'Test whether the beneficiary sets, victim sets, and enforcement mechanisms differ across readings. If the readings instantiate different constraints with different structural relationships and different parties, they are distinct constraints. If the readings are interpretive lenses on a single beneficiary/victim structure with one stable enforcement mechanism, they are observer framings of one constraint and should be decomposed differently.',
    'If the readings are truly distinct constraints, the kernel decomposition is valid and the committer frame captures real structural plurality. If they are observer framings, the kernel itself is the constraint and the readings are perspectival variations—a different authoring pattern is required.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(committer_frame_kernel_ambiguity, conceptual, 'Whether the declared readings instantiate distinct constraints or observer-relative framings of one constraint.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(acceptable_risk_energy__option_value_preserving, 0, 40).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(acce_tr_t0, acceptable_risk_energy__option_value_preserving, theater_ratio, 0, 0.15).
narrative_ontology:measurement_basis(acce_tr_t0, observed).
narrative_ontology:measurement(acce_tr_t8, acceptable_risk_energy__option_value_preserving, theater_ratio, 8, 0.18).
narrative_ontology:measurement_basis(acce_tr_t8, observed).
narrative_ontology:measurement(acce_tr_t16, acceptable_risk_energy__option_value_preserving, theater_ratio, 16, 0.21).
narrative_ontology:measurement_basis(acce_tr_t16, observed).
narrative_ontology:measurement(acce_tr_t24, acceptable_risk_energy__option_value_preserving, theater_ratio, 24, 0.24).
narrative_ontology:measurement_basis(acce_tr_t24, observed).
narrative_ontology:measurement(acce_tr_t32, acceptable_risk_energy__option_value_preserving, theater_ratio, 32, 0.26).
narrative_ontology:measurement_basis(acce_tr_t32, observed).
narrative_ontology:measurement(acce_tr_t40, acceptable_risk_energy__option_value_preserving, theater_ratio, 40, 0.28).
narrative_ontology:measurement_basis(acce_tr_t40, observed).

% Extraction over time
narrative_ontology:measurement(acce_be_t0, acceptable_risk_energy__option_value_preserving, base_extractiveness, 0, 0.22).
narrative_ontology:measurement_basis(acce_be_t0, observed).
narrative_ontology:measurement(acce_be_t8, acceptable_risk_energy__option_value_preserving, base_extractiveness, 8, 0.26).
narrative_ontology:measurement_basis(acce_be_t8, observed).
narrative_ontology:measurement(acce_be_t16, acceptable_risk_energy__option_value_preserving, base_extractiveness, 16, 0.31).
narrative_ontology:measurement_basis(acce_be_t16, observed).
narrative_ontology:measurement(acce_be_t24, acceptable_risk_energy__option_value_preserving, base_extractiveness, 24, 0.35).
narrative_ontology:measurement_basis(acce_be_t24, observed).
narrative_ontology:measurement(acce_be_t32, acceptable_risk_energy__option_value_preserving, base_extractiveness, 32, 0.37).
narrative_ontology:measurement_basis(acce_be_t32, observed).
narrative_ontology:measurement(acce_be_t40, acceptable_risk_energy__option_value_preserving, base_extractiveness, 40, 0.38).
narrative_ontology:measurement_basis(acce_be_t40, observed).

% Suppression requirement over time
narrative_ontology:measurement(acce_su_t0, acceptable_risk_energy__option_value_preserving, suppression_requirement, 0, 0.35).
narrative_ontology:measurement_basis(acce_su_t0, observed).
narrative_ontology:measurement(acce_su_t8, acceptable_risk_energy__option_value_preserving, suppression_requirement, 8, 0.4).
narrative_ontology:measurement_basis(acce_su_t8, observed).
narrative_ontology:measurement(acce_su_t16, acceptable_risk_energy__option_value_preserving, suppression_requirement, 16, 0.44).
narrative_ontology:measurement_basis(acce_su_t16, observed).
narrative_ontology:measurement(acce_su_t24, acceptable_risk_energy__option_value_preserving, suppression_requirement, 24, 0.47).
narrative_ontology:measurement_basis(acce_su_t24, observed).
narrative_ontology:measurement(acce_su_t32, acceptable_risk_energy__option_value_preserving, suppression_requirement, 32, 0.5).
narrative_ontology:measurement_basis(acce_su_t32, observed).
narrative_ontology:measurement(acce_su_t40, acceptable_risk_energy__option_value_preserving, suppression_requirement, 40, 0.52).
narrative_ontology:measurement_basis(acce_su_t40, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(acceptable_risk_energy__option_value_preserving, resource_allocation).
narrative_ontology:affects_constraint(acceptable_risk_energy__option_value_preserving, acceptable_risk_energy__catastrophic_tail_dominant).
narrative_ontology:affects_constraint(acceptable_risk_energy__option_value_preserving, acceptable_risk_energy__expected_value_dominant).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the acceptable_risk_energy kernel. The option_value_preserving reading maintains all pathways and distributes costs to advocacy groups and local communities. The catastrophic_tail_dominant reading would close high-tail-risk pathways (nuclear or fossil depending on which tail is prioritized). The expected_value_dominant reading would aggressively close coal based on mortality-per-TWh data. The three readings share a contested kernel but produce different beneficiary/victim structures and different policy outcomes.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
