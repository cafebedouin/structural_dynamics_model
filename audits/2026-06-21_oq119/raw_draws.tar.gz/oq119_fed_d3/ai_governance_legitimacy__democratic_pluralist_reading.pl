% ============================================================================
% CONSTRAINT STORY: ai_governance_legitimacy__democratic_pluralist_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_ai_governance_legitimacy__democratic_pluralist_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: ai_governance_legitimacy__democratic_pluralist_reading
 *   human_readable: Democratic Pluralist AI Governance Legitimacy
 *   domain: theological_ethics/technology_governance/political_theology
 *
 * SUMMARY:
 *   Democratic pluralist legitimacy for AI governance treats the encyclical
 *   as one contributory voice in public deliberation, not as authoritative
 *   doctrine. No single tradition—religious or technocratic—holds
 *   interpretive monopoly. Principles emerge through inclusive processes
 *   balancing diverse values. The constraint is CLAIMED as a mountain
 *   (foundational feature of legitimate governance in pluralist societies)
 *   while metrics describe moderate extraction and active enforcement—the
 *   engine measures this divergence. The claim asserts popular sovereignty as
 *   a natural principle; the metrics describe its implementation costs.
 *
 * KEY AGENTS:
 *   - civil_society_organizations: Primary beneficiaries (organized/mobile) — gain institutional voice in deliberative processes
 *   - democratic_institutions: Agenda setters (institutional/constrained) — convene and facilitate deliberation
 *   - minority_rights_holders: Beneficiaries (moderate/constrained) — protected through judicial review and pluralist norms
 *   - excluded_populations: Victims (powerless/trapped) — bear costs when access barriers persist
 *   - authoritarian_regime_populations: Victims (powerless/trapped) — subject to decisions without consent
 *   - religious_authorities: Excluded seat (institutional/mobile) — contribute but hold no monopoly
 *   - technocratic_elites: Excluded seat (powerful/arbitrage) — constrained from optimization monopoly
 *   - political_theorists: Analytical observers — measure deliberative capacity
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(ai_governance_legitimacy__democratic_pluralist_reading, 0.4).
domain_priors:suppression_score(ai_governance_legitimacy__democratic_pluralist_reading, 0.35).
domain_priors:theater_ratio(ai_governance_legitimacy__democratic_pluralist_reading, 0.28).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, extractiveness, 0.4).
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 0.35).
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 0.28).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, accessibility_collapse, 0.25).
narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, resistance, 0.55).

% --- Constraint claim ---
narrative_ontology:constraint_claim(ai_governance_legitimacy__democratic_pluralist_reading, mountain).
narrative_ontology:human_readable(ai_governance_legitimacy__democratic_pluralist_reading, "Democratic Pluralist AI Governance Legitimacy").
narrative_ontology:topic_domain(ai_governance_legitimacy__democratic_pluralist_reading, "theological_ethics/technology_governance/political_theology").

domain_priors:requires_active_enforcement(ai_governance_legitimacy__democratic_pluralist_reading).
domain_priors:emerges_naturally(ai_governance_legitimacy__democratic_pluralist_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(ai_governance_legitimacy__democratic_pluralist_reading, '1cdec921-0e1c-4772-be28-3792d9e9c60f').
narrative_ontology:cs_kernel_codification('1cdec921-0e1c-4772-be28-3792d9e9c60f', distributed).
narrative_ontology:cs_authority_grounding('1cdec921-0e1c-4772-be28-3792d9e9c60f', practice).
narrative_ontology:cs_interpretation_layer_present('1cdec921-0e1c-4772-be28-3792d9e9c60f').
narrative_ontology:cs_reading_relation('1cdec921-0e1c-4772-be28-3792d9e9c60f', ai_governance_legitimacy__magisterial_subsidiarity_reading, coexists_with).
narrative_ontology:cs_reading_relation('1cdec921-0e1c-4772-be28-3792d9e9c60f', ai_governance_legitimacy__technocratic_optimization_reading, coexists_with).
narrative_ontology:cs_reading_relation('1cdec921-0e1c-4772-be28-3792d9e9c60f', ai_governance_legitimacy__market_libertarian_reading, coexists_with).
narrative_ontology:cs_axiom('1cdec921-0e1c-4772-be28-3792d9e9c60f', foundational, popular_sovereignty_grounds_ai_governance).
narrative_ontology:cs_axiom_status(popular_sovereignty_grounds_ai_governance, holdable).
narrative_ontology:cs_axiom_grounding('1cdec921-0e1c-4772-be28-3792d9e9c60f', popular_sovereignty_grounds_ai_governance, deontological).
narrative_ontology:cs_axiom('1cdec921-0e1c-4772-be28-3792d9e9c60f', foundational, no_interpretive_monopoly_over_dignity).
narrative_ontology:cs_axiom_status(no_interpretive_monopoly_over_dignity, holdable).
narrative_ontology:cs_axiom_grounding('1cdec921-0e1c-4772-be28-3792d9e9c60f', no_interpretive_monopoly_over_dignity, conventional).
narrative_ontology:cs_reference_frame('1cdec921-0e1c-4772-be28-3792d9e9c60f', postwar_democratic_constitutionalism).
narrative_ontology:cs_drift_state('1cdec921-0e1c-4772-be28-3792d9e9c60f', contemporary_ai_governance_era, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('1cdec921-0e1c-4772-be28-3792d9e9c60f', '').
narrative_ontology:cs_kernel_id(ai_governance_legitimacy__democratic_pluralist_reading, ai_governance_legitimacy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__democratic_pluralist_reading, civil_society_organizations).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__democratic_pluralist_reading, democratic_institutions).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__democratic_pluralist_reading, minority_rights_holders).
narrative_ontology:constraint_victim(ai_governance_legitimacy__democratic_pluralist_reading, excluded_populations).
narrative_ontology:constraint_victim(ai_governance_legitimacy__democratic_pluralist_reading, authoritarian_regime_populations).
narrative_ontology:constraint_vindicates(ai_governance_legitimacy__democratic_pluralist_reading, popular_sovereignty_doctrine).
narrative_ontology:constraint_vindicates(ai_governance_legitimacy__democratic_pluralist_reading, public_reason_principle).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Gain recognized voice in AI governance deliberation. Their advocacy for diverse values and marginalized interests is legitimated through participatory processes. They benefit from institutional channels that amplify grassroots concerns and constrain technocratic capture.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, civil_society_organizations, beneficiary,
    organized, generational, mobile, global).

% Establish and maintain deliberative frameworks for AI governance. They convene stakeholders, facilitate public reason, and translate consensus into policy. Their authority derives from electoral accountability and constitutional legitimacy, not from technical expertise or religious tradition.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, democratic_institutions, agenda_setter,
    institutional, generational, constrained, national).

% Protected from majoritarian technocratic overreach through judicial review and civil liberties frameworks. Their dignity claims are heard in deliberative forums where diverse values are balanced, rather than subordinated to a single interpretive tradition.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, minority_rights_holders, beneficiary,
    moderate, biographical, constrained, national).

% Bear costs when deliberative processes remain inaccessible due to barriers of language, literacy, digital infrastructure, or political marginalization. The constraint's coordination function depends on inclusive participation, but actual inclusion is incomplete.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, excluded_populations, payer,
    powerless, biographical, trapped, regional).

% Subject to AI governance decisions made without their consent or participation. The constraint's legitimacy principle operates as an unreachable norm in contexts where democratic deliberation is suppressed. They carry the extraction of governance without voice.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, authoritarian_regime_populations, payer,
    powerless, biographical, trapped, national).

% Contribute moral frameworks to public deliberation but hold no interpretive monopoly. Their doctrine is one voice among many, subject to democratic contestation. They would prefer authoritative interpretive status but are constrained by pluralist norms.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, religious_authorities, excluded,
    institutional, generational, mobile, global).

% Must justify technical decisions through public reason rather than expert authority alone. Their preferred governance mode—optimization unconstrained by diverse values—is subordinated to deliberative legitimacy. They retain influence but not monopoly.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, technocratic_elites, excluded,
    powerful, biographical, arbitrage, global).

% Analyze whether democratic deliberation can produce stable AI governance norms across value-diverse societies, or whether pluralism fragments into incommensurable frameworks. They measure the gap between deliberative ideals and implementation constraints.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__democratic_pluralist_reading, political_theorists, observer,
    analytical, civilizational, analytical, universal).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Produces legitimacy for AI governance through inclusive deliberation that balances diverse values: religious, secular humanist, utilitarian, rights-based. Coordinates across traditions without granting any single tradition interpretive monopoly.
% TRANSFER_FUNCTION: Shifts interpretive authority from concentrated elites (religious magisterium, technocratic experts) to distributed deliberative processes. Imposes procedural costs on all participants—time, transparency, compromise—as the price of legitimacy.
% ABSENT_VOICES: Populations under authoritarian regimes, digitally excluded communities, and future generations whose interests are systematically underweighted in present-tense deliberation. Religious authorities and technocratic elites are present but structurally constrained from monopoly.
% DISAPPEARANCE_RATIONALE: If this legitimacy principle vanished, AI governance would revert to technocratic optimization or religious authority as unconstrained interpretive frameworks. Civil society organizations would lose institutional voice, minority protections would weaken, and the encyclical would be read as binding doctrine rather than contributory input. Arrangements depend on the deliberative constraint.
% FOUNDING_PROBLEM: Mid-20th century recognition that modern technological governance affecting diverse populations cannot rest solely on traditional religious authority or technical expertise without democratic accountability. Built to solve legitimacy crises in pluralist societies.
% FOUNDING_PROBLEM_CORROBORATION: Political theorists outside beneficiary institutions, constitutional courts in democratic jurisdictions, and comparative governance studies document that AI governance without deliberative legitimacy produces sustained resistance and implementation failure. The founding problem remains contested by authoritarian regimes but is corroborated by civil liberties organizations and empirical studies of governance stability.
narrative_ontology:disappearance_verdict(ai_governance_legitimacy__democratic_pluralist_reading, world_rearranges).
narrative_ontology:founding_problem_status(ai_governance_legitimacy__democratic_pluralist_reading, live).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(ai_governance_legitimacy__democratic_pluralist_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(ai_governance_legitimacy__democratic_pluralist_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(ai_governance_legitimacy__democratic_pluralist_reading_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, ExtMetricName, E),
    domain_priors:suppression_score(ai_governance_legitimacy__democratic_pluralist_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(ai_governance_legitimacy__democratic_pluralist_reading),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__democratic_pluralist_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(ai_governance_legitimacy__democratic_pluralist_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness (0.40) is moderate because deliberative processes impose real costs—time, transparency, compromise, procedural burdens—on all participants, even as they produce coordination benefits. The extraction is highest for excluded populations who bear governance costs without voice. Suppression (0.35) reflects active enforcement of pluralist norms against monopolistic interpretive claims, whether religious or technocratic. Theater ratio (0.28) captures performative deliberation in contexts where real power remains concentrated. Accessibility collapse (0.25) is low—alternative governance frameworks (technocratic, religious, market-based) remain live options contested by powerful actors. Resistance (0.55) is substantial—authoritarian regimes, some religious authorities, and technocratic elites actively resist deliberative constraints on their interpretive monopolies.
 *
 * PERSPECTIVAL GAP:
 *   Democratic institutions experience this as legitimating coordination they built and maintain—low effective extraction. Excluded populations experience it as governance without consent—high effective extraction. Technocratic elites and religious authorities experience constraint on their preferred monopoly interpretations—moderate extraction relative to their foregone authority. The engine computes per-seat classifications from these structural differences; the mountain claim is not adjudicated by the authored metrics.
 *
 * DIRECTIONALITY LOGIC:
 *   Democratic institutions are agenda setters but not pure beneficiaries—they bear procedural costs while gaining legitimacy. Civil society organizations and minority rights holders are structural beneficiaries with low directionality toward extraction. Excluded populations and authoritarian regime populations are high-directionality victims—they bear governance costs without voice. Religious authorities and technocratic elites are structurally excluded from monopoly but retain partial influence—mixed directionality. The divergence is: from the democratic institutions' seat, the constraint is legitimating coordination; from excluded populations' seat, the same structure is governance extraction without consent.
 *
 * MANDATROPHY ANALYSIS:
 *   The coordination function is real—pluralist deliberation does produce stable governance norms across diverse value systems. But the extraction is also real—excluded populations bear costs without voice, deliberative access barriers persist, and enforcement against interpretive monopolies requires institutional power. This prevents mislabeling: not pure mountain (real victims exist), not pure rope (moderate suppression requirement), not snare (genuine coordination alongside extraction). The measurements show rising theater ratio, consistent with performative deliberation in captured contexts.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    natural_vs_constructed_legitimacy,
    'Is democratic legitimacy a natural feature of legitimate governance in pluralist societies (mountain), or a constructed arrangement that benefits civil society organizations and constrains religious/technocratic authority (tangled rope)?',
    'Cross-cultural governance stability analysis: if societies without deliberative frameworks experience sustained legitimacy crises that cannot be resolved through alternative governance modes, the principle is more mountain-like. If stable governance is achievable through religious or technocratic authority in value-diverse contexts, the principle is more constructed.',
    'If natural, the constraint''s moderate extraction represents unavoidable coordination costs. If constructed, the extraction accrues to democratic institutions and civil society as beneficiaries of a particular governance arrangement.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(natural_vs_constructed_legitimacy, empirical, 'Whether democratic legitimacy is foundational or one governance arrangement among alternatives').

omega_variable(
    deliberative_capacity_threshold,
    'What minimum threshold of inclusive participation must a deliberative process reach before it produces legitimate governance, versus performative theater that masks concentrated power?',
    'Comparative analysis of deliberative governance outcomes: measure correlation between inclusion metrics (access barriers, representation, voice uptake) and implementation stability. Identify threshold below which increased deliberation does not reduce resistance or improve compliance.',
    'Below threshold, rising theater ratio indicates the constraint operates as legitimation cover for extraction rather than genuine coordination. Above threshold, procedural costs are genuine coordination overhead.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(deliberative_capacity_threshold, empirical, 'Minimum inclusion threshold for deliberation to function as coordination vs theater').

omega_variable(
    reading_framing_underdetermination,
    'Does this reading''s democratic_pluralist framing capture the constraint''s operation, or does the magisterial_subsidiarity framing (religious authority) or technocratic_optimization framing (expert authority) better describe actual governance structures?',
    'Institutional analysis: which seat actually holds interpretive authority in implemented AI governance frameworks? If religious or technical authorities make binding determinations, this reading is aspirational rather than descriptive.',
    'If actual authority rests elsewhere, this constraint is a claimed principle rather than an operating structure—victims and beneficiaries shift to match the real authority distribution.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(reading_framing_underdetermination, conceptual, 'Whether democratic deliberation or alternative authority structures govern in practice').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(ai_governance_legitimacy__democratic_pluralist_reading, 0, 30).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(ai_g_tr_t0, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 0, 0.15).
narrative_ontology:measurement(ai_g_tr_t6, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 6, 0.18).
narrative_ontology:measurement(ai_g_tr_t12, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 12, 0.21).
narrative_ontology:measurement(ai_g_tr_t18, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 18, 0.24).
narrative_ontology:measurement(ai_g_tr_t24, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 24, 0.26).
narrative_ontology:measurement(ai_g_tr_t30, ai_governance_legitimacy__democratic_pluralist_reading, theater_ratio, 30, 0.28).

% Extraction over time
narrative_ontology:measurement(ai_g_be_t0, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 0, 0.32).
narrative_ontology:measurement(ai_g_be_t6, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 6, 0.35).
narrative_ontology:measurement(ai_g_be_t12, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 12, 0.37).
narrative_ontology:measurement(ai_g_be_t18, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 18, 0.39).
narrative_ontology:measurement(ai_g_be_t24, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 24, 0.4).
narrative_ontology:measurement(ai_g_be_t30, ai_governance_legitimacy__democratic_pluralist_reading, base_extractiveness, 30, 0.4).

% Suppression requirement over time
narrative_ontology:measurement(ai_g_su_t0, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 0, 0.25).
narrative_ontology:measurement(ai_g_su_t6, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 6, 0.28).
narrative_ontology:measurement(ai_g_su_t12, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 12, 0.3).
narrative_ontology:measurement(ai_g_su_t18, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 18, 0.32).
narrative_ontology:measurement(ai_g_su_t24, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 24, 0.34).
narrative_ontology:measurement(ai_g_su_t30, ai_governance_legitimacy__democratic_pluralist_reading, suppression_requirement, 30, 0.35).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(ai_governance_legitimacy__democratic_pluralist_reading, identity_coordination).
narrative_ontology:affects_constraint(ai_governance_legitimacy__democratic_pluralist_reading, ai_governance_legitimacy__magisterial_subsidiarity_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__democratic_pluralist_reading, ai_governance_legitimacy__technocratic_optimization_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__democratic_pluralist_reading, ai_governance_legitimacy__market_libertarian_reading).

% DUAL FORMULATION NOTE:
% This constraint is one reading within the ai_governance_legitimacy kernel family. All four readings address the same contested question—what grounds legitimate authority over AI governance—but instantiate different constraints with different beneficiary/victim structures and different enforcement mechanisms. The ε values diverge substantially: this reading shows moderate extraction (0.40) from deliberative costs and exclusion barriers; the magisterial reading would show higher extraction on non-Catholic populations subject to doctrine; the technocratic reading extracts from value-diverse populations subordinated to optimization; the market reading extracts from those without viable exit options. Network edges represent structural influence: democratic institutions' legitimacy claims constrain but do not foreclose religious and technocratic authority in pluralist contexts.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
