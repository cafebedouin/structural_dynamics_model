% ============================================================================
% CONSTRAINT STORY: westphalia_sovereignty__conditional_responsibility
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-01-15
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_westphalia_sovereignty__conditional_responsibility, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    constraint_indexing:directionality_override/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: westphalia_sovereignty__conditional_responsibility
 *   human_readable: Responsibility to Protect: Conditional Sovereignty Norm
 *   domain: international_law/political_theory
 *
 * SUMMARY:
 *   The Responsibility to Protect doctrine reconceptualizes sovereignty as
 *   conditional on state performance of protection duties toward populations.
 *   Emerging from post-Rwanda normative consensus, the doctrine authorizes
 *   international intervention when states commit or fail to prevent
 *   genocide, ethnic cleansing, crimes against humanity, or war crimes. The
 *   constraint is CLAIMED as mountain—proponents frame it as natural
 *   evolution of international law and universal human rights principles,
 *   inevitable moral architecture of the international system. The authored
 *   metrics describe substantially extractive, actively enforced operation
 *   with rising theater ratio and persistent resistance, documenting the gap
 *   between protection rhetoric and selective application patterns. The
 *   engine measures this claim-metric divergence; the divergence itself is
 *   the object of measurement.
 *
 * KEY AGENTS:
 *   - humanitarian_intervention_coalitions: Institutional agenda-setters (institutional/arbitrage) — control threshold determination and authorization machinery, benefit from selective application discretion
 *   - global_governance_institutions: Institutional beneficiaries (institutional/analytical) — gain adjudicative authority and expanded mandate without bearing intervention costs
 *   - populations_under_atrocity_threat: Powerless beneficiaries/payers (powerless/trapped) — nominal beneficiaries of protection doctrine, actual bearers of intervention costs and displacement
 *   - sovereignty_priority_states: Institutional payers (institutional/constrained) — lose juridical protection, territorial inviolability becomes contingent on external assessment
 *   - targeted_regime_governments: Powerful payers (powerful/trapped) — face intervention, prosecution, regime change with collapsed choice set once intervention declared
 *   - geopolitical_realist_scholars: Analytical observers (analytical/analytical) — document selective application and strategic capture of humanitarian justification
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(westphalia_sovereignty__conditional_responsibility, 0.62).
domain_priors:suppression_score(westphalia_sovereignty__conditional_responsibility, 0.71).
domain_priors:theater_ratio(westphalia_sovereignty__conditional_responsibility, 0.48).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, extractiveness, 0.62).
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, suppression_requirement, 0.71).
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, theater_ratio, 0.48).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, accessibility_collapse, 0.58).
narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, resistance, 0.74).

% --- Constraint claim ---
narrative_ontology:constraint_claim(westphalia_sovereignty__conditional_responsibility, mountain).
narrative_ontology:human_readable(westphalia_sovereignty__conditional_responsibility, "Responsibility to Protect: Conditional Sovereignty Norm").
narrative_ontology:topic_domain(westphalia_sovereignty__conditional_responsibility, "international_law/political_theory").

domain_priors:requires_active_enforcement(westphalia_sovereignty__conditional_responsibility).
domain_priors:emerges_naturally(westphalia_sovereignty__conditional_responsibility).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(westphalia_sovereignty__conditional_responsibility, '369f27ad-e50e-4997-acac-d8dfceb3e1d5').
narrative_ontology:cs_kernel_codification('369f27ad-e50e-4997-acac-d8dfceb3e1d5', formalized).
narrative_ontology:cs_authority_grounding('369f27ad-e50e-4997-acac-d8dfceb3e1d5', extraction).
narrative_ontology:cs_interpretation_layer_present('369f27ad-e50e-4997-acac-d8dfceb3e1d5').
narrative_ontology:cs_reading_relation('369f27ad-e50e-4997-acac-d8dfceb3e1d5', westphalia_sovereignty__absolute_non_intervention, influences).
narrative_ontology:cs_reading_relation('369f27ad-e50e-4997-acac-d8dfceb3e1d5', westphalia_sovereignty__graded_sovereignty, coexists_with).
narrative_ontology:cs_axiom('369f27ad-e50e-4997-acac-d8dfceb3e1d5', foundational, sovereignty_contingent_on_protection_performance).
narrative_ontology:cs_axiom_status(sovereignty_contingent_on_protection_performance, holdable).
narrative_ontology:cs_axiom_grounding('369f27ad-e50e-4997-acac-d8dfceb3e1d5', sovereignty_contingent_on_protection_performance, deontological).
narrative_ontology:cs_axiom('369f27ad-e50e-4997-acac-d8dfceb3e1d5', foundational, international_community_legitimate_arbiter).
narrative_ontology:cs_axiom_status(international_community_legitimate_arbiter, holdable).
narrative_ontology:cs_axiom_grounding('369f27ad-e50e-4997-acac-d8dfceb3e1d5', international_community_legitimate_arbiter, conventional).
narrative_ontology:cs_axiom('369f27ad-e50e-4997-acac-d8dfceb3e1d5', secondary, atrocity_threshold_overrides_territorial_immunity).
narrative_ontology:cs_axiom_status(atrocity_threshold_overrides_territorial_immunity, holdable).
narrative_ontology:cs_axiom_grounding('369f27ad-e50e-4997-acac-d8dfceb3e1d5', atrocity_threshold_overrides_territorial_immunity, deontological).
narrative_ontology:cs_reference_frame('369f27ad-e50e-4997-acac-d8dfceb3e1d5', westphalian_territorial_inviolability).
narrative_ontology:cs_drift_state('369f27ad-e50e-4997-acac-d8dfceb3e1d5', post_libya_intervention_era, gap(authority_erosion, substantial, false)).
narrative_ontology:cs_created_at('369f27ad-e50e-4997-acac-d8dfceb3e1d5', '').
narrative_ontology:cs_kernel_id(westphalia_sovereignty__conditional_responsibility, westphalia_sovereignty).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, humanitarian_intervention_coalitions).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, global_governance_institutions).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, international_criminal_court).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__conditional_responsibility, populations_under_atrocity_threat).
narrative_ontology:constraint_victim(westphalia_sovereignty__conditional_responsibility, sovereignty_priority_states).
narrative_ontology:constraint_victim(westphalia_sovereignty__conditional_responsibility, non_western_regional_blocs).
narrative_ontology:constraint_victim(westphalia_sovereignty__conditional_responsibility, targeted_regime_governments).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_victim(westphalia_sovereignty__conditional_responsibility, populations_under_atrocity_threat).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__conditional_responsibility, universal_human_rights_doctrine).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__conditional_responsibility, international_community_authority).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Permanent Security Council members and their allies who determine when atrocity thresholds are met and authorize intervention operations. They control the adjudicative machinery, decide which crises warrant response, and provide military capacity for enforcement. Their institutional position allows selective application: they intervene where geopolitically convenient while declining action where strategic interests conflict with protection mandates.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, humanitarian_intervention_coalitions, agenda_setter,
    institutional, generational, arbitrage, global).

% United Nations organs, regional security organizations, and international legal bodies that gain adjudicative authority over sovereignty disputes. The conditional sovereignty doctrine expands their mandate from observer to arbiter, shifting the locus of legitimacy from state consent to institutional determination. They benefit from enhanced relevance and expanded jurisdiction without bearing direct intervention costs.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, global_governance_institutions, beneficiary,
    institutional, civilizational, analytical, universal).

% Prosecutorial body whose jurisdiction expands when sovereignty is deemed conditional. When states forfeit protection from intervention, their officials simultaneously lose immunity from international prosecution. The doctrine provides legal foundation for indictments that would otherwise violate state sovereignty, creating enforcement pathway for universal jurisdiction claims.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, international_criminal_court, beneficiary,
    institutional, generational, analytical, global).

% Civilian populations facing genocide, ethnic cleansing, crimes against humanity, or war crimes whose own state fails to protect them. They are the nominal beneficiaries of the protection doctrine—intervention promises rescue from atrocity. They also bear the direct costs: military operations destroy infrastructure, create displacement, and sometimes cause civilian casualties. Their voice in determining whether intervention occurs or how it is conducted is effectively zero; they experience the outcome but do not participate in the decision.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, populations_under_atrocity_threat, beneficiary,
    powerless, immediate, trapped, local).
narrative_ontology:stakeholder_secondary_role(westphalia_sovereignty__conditional_responsibility, populations_under_atrocity_threat, payer).

% States outside the intervention coalition who view conditional sovereignty as erosion of Westphalian equality and a vehicle for selective Western interference. They pay through loss of juridical protection: their territorial inviolability becomes contingent on external assessment of their internal conduct. Most lack veto power in Security Council or capacity to resist intervention militarily, leaving them structurally vulnerable to selective application of protection standards.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, sovereignty_priority_states, payer,
    institutional, generational, constrained, national).

% African Union, ASEAN, Non-Aligned Movement, and other regional organizations that formally endorsed responsibility to protect principles but increasingly experience them as cover for intervention in their regions while atrocities in powerful states go unaddressed. They bear reputational and institutional costs: their regional autonomy is subordinated to global governance structures they did not design and cannot effectively veto.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, non_western_regional_blocs, payer,
    organized, generational, constrained, continental).

% Governments determined to have forfeited sovereignty through atrocity commission. They face military intervention, international prosecution of leadership, forced regime change, and post-intervention occupation. Their choice set collapses: they cannot exit the international system, cannot credibly defend against coalition intervention, and face personal criminal liability that makes negotiated settlement nearly impossible once intervention is declared.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, targeted_regime_governments, payer,
    powerful, biographical, trapped, national).

% International relations theorists and legal scholars who analyze the doctrine's selective application and identify the gap between protection rhetoric and intervention patterns. They document that intervention correlates with intervener strategic interests rather than atrocity severity, that powerful states never face responsibility to protect enforcement, and that the doctrine's institutional beneficiaries are primarily Western. They see the structure from outside but cannot alter its operation.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__conditional_responsibility, geopolitical_realist_scholars, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Solves the collective action problem of responding to mass atrocities: absent a doctrine authorizing intervention, states face a coordination failure where each waits for others to act while populations die. The conditional sovereignty norm establishes threshold criteria and institutional pathways for multilateral response.
% TRANSFER_FUNCTION: Transfers juridical authority from target states to international institutions and intervention coalitions: the power to determine legitimate government conduct, to override territorial sovereignty, to authorize military force, and to prosecute officials moves from sovereign states to global governance organs. Also transfers military and reconstruction costs to intervening states while concentrating decision authority in permanent Security Council members.
% ABSENT_VOICES: States that have been intervention targets but lack Security Council representation—Libya, Syria, Yugoslavia. Populations in ongoing atrocities where geopolitical factors block intervention—Yemen, Myanmar during certain periods, Xinjiang. Regional organizations from global South who endorsed the doctrine but now contest its application. These voices would testify that protection is selectively granted, that intervention often worsens humanitarian outcomes, and that the doctrine licenses regime change for strategic purposes under humanitarian cover.
% DISAPPEARANCE_RATIONALE: If the conditional sovereignty doctrine vanished, the international system would reorganize around competing principles: either pure non-intervention (Westphalian sovereignty) or explicit sphere-of-influence arrangements. Intervention coalitions would lose the legitimating framework that allows military action without formal UN authorization. Global governance institutions would contract to coordinating rather than adjudicating roles. States currently vulnerable to intervention would gain juridical protection regardless of internal conduct. The authority structure of the post-Cold War order depends on this doctrine.
% FOUNDING_PROBLEM: The Rwandan genocide and Srebrenica massacre demonstrated catastrophic failure of absolute non-intervention norms: the international community watched while 800,000 died in Rwanda and 8,000 in Bosnia because intervention would violate sovereignty. Kofi Annan's 'two sovereignties' speech and the International Commission on Intervention and State Sovereignty established responsibility to protect as response to this normative crisis.
% FOUNDING_PROBLEM_CORROBORATION: Intervention coalitions and global governance institutions attest the founding problem remains live, citing ongoing atrocities. Sovereignty-priority states and targeted regimes attest the doctrine has diverged from its founding purpose: rather than preventing Rwanda-scale catastrophes, it now authorizes regime change in strategic contexts (Libya 2011) while allowing equivalent or larger atrocities where intervention conflicts with great power interests (Syria, Yemen). Academic observers from international law and genocide studies document this divergence extensively—the protection justification is increasingly detached from protection outcomes. Multiple independent commissions and UN internal reviews confirm selective application.
narrative_ontology:disappearance_verdict(westphalia_sovereignty__conditional_responsibility, world_rearranges).
narrative_ontology:founding_problem_status(westphalia_sovereignty__conditional_responsibility, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(westphalia_sovereignty__conditional_responsibility, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(westphalia_sovereignty__conditional_responsibility, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(westphalia_sovereignty__conditional_responsibility_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(westphalia_sovereignty__conditional_responsibility, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, ExtMetricName, E),
    domain_priors:suppression_score(westphalia_sovereignty__conditional_responsibility, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(westphalia_sovereignty__conditional_responsibility),
    narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(westphalia_sovereignty__conditional_responsibility, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(westphalia_sovereignty__conditional_responsibility_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Base extractiveness rises from 0.38 to 0.62 over the 25-year interval as the doctrine's application increasingly diverges from atrocity prevention toward regime change in strategically convenient contexts. Early interventions (Kosovo, East Timor) more closely tracked protection logic; Libya 2011 marked inflection toward strategic application; subsequent non-intervention in Syria, Yemen, Myanmar demonstrates selectivity. Theater ratio climbs from 0.22 to 0.48 as protection rhetoric persists while intervention patterns track intervener interests rather than atrocity severity. Suppression requirement increases from 0.48 to 0.71 as the doctrine's enforcement depends on excluding sovereignty-priority voices from Security Council or overriding their objections through coalition action. Resistance remains high (0.74) because multiple state blocs and regional organizations actively contest the doctrine's legitimacy and application. Accessibility collapse is moderate (0.58) because alternative sovereignty frameworks remain conceptually available and regionally defended, though institutionally marginalized at global level.
 *
 * PERSPECTIVAL GAP:
 *   The constraint computes differently from distinct institutional positions. From the intervention coalition seat, the doctrine operates as legitimate authority to protect populations—coordination of collective response to atrocities with themselves as executors. From the sovereignty-priority state seat, the same structure operates as selective interference vehicle—juridical protection becomes contingent on external judgment they cannot control or reciprocate. From the targeted regime seat, it operates as existential threat—cascading loss of sovereignty, immunity, and survival once protection threshold is invoked. From the populations-under-atrocity seat, it is simultaneously promise of rescue and generator of intervention costs they cannot consent to or refuse. The engine computes these seat-specific types from the structural asymmetries in power, exit options, and beneficiary/victim positioning.
 *
 * DIRECTIONALITY LOGIC:
 *   Intervention coalitions are structural beneficiaries with arbitrage-grade exit: they decide when to invoke the doctrine, face no reciprocal vulnerability to intervention, and can decline action when strategic interests conflict with protection mandates. Their directionality sits near the beneficiary end. Global governance institutions are pure beneficiaries: they gain authority without bearing costs, with analytical exit from any particular application. Populations under atrocity threat are trapped powerless actors with dual positioning: they are the nominal beneficiaries (the doctrine promises protection) but also bear intervention's direct costs (military operations, displacement, infrastructure destruction). Their directionality depends on whether intervention actually occurs and succeeds—variable across cases but structurally they cannot exit and cannot effectively voice preferences in the decision. Sovereignty-priority states are institutional payers with constrained exit: they lose juridical protection and face subordination to global governance organs they cannot effectively veto, though they retain some defensive capacity through regional bloc coordination. Targeted regimes are powerful but trapped payers: once intervention is declared, their choice set collapses—they face military action, prosecution, and regime change with no credible exit path.
 *
 * MANDATROPHY ANALYSIS:
 *   The mandatrophy question is whether this constraint coordinates response to atrocities (rope) or extracts regime change authority under humanitarian cover (snare). The six-questions interview and R5 genealogy document the resolution: founding_problem_status is 'contested' with corroboration from outside beneficiaries establishing that the doctrine's application has diverged from its founding purpose. The disappearance_verdict is 'world_rearranges' because the authority structure of post-Cold War order depends on this doctrine—if it vanished, intervention legitimacy frameworks and global governance jurisdiction would collapse and reorganize. This is NOT a piton (no concentrated beneficiary maintains it through inertia; intervention coalitions actively defend and apply it) and NOT pure coordination (victims are named, selectivity is documented). The constraint genuinely solved a coordination problem at founding (Rwanda response failure) AND now concentrates authority in institutional actors who apply it selectively for strategic advantage. That dual structure is precisely what tangled_rope captures, but the CLAIM is mountain—the authored divergence between claimed natural law and measured extraction is the detection target.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    natural_law_vs_institutional_construction,
    'Is conditional sovereignty a natural evolution of universal human rights principles (emergent moral architecture) or an institutional construct serving intervention coalition strategic interests?',
    'Comparative analysis of intervention patterns against atrocity severity indices: if intervention tracks protection need independent of intervener strategic interests, supports natural evolution claim; if intervention correlates with geopolitical convenience while equivalent atrocities in inconvenient contexts face non-intervention, supports construction claim. Libya/Syria comparison is natural experiment.',
    'If natural law, the rising extractiveness and theater ratio represent growing pains of norm emergence—resistance will decline as the principle becomes universal. If institutional construction, rising extractiveness represents successful capture of humanitarian justification for strategic intervention—resistance will persist and regional blocs will develop countervailing sovereignty frameworks. Classification shifts from mountain (claimed) toward tangled_rope (coordination plus extraction) or snare (pure strategic vehicle).',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(natural_law_vs_institutional_construction, empirical, 'Whether conditional sovereignty emerges from moral logic or serves institutional power.').

omega_variable(
    protection_beneficiary_identity,
    'Are populations under atrocity threat the real beneficiaries of this doctrine, or do intervention costs and displacement risks make them net payers whose protection is incidental to institutional authority expansion?',
    'Outcome studies of post-intervention humanitarian conditions: if populations consistently experience net improvement (atrocity cessation outweighs intervention costs), beneficiary classification holds; if substantial fraction experience equivalent or worsened conditions (Libya post-2011, Afghanistan), classification should shift to dual beneficiary/payer or pure payer depending on severity.',
    'If populations are net beneficiaries despite intervention costs, the doctrine retains coordination legitimacy. If populations are net payers (intervention causes comparable harm to atrocity it claims to prevent), the beneficiary structure collapses and only institutional actors benefit—pure extraction from both targeted regimes and populations. This omega is structurally tied to the first: if doctrine is natural law, protection outcomes should improve; if institutional construction, populations become cover rather than beneficiaries.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(protection_beneficiary_identity, empirical, 'Whether populations under atrocity threat benefit from or pay for intervention.').

omega_variable(
    selectivity_vs_resource_constraint,
    'Is the doctrine''s selective application structural (intervention occurs when it serves coalition interests, protection rhetoric is cover) or resource-constrained (coalition would intervene everywhere atrocities meet threshold but lacks capacity)?',
    'Examination of intervention decision-making records and coalition resource allocation: if internal documents show protection criteria systematically overridden by strategic considerations, supports structural selectivity; if documents show genuine resource constraints preventing intervention in cases that meet protection thresholds, supports resource explanation.',
    'Resource constraint would preserve coordination legitimacy—the doctrine is imperfectly executed but genuinely protective in intent. Structural selectivity would establish the doctrine as cover story for strategic regime change—protection threshold exists but is applied only when convenient, making it extraction mechanism rather than coordination. Structural selectivity supports reclassification from mountain toward snare; resource constraint would support scaffold (transitional coordination mechanism maturing toward universal application).',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(selectivity_vs_resource_constraint, empirical, 'Whether non-intervention in some atrocities reflects resource limits or strategic choice.').

omega_variable(
    reciprocity_asymmetry_stability,
    'Can a sovereignty framework remain stable when protection obligations apply asymmetrically—intervening states never face responsibility to protect enforcement against themselves?',
    'Long-term tracking of doctrine acceptance by sovereignty-priority states and regional blocs: if resistance declines over multi-generational interval and regional organizations adopt similar conditional frameworks, asymmetry is sustainable. If resistance crystallizes into counter-institutional arrangements (alternative sovereignty charters, regional non-intervention pacts), asymmetry generates instability.',
    'Sustainable asymmetry would support mountain classification—the principle becomes universal even when enforcement remains selective, analogous to how universal jurisdiction for piracy persists despite selective prosecution. Unstable asymmetry would reveal the doctrine as time-limited extraction from vulnerable states—coordination would collapse as sovereignty-priority blocs develop countervailing frameworks. Would support reclassification toward tangled_rope or piton depending on whether institutional beneficiaries retain enforcement capacity.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(reciprocity_asymmetry_stability, conceptual, 'Whether permanent non-reciprocity in sovereignty framework is structurally stable.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(westphalia_sovereignty__conditional_responsibility, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(west_tr_t0, westphalia_sovereignty__conditional_responsibility, theater_ratio, 0, 0.22).
narrative_ontology:measurement_basis(west_tr_t0, observed).
narrative_ontology:measurement(west_tr_t5, westphalia_sovereignty__conditional_responsibility, theater_ratio, 5, 0.28).
narrative_ontology:measurement_basis(west_tr_t5, observed).
narrative_ontology:measurement(west_tr_t10, westphalia_sovereignty__conditional_responsibility, theater_ratio, 10, 0.35).
narrative_ontology:measurement_basis(west_tr_t10, observed).
narrative_ontology:measurement(west_tr_t15, westphalia_sovereignty__conditional_responsibility, theater_ratio, 15, 0.41).
narrative_ontology:measurement_basis(west_tr_t15, observed).
narrative_ontology:measurement(west_tr_t20, westphalia_sovereignty__conditional_responsibility, theater_ratio, 20, 0.46).
narrative_ontology:measurement_basis(west_tr_t20, observed).
narrative_ontology:measurement(west_tr_t25, westphalia_sovereignty__conditional_responsibility, theater_ratio, 25, 0.48).
narrative_ontology:measurement_basis(west_tr_t25, observed).

% Extraction over time
narrative_ontology:measurement(west_be_t0, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 0, 0.38).
narrative_ontology:measurement_basis(west_be_t0, observed).
narrative_ontology:measurement(west_be_t5, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 5, 0.45).
narrative_ontology:measurement_basis(west_be_t5, observed).
narrative_ontology:measurement(west_be_t10, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 10, 0.52).
narrative_ontology:measurement_basis(west_be_t10, observed).
narrative_ontology:measurement(west_be_t15, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 15, 0.58).
narrative_ontology:measurement_basis(west_be_t15, observed).
narrative_ontology:measurement(west_be_t20, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 20, 0.61).
narrative_ontology:measurement_basis(west_be_t20, observed).
narrative_ontology:measurement(west_be_t25, westphalia_sovereignty__conditional_responsibility, base_extractiveness, 25, 0.62).
narrative_ontology:measurement_basis(west_be_t25, observed).

% Suppression requirement over time
narrative_ontology:measurement(west_su_t0, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 0, 0.48).
narrative_ontology:measurement_basis(west_su_t0, observed).
narrative_ontology:measurement(west_su_t5, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 5, 0.54).
narrative_ontology:measurement_basis(west_su_t5, observed).
narrative_ontology:measurement(west_su_t10, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 10, 0.61).
narrative_ontology:measurement_basis(west_su_t10, observed).
narrative_ontology:measurement(west_su_t15, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 15, 0.66).
narrative_ontology:measurement_basis(west_su_t15, observed).
narrative_ontology:measurement(west_su_t20, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 20, 0.69).
narrative_ontology:measurement_basis(west_su_t20, observed).
narrative_ontology:measurement(west_su_t25, westphalia_sovereignty__conditional_responsibility, suppression_requirement, 25, 0.71).
narrative_ontology:measurement_basis(west_su_t25, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(westphalia_sovereignty__conditional_responsibility, enforcement_mechanism).
narrative_ontology:boltzmann_floor_override(westphalia_sovereignty__conditional_responsibility, 0.12).
narrative_ontology:affects_constraint(westphalia_sovereignty__conditional_responsibility, westphalia_sovereignty__absolute_non_intervention).
narrative_ontology:affects_constraint(westphalia_sovereignty__conditional_responsibility, westphalia_sovereignty__graded_sovereignty).
narrative_ontology:affects_constraint(westphalia_sovereignty__conditional_responsibility, international_criminal_court_jurisdiction).
narrative_ontology:affects_constraint(westphalia_sovereignty__conditional_responsibility, un_security_council_authority).

% DUAL FORMULATION NOTE:
% This constraint is the 'conditional_responsibility' reading of the Westphalian sovereignty kernel. The epsilon values differ substantially across readings: absolute_non_intervention maintains low extraction (territorial inviolability imposes minimal costs on intervener states, high costs on potential intervention targets seeking protection); conditional_responsibility shows moderate-high extraction (lowered threshold concentrates authority in institutions that apply it selectively); graded_sovereignty calibrates extraction to sovereignty capacity (failed states face intervention, established states retain protection). The readings form a constraint family because they are alternative interpretations of sovereignty's nature and scope, each operationalized by different state coalitions, with distinct beneficiary/victim structures and legitimacy foundations. They are linked through institutional competition—Security Council debates invoke all three readings depending on case facts and member strategic interests.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

constraint_indexing:directionality_override(westphalia_sovereignty__conditional_responsibility, institutional, 0.18).

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
