% ============================================================================
% CONSTRAINT STORY: woman_category__gender_identity_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-12
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_woman_category__gender_identity_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: woman_category__gender_identity_reading
 *   human_readable: Woman Category via Gender Identity Recognition
 *   domain: political_philosophy/law/social_policy/bioethics
 *
 * SUMMARY:
 *   This constraint instantiates the gender-identity reading of the
 *   woman-category kernel: legal and institutional membership in the woman
 *   category is determined by self-identified gender rather than biological
 *   sex. The reading claims to recognize a natural ontological fact—that
 *   gender identity is constitutive of personhood—and frames sex-based
 *   categorization as an imposed social construct. The constraint operates
 *   through identity-document law, anti-discrimination enforcement,
 *   institutional inclusion mandates, and social censure of dissent.
 *   Resistance is high because sex-based distinctions structure material
 *   resources (sports, spaces, data) and safety expectations; the identity
 *   framework collapses those distinctions and transfers access rights from
 *   one class to another. The claim (mountain) asserts the framework reflects
 *   discovered reality; the metrics describe enforced transfer with rising
 *   suppression and theatrical compliance.
 *
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(woman_category__gender_identity_reading, 0.68).
domain_priors:suppression_score(woman_category__gender_identity_reading, 0.72).
domain_priors:theater_ratio(woman_category__gender_identity_reading, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, extractiveness, 0.68).
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, suppression_requirement, 0.72).
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(woman_category__gender_identity_reading, resistance, 0.76).

% --- Constraint claim ---
narrative_ontology:constraint_claim(woman_category__gender_identity_reading, mountain).
narrative_ontology:human_readable(woman_category__gender_identity_reading, "Woman Category via Gender Identity Recognition").
narrative_ontology:topic_domain(woman_category__gender_identity_reading, "political_philosophy/law/social_policy/bioethics").

domain_priors:requires_active_enforcement(woman_category__gender_identity_reading).
domain_priors:emerges_naturally(woman_category__gender_identity_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(woman_category__gender_identity_reading, '2c904e96-1bcf-4121-b69b-1fd19d51d22f').
narrative_ontology:cs_kernel_codification('2c904e96-1bcf-4121-b69b-1fd19d51d22f', distributed).
narrative_ontology:cs_authority_grounding('2c904e96-1bcf-4121-b69b-1fd19d51d22f', distributed).
narrative_ontology:cs_reading_relation('2c904e96-1bcf-4121-b69b-1fd19d51d22f', woman_category__sex_biology_reading, coexists_with).
narrative_ontology:cs_reading_relation('2c904e96-1bcf-4121-b69b-1fd19d51d22f', woman_category__intersex_accommodation_reading, influences).
narrative_ontology:cs_axiom('2c904e96-1bcf-4121-b69b-1fd19d51d22f', foundational, gender_identity_constitutes_category_membership).
narrative_ontology:cs_axiom_status(gender_identity_constitutes_category_membership, holdable).
narrative_ontology:cs_axiom_grounding('2c904e96-1bcf-4121-b69b-1fd19d51d22f', gender_identity_constitutes_category_membership, deontological).
narrative_ontology:cs_axiom('2c904e96-1bcf-4121-b69b-1fd19d51d22f', foundational, self_attestation_sufficient_for_recognition).
narrative_ontology:cs_axiom_status(self_attestation_sufficient_for_recognition, holdable).
narrative_ontology:cs_axiom_grounding('2c904e96-1bcf-4121-b69b-1fd19d51d22f', self_attestation_sufficient_for_recognition, conventional).
narrative_ontology:cs_axiom('2c904e96-1bcf-4121-b69b-1fd19d51d22f', secondary, biological_sex_markers_non_determinative).
narrative_ontology:cs_axiom_status(biological_sex_markers_non_determinative, holdable).
narrative_ontology:cs_axiom_grounding('2c904e96-1bcf-4121-b69b-1fd19d51d22f', biological_sex_markers_non_determinative, conventional).
narrative_ontology:cs_reference_frame('2c904e96-1bcf-4121-b69b-1fd19d51d22f', gender_identity_self_determination_framework).
narrative_ontology:cs_drift_state('2c904e96-1bcf-4121-b69b-1fd19d51d22f', contemporary_institutional_adoption, gap(authority_erosion, substantial, false)).
narrative_ontology:cs_created_at('2c904e96-1bcf-4121-b69b-1fd19d51d22f', '').
narrative_ontology:cs_kernel_id(woman_category__gender_identity_reading, woman_category).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(woman_category__gender_identity_reading, transgender_women).
narrative_ontology:constraint_beneficiary(woman_category__gender_identity_reading, gender_identity_advocacy_organizations).
narrative_ontology:constraint_beneficiary(woman_category__gender_identity_reading, progressive_institutional_coalitions).
narrative_ontology:constraint_victim(woman_category__gender_identity_reading, sex_based_protections_advocates).
narrative_ontology:constraint_victim(woman_category__gender_identity_reading, competitive_female_athletes).
narrative_ontology:constraint_victim(woman_category__gender_identity_reading, users_of_sex_segregated_spaces).
narrative_ontology:constraint_vindicates(woman_category__gender_identity_reading, gender_self_determination_doctrine).
narrative_ontology:constraint_vindicates(woman_category__gender_identity_reading, identity_primacy_over_biology).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Gain legal recognition, document correction, and institutional access under the woman category based on self-identified gender rather than assigned sex. Exit from this framework would require either reverting to sex-based classification (which denies their identity) or abandoning categorical membership claims entirely (which forfeits legal protections and social recognition). Identity-locked because the gender identity that grounds their claim is constitutive of self-concept.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, transgender_women, beneficiary,
    organized, biographical, identity_locked, national).

% Draft model legislation, lobby for policy adoption, provide legal defense for identity-based classification challenges, and conduct public education campaigns. They set the terms of the discourse by framing sex-based categorization as discriminatory and identity recognition as a civil rights issue. They can pivot strategies or domains but are organizationally committed to the identity framework.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, gender_identity_advocacy_organizations, agenda_setter,
    institutional, generational, mobile, national).

% Universities, corporations, and government agencies adopt gender identity policies to signal alignment with progressive values and avoid discrimination liability. They benefit through reputational capital in ideologically aligned networks and legal safe harbor. Constrained exit because reversing policy invites litigation, internal dissent, and coalition fracture; the identity framework has become institutionally embedded.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, progressive_institutional_coalitions, beneficiary,
    institutional, generational, constrained, national).
narrative_ontology:stakeholder_secondary_role(woman_category__gender_identity_reading, progressive_institutional_coalitions, agenda_setter).

% Advocates for women's sex-based rights argue that collapsing sex and gender categories erodes protections built on biological sex differences—domestic violence shelters, sexual assault services, pregnancy discrimination law. They bear the cost of defending sex-based boundaries in legal and institutional contexts where identity recognition is treated as settled. Constrained because framing their position publicly risks accusations of bigotry; major platforms and funders have exited sex-based advocacy.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, sex_based_protections_advocates, payer,
    organized, biographical, constrained, national).

% Face competition from transgender women who retain male-puberty physiological advantages in strength, speed, and endurance. Policies allowing self-identified gender for sports eligibility transfer competitive opportunity from natal females to male-bodied athletes. Trapped because objecting publicly invites career destruction; remaining silent means accepting displacement. Exit from competitive sport is exit from years of investment and identity.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, competitive_female_athletes, payer,
    moderate, biographical, trapped, national).

% Women and girls using locker rooms, restrooms, prisons, and shelters under policies allowing access based on self-identified gender. They bear privacy loss, safety risk perception, and discomfort when male-bodied individuals access female spaces. Constrained because objecting is socially sanctioned as discriminatory; alternatives (single-stall facilities, opting out) are rarely provided. Their preferences are subordinated to access rights claims.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, users_of_sex_segregated_spaces, payer,
    powerless, immediate, constrained, local).

% Clinicians and professional associations that establish diagnostic criteria and treatment protocols for gender dysphoria. Under identity primacy, the gatekeeping function atrophies: affirmation replaces assessment. They set standards but face institutional pressure to adopt informed-consent models that remove clinical discretion. Constrained because dissenting from affirmative-only care invites professional sanction.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, medical_transition_gatekeepers, agenda_setter,
    institutional, biographical, constrained, national).

% Analyze whether gender identity is a stable ground for legal categorization, whether identity claims can be verified or falsified, and how conflicts between identity-based and sex-based rights are resolved. They trace the conceptual structure and its internal tensions without institutional stake in the outcome.
narrative_ontology:constraint_stakeholder(woman_category__gender_identity_reading, philosophers_and_legal_theorists, observer,
    analytical, generational, analytical, universal).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides legal and social recognition for transgender women by aligning category membership with subjective gender identity rather than objective biological markers; solves the coordination problem of how institutions classify individuals when sex and gender diverge.
% TRANSFER_FUNCTION: Transfers institutional access, legal protections, competitive opportunities, and privacy expectations from natal females to transgender women in contexts where category boundaries determine who may enter: sports, shelters, prisons, identity documents, sex-disaggregated data collection.
% ABSENT_VOICES: Detransitioners who reject gender identity frameworks after medical transition, gender-critical feminists who argue sex-based rights require sex-based categories, religious communities for whom sex is theologically determined—all structurally excluded from institutional policy formation because their positions are treated as per se discriminatory rather than as substantive claims requiring adjudication.
% DISAPPEARANCE_RATIONALE: If gender identity ceased to determine woman-category membership, institutions would revert to sex-based classification or adopt explicit intersectional criteria. Transgender women would lose automatic access to women's spaces and categories; sex-based protections advocates would regain standing to defend biological-sex boundaries; competitive sports would reinstate sexed eligibility criteria. The entire architecture of identity-document law, anti-discrimination enforcement, and institutional inclusion policy would restructure.
% FOUNDING_PROBLEM: Transgender individuals faced categorical erasure and institutional exclusion when legal sex was determined solely by birth assignment, with no mechanism to correct documents or access sex-segregated spaces consistent with lived gender.
% FOUNDING_PROBLEM_CORROBORATION: Transgender advocacy organizations and progressive coalitions attest the founding problem persists wherever identity recognition is incomplete. Sex-based protections advocates and detransitioner networks attest the founding problem has been substantially solved via legal transition pathways, and that current enforcement erases sex-based distinctions rather than accommodating gender diversity. Legal scholars and medical ethicists outside both coalitions document that document correction and transitional accommodation are now widespread, but disagree on whether categorical collapse is the necessary solution or an overreach.
narrative_ontology:disappearance_verdict(woman_category__gender_identity_reading, world_rearranges).
narrative_ontology:founding_problem_status(woman_category__gender_identity_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(woman_category__gender_identity_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(woman_category__gender_identity_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(woman_category__gender_identity_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(woman_category__gender_identity_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(woman_category__gender_identity_reading, ExtMetricName, E),
    domain_priors:suppression_score(woman_category__gender_identity_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(woman_category__gender_identity_reading),
    narrative_ontology:constraint_metric(woman_category__gender_identity_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(woman_category__gender_identity_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(woman_category__gender_identity_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is substantial (0.68 at T=25) because the constraint operates as a zero-sum transfer in contexts where category boundaries determine finite resource allocation: competitive rankings, shelter beds, prison housing, identity-document markers. Suppression is high (0.72) because enforcement relies on platform deplatforming, employment termination, and legal liability for misgendering or exclusion; alternatives are not tolerated as reasonable disagreement but punished as discrimination. Theater ratio is moderate-rising (0.42) as institutions adopt performative pronoun rituals and land acknowledgments that signal compliance without addressing underlying tensions. Accessibility collapse is moderate (0.48) because sex-based alternatives remain conceptually available but institutionally foreclosed; individuals understand the distinction but cannot invoke it without sanction. Resistance is high (0.76) because natal females, detransitioners, and religious communities actively contest categorical collapse in litigation, policy advocacy, and underground networks; the constraint does not command assent but compels behavioral conformity.
 *
 * PERSPECTIVAL GAP:
 *   From the beneficiary seats (transgender women, advocacy organizations), the constraint is a correction of historical injustice and recognition of ontological reality—a mountain that institutions are belatedly acknowledging. From the payer seats (female athletes, sex-based advocates, space users), the same structure operates as enforced redefinition that erases material sex differences and punishes dissent—a snare that leverages institutional power to compel acceptance of contested metaphysical claims. The engine computes this seat divergence from power, exit options, and structural position; the gap between claimed mountain and measured extraction is the central datum.
 *
 * DIRECTIONALITY LOGIC:
 *   Transgender women and advocacy organizations are structural beneficiaries: they gain legal standing, institutional access, and legitimacy by collapsing sex and gender into identity. Progressive coalitions benefit through reputational capital and legal safe harbor. Sex-based protections advocates, competitive female athletes, and users of sex-segregated spaces are structural victims: they lose legal recognition for sex-based boundaries, competitive fairness, and privacy expectations. Medical gatekeepers sit near symmetric: their professional role is preserved but transformed from assessment to affirmation. Philosophers and legal theorists occupy the analytical seat.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint's mandate (recognize transgender women as women) is internally coherent if gender identity is ontologically primary. The mandate becomes extractive if sex-based distinctions are material and non-substitutable—if competitive fairness in sport depends on biology, if safety in shelters depends on sex-based segregation, if data collection for health research requires tracking natal sex. The mandatrophy question is whether institutional enforcement has outlived the coordination function (document correction for genuinely dysphoric individuals) and now operates to suppress legitimate disagreement about category boundaries. Rising theater ratio and suppression requirement suggest the constraint increasingly functions to defend itself rather than solve the founding problem.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    identity_verifiability,
    'Can gender identity claims be objectively verified or falsified, or are they necessarily self-attesting and immune to external validation?',
    'Philosophical analysis of whether subjective states constitute objective category membership, combined with case law on fraudulent identity claims and institutional attempts to operationalize identity verification without gatekeeping.',
    'If identity is necessarily self-attesting, the constraint has no falsifiability condition and category membership is determined solely by declaration—any enforcement becomes pure stipulation. If identity requires external validation, the constraint collapses back into a gatekeeping regime and ceases to instantiate identity primacy. The omega is structural: one horn makes the framework unfalsifiable, the other dissolves it.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(identity_verifiability, conceptual, 'Whether gender identity can be verified or is necessarily self-attesting').

omega_variable(
    naturality_vs_construction,
    'Is this constraint a mountain (recognition of natural ontological fact about gender identity) or a constructed norm (institutional decision to prioritize identity claims over biological markers)?',
    'Cross-cultural and historical analysis of whether gender identity as self-attesting category membership appears universally or is specific to contemporary Western frameworks; neuroscience research on whether gender identity has stable biological correlates independent of socialization.',
    'If gender identity is a stable natural kind appearing across all cultures, the constraint is mountain and resistance is denial of reality. If it is a culturally contingent framework, the constraint is constructed and enforcement operates as norm imposition. The presence of declared beneficiaries who advocate for institutional adoption suggests constructed enforcement rather than discovered natural law.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(naturality_vs_construction, empirical, 'Whether gender identity is natural ontological kind or constructed social category').

omega_variable(
    zero_sum_resource_conflict,
    'In contexts where category membership determines access to finite resources (competitive slots, shelter beds, prison housing), is the transfer from natal females to transgender women a necessary recognition of ontological fact, or an enforced redistribution that one class bears and another captures?',
    'Policy experiments with third-category options, litigation outcomes on sex-segregated space access, longitudinal data on competitive displacement and institutional accommodation costs.',
    'If zero-sum conflicts are resolvable through neutral accommodation (third categories, tiered competition), extraction falls and the constraint stabilizes as rope. If conflicts are irreducible and resolved by prioritizing identity claims, extraction is confirmed and victims remain structurally subordinated. Current trajectory shows institutions defaulting to identity priority without accommodation; measured ε rises as conflicts intensify.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(zero_sum_resource_conflict, empirical, 'Whether resource conflicts are accommodatable or inherently extractive').

omega_variable(
    suppression_mechanism,
    'Is the measured suppression structural (legal liability, employment termination, platform removal) or internalized (self-censorship from fear of social sanction after threat removal)?',
    'Post-enforcement suppression trajectory: if individuals continue self-censoring after legal and employment threats are removed, the suppression is partly internalized and travels with subjects. If speech recovers immediately when structural barriers fall, suppression is fully external.',
    'If internalized, effective suppression is higher than structural measures suggest—the constraint has rewritten cognitive norms and individuals police themselves. If purely structural, suppression is reversible by removing enforcement mechanisms. Rising theater ratio combined with persistent self-censorship in anonymous surveys suggests partial internalization.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(suppression_mechanism, empirical, 'Whether suppression is structural enforcement or internalized norm compliance').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(woman_category__gender_identity_reading, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(woma_tr_t0, woman_category__gender_identity_reading, theater_ratio, 0, 0.18).
narrative_ontology:measurement_basis(woma_tr_t0, observed).
narrative_ontology:measurement(woma_tr_t5, woman_category__gender_identity_reading, theater_ratio, 5, 0.24).
narrative_ontology:measurement_basis(woma_tr_t5, observed).
narrative_ontology:measurement(woma_tr_t10, woman_category__gender_identity_reading, theater_ratio, 10, 0.31).
narrative_ontology:measurement_basis(woma_tr_t10, observed).
narrative_ontology:measurement(woma_tr_t15, woman_category__gender_identity_reading, theater_ratio, 15, 0.36).
narrative_ontology:measurement_basis(woma_tr_t15, observed).
narrative_ontology:measurement(woma_tr_t20, woman_category__gender_identity_reading, theater_ratio, 20, 0.39).
narrative_ontology:measurement_basis(woma_tr_t20, observed).
narrative_ontology:measurement(woma_tr_t25, woman_category__gender_identity_reading, theater_ratio, 25, 0.42).
narrative_ontology:measurement_basis(woma_tr_t25, observed).

% Extraction over time
narrative_ontology:measurement(woma_be_t0, woman_category__gender_identity_reading, base_extractiveness, 0, 0.35).
narrative_ontology:measurement_basis(woma_be_t0, observed).
narrative_ontology:measurement(woma_be_t5, woman_category__gender_identity_reading, base_extractiveness, 5, 0.42).
narrative_ontology:measurement_basis(woma_be_t5, observed).
narrative_ontology:measurement(woma_be_t10, woman_category__gender_identity_reading, base_extractiveness, 10, 0.51).
narrative_ontology:measurement_basis(woma_be_t10, observed).
narrative_ontology:measurement(woma_be_t15, woman_category__gender_identity_reading, base_extractiveness, 15, 0.59).
narrative_ontology:measurement_basis(woma_be_t15, observed).
narrative_ontology:measurement(woma_be_t20, woman_category__gender_identity_reading, base_extractiveness, 20, 0.64).
narrative_ontology:measurement_basis(woma_be_t20, observed).
narrative_ontology:measurement(woma_be_t25, woman_category__gender_identity_reading, base_extractiveness, 25, 0.68).
narrative_ontology:measurement_basis(woma_be_t25, observed).

% Suppression requirement over time
narrative_ontology:measurement(woma_su_t0, woman_category__gender_identity_reading, suppression_requirement, 0, 0.45).
narrative_ontology:measurement_basis(woma_su_t0, observed).
narrative_ontology:measurement(woma_su_t5, woman_category__gender_identity_reading, suppression_requirement, 5, 0.52).
narrative_ontology:measurement_basis(woma_su_t5, observed).
narrative_ontology:measurement(woma_su_t10, woman_category__gender_identity_reading, suppression_requirement, 10, 0.59).
narrative_ontology:measurement_basis(woma_su_t10, observed).
narrative_ontology:measurement(woma_su_t15, woman_category__gender_identity_reading, suppression_requirement, 15, 0.65).
narrative_ontology:measurement_basis(woma_su_t15, observed).
narrative_ontology:measurement(woma_su_t20, woman_category__gender_identity_reading, suppression_requirement, 20, 0.69).
narrative_ontology:measurement_basis(woma_su_t20, observed).
narrative_ontology:measurement(woma_su_t25, woman_category__gender_identity_reading, suppression_requirement, 25, 0.72).
narrative_ontology:measurement_basis(woma_su_t25, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(woman_category__gender_identity_reading, identity_coordination).
narrative_ontology:boltzmann_floor_override(woman_category__gender_identity_reading, 0.08).
narrative_ontology:affects_constraint(woman_category__gender_identity_reading, woman_category__sex_biology_reading).
narrative_ontology:affects_constraint(woman_category__gender_identity_reading, woman_category__intersex_accommodation_reading).
narrative_ontology:affects_constraint(woman_category__gender_identity_reading, sex_segregated_spaces_access).
narrative_ontology:affects_constraint(woman_category__gender_identity_reading, competitive_sports_eligibility_by_sex).
narrative_ontology:affects_constraint(woman_category__gender_identity_reading, legal_sex_marker_correction).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the woman_category kernel. Sibling readings (sex_biology_reading, intersex_accommodation_reading) produce different victim sets, different ε values, and different enforcement requirements. The readings are not equivalent framings—they make incompatible ontological claims and produce incompatible category boundaries. All three are linked via network.affects_constraints to trace how the contest propagates through dependent policy domains.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
