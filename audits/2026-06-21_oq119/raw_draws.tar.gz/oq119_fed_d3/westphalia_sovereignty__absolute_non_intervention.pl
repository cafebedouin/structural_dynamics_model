% ============================================================================
% CONSTRAINT STORY: westphalia_sovereignty__absolute_non_intervention
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-01-13
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_westphalia_sovereignty__absolute_non_intervention, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: westphalia_sovereignty__absolute_non_intervention
 *   human_readable: Westphalian Sovereignty: Absolute Non-Intervention Reading
 *   domain: international_law/political_theory
 *
 * SUMMARY:
 *   The absolute non-intervention reading of Westphalian sovereignty holds
 *   that territorial inviolability is categorical: no internal conduct,
 *   however severe, legitimates external interference. This reading treats
 *   state boundaries as morally and legally prior to the welfare of
 *   populations within them. The constraint is CLAIMED as mountain
 *   (natural/foundational feature of the state system) while the authored
 *   metrics describe substantially extractive operation with identifiable
 *   beneficiaries and victims—the engine measures that divergence as a test
 *   of the naturalness claim.
 *
 * KEY AGENTS:
 *   - authoritarian_state_elites: Primary beneficiary (institutional/arbitrage) — invoke absolute sovereignty to shield internal repression from external accountability
 *   - state_sovereignty_doctrine_advocates: Beneficiary + agenda setter (institutional/mobile) — maintain doctrinal authority by defending territorial inviolability as foundational
 *   - populations_under_authoritarian_control: Primary victim (powerless/trapped) — live under systematic repression with international recourse foreclosed by the constraint itself
 *   - stateless_populations: Victim (powerless/trapped) — excluded from sovereignty framework, fall into gap between domestic exclusion and international non-intervention
 *   - minority_groups_within_borders: Victim (powerless/identity_locked) — face systematic discrimination framed as internal matters; exit means abandoning ancestral territory
 *   - intervention_advocating_states: Excluded (institutional/constrained) — capacity to intervene is categorically delegitimized regardless of atrocity evidence
 *   - international_human_rights_institutions: Excluded (institutional/constrained) — jurisdiction subordinated to state consent under this reading
 *   - international_law_scholars: Analytical observer — document contest among sovereignty readings and beneficiary structures
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(westphalia_sovereignty__absolute_non_intervention, 0.68).
domain_priors:suppression_score(westphalia_sovereignty__absolute_non_intervention, 0.79).
domain_priors:theater_ratio(westphalia_sovereignty__absolute_non_intervention, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, extractiveness, 0.68).
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 0.79).
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, accessibility_collapse, 0.71).
narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, resistance, 0.58).

% --- Constraint claim ---
narrative_ontology:constraint_claim(westphalia_sovereignty__absolute_non_intervention, mountain).
narrative_ontology:human_readable(westphalia_sovereignty__absolute_non_intervention, "Westphalian Sovereignty: Absolute Non-Intervention Reading").
narrative_ontology:topic_domain(westphalia_sovereignty__absolute_non_intervention, "international_law/political_theory").

domain_priors:requires_active_enforcement(westphalia_sovereignty__absolute_non_intervention).
domain_priors:emerges_naturally(westphalia_sovereignty__absolute_non_intervention).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(westphalia_sovereignty__absolute_non_intervention, 'ee62d606-fbb5-48df-b906-ffaa57c1939b').
narrative_ontology:cs_kernel_codification('ee62d606-fbb5-48df-b906-ffaa57c1939b', formalized).
narrative_ontology:cs_authority_grounding('ee62d606-fbb5-48df-b906-ffaa57c1939b', lineage).
narrative_ontology:cs_interpretation_layer_present('ee62d606-fbb5-48df-b906-ffaa57c1939b').
narrative_ontology:cs_reading_relation('ee62d606-fbb5-48df-b906-ffaa57c1939b', westphalia_sovereignty__conditional_responsibility, coexists_with).
narrative_ontology:cs_reading_relation('ee62d606-fbb5-48df-b906-ffaa57c1939b', westphalia_sovereignty__graded_sovereignty, coexists_with).
narrative_ontology:cs_axiom('ee62d606-fbb5-48df-b906-ffaa57c1939b', foundational, territorial_authority_ontologically_prior).
narrative_ontology:cs_axiom_status(territorial_authority_ontologically_prior, holdable).
narrative_ontology:cs_axiom_grounding('ee62d606-fbb5-48df-b906-ffaa57c1939b', territorial_authority_ontologically_prior, deontological).
narrative_ontology:cs_axiom('ee62d606-fbb5-48df-b906-ffaa57c1939b', foundational, internal_conduct_categorically_immune).
narrative_ontology:cs_axiom_status(internal_conduct_categorically_immune, holdable).
narrative_ontology:cs_axiom_grounding('ee62d606-fbb5-48df-b906-ffaa57c1939b', internal_conduct_categorically_immune, conventional).
narrative_ontology:cs_reference_frame('ee62d606-fbb5-48df-b906-ffaa57c1939b', westphalian_mutual_forbearance).
narrative_ontology:cs_drift_state('ee62d606-fbb5-48df-b906-ffaa57c1939b', post_humanitarian_intervention_era, gap(axiom_overriding, substantial, false)).
narrative_ontology:cs_created_at('ee62d606-fbb5-48df-b906-ffaa57c1939b', '').
narrative_ontology:cs_kernel_id(westphalia_sovereignty__absolute_non_intervention, westphalia_sovereignty).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__absolute_non_intervention, authoritarian_state_elites).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__absolute_non_intervention, state_sovereignty_doctrine_advocates).
narrative_ontology:constraint_victim(westphalia_sovereignty__absolute_non_intervention, populations_under_authoritarian_control).
narrative_ontology:constraint_victim(westphalia_sovereignty__absolute_non_intervention, stateless_populations).
narrative_ontology:constraint_victim(westphalia_sovereignty__absolute_non_intervention, minority_groups_within_borders).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__absolute_non_intervention, territorial_integrity_as_categorical_imperative).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__absolute_non_intervention, domestic_affairs_exemption_doctrine).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Control state apparatus with complete domestic authority. Invoke absolute sovereignty to reject external scrutiny of internal repression, mass detention, or ethnic suppression. Can participate in international forums while maintaining full internal control. Exit options include forum-shopping among non-intervention coalitions and leveraging economic dependencies to deter intervention.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, authoritarian_state_elites, beneficiary,
    institutional, biographical, arbitrage, national).

% Academic and diplomatic networks that defend absolute territorial inviolability as foundational to international order. Frame any intervention threshold as destabilizing the state system. Benefit from the doctrine by maintaining positional authority in international law discourse and state-system stability institutions. Can exit to adjacent institutional roles if the reading loses dominance.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, state_sovereignty_doctrine_advocates, beneficiary,
    institutional, generational, mobile, global).
narrative_ontology:stakeholder_secondary_role(westphalia_sovereignty__absolute_non_intervention, state_sovereignty_doctrine_advocates, agenda_setter).

% Live under systematic repression with no domestic recourse and no international protection. The constraint treats their situation as an internal matter regardless of severity. Physical exit is blocked by borders; international appeal is foreclosed by the non-intervention norm itself. Their appeals for external intervention are structurally illegitimate under this reading.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, populations_under_authoritarian_control, payer,
    powerless, biographical, trapped, national).

% Lack state protection and are excluded from the sovereignty framework entirely. When a state systematically denies their status, no external actor can intervene without violating territorial inviolability. They fall into the gap between domestic exclusion and international non-intervention.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, stateless_populations, payer,
    powerless, generational, trapped, regional).

% Face systematic discrimination, cultural suppression, or territorial displacement framed by the state as internal administrative matters. External advocacy on their behalf is treated as interference. Identity-locked because leaving means abandoning ancestral territory and cultural ties; staying means enduring treatment that absolute sovereignty renders internationally uncontestable.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, minority_groups_within_borders, payer,
    powerless, generational, identity_locked, national).

% States with capacity and sometimes willingness to intervene against mass atrocities. Under this reading their interventions are categorically illegitimate regardless of internal conditions. They can only act by violating the norm, which carries reputational and coalition costs even when atrocity evidence is overwhelming.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, intervention_advocating_states, excluded,
    institutional, biographical, constrained, global).

% UN human rights mechanisms, regional courts, international tribunals whose mandates rest on the premise that some conduct is internationally accountable. This reading structurally subordinates their jurisdiction to state consent, making their authority conditional on the goodwill of the states they would scrutinize.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, international_human_rights_institutions, excluded,
    institutional, generational, constrained, global).

% Analyze the contest among sovereignty readings. Document the historical oscillation between intervention and non-intervention norms, map the beneficiary structures of each reading, and trace how doctrinal claims about state-system stability encode positional interests.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__absolute_non_intervention, international_law_scholars, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes a mutual non-interference pact among states: each agrees not to contest others' internal arrangements in exchange for the same forbearance, preventing wars of regime-change and stabilizing territorial boundaries across ideologically heterogeneous polities.
% TRANSFER_FUNCTION: Transfers international accountability for internal conduct from populations suffering repression to the state apparatus that governs them. Populations lose international recourse; state elites gain immunity from external challenge regardless of how power is exercised internally.
% ABSENT_VOICES: Populations systematically repressed within borders, stateless groups, and minority populations whose appeals for external protection are foreclosed by the constraint itself. Also excluded: human rights institutions whose mandate presupposes some conduct is internationally accountable, and intervention-capable states whose capacity to act is categorically delegitimized.
% DISAPPEARANCE_RATIONALE: If absolute non-intervention disappeared overnight, intervention-advocating states would immediately face demands to act on ongoing atrocities; human rights institutions would operationalize broader jurisdiction without state-consent barriers; authoritarian regimes would lose their primary shield against external accountability. The international system would reorganize around some alternative legitimacy threshold for intervention, whether humanitarian, democratic, or capacity-based.
% FOUNDING_PROBLEM: The Thirty Years' War and the wars of religion: states prosecuted religious and dynastic claims across borders, collapsing order into decades of total war. The Peace of Westphalia established cuius regio, eius religio—territorial rulers determined internal arrangements, and external powers agreed not to contest them, ending the religious-war cycle.
% FOUNDING_PROBLEM_CORROBORATION: The constraint's advocates (state sovereignty doctrine networks, non-intervention coalition states) attest the founding problem remains live: without absolute territorial inviolability, great powers will manufacture humanitarian pretexts for regime-change wars. Critics (human rights institutions, intervention advocates, populations under repression) attest the founding problem is dead: religious wars ended, but the constraint now shields mass atrocities from international response. Independent historical scholarship supports the dead-problem reading: post-1945 wars of regime-change are rare and typically unsuccessful; the Cold War superpowers honored territorial boundaries even while sponsoring internal conflicts. The live threat is not intervention for religious conversion but intervention to halt genocide, which the absolute reading treats identically.
narrative_ontology:disappearance_verdict(westphalia_sovereignty__absolute_non_intervention, world_rearranges).
narrative_ontology:founding_problem_status(westphalia_sovereignty__absolute_non_intervention, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(westphalia_sovereignty__absolute_non_intervention, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(westphalia_sovereignty__absolute_non_intervention, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(westphalia_sovereignty__absolute_non_intervention_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(westphalia_sovereignty__absolute_non_intervention, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, ExtMetricName, E),
    domain_priors:suppression_score(westphalia_sovereignty__absolute_non_intervention, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(westphalia_sovereignty__absolute_non_intervention),
    narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(westphalia_sovereignty__absolute_non_intervention, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(westphalia_sovereignty__absolute_non_intervention_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is high (0.68 at interval end) because the constraint transfers international accountability from repressed populations to state elites regardless of conduct severity. Suppression is higher still (0.79) because persistence depends on actively delegitimizing intervention advocacy and subordinating human rights jurisdiction to state consent. Theater is moderate (0.42): the stability-preservation function was historically real but a growing share of doctrinal defense now operates to shield atrocities rather than prevent religious wars. Accessibility collapse is high (0.71) because territorial boundaries are treated as morally prior, making alternatives to state-mediated order conceptually inaccessible within the framework. Resistance is substantial (0.58) because human rights institutions and intervention advocates actively contest the reading, and populations under repression resist when they can, though structurally foreclosed from international recourse. The measurement series shows extraction, theater, and suppression all rising over the 40-year interval as the founding religious-war problem receded while the shield-for-atrocities function intensified.
 *
 * PERSPECTIVAL GAP:
 *   The beneficiary and victim seats should compute radically different types. From the institutional-beneficiary position (state elites, doctrine advocates), the constraint is legitimate coordination solving the religious-war problem and stabilizing the state system. From the powerless-trapped position (repressed populations, stateless groups), the same constraint is a snare: their appeals for protection are structurally illegitimate and their exit is blocked by the very boundaries the constraint treats as inviolable. The analytical observer seat sees both the historical coordination function and the contemporary extraction, measuring the gap between the founding problem (religious wars, now dead per independent scholarship) and current beneficiary structure (state elites claiming immunity regardless of conduct).
 *
 * DIRECTIONALITY LOGIC:
 *   Authoritarian state elites are structural beneficiaries (collect immunity from accountability, arbitrage-grade exit via forum-shopping). Doctrine advocates benefit from maintaining positional authority in the sovereignty discourse. Populations under authoritarian control, stateless populations, and minority groups are the targets (bear costs of foreclosed international recourse, trapped or identity-locked exit). Intervention-advocating states and human rights institutions are excluded rather than coordinated—their exclusion is what the enforcement object maintains. The engine should compute divergent seat types: from the beneficiary seats the arrangement is genuine coordination (mutual forbearance preventing war); from the trapped victim seats the same structure operates as enforced extraction (immunity transferred to elites regardless of conduct).
 *
 * MANDATROPHY ANALYSIS:
 *   The founding problem (wars of religion and dynastic regime-change across borders) is contested-to-dead per independent historical scholarship: post-1945 religious wars are rare, territorial boundaries are broadly stable, and Cold War superpowers honored sovereignty even while sponsoring internal conflicts. But the constraint persists with rising suppression (0.62→0.79) and rising theater (0.22→0.42), now primarily operating to shield state elites from accountability for mass atrocities rather than to prevent cross-border religious wars. This is the mandatrophy signature: a coordination function built for a specific historical threat that has receded, now repurposed to serve beneficiary interests unrelated to the founding problem. The R5 genealogy interview surfaces this: advocates claim the founding problem is live (great powers will manufacture humanitarian pretexts for regime-change), but independent evidence shows the threat is minimal and the actual protection is for internal repression, not external stability.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    natural_law_vs_constructed_immunity,
    'Is territorial inviolability a natural feature of political order (states as ontologically prior to populations), or is it a constructed immunity that benefits identifiable agents (state elites) by foreclosing external accountability?',
    'Historical analysis of sovereignty''s origins and beneficiaries. If territorial inviolability emerged from treaties among elites (Peace of Westphalia as negotiated settlement) rather than discovered necessity, and if its operation systematically protects elite interests over population welfare, the constructed-immunity reading is corroborated. Natural-law reading would require showing that states without territorial protection collapse universally, independent of elite interests.',
    'If constructed immunity, the mountain claim is false and the constraint reclassifies to snare or tangled_rope depending on coordination residue. If natural law, the high extraction is inherent cost of state-system stability and beneficiaries are incidental. This omega is required by the schema because the constraint is claimed as mountain with declared beneficiaries, triggering FSM evaluation.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(natural_law_vs_constructed_immunity, conceptual, 'Whether territorial inviolability is natural law or constructed elite immunity').

omega_variable(
    founding_problem_substitution,
    'Has the constraint''s function shifted from preventing cross-border religious wars (founding problem, now largely resolved) to shielding domestic atrocities from international accountability (current primary operation)?',
    'Temporal analysis of constraint invocations: if absolute sovereignty is now primarily invoked to reject scrutiny of internal repression rather than to prevent external regime-change wars, and if post-1945 religious wars are rare while invocations against human rights jurisdiction are routine, function-shift is established. Cross-reference with theater_ratio trajectory (0.22→0.42) and suppression_requirement rise (0.62→0.79).',
    'If function has shifted, the constraint exhibits mandatrophy: built for one problem, now operating to serve different beneficiaries. This supports reclassification from mountain (natural coordination) to tangled_rope or snare (extraction riding on vestigial coordination narrative). If function is stable, rising metrics reflect increasing cost of maintaining genuine stability.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(founding_problem_substitution, empirical, 'Whether constraint function has shifted from religious-war prevention to atrocity-shielding').

omega_variable(
    committer_frame_under_determination,
    'Does the sovereignty kernel admit multiple coherent readings (non-intervention, conditional responsibility, graded capacity) with different victim sets and beneficiary structures, or is one reading the correct instantiation of the Westphalian settlement?',
    'Historical and doctrinal analysis of whether the Peace of Westphalia and successor treaties encode a single determinate rule or a contested kernel that different institutional actors read differently. If treaty language is ambiguous on intervention thresholds and readings have coexisted across different state coalitions with no formal resolution, the kernel is under-determined. If one reading has been formally adopted by authoritative institutions (UN Charter interpretation, ICJ precedent), that reading is determinate.',
    'If kernel is under-determined, the three readings are legitimate framings held by different parties, and classification differences across readings are real positional divergence rather than measurement error. If one reading is determinate, the others are contested interpretations and one is structurally correct. This omega routes the committer-frame under-determination per Rule 2.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(committer_frame_under_determination, conceptual, 'Whether sovereignty kernel admits multiple coherent readings or one determinate rule').

omega_variable(
    intervention_threshold_calibration,
    'If absolute non-intervention is abandoned, what conduct threshold legitimates external interference—genocide only, systematic repression, any rights violation—and who decides?',
    'Comparative analysis of intervention precedents and their justifications. If thresholds vary by intervener power and target vulnerability rather than by conduct severity, legitimacy is power-relative rather than rule-bound. If international consensus on specific thresholds (e.g., R2P criteria) exists and is honored by states with intervention capacity, a rule-bound threshold is operational.',
    'If no stable threshold exists, abandoning absolute non-intervention may replace one extractive structure (immunity for state elites) with another (selective intervention by powerful states). If a stable threshold exists, populations gain meaningful international recourse without opening arbitrary intervention. This uncertainty is inherent to the sovereignty contest and cannot be resolved within this reading.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(intervention_threshold_calibration, preference, 'What conduct threshold would legitimate intervention if absolute reading is abandoned').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(westphalia_sovereignty__absolute_non_intervention, 0, 40).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(west_tr_t0, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 0, 0.22).
narrative_ontology:measurement(west_tr_t8, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 8, 0.27).
narrative_ontology:measurement(west_tr_t16, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 16, 0.32).
narrative_ontology:measurement(west_tr_t24, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 24, 0.36).
narrative_ontology:measurement(west_tr_t32, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 32, 0.39).
narrative_ontology:measurement(west_tr_t40, westphalia_sovereignty__absolute_non_intervention, theater_ratio, 40, 0.42).

% Extraction over time
narrative_ontology:measurement(west_be_t0, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 0, 0.48).
narrative_ontology:measurement(west_be_t8, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 8, 0.53).
narrative_ontology:measurement(west_be_t16, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 16, 0.59).
narrative_ontology:measurement(west_be_t24, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 24, 0.64).
narrative_ontology:measurement(west_be_t32, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 32, 0.67).
narrative_ontology:measurement(west_be_t40, westphalia_sovereignty__absolute_non_intervention, base_extractiveness, 40, 0.68).

% Suppression requirement over time
narrative_ontology:measurement(west_su_t0, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 0, 0.62).
narrative_ontology:measurement(west_su_t8, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 8, 0.67).
narrative_ontology:measurement(west_su_t16, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 16, 0.71).
narrative_ontology:measurement(west_su_t24, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 24, 0.75).
narrative_ontology:measurement(west_su_t32, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 32, 0.77).
narrative_ontology:measurement(west_su_t40, westphalia_sovereignty__absolute_non_intervention, suppression_requirement, 40, 0.79).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(westphalia_sovereignty__absolute_non_intervention, enforcement_mechanism).
narrative_ontology:affects_constraint(westphalia_sovereignty__absolute_non_intervention, westphalia_sovereignty__conditional_responsibility).
narrative_ontology:affects_constraint(westphalia_sovereignty__absolute_non_intervention, westphalia_sovereignty__graded_sovereignty).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the westphalia_sovereignty kernel. The kernel decomposes into three structural constraints with different ε values and victim sets. Absolute non-intervention (this story) treats all internal conduct as immune regardless of severity (high ε, victims are trapped populations). Conditional responsibility creates atrocity-based intervention threshold (lower ε, victims gain emergency international recourse). Graded sovereignty makes legitimacy continuous with state capacity (ε depends on capacity measurement, victims are populations in failed/failing states). The readings are linked via network.affects_constraints because they share institutional space and readings compete in the same doctrinal discourse—one reading's dominance forecloses the others in practice even when all remain theoretically available.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
