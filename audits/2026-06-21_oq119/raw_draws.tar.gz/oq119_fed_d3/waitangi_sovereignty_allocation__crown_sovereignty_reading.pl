% ============================================================================
% CONSTRAINT STORY: waitangi_sovereignty_allocation__crown_sovereignty_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-01-15
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_waitangi_sovereignty_allocation__crown_sovereignty_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: waitangi_sovereignty_allocation__crown_sovereignty_reading
 *   human_readable: Crown Sovereignty Reading of Treaty of Waitangi Article I
 *   domain: constitutional_law/indigenous_rights/post_colonial_governance
 *
 * SUMMARY:
 *   The Crown sovereignty reading of Treaty of Waitangi Article I treats the
 *   1840 English text as an unambiguous cession of complete sovereignty from
 *   Māori chiefs to the British Crown, establishing Westminster parliamentary
 *   supremacy as New Zealand's foundational constitutional principle. Under
 *   this reading, Parliament exercises plenary legislative authority over all
 *   persons and territory, including traditional Māori lands and governance
 *   structures, without structural Treaty-based consent requirements or
 *   co-governance obligations. This interpretation became entrenched through
 *   colonial legal practice, judicial doctrine, and legislative convention
 *   despite the Māori text's use of 'kāwanatanga' (governorship) rather than
 *   'mana' (sovereignty) and despite historical evidence that many signing
 *   chiefs understood they were granting limited governance authority while
 *   retaining 'tino rangatiratanga' (full authority) over their lands and
 *   peoples. The sovereignty reading is CLAIMED as constitutional mountain
 *   (natural/foundational law), while the metrics describe substantially
 *   extractive operation concentrating authority in majoritarian settler
 *   institutions and systematically subordinating Māori Treaty-based
 *   claims—the engine measures this mountain-claim/extraction-metrics
 *   divergence as exactly the false-summit detection the framework exists to
 *   perform.
 *
 * KEY AGENTS:
 *   - crown_government: Primary agenda-setter (institutional/arbitrage) — exercises plenary authority, claims complete sovereignty cession, maintains reading through doctrine and practice
 *   - settler_majority_parliament: Primary beneficiary (institutional/mobile) — operates under unimpeded legislative supremacy, allocates resources without Treaty constraint
 *   - maori_iwi_hapu: Primary victims (organized/identity_locked) — traditional authority subordinated, resource claims reduced to residual property rights, cannot exit ancestral territory's constitutional framework
 *   - treaty_claimants: Secondary victims (moderate/constrained) — navigate claims process that embeds sovereignty reading as premise, remedies subordinate to parliamentary will
 *   - partnership_advocates: Excluded actors (moderate/constrained) — advance alternative constitutional readings, heard in moral/political discourse but excluded from binding doctrine
 *   - constitutional_historians: Analytical observers — document textual ambiguity, signing-chiefs' understanding, multiple possible framings, and entrenchment through practice rather than unambiguous foundation
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(waitangi_sovereignty_allocation__crown_sovereignty_reading, 0.81).
domain_priors:suppression_score(waitangi_sovereignty_allocation__crown_sovereignty_reading, 0.88).
domain_priors:theater_ratio(waitangi_sovereignty_allocation__crown_sovereignty_reading, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, extractiveness, 0.81).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 0.88).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, accessibility_collapse, 0.73).
narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, resistance, 0.76).

% --- Constraint claim ---
narrative_ontology:constraint_claim(waitangi_sovereignty_allocation__crown_sovereignty_reading, mountain).
narrative_ontology:human_readable(waitangi_sovereignty_allocation__crown_sovereignty_reading, "Crown Sovereignty Reading of Treaty of Waitangi Article I").
narrative_ontology:topic_domain(waitangi_sovereignty_allocation__crown_sovereignty_reading, "constitutional_law/indigenous_rights/post_colonial_governance").

domain_priors:requires_active_enforcement(waitangi_sovereignty_allocation__crown_sovereignty_reading).
domain_priors:emerges_naturally(waitangi_sovereignty_allocation__crown_sovereignty_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(waitangi_sovereignty_allocation__crown_sovereignty_reading, '208a383e-05e0-4ac8-b16f-e14f506aa2e7').
narrative_ontology:cs_kernel_codification('208a383e-05e0-4ac8-b16f-e14f506aa2e7', fixed_text).
narrative_ontology:cs_authority_grounding('208a383e-05e0-4ac8-b16f-e14f506aa2e7', extraction).
narrative_ontology:cs_interpretation_layer_present('208a383e-05e0-4ac8-b16f-e14f506aa2e7').
narrative_ontology:cs_reading_relation('208a383e-05e0-4ac8-b16f-e14f506aa2e7', waitangi_sovereignty_allocation__partnership_reading, forecloses).
narrative_ontology:cs_reading_relation('208a383e-05e0-4ac8-b16f-e14f506aa2e7', waitangi_sovereignty_allocation__rangatiratanga_reading, forecloses).
narrative_ontology:cs_axiom('208a383e-05e0-4ac8-b16f-e14f506aa2e7', foundational, sovereignty_completely_ceded_1840).
narrative_ontology:cs_axiom_status(sovereignty_completely_ceded_1840, holdable).
narrative_ontology:cs_axiom_grounding('208a383e-05e0-4ac8-b16f-e14f506aa2e7', sovereignty_completely_ceded_1840, conventional).
narrative_ontology:cs_axiom('208a383e-05e0-4ac8-b16f-e14f506aa2e7', foundational, parliamentary_supremacy_unlimited_by_treaty).
narrative_ontology:cs_axiom_status(parliamentary_supremacy_unlimited_by_treaty, holdable).
narrative_ontology:cs_axiom_grounding('208a383e-05e0-4ac8-b16f-e14f506aa2e7', parliamentary_supremacy_unlimited_by_treaty, conventional).
narrative_ontology:cs_reference_frame('208a383e-05e0-4ac8-b16f-e14f506aa2e7', westminster_parliamentary_supremacy).
narrative_ontology:cs_drift_state('208a383e-05e0-4ac8-b16f-e14f506aa2e7', contemporary_treaty_justice_era, gap(authority_erosion, substantial, false)).
narrative_ontology:cs_created_at('208a383e-05e0-4ac8-b16f-e14f506aa2e7', '').
narrative_ontology:cs_kernel_id(waitangi_sovereignty_allocation__crown_sovereignty_reading, waitangi_sovereignty_allocation).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__crown_sovereignty_reading, crown_government).
narrative_ontology:constraint_beneficiary(waitangi_sovereignty_allocation__crown_sovereignty_reading, settler_majority_parliament).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__crown_sovereignty_reading, maori_iwi_hapu).
narrative_ontology:constraint_victim(waitangi_sovereignty_allocation__crown_sovereignty_reading, treaty_claimants).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Exercises plenary legislative and executive authority over all New Zealand territory under the sovereignty interpretation. Claims Article I as complete cession of sovereignty creating unitary Westminster parliamentary supremacy. Allocates resources, defines property rights, and adjudicates disputes without structural consent requirement from Māori. Maintains this reading through judicial doctrine, legislative practice, and constitutional convention despite ongoing contestation.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, crown_government, agenda_setter,
    institutional, civilizational, arbitrage, national).

% Operates under a constitutional framework that treats Crown sovereignty as complete and Parliament as supreme. Legislates over all matters including traditional Māori lands, resources, and governance structures without Treaty-based constraint. Benefits from unimpeded legislative authority and majoritarian resource allocation where Māori interests are one input among many rather than a structural veto or co-governance requirement.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, settler_majority_parliament, beneficiary,
    institutional, generational, mobile, national).

% Bear systematic subordination of traditional authority structures and resource claims under the sovereignty reading. Tribal rangatiratanga over lands, fisheries, and taonga is reduced to residual property rights subject to parliamentary override. Cannot exit the constitutional framework that governs their ancestral territories. Maintain alternative Māori-text reading asserting retained tino rangatiratanga, but this reading is structurally excluded from constitutional doctrine. Experience the sovereignty reading as imposed law rather than agreed governance.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, maori_iwi_hapu, payer,
    organized, civilizational, identity_locked, national).

% Navigate a claims process that operates within the sovereignty framework rather than challenging its foundation. The Waitangi Tribunal can recommend redress but cannot bind Parliament; claims are resolved through political negotiation where Crown sovereignty is the starting premise. Even successful claims produce settlements subordinate to parliamentary will rather than recognition of ongoing Treaty-based authority. The remedy structure itself embeds the sovereignty reading.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, treaty_claimants, payer,
    moderate, biographical, constrained, national).

% Argue for constitutional recognition of Treaty partnership requiring Crown good faith and active protection of Māori interests. Advance legal and historical scholarship supporting partnership obligations despite unambiguous English-text cession. Are heard in Tribunal processes and some judicial dicta but excluded from binding constitutional doctrine. The sovereignty reading treats partnership claims as moral or political arguments rather than constitutional limits on parliamentary authority.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, partnership_advocates, excluded,
    moderate, generational, constrained, national).

% Document that the English and Māori Treaty texts differ substantially in their sovereignty implications, that many chiefs understood they were retaining rangatiratanga rather than ceding sovereignty, and that the sovereignty reading became dominant through colonial practice rather than unambiguous textual foundation. Provide evidence that multiple constitutional framings were possible in 1840 and remain conceptually available, though only one became institutionally entrenched.
narrative_ontology:constraint_stakeholder(waitangi_sovereignty_allocation__crown_sovereignty_reading, constitutional_historians, observer,
    analytical, generational, analytical, national).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes unambiguous ultimate legal authority for resource allocation, dispute resolution, and legislative power across New Zealand territory through Westminster parliamentary supremacy backed by Crown sovereignty.
% TRANSFER_FUNCTION: Concentrates constitutional authority entirely in Crown and Parliament, systematically subordinating Māori traditional authority and Treaty-based claims to parliamentary will. Transfers decision-making power over ancestral lands, resources, and governance from iwi/hapu structures to majoritarian settler institutions.
% ABSENT_VOICES: Māori Treaty signatories operating under the Māori-text understanding that they retained tino rangatiratanga are structurally absent from the constitutional settlement. The rangatiratanga reading is excluded from binding doctrine despite being the understanding many chiefs held when signing. The founding constitutional moment embedded one reading and excluded its alternative as non-justiciable.
% DISAPPEARANCE_RATIONALE: If the sovereignty reading vanished and was replaced by partnership or rangatiratanga frameworks, New Zealand's constitutional structure would fundamentally reorganize: Parliament's supremacy would be Treaty-constrained, resource allocation would require iwi consent mechanisms, historical land claims would be adjudicated under co-governance rather than Crown ownership presumptions, and the basic legitimacy question of state authority would shift from settled doctrine to negotiated settlement. Every major policy domain touching traditional resources or Treaty obligations would operate under different constitutional rules.
% FOUNDING_PROBLEM: Post-1840 governance required ultimate legal authority to establish property rights, resolve disputes between settlers and Māori, and coordinate infrastructure development across territory with competing sovereignty claims and no accepted adjudicating framework.
% FOUNDING_PROBLEM_CORROBORATION: The Crown attests the founding problem remains live, citing need for clear ultimate authority in resource disputes and infrastructure projects. Constitutional historians, the Waitangi Tribunal record, and Māori claimants attest the founding problem is resolved: New Zealand operates stable legal and political institutions, and the sovereignty reading now persists not to solve coordination problems but to preserve parliamentary supremacy and Crown resource control against Treaty-based co-governance claims. The historical necessity dissolved into institutional extraction.
narrative_ontology:disappearance_verdict(waitangi_sovereignty_allocation__crown_sovereignty_reading, world_rearranges).
narrative_ontology:founding_problem_status(waitangi_sovereignty_allocation__crown_sovereignty_reading, dead).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(waitangi_sovereignty_allocation__crown_sovereignty_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(waitangi_sovereignty_allocation__crown_sovereignty_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(waitangi_sovereignty_allocation__crown_sovereignty_reading_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(waitangi_sovereignty_allocation__crown_sovereignty_reading, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, ExtMetricName, E),
    domain_priors:suppression_score(waitangi_sovereignty_allocation__crown_sovereignty_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(waitangi_sovereignty_allocation__crown_sovereignty_reading),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(waitangi_sovereignty_allocation__crown_sovereignty_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(waitangi_sovereignty_allocation__crown_sovereignty_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extractiveness is high (0.81 at interval end, rising from 0.68 at founding) because the sovereignty reading concentrates constitutional authority entirely in Crown and Parliament while systematically excluding Māori Treaty-based claims from binding constitutional status. The extraction intensifies over time as the gap between founding coordination necessity and contemporary institutional preservation widens. Suppression is higher still (0.88, rising from 0.72) because maintaining the reading against partnership and rangatiratanga alternatives requires active doctrinal enforcement: courts must repeatedly reaffirm parliamentary supremacy, the Waitangi Tribunal's recommendations must remain non-binding, and co-governance claims must be cabined as political concessions rather than constitutional requirements. Theater ratio rises substantially (0.42 from 0.22) as Treaty commemorations, Tribunal processes, and partnership rhetoric proliferate while the core sovereignty doctrine remains unchanged—the apparatus increasingly performs Treaty respect while preserving the constitutional structure the partnership reading would displace. Accessibility collapse is moderately high (0.73) because once parliamentary supremacy is understood as the constitutional baseline, Treaty-based limits appear as political claims rather than legal constraints. Resistance is also high (0.76) because Māori communities, Treaty scholars, and justice advocates continuously contest the sovereignty reading despite its doctrinal dominance. All three metrics share one time grid spanning the 180-year interval, with measurements at seven points showing the constraint's drift from founding coordination necessity toward entrenched institutional extraction.
 *
 * PERSPECTIVAL GAP:
 *   The Crown/Parliament seats and the Māori iwi/hapu seats should compute radically different constraint types from their structural positions. From the agenda-setter seat, the sovereignty reading is constitutional bedrock—a foundational settlement establishing clear ultimate authority for governance, presented as emerging from the Treaty text and operating as natural law of the constitutional order. From the target seats bearing identity-locked subordination of traditional authority, the same reading operates as imposed extraction: a colonial interpretation that became entrenched through practice rather than unambiguous Treaty foundation, systematically concentrating power in settler institutions while excluding Māori Treaty-based claims from constitutional status. The partnership and rangatiratanga alternatives remain live in Māori discourse and Treaty scholarship precisely because the sovereignty reading's 'natural law' status is contested rather than accepted. The metric profile—high extraction, high suppression, rising theater, strong resistance—describes operation as enforced institutional arrangement rather than inevitable constitutional fact. The engine measures this seat divergence from the structural data; the authored mountain claim and the computed seat types may legitimately differ, and that divergence is the measurement.
 *
 * DIRECTIONALITY LOGIC:
 *   Crown government is the structural beneficiary and agenda-setter: it claims the sovereignty cession as constitutional foundation, exercises the plenary authority the reading grants, and benefits from unimpeded resource allocation and legislative control (d near 0.1, full beneficiary). Settler majority Parliament is also a beneficiary: it operates under Westminster supremacy without Treaty-based co-governance constraints, legislating over traditional Māori interests as one factor among many rather than a constitutional limit (d approximately 0.15). Māori iwi/hapu are the primary targets: their traditional rangatiratanga is subordinated to parliamentary will, their resource claims are reduced to property disputes within Crown-controlled legal frameworks, and they are identity-locked to the ancestral territories the sovereignty reading governs—they cannot exit the constitutional arrangement that extracts authority from them (d near 0.95, nearly full target). Treaty claimants are secondary targets: even successful claims operate within rather than challenge the sovereignty framework, with remedies subject to parliamentary supremacy (d approximately 0.75). Partnership advocates are excluded rather than coordinated: their constitutional alternative is heard but structurally barred from displacing the sovereignty doctrine (d approximately 0.70, bearing exclusion costs without the full identity-lock of iwi/hapu). The engine computes these seat-specific d values and resulting χ from the structural data; the mountain claim does not adjudicate them.
 *
 * MANDATROPHY ANALYSIS:
 *   The sovereignty reading exhibits classic mandatrophy trajectory visible in the temporal measurements: extraction rises from 0.68 to 0.81 over 180 years as the gap between founding coordination necessity (establishing clear authority for settler-Māori dispute resolution in 1840) and contemporary function (preserving parliamentary supremacy against Treaty-based co-governance claims in 2020s) widens. Theater rises from 0.22 to 0.42 as Treaty commemorations, Waitangi Tribunal processes, and partnership rhetoric proliferate while core sovereignty doctrine remains unchanged—the state increasingly performs Treaty respect without yielding the constitutional supremacy the partnership reading would require. Suppression requirement rises from 0.72 to 0.88 as maintaining the reading against strengthening Māori constitutional scholarship, international indigenous rights norms, and domestic co-governance movements demands more active doctrinal enforcement. The founding problem (coordinating governance across competing sovereignty claims in early colonial period) is dead per historian and claimant testimony, yet the constraint persists because it concentrates authority in the beneficiary institutions that would lose power under alternative readings. The six-questions interview captures this: founding_problem_status is 'dead', disappearance_verdict is 'world_rearranges' (entrenched arrangements depend on it), and corroboration comes from outside the benefiting Crown/Parliament—exactly the status-disappearance mismatch the mandatrophy detection system targets. The sovereignty reading is a constitutional arrangement whose original coordination function has dissolved into institutional extraction, maintained through active suppression of Treaty-based alternatives.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    textual_authority_ambiguity,
    'Is the sovereignty reading grounded in unambiguous Treaty text, or in colonial practice that selected one interpretation of ambiguous dual-language texts?',
    'Comparative textual analysis combined with historical documentation of signing chiefs'' expressed understanding and early Crown-Māori interactions shows ''kāwanatanga'' was understood as limited governorship rather than sovereignty cession by many signatories. The sovereignty reading became authoritative through judicial and legislative practice rather than clear textual foundation.',
    'If the textual foundation is ambiguous and the sovereignty reading was one possible interpretation entrenched through colonial power rather than inevitable from Treaty language, the mountain claim dissolves—the constraint is constructed institutional choice rather than natural constitutional law, shifting classification toward tangled_rope or snare depending on whether coordination function remains.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(textual_authority_ambiguity, empirical, 'Whether sovereignty reading emerges from unambiguous text or colonial interpretive practice').

omega_variable(
    founding_necessity_vs_contemporary_extraction,
    'Did the sovereignty reading solve a genuine 1840 coordination problem (competing authority claims requiring ultimate arbiter), or has contemporary persistence shifted from coordination to institutional extraction?',
    'Historical analysis of early colonial period shows real coordination necessity for dispute resolution; contemporary analysis shows stable institutions no longer requiring sovereignty doctrine to function, with the reading now preserving parliamentary supremacy against Treaty-based co-governance claims. Founding necessity was real; contemporary function is power preservation.',
    'If the coordination necessity dissolved and the constraint persists to concentrate authority in beneficiary institutions against Treaty-based limits, the mountain claim is false summit—mandatrophy has occurred, and the constraint should reclassify to tangled_rope (residual coordination with layered extraction) or snare (pure extraction with coordination cover story).',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(founding_necessity_vs_contemporary_extraction, empirical, 'Whether contemporary persistence serves coordination or institutional extraction').

omega_variable(
    naturalness_vs_beneficiary_entrenchment,
    'Is parliamentary supremacy a natural feature of New Zealand''s constitutional order, or a constructed reading that became entrenched because it benefits the institutions that interpret constitutional doctrine?',
    'Structural analysis: the institutions that benefit from the sovereignty reading (Crown, Parliament, settler-majority judiciary) are the same institutions that determine which Treaty interpretation has constitutional authority. Alternative readings that would constrain those institutions remain live in scholarship and Māori discourse but excluded from binding doctrine. The sovereignty reading is not inevitable—it is maintained by the beneficiaries.',
    'If the sovereignty reading persists because beneficiary institutions exclude alternatives rather than because it emerges naturally from Treaty text or constitutional necessity, the mountain claim is false and the constraint operates as institutional extraction. The presence of beneficiaries (Crown, settler Parliament) collecting authority concentration while victims (iwi/hapu) bear subordination is the false-summit signature—a claimed natural law that identifiably benefits specific parties.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(naturalness_vs_beneficiary_entrenchment, conceptual, 'Whether sovereignty reading is natural constitutional law or beneficiary-entrenched interpretation').

omega_variable(
    committer_kernel_reading_selection,
    'Why did the sovereignty reading become constitutionally dominant when partnership and rangatiratanga readings were also available from Treaty text and signing-chiefs'' understanding?',
    'Historical analysis shows sovereignty reading was selected and entrenched by colonial legal system during period of Crown territorial expansion and resource appropriation. Alternative readings that would have constrained Crown authority or required co-governance were available but structurally excluded from constitutional doctrine because they conflicted with colonial project. The reading selection was not textually inevitable—it was institutionally chosen.',
    'If the sovereignty reading''s dominance results from colonial institutional power selecting the interpretation that maximized Crown authority rather than from unambiguous textual foundation, the constraint is one reading of a contested kernel rather than natural constitutional law. The kernel (Treaty of Waitangi sovereignty allocation) admits multiple readings with different beneficiary/victim structures; only one became entrenched, and its entrenchment tracks beneficiary power rather than textual clarity.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(committer_kernel_reading_selection, conceptual, 'Kernel reading selection mechanism: textual inevitability vs institutional power').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(waitangi_sovereignty_allocation__crown_sovereignty_reading, 0, 180).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(wait_tr_t0, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 0, 0.22).
narrative_ontology:measurement_basis(wait_tr_t0, observed).
narrative_ontology:measurement(wait_tr_t30, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 30, 0.26).
narrative_ontology:measurement_basis(wait_tr_t30, observed).
narrative_ontology:measurement(wait_tr_t60, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 60, 0.3).
narrative_ontology:measurement_basis(wait_tr_t60, observed).
narrative_ontology:measurement(wait_tr_t90, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 90, 0.34).
narrative_ontology:measurement_basis(wait_tr_t90, observed).
narrative_ontology:measurement(wait_tr_t120, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 120, 0.37).
narrative_ontology:measurement_basis(wait_tr_t120, observed).
narrative_ontology:measurement(wait_tr_t150, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 150, 0.4).
narrative_ontology:measurement_basis(wait_tr_t150, observed).
narrative_ontology:measurement(wait_tr_t180, waitangi_sovereignty_allocation__crown_sovereignty_reading, theater_ratio, 180, 0.42).
narrative_ontology:measurement_basis(wait_tr_t180, observed).

% Extraction over time
narrative_ontology:measurement(wait_be_t0, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 0, 0.68).
narrative_ontology:measurement_basis(wait_be_t0, observed).
narrative_ontology:measurement(wait_be_t30, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 30, 0.71).
narrative_ontology:measurement_basis(wait_be_t30, observed).
narrative_ontology:measurement(wait_be_t60, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 60, 0.74).
narrative_ontology:measurement_basis(wait_be_t60, observed).
narrative_ontology:measurement(wait_be_t90, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 90, 0.76).
narrative_ontology:measurement_basis(wait_be_t90, observed).
narrative_ontology:measurement(wait_be_t120, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 120, 0.78).
narrative_ontology:measurement_basis(wait_be_t120, observed).
narrative_ontology:measurement(wait_be_t150, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 150, 0.8).
narrative_ontology:measurement_basis(wait_be_t150, observed).
narrative_ontology:measurement(wait_be_t180, waitangi_sovereignty_allocation__crown_sovereignty_reading, base_extractiveness, 180, 0.81).
narrative_ontology:measurement_basis(wait_be_t180, observed).

% Suppression requirement over time
narrative_ontology:measurement(wait_su_t0, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 0, 0.72).
narrative_ontology:measurement_basis(wait_su_t0, observed).
narrative_ontology:measurement(wait_su_t30, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 30, 0.76).
narrative_ontology:measurement_basis(wait_su_t30, observed).
narrative_ontology:measurement(wait_su_t60, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 60, 0.79).
narrative_ontology:measurement_basis(wait_su_t60, observed).
narrative_ontology:measurement(wait_su_t90, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 90, 0.82).
narrative_ontology:measurement_basis(wait_su_t90, observed).
narrative_ontology:measurement(wait_su_t120, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 120, 0.84).
narrative_ontology:measurement_basis(wait_su_t120, observed).
narrative_ontology:measurement(wait_su_t150, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 150, 0.86).
narrative_ontology:measurement_basis(wait_su_t150, observed).
narrative_ontology:measurement(wait_su_t180, waitangi_sovereignty_allocation__crown_sovereignty_reading, suppression_requirement, 180, 0.88).
narrative_ontology:measurement_basis(wait_su_t180, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(waitangi_sovereignty_allocation__crown_sovereignty_reading, enforcement_mechanism).
narrative_ontology:boltzmann_floor_override(waitangi_sovereignty_allocation__crown_sovereignty_reading, 0.15).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__crown_sovereignty_reading, waitangi_sovereignty_allocation__partnership_reading).
narrative_ontology:affects_constraint(waitangi_sovereignty_allocation__crown_sovereignty_reading, waitangi_sovereignty_allocation__rangatiratanga_reading).

% DUAL FORMULATION NOTE:
% The Treaty of Waitangi sovereignty allocation is a contested kernel admitting multiple constitutional readings with radically different ε values and beneficiary/victim structures. The crown_sovereignty_reading (this constraint) concentrates authority in Crown/Parliament and subordinates Māori Treaty-based claims; the partnership_reading creates binding co-governance obligations constraining Crown authority; the rangatiratanga_reading preserves Māori sovereignty and reduces Crown power to settler governorship. These are not perspective-dependent views of one constraint—they are three distinct constitutional structures that cannot coexist within a single legal framework. Only the sovereignty reading became entrenched in binding doctrine, and its entrenchment tracks colonial institutional power rather than unambiguous textual foundation. The framework models them as three separate constraint stories linked by affects_constraints, each with its own stakeholders, ε, and classification, rather than as one story with a measurement parameter.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
