% ============================================================================
% CONSTRAINT STORY: acceptable_risk_energy__catastrophic_tail_dominant
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-12
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_acceptable_risk_energy__catastrophic_tail_dominant, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: acceptable_risk_energy__catastrophic_tail_dominant
 *   human_readable: Catastrophic Tail Dominance in Energy Risk Assessment
 *   domain: risk_assessment/energy_policy/decision_theory
 *
 * SUMMARY:
 *   The catastrophic tail dominance reading of acceptable risk in energy
 *   policy prioritizes avoiding low-probability high-consequence nuclear
 *   accidents even when this choice produces higher expected aggregate
 *   mortality through continued fossil dependence. It is CLAIMED as mountain
 *   (a natural feature of rational decision-making under uncertainty) while
 *   the metrics describe substantial extraction and active enforcement
 *   against nuclear pathway development. The engine will measure this
 *   divergence from the structural data — the claim and metrics are
 *   independently authored and deliberately not reconciled.
 *
 * KEY AGENTS:
 *   - fossil_fuel_industry: Primary beneficiary (institutional/constrained) — maintains market position through nuclear suppression
 *   - anti_nuclear_advocacy_organizations: Agenda setter (organized/mobile) — constructs and propagates the risk framing
 *   - future_generations_climate_exposed: Victim (powerless/trapped/civilizational) — bears accumulated climate risk from delayed transition
 *   - present_day_air_pollution_casualties: Victim (powerless/trapped/immediate) — dies from distributed fossil mortality rendered invisible by framing
 *   - nuclear_energy_development_pipeline: Victim (moderate/constrained) — faces suppression through catastrophic-calibrated barriers
 *   - climate_policy_economists: Observer (analytical) — documents mortality inversion and policy-induced harm
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(acceptable_risk_energy__catastrophic_tail_dominant, 0.71).
domain_priors:suppression_score(acceptable_risk_energy__catastrophic_tail_dominant, 0.78).
domain_priors:theater_ratio(acceptable_risk_energy__catastrophic_tail_dominant, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, extractiveness, 0.71).
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 0.78).
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, accessibility_collapse, 0.48).
narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, resistance, 0.62).

% --- Constraint claim ---
narrative_ontology:constraint_claim(acceptable_risk_energy__catastrophic_tail_dominant, mountain).
narrative_ontology:human_readable(acceptable_risk_energy__catastrophic_tail_dominant, "Catastrophic Tail Dominance in Energy Risk Assessment").
narrative_ontology:topic_domain(acceptable_risk_energy__catastrophic_tail_dominant, "risk_assessment/energy_policy/decision_theory").

domain_priors:requires_active_enforcement(acceptable_risk_energy__catastrophic_tail_dominant).
domain_priors:emerges_naturally(acceptable_risk_energy__catastrophic_tail_dominant).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(acceptable_risk_energy__catastrophic_tail_dominant, 'f5ed37c0-64ed-4587-9861-0462a7902949').
narrative_ontology:cs_kernel_codification('f5ed37c0-64ed-4587-9861-0462a7902949', distributed).
narrative_ontology:cs_authority_grounding('f5ed37c0-64ed-4587-9861-0462a7902949', distributed).
narrative_ontology:cs_reading_relation('f5ed37c0-64ed-4587-9861-0462a7902949', acceptable_risk_energy__expected_value_dominant, coexists_with).
narrative_ontology:cs_reading_relation('f5ed37c0-64ed-4587-9861-0462a7902949', acceptable_risk_energy__option_value_preserving, coexists_with).
narrative_ontology:cs_axiom('f5ed37c0-64ed-4587-9861-0462a7902949', foundational, catastrophic_scenarios_infinite_weight).
narrative_ontology:cs_axiom_status(catastrophic_scenarios_infinite_weight, holdable).
narrative_ontology:cs_axiom_grounding('f5ed37c0-64ed-4587-9861-0462a7902949', catastrophic_scenarios_infinite_weight, deontological).
narrative_ontology:cs_axiom('f5ed37c0-64ed-4587-9861-0462a7902949', secondary, distributed_mortality_temporally_discountable).
narrative_ontology:cs_axiom_status(distributed_mortality_temporally_discountable, holdable).
narrative_ontology:cs_axiom_grounding('f5ed37c0-64ed-4587-9861-0462a7902949', distributed_mortality_temporally_discountable, conventional).
narrative_ontology:cs_reference_frame('f5ed37c0-64ed-4587-9861-0462a7902949', early_nuclear_era_epistemic_uncertainty).
narrative_ontology:cs_drift_state('f5ed37c0-64ed-4587-9861-0462a7902949', post_passive_safety_and_mortality_data_era, gap(axiom_overriding, substantial, false)).
narrative_ontology:cs_created_at('f5ed37c0-64ed-4587-9861-0462a7902949', '').
narrative_ontology:cs_kernel_id(acceptable_risk_energy__catastrophic_tail_dominant, acceptable_risk_energy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__catastrophic_tail_dominant, fossil_fuel_industry).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__catastrophic_tail_dominant, anti_nuclear_advocacy_organizations).
narrative_ontology:constraint_beneficiary(acceptable_risk_energy__catastrophic_tail_dominant, coal_dependent_regional_economies).
narrative_ontology:constraint_victim(acceptable_risk_energy__catastrophic_tail_dominant, future_generations_climate_exposed).
narrative_ontology:constraint_victim(acceptable_risk_energy__catastrophic_tail_dominant, present_day_air_pollution_casualties).
narrative_ontology:constraint_victim(acceptable_risk_energy__catastrophic_tail_dominant, nuclear_energy_development_pipeline).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__catastrophic_tail_dominant, precautionary_principle_absolute_form).
narrative_ontology:constraint_vindicates(acceptable_risk_energy__catastrophic_tail_dominant, catastrophic_risk_incommensurability).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Benefits from policy frameworks that suppress nuclear pathway development. The catastrophic framing of nuclear risk maintains demand for fossil baseload capacity that would otherwise face displacement. Competes in the same energy market but operates under different risk accounting: distributed fossil mortality is absorbed into background statistics while concentrated nuclear scenarios remain salient in regulatory gatekeeping.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, fossil_fuel_industry, beneficiary,
    institutional, biographical, constrained, global).

% Construct and propagate the risk framing itself. Maintain institutional memory of Chernobyl and Fukushima as proof of catastrophic irreversibility. Successfully lobbied for regulatory structures that encode tail-dominant risk assessment into nuclear licensing while analogous frameworks do not exist for chronic fossil mortality. Their organizational legitimacy depends on the continued salience of the catastrophic nuclear narrative.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, anti_nuclear_advocacy_organizations, agenda_setter,
    organized, generational, mobile, national).

% Preserve employment and tax base through continued coal operation justified partly by nuclear pathway suppression. The catastrophic risk frame provides political cover for delaying transition. Their economic dependence on fossil infrastructure makes them structurally aligned with any framework that slows nuclear adoption, even though they bear direct local health costs from coal emissions.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, coal_dependent_regional_economies, beneficiary,
    organized, biographical, trapped, regional).

% Bear the accumulated climate risk from decades of continued fossil dependence enabled by nuclear suppression. They have no voice in current risk assessment frameworks. The catastrophic tail framing discounts distributed future harm in favor of avoiding concentrated present scenarios, systematically transferring risk forward in time to populations with no representation.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, future_generations_climate_exposed, payer,
    powerless, civilizational, trapped, global).

% Die annually from fossil fuel combustion byproducts at rates orders of magnitude higher than nuclear casualties across all historical accidents combined. Their deaths are statistically distributed, individually unspectacular, and occur in the normal course of energy system operation rather than as discrete catastrophic events, rendering them invisible to the risk framing that gates policy.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, present_day_air_pollution_casualties, payer,
    powerless, immediate, trapped, local).

% Faces regulatory barriers and financing costs calibrated to catastrophic tail scenarios rather than aggregate mortality metrics. Projects are abandoned or delayed by orders of magnitude compared to fossil alternatives despite lower mortality-per-TWh. The constraint operates through licensing timelines, insurance requirements, and public opposition mobilized around the catastrophic frame.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, nuclear_energy_development_pipeline, payer,
    moderate, generational, constrained, national).

% Measure mortality-per-TWh across all energy sources and document the expected-value inversion: the risk frame produces higher aggregate mortality by suppressing the statistically safest baseload option. Publish integrated assessment models showing climate trajectories under different energy mixes. Their analysis reveals the structure but does not determine the framing that enters policy.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, climate_policy_economists, observer,
    analytical, generational, analytical, global).

% Administer the licensing frameworks that encode catastrophic tail dominance into nuclear pathway requirements. Simultaneously observe that the standards they enforce produce systematic bias toward higher-mortality alternatives. Institutionally bound to the precautionary interpretation even when their own technical staff document the mortality inversion.
narrative_ontology:constraint_stakeholder(acceptable_risk_energy__catastrophic_tail_dominant, nuclear_safety_regulators, agenda_setter,
    institutional, generational, constrained, national).
narrative_ontology:stakeholder_secondary_role(acceptable_risk_energy__catastrophic_tail_dominant, nuclear_safety_regulators, observer).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes common decision criteria for energy infrastructure investment under uncertainty. Provides a shared framework for comparing incomparable risks: discrete catastrophic events versus distributed chronic harms. Enables regulatory coherence across jurisdictions facing similar energy trilemmas.
% TRANSFER_FUNCTION: Transfers mortality risk from concentrated visible scenarios to distributed invisible background casualties. Moves climate risk forward in time from present regulatory decisions to future populations. Redirects capital from nuclear development pipeline to fossil incumbents and their supply chains.
% ABSENT_VOICES: Future generations bearing accumulated climate costs have no seat. Present-day air pollution casualties are statistically visible but politically inert. Nuclear engineering community that could articulate alternative risk frames is structurally excluded from framing-level discourse by the precautionary interpretation already embedded in regulatory architecture.
% DISAPPEARANCE_RATIONALE: If catastrophic tail dominance vanished as a decision criterion, energy infrastructure investment would rebalance toward mortality-minimizing portfolios. Nuclear licensing timelines would compress to match fossil alternatives under equivalent safety standards. Regional coal dependence would lose its climate-policy cover. Anti-nuclear advocacy organizations would require different legitimating narratives. Fossil industry market share would contract as baseload competition intensified.
% FOUNDING_PROBLEM: Post-war energy planning faced genuine uncertainty about low-probability high-consequence nuclear failure modes with no historical base rates. Early reactor designs carried real catastrophic potential. The precautionary frame emerged as epistemic humility under deep uncertainty about complex technological systems.
% FOUNDING_PROBLEM_CORROBORATION: The constraint's beneficiaries attest the founding problem remains live, citing Fukushima as recent evidence. Climate economists and nuclear safety engineers attest the founding problem is substantially resolved: modern reactor designs are passively safe, historical accident rates are now statistically bounded, and the mortality-per-TWh gap between nuclear and fossil is empirically established across 70 years of operation. Independent mortality accounting from public health researchers outside the energy sector corroborates the shifted-function reading.
narrative_ontology:disappearance_verdict(acceptable_risk_energy__catastrophic_tail_dominant, world_rearranges).
narrative_ontology:founding_problem_status(acceptable_risk_energy__catastrophic_tail_dominant, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(acceptable_risk_energy__catastrophic_tail_dominant, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(acceptable_risk_energy__catastrophic_tail_dominant, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(acceptable_risk_energy__catastrophic_tail_dominant_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(acceptable_risk_energy__catastrophic_tail_dominant, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, ExtMetricName, E),
    domain_priors:suppression_score(acceptable_risk_energy__catastrophic_tail_dominant, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(acceptable_risk_energy__catastrophic_tail_dominant),
    narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(acceptable_risk_energy__catastrophic_tail_dominant, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(acceptable_risk_energy__catastrophic_tail_dominant_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is high (0.71) because the framing systematically transfers mortality from visible concentrated scenarios to invisible distributed casualties at a rate that produces higher total harm. Suppression is high (0.78) because nuclear pathway development requires active regulatory barriers calibrated to tail scenarios while fossil alternatives face no equivalent catastrophic accounting. Theater ratio is moderate (0.42): genuine early uncertainty about reactor safety has been replaced by performative precaution as passive safety and historical base rates have resolved the founding problem. Accessibility collapse is moderate-low (0.48) because alternative risk frames (expected value, option value) remain intellectually available even though institutionally suppressed. Resistance is substantial (0.62) because nuclear engineers, climate economists, and mortality-accounting public health researchers actively contest the framing. The temporal series shows extractiveness and suppression intensifying as the founding problem (genuine uncertainty) resolves but the institutional apparatus persists.
 *
 * PERSPECTIVAL GAP:
 *   From the fossil industry seat, the constraint operates as legitimate risk prudence that happens to align with their market interests. From the anti-nuclear advocacy seat, it is vindication of precautionary principle against technological hubris. From the powerless victim seats (future generations, present casualties), the same structure operates as systematic mortality transfer. From the analytical seat, it is an expected-value inversion maintained by salience bias and regulatory path dependence. The engine computes these seat-level classifications from the structural positioning — the authored mountain claim does not adjudicate them.
 *
 * DIRECTIONALITY LOGIC:
 *   Fossil fuel industry and coal-dependent regional economies are structural beneficiaries (d near beneficiary end): they collect market protection and regulatory cover from nuclear suppression. Anti-nuclear advocacy organizations are agenda setters maintaining the framing but with mobile exit. Future generations and present-day air pollution casualties are the primary victims (d near full-target end, powerless/trapped): they bear the mortality transfer with no voice in the framing. Nuclear development pipeline is constrained target. Regulators are dual-positioned: institutionally bound to enforce catastrophic standards while observing the mortality inversion.
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint's mandate (avoid catastrophic nuclear accidents) has not outlived its function if one accepts infinite weighting of tail scenarios as natural. But the mortality data establishes that catastrophic avoidance produces higher aggregate harm, and the founding uncertainty (reactor failure modes) is substantially resolved by passive safety and 70 years of base rates. The arrangement persists not because the problem persists but because the framing is institutionally entrenched and benefits identifiable actors. This is the mandatrophy signature: founding problem status is contested, disappearance would rearrange arrangements (not leave world unchanged), and beneficiaries lack corroboration from outside seats for the claim that founding uncertainty remains live.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    natural_vs_constructed_risk_framing,
    'Is catastrophic tail dominance a natural feature of rational decision-making under uncertainty (as claimed), or a constructed policy frame that benefits identifiable actors by systematically discounting distributed mortality?',
    'Cross-cultural risk perception studies showing whether tail dominance is universal or culturally contingent. Historical analysis of when precautionary principle gained institutional force and which actors promoted its adoption. Longitudinal tracking of whether mortality-per-TWh data shifts public risk intuitions once widely disseminated.',
    'If natural, the constraint is a mountain and the mortality inversion is an unavoidable cost of human cognitive architecture. If constructed with identifiable beneficiaries, it is extractive coordination (tangled rope) or pure extraction (snare) depending on whether any genuine coordination function remains separable from the beneficiary structure.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(natural_vs_constructed_risk_framing, conceptual, 'Whether tail dominance reflects natural risk psychology or constructed policy benefiting identifiable actors').

omega_variable(
    salience_bias_vs_rational_incommensurability,
    'Does catastrophic tail dominance reflect salience bias (cognitive error overweighting vivid scenarios) or genuine rational incommensurability (some harms cannot be aggregated with others)?',
    'Experimental philosophy studies testing whether subjects maintain tail dominance after viewing equivalent-framing mortality data. Decision theory analysis of whether infinite weighting can be derived from axioms or requires additional normative premise. Neuroscience of risk perception distinguishing automatic salience from reflective evaluation.',
    'If salience bias, the constraint is a systematic cognitive error that can be corrected through better risk communication and framing interventions. If rational incommensurability, the constraint reflects a legitimate ethical judgment about non-fungibility of harms, and mortality-per-TWh optimization is the error.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(salience_bias_vs_rational_incommensurability, empirical, 'Whether tail dominance is cognitive bias or defensible ethical position about harm incommensurability').

omega_variable(
    passive_safety_threshold,
    'At what level of passive safety design (if any) does the catastrophic nuclear scenario cease to warrant infinite weight in risk accounting?',
    'Engineering analysis of failure mode exhaustion in Generation IV designs. Probabilistic risk assessment comparing passive-safe reactor scenarios to other accepted societal risks (dam failures, chemical plant accidents, aviation). Revealed preference analysis of regulatory treatment of other low-probability catastrophic infrastructure risks.',
    'If passive safety can drive catastrophic probability below societal threshold for infinite weighting, the continued application of tail dominance to modern reactor designs is unjustified precaution. If no threshold exists because catastrophe is axiomatically infinite-weight regardless of probability, then the frame cannot be resolved by technical improvement.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(passive_safety_threshold, empirical, 'Whether engineering can resolve the catastrophic frame or whether frame is probability-insensitive').

omega_variable(
    temporal_discount_asymmetry,
    'Why does the catastrophic frame discount future distributed climate mortality but not future concentrated nuclear scenarios, when both are probabilistic and both harm future populations?',
    'Explicit elicitation of temporal discounting applied to nuclear vs. climate risks in regulatory cost-benefit analyses. Consistency check across policy domains for treatment of low-probability future harms. Comparison of how different risk frames handle intergenerational transfers.',
    'If the temporal asymmetry is arbitrary, it reveals the frame as serving present fossil interests at future expense rather than expressing consistent precautionary principle. If the asymmetry is principled (concentration matters more than distribution), the principle needs articulation to be evaluable.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(temporal_discount_asymmetry, conceptual, 'Whether differential temporal treatment of nuclear vs. climate risk is principled or arbitrary').

omega_variable(
    institutional_path_dependence,
    'Would the catastrophic tail frame have been adopted if modern mortality-per-TWh data were available at the moment of initial regulatory architecture design, or does the frame persist primarily through institutional inertia?',
    'Historical counterfactual analysis of regulatory origins. International comparison of jurisdictions that developed nuclear policy at different informational moments. Regulatory reform case studies examining barriers to updating risk frameworks when new mortality data emerges.',
    'If path dependence dominates, the constraint is maintained by switching costs and beneficiary resistance rather than by continued epistemic warrant, strengthening the extractive reading. If the frame would be readopted given current information, institutional inertia is not explanatorily load-bearing.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(institutional_path_dependence, empirical, 'Whether constraint persistence is information-driven or institutionally locked-in').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(acceptable_risk_energy__catastrophic_tail_dominant, 0, 35).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(acce_tr_t0, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 0, 0.18).
narrative_ontology:measurement_basis(acce_tr_t0, observed).
narrative_ontology:measurement(acce_tr_t7, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 7, 0.23).
narrative_ontology:measurement_basis(acce_tr_t7, observed).
narrative_ontology:measurement(acce_tr_t14, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 14, 0.29).
narrative_ontology:measurement_basis(acce_tr_t14, observed).
narrative_ontology:measurement(acce_tr_t21, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 21, 0.34).
narrative_ontology:measurement_basis(acce_tr_t21, observed).
narrative_ontology:measurement(acce_tr_t28, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 28, 0.38).
narrative_ontology:measurement_basis(acce_tr_t28, observed).
narrative_ontology:measurement(acce_tr_t35, acceptable_risk_energy__catastrophic_tail_dominant, theater_ratio, 35, 0.42).
narrative_ontology:measurement_basis(acce_tr_t35, observed).

% Extraction over time
narrative_ontology:measurement(acce_be_t0, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 0, 0.38).
narrative_ontology:measurement_basis(acce_be_t0, observed).
narrative_ontology:measurement(acce_be_t7, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 7, 0.48).
narrative_ontology:measurement_basis(acce_be_t7, observed).
narrative_ontology:measurement(acce_be_t14, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 14, 0.56).
narrative_ontology:measurement_basis(acce_be_t14, observed).
narrative_ontology:measurement(acce_be_t21, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 21, 0.63).
narrative_ontology:measurement_basis(acce_be_t21, observed).
narrative_ontology:measurement(acce_be_t28, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 28, 0.68).
narrative_ontology:measurement_basis(acce_be_t28, observed).
narrative_ontology:measurement(acce_be_t35, acceptable_risk_energy__catastrophic_tail_dominant, base_extractiveness, 35, 0.71).
narrative_ontology:measurement_basis(acce_be_t35, observed).

% Suppression requirement over time
narrative_ontology:measurement(acce_su_t0, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 0, 0.52).
narrative_ontology:measurement_basis(acce_su_t0, observed).
narrative_ontology:measurement(acce_su_t7, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 7, 0.59).
narrative_ontology:measurement_basis(acce_su_t7, observed).
narrative_ontology:measurement(acce_su_t14, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 14, 0.65).
narrative_ontology:measurement_basis(acce_su_t14, observed).
narrative_ontology:measurement(acce_su_t21, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 21, 0.71).
narrative_ontology:measurement_basis(acce_su_t21, observed).
narrative_ontology:measurement(acce_su_t28, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 28, 0.75).
narrative_ontology:measurement_basis(acce_su_t28, observed).
narrative_ontology:measurement(acce_su_t35, acceptable_risk_energy__catastrophic_tail_dominant, suppression_requirement, 35, 0.78).
narrative_ontology:measurement_basis(acce_su_t35, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(acceptable_risk_energy__catastrophic_tail_dominant, enforcement_mechanism).
narrative_ontology:affects_constraint(acceptable_risk_energy__catastrophic_tail_dominant, acceptable_risk_energy__expected_value_dominant).
narrative_ontology:affects_constraint(acceptable_risk_energy__catastrophic_tail_dominant, acceptable_risk_energy__option_value_preserving).

% DUAL FORMULATION NOTE:
% This constraint is one of three readings of the acceptable_risk_energy kernel. The catastrophic_tail_dominant reading (this file) assigns infinite weight to nuclear accidents and suppresses nuclear pathway; the expected_value_dominant reading minimizes aggregate mortality using mortality-per-TWh; the option_value_preserving reading maintains multiple pathways under deep uncertainty. They decompose because they have different victim sets (this reading: future climate casualties; expected-value: present air pollution casualties and future climate both), different beneficiary structures (this reading: fossil incumbents; expected-value: future populations generally), and different ε values (this reading: high extraction from mortality transfer; expected-value: low extraction from mortality minimization).

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
