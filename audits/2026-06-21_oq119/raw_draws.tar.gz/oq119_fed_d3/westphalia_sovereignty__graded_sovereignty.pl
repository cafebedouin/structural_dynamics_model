% ============================================================================
% CONSTRAINT STORY: westphalia_sovereignty__graded_sovereignty
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-11
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_westphalia_sovereignty__graded_sovereignty, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:measurement_basis/2,
    narrative_ontology:coordination_type/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:stakeholder_secondary_role/3,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: westphalia_sovereignty__graded_sovereignty
 *   human_readable: Graded Sovereignty: Scalar State Capacity and Intervention Legitimacy
 *   domain: international_law/political_theory
 *
 * SUMMARY:
 *   Graded sovereignty is one reading of the post-Westphalian sovereignty
 *   kernel. It treats state authority as existing on a spectrum calibrated to
 *   institutional capacity, with intervention legitimacy scaled inversely to
 *   capacity scores. The framework emerged in post-Cold War debates over
 *   humanitarian intervention and state-building, presented as a realistic
 *   middle path between absolute non-intervention and unilateral regime
 *   change. It is CLAIMED as mountain (a natural recognition of empirical
 *   capacity variation in the state system) while the metrics describe
 *   substantial extraction (authority transfer from weak to strong states),
 *   high suppression (low-capacity states cannot exit their designated
 *   status), and rising theater (capacity measurement increasingly performs
 *   legitimation for strategic intervention rather than tracking objective
 *   governance). The divergence is the point: the engine measures whether a
 *   claimed natural law operates as constructed hierarchy.
 *
 * KEY AGENTS:
 *   - capacity_evaluation_authorities: Primary agenda-setters (institutional/arbitrage) — design the capacity indices and maintain the measurement infrastructure
 *   - intervention_capable_states: Primary beneficiaries (institutional/arbitrage) — gain normative cover for intervention and preserve categorical sovereignty for themselves
 *   - international_development_institutions: Dual beneficiary/agenda-setter (institutional/mobile) — gain operational mandates and prestige from administering remediation
 *   - low_capacity_states: Primary targets (moderate/identity_locked) — lose decision-making authority and face externally imposed governance under capacity deficits they cannot quickly remedy
 *   - disputed_governance_entities: Secondary targets (moderate/trapped) — denied recognition and territorial protection because capacity framework treats them as symptoms of failure
 *   - populations_in_low_capacity_states: Dual beneficiary/payer (powerless/trapped) — invoked as justification but bear consequences of external governance
 *   - legal_scholars_of_intervention: Analytical observers (analytical/analytical) — assess whether the framework describes reality or constructs hierarchy
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(westphalia_sovereignty__graded_sovereignty, 0.68).
domain_priors:suppression_score(westphalia_sovereignty__graded_sovereignty, 0.71).
domain_priors:theater_ratio(westphalia_sovereignty__graded_sovereignty, 0.42).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, extractiveness, 0.68).
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, suppression_requirement, 0.71).
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, theater_ratio, 0.42).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, accessibility_collapse, 0.34).
narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, resistance, 0.73).

% --- Constraint claim ---
narrative_ontology:constraint_claim(westphalia_sovereignty__graded_sovereignty, mountain).
narrative_ontology:human_readable(westphalia_sovereignty__graded_sovereignty, "Graded Sovereignty: Scalar State Capacity and Intervention Legitimacy").
narrative_ontology:topic_domain(westphalia_sovereignty__graded_sovereignty, "international_law/political_theory").

domain_priors:requires_active_enforcement(westphalia_sovereignty__graded_sovereignty).
domain_priors:emerges_naturally(westphalia_sovereignty__graded_sovereignty).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(westphalia_sovereignty__graded_sovereignty, '11d19e0a-331e-4319-999d-f5c432882633').
narrative_ontology:cs_kernel_codification('11d19e0a-331e-4319-999d-f5c432882633', formalized).
narrative_ontology:cs_authority_grounding('11d19e0a-331e-4319-999d-f5c432882633', expertise).
narrative_ontology:cs_interpretation_layer_present('11d19e0a-331e-4319-999d-f5c432882633').
narrative_ontology:cs_reading_relation('11d19e0a-331e-4319-999d-f5c432882633', westphalia_sovereignty__absolute_non_intervention, forecloses).
narrative_ontology:cs_reading_relation('11d19e0a-331e-4319-999d-f5c432882633', westphalia_sovereignty__conditional_responsibility, coexists_with).
narrative_ontology:cs_axiom('11d19e0a-331e-4319-999d-f5c432882633', foundational, sovereignty_proportional_to_capacity).
narrative_ontology:cs_axiom_status(sovereignty_proportional_to_capacity, holdable).
narrative_ontology:cs_axiom_grounding('11d19e0a-331e-4319-999d-f5c432882633', sovereignty_proportional_to_capacity, empirically_contingent).
narrative_ontology:cs_axiom('11d19e0a-331e-4319-999d-f5c432882633', foundational, intervention_legitimacy_calibrated_to_deficit).
narrative_ontology:cs_axiom_status(intervention_legitimacy_calibrated_to_deficit, holdable).
narrative_ontology:cs_axiom_grounding('11d19e0a-331e-4319-999d-f5c432882633', intervention_legitimacy_calibrated_to_deficit, instrumental).
narrative_ontology:cs_reference_frame('11d19e0a-331e-4319-999d-f5c432882633', westphalian_categorical_sovereignty).
narrative_ontology:cs_drift_state('11d19e0a-331e-4319-999d-f5c432882633', post_cold_war_intervention_era, gap(practice_drift, substantial, false)).
narrative_ontology:cs_created_at('11d19e0a-331e-4319-999d-f5c432882633', '').
narrative_ontology:cs_kernel_id(westphalia_sovereignty__graded_sovereignty, westphalia_sovereignty).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, capacity_evaluation_authorities).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, intervention_capable_states).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, international_development_institutions).
narrative_ontology:constraint_victim(westphalia_sovereignty__graded_sovereignty, low_capacity_states).
narrative_ontology:constraint_victim(westphalia_sovereignty__graded_sovereignty, disputed_governance_entities).
% Derived from stakeholders[] roles (beneficiary->beneficiary, payer->victim;
% agent-gated; excluded derives nothing; deduped against the authored arrays).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, populations_in_low_capacity_states).
narrative_ontology:constraint_beneficiary(westphalia_sovereignty__graded_sovereignty, regional_security_organizations).
narrative_ontology:constraint_victim(westphalia_sovereignty__graded_sovereignty, populations_in_low_capacity_states).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__graded_sovereignty, hierarchical_state_order_naturalism).
narrative_ontology:constraint_vindicates(westphalia_sovereignty__graded_sovereignty, capacity_based_legitimacy_doctrine).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Developed and maintain the metrics, indices, and frameworks by which state capacity is measured and intervention thresholds are calibrated. They publish annual assessments ranking states on governance, institutional effectiveness, and control over territory. Their evaluations shape donor conditionality, humanitarian intervention discourse, and UN Security Council deliberation. They present capacity measurement as technical expertise applied to objective governance indicators.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, capacity_evaluation_authorities, agenda_setter,
    institutional, generational, arbitrage, global).

% Possess military, economic, and diplomatic resources to intervene across borders. Under graded sovereignty, their intervention in low-capacity states gains normative cover as remedial action rather than aggression. They fund the capacity-evaluation institutions, cite their indices in intervention justifications, and shape the thresholds at which sovereignty is treated as degraded. They benefit from a tiered international order where their own territorial inviolability is categorical while intervention elsewhere is calibrated to metrics they substantially control.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, intervention_capable_states, beneficiary,
    institutional, generational, arbitrage, global).

% Administer loans, grants, and technical assistance conditioned on governance reforms and capacity improvements. Graded sovereignty provides the normative scaffolding for their conditionality regimes: states scoring low on capacity indices face intrusive monitoring, structural adjustment requirements, and diminished sovereignty over fiscal and regulatory policy. They collect operational authority and prestige from being the designated capacity-builders; their continued relevance depends on the persistence of a tiered state system requiring remediation.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, international_development_institutions, beneficiary,
    institutional, generational, mobile, global).
narrative_ontology:stakeholder_secondary_role(westphalia_sovereignty__graded_sovereignty, international_development_institutions, agenda_setter).

% Are designated as failing, fragile, or low-capacity by the evaluation authorities. Their sovereignty is treated as conditional or degraded: they face intervention, occupation, international administration, or externally imposed governance reforms without consent. Exit from the low-capacity classification requires adopting institutions and policies specified by the evaluators, which often conflict with local legitimacy structures. They experience the constraint as paternalistic oversight that extracts decision-making authority while framing their resistance as proof of incapacity.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, low_capacity_states, payer,
    moderate, generational, identity_locked, national).

% Exercise de facto control over territory but are denied recognition as sovereign equals because they fail capacity tests or are designated as insurgencies, warlord regimes, or transitional authorities. Graded sovereignty allows recognized states to intervene against them without triggering non-intervention norms. They cannot access multilateral forums, sign treaties, or claim territorial protection, because the capacity framework treats them as symptoms of state failure rather than competing authority structures.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, disputed_governance_entities, payer,
    moderate, biographical, trapped, regional).

% Are invoked as the justification for intervention: graded sovereignty doctrine frames intervention as remedial protection for populations whose own states lack capacity to govern effectively. In some cases, external intervention does deliver security or services local institutions cannot provide. In other cases, intervention imposes governance models misaligned with local needs, fragments existing social order, or empowers external actors over indigenous political processes. They bear the consequences of being governed by capacity metrics set elsewhere but have no voice in setting those metrics or in deciding when intervention is warranted.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, populations_in_low_capacity_states, beneficiary,
    powerless, biographical, trapped, national).
narrative_ontology:stakeholder_secondary_role(westphalia_sovereignty__graded_sovereignty, populations_in_low_capacity_states, payer).

% Gain operational mandates to stabilize or administer low-capacity states within their regions. Graded sovereignty provides legitimacy for peacekeeping, transitional administration, and regional intervention frameworks. They benefit from expanded authority but are constrained by dependency on funding and approval from global-capacity states and institutions.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, regional_security_organizations, beneficiary,
    institutional, generational, constrained, regional).

% Analyze whether graded sovereignty represents a descriptive recognition of state system reality or a constructed hierarchy that legitimates extractive intervention. They document how capacity metrics correlate with prior colonial relationships, how intervention thresholds shift with geopolitical interests, and how the framework marginalizes non-Western governance models. Some argue graded sovereignty is inevitable given empirical capacity variation; others argue it is a false summit naturalizing hegemonic power.
narrative_ontology:constraint_stakeholder(westphalia_sovereignty__graded_sovereignty, legal_scholars_of_intervention, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Provides a calibrated framework for international responses to governance breakdown: instead of treating all territorial boundaries as equally inviolable or all crises as equally warranting intervention, graded sovereignty scales intervention legitimacy to the severity of state incapacity, coordinating collective action where unilateral aggression would otherwise be indistinguishable from remedial protection.
% TRANSFER_FUNCTION: Transfers decision-making authority, territorial control, and normative standing from states designated as low-capacity to external evaluators, intervening states, and international institutions who administer remedial governance and set conditions for restored sovereignty.
% ABSENT_VOICES: Non-recognized governance entities, indigenous political systems not legible to Western state-capacity metrics, and populations in low-capacity states who are governed by externally imposed standards but excluded from setting those standards. They would argue capacity metrics encode specific cultural and institutional biases and that intervention often serves intervener interests under humanitarian cover.
% DISAPPEARANCE_RATIONALE: If graded sovereignty disappeared and all states were treated as categorically sovereign regardless of capacity, intervention in failed states would lack normative cover, humanitarian crises would meet with paralysis or unilateral aggression unbound by capacity criteria, and international institutions premised on remedial administration would lose their mandates. The state system would reorganize around either absolute non-intervention or alternative intervention criteria not tied to capacity scoring.
% FOUNDING_PROBLEM: Mid-20th-century decolonization created dozens of new states with widely varying institutional capacity; the absolute sovereignty norm inherited from Westphalia provided no framework for distinguishing remedial intervention in humanitarian crises from neo-colonial aggression, and complete non-intervention allowed mass atrocities to proceed unchecked.
% FOUNDING_PROBLEM_CORROBORATION: Intervention-capable states and international institutions attest the problem is live and cite ongoing state failures and humanitarian crises as evidence. Legal scholars from post-colonial states and critical international law traditions attest the founding problem has morphed: the original coordination challenge has been solved by creating a tiered system, but the system now operates as extractive hierarchy where capacity deficits justify permanent external oversight and intervention thresholds shift with geopolitical convenience rather than humanitarian need.
narrative_ontology:disappearance_verdict(westphalia_sovereignty__graded_sovereignty, world_rearranges).
narrative_ontology:founding_problem_status(westphalia_sovereignty__graded_sovereignty, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(westphalia_sovereignty__graded_sovereignty, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(westphalia_sovereignty__graded_sovereignty, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(westphalia_sovereignty__graded_sovereignty_tests).

test(extraction_signature) :-
    domain_priors:base_extractiveness(westphalia_sovereignty__graded_sovereignty, E),
    E >= 0.46. % Ensures high-extraction Snare/Tangled territory.

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, ExtMetricName, E),
    domain_priors:suppression_score(westphalia_sovereignty__graded_sovereignty, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(westphalia_sovereignty__graded_sovereignty),
    narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(westphalia_sovereignty__graded_sovereignty, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(westphalia_sovereignty__graded_sovereignty_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is substantial (0.68 at interval end) because the constraint transfers decision-making authority and territorial control from states it designates as low-capacity to external evaluators and interveners, not as a temporary remedy but as a structural feature of a tiered state system. The transfer is masked by framing capacity as objective and scalar sovereignty as descriptive recognition of variation. Suppression is high (0.71) because low-capacity states cannot exit their classification without adopting institutions specified by evaluators, and disputed entities are trapped outside the recognition system entirely. Theater rises over the interval (0.22 → 0.42) as capacity indices proliferate and intervention doctrine becomes more elaborate while intervention decisions increasingly track strategic interests rather than capacity scores. Accessibility collapse is low-moderate (0.34) because genuine alternatives to graded sovereignty exist and have historical precedent (absolute non-intervention, conditional responsibility), and the framework faces sustained resistance from states and scholars who read it as constructed hierarchy. Resistance is high (0.73) because states designated as low-capacity resist externally imposed governance, non-Western governance models resist being measured by capacity indices designed around Western institutional forms, and critical scholars resist the naturalization of hierarchy.
 *
 * PERSPECTIVAL GAP:
 *   From the evaluation authorities' and intervention-capable states' seats, graded sovereignty is descriptive realism recognizing that not all states have equal capacity and that intervention legitimacy should track that variation. From low-capacity states' and critical scholars' seats, the same structure operates as a naturalized hierarchy where capacity deficits justify extractive intervention and where the metrics encode institutional biases that perpetuate dependency. The engine computes this divergence from the structural data.
 *
 * DIRECTIONALITY LOGIC:
 *   Capacity-evaluation authorities and intervention-capable states are structural beneficiaries: they set the metrics, control the thresholds, and preserve categorical sovereignty for themselves while interventions elsewhere gain legitimacy. Development institutions benefit through expanded mandates. Low-capacity states and disputed entities are targets: they lose authority and face imposed governance. Populations in those states are dual-positioned: genuinely benefited when intervention provides security but harmed when it imposes misaligned governance or serves intervener interests. The engine should compute beneficiary seats as low d (low/negative effective extraction) and target seats as high d (high effective extraction modulated by identity-lock).
 *
 * MANDATROPHY ANALYSIS:
 *   The constraint's mandate is to coordinate international responses to state failure and prevent both paralysis in humanitarian crises and unchecked aggression. The metrics show that function is partly real (genuine coordination benefit for populations facing breakdown) but layered with extraction (authority transfer that exceeds coordination need, capacity measurement that tracks geopolitical alignment more than governance effectiveness, intervention thresholds that shift with strategic convenience). Rising theater ratio indicates the measurement and doctrine apparatus increasingly performs legitimation rather than tracking objective capacity. The founding problem (distinguishing remedial intervention from aggression post-decolonization) is contested: intervention-capable states attest it is live; post-colonial scholars attest it has been solved by constructing a tiered system that now operates as its own extraction mechanism.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    naturalism_vs_construction,
    'Is graded sovereignty a descriptive recognition of empirical capacity variation in the state system, or is it a constructed hierarchy that naturalizes power asymmetries and legitimates extractive intervention?',
    'Longitudinal analysis of intervention decisions and capacity scores: if intervention thresholds track humanitarian need and capacity metrics independently of geopolitical interests, the framework is more descriptive; if intervention decisions systematically correlate with strategic interests and capacity scores shift to rationalize predetermined interventions, the framework is constructed legitimation.',
    'If descriptive, the constraint is closer to genuine coordination with natural baselines (mountain with real coordination function). If constructed, it is extractive hierarchy masked by technical measurement (tangled rope or snare, with capacity evaluation as the suppression mechanism).',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(naturalism_vs_construction, conceptual, 'Whether scalar sovereignty describes world or constructs hierarchy.').

omega_variable(
    capacity_metric_bias,
    'Do the capacity indices measure objective governance effectiveness, or do they encode institutional biases that privilege Western state forms and penalize alternative governance models?',
    'Comparative analysis of capacity scores against non-Western institutional performance on population welfare outcomes; evaluation of whether traditional governance systems, religious authority structures, or clan-based coordination are systematically scored as incapacity despite effective local legitimacy.',
    'If metrics are biased, low-capacity designation becomes a mechanism for extracting authority from non-Western polities and imposing institutional models that serve external interests. The suppression component is higher than the scalar suggests because exit from low-capacity requires abandoning indigenous governance rather than merely improving effectiveness.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(capacity_metric_bias, empirical, 'Whether capacity measurement is technically objective or culturally biased.').

omega_variable(
    intervention_threshold_stability,
    'Are the capacity thresholds triggering intervention stable and applied uniformly, or do they shift with the geopolitical interests of intervention-capable states?',
    'Historical analysis of intervention decisions: do states with similar capacity scores receive similar interventions, or do interventions cluster in resource-rich regions, strategic locations, or states resisting alignment with major powers while higher-capacity failures in aligned states face no intervention?',
    'If thresholds shift, graded sovereignty operates as flexible cover for strategic intervention rather than as principled coordination. The theater ratio is higher than the measurement suggests because capacity doctrine performs post-hoc rationalization.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(intervention_threshold_stability, empirical, 'Whether intervention thresholds are principled or strategic.').

omega_variable(
    remedial_vs_extractive_intervention,
    'When intervention occurs under graded sovereignty, does it primarily deliver remedial governance and capacity-building that restores sovereignty, or does it primarily extract resources, install compliant regimes, and perpetuate external control?',
    'Outcome analysis of interventions: track post-intervention sovereignty restoration rates, economic control transfer, political alignment shifts, and indigenous governance displacement. If most interventions restore capacity and exit, the framework is remedial; if most interventions establish prolonged external administration or extract concessions, the framework is extractive.',
    'If interventions are remedial, graded sovereignty functions as intended coordination. If extractive, the capacity deficit becomes the entry point for rent extraction and the framework is a snare with humanitarian cover.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(remedial_vs_extractive_intervention, empirical, 'Whether intervention under graded sovereignty is remedial or extractive.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(westphalia_sovereignty__graded_sovereignty, 0, 35).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(west_tr_t0, westphalia_sovereignty__graded_sovereignty, theater_ratio, 0, 0.22).
narrative_ontology:measurement_basis(west_tr_t0, observed).
narrative_ontology:measurement(west_tr_t7, westphalia_sovereignty__graded_sovereignty, theater_ratio, 7, 0.26).
narrative_ontology:measurement_basis(west_tr_t7, observed).
narrative_ontology:measurement(west_tr_t14, westphalia_sovereignty__graded_sovereignty, theater_ratio, 14, 0.31).
narrative_ontology:measurement_basis(west_tr_t14, observed).
narrative_ontology:measurement(west_tr_t21, westphalia_sovereignty__graded_sovereignty, theater_ratio, 21, 0.36).
narrative_ontology:measurement_basis(west_tr_t21, observed).
narrative_ontology:measurement(west_tr_t28, westphalia_sovereignty__graded_sovereignty, theater_ratio, 28, 0.4).
narrative_ontology:measurement_basis(west_tr_t28, observed).
narrative_ontology:measurement(west_tr_t35, westphalia_sovereignty__graded_sovereignty, theater_ratio, 35, 0.42).
narrative_ontology:measurement_basis(west_tr_t35, observed).

% Extraction over time
narrative_ontology:measurement(west_be_t0, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 0, 0.48).
narrative_ontology:measurement_basis(west_be_t0, observed).
narrative_ontology:measurement(west_be_t7, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 7, 0.54).
narrative_ontology:measurement_basis(west_be_t7, observed).
narrative_ontology:measurement(west_be_t14, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 14, 0.59).
narrative_ontology:measurement_basis(west_be_t14, observed).
narrative_ontology:measurement(west_be_t21, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 21, 0.64).
narrative_ontology:measurement_basis(west_be_t21, observed).
narrative_ontology:measurement(west_be_t28, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 28, 0.67).
narrative_ontology:measurement_basis(west_be_t28, observed).
narrative_ontology:measurement(west_be_t35, westphalia_sovereignty__graded_sovereignty, base_extractiveness, 35, 0.68).
narrative_ontology:measurement_basis(west_be_t35, observed).

% Suppression requirement over time
narrative_ontology:measurement(west_su_t0, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 0, 0.52).
narrative_ontology:measurement_basis(west_su_t0, observed).
narrative_ontology:measurement(west_su_t7, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 7, 0.58).
narrative_ontology:measurement_basis(west_su_t7, observed).
narrative_ontology:measurement(west_su_t14, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 14, 0.63).
narrative_ontology:measurement_basis(west_su_t14, observed).
narrative_ontology:measurement(west_su_t21, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 21, 0.67).
narrative_ontology:measurement_basis(west_su_t21, observed).
narrative_ontology:measurement(west_su_t28, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 28, 0.7).
narrative_ontology:measurement_basis(west_su_t28, observed).
narrative_ontology:measurement(west_su_t35, westphalia_sovereignty__graded_sovereignty, suppression_requirement, 35, 0.71).
narrative_ontology:measurement_basis(west_su_t35, observed).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(westphalia_sovereignty__graded_sovereignty, enforcement_mechanism).
narrative_ontology:affects_constraint(westphalia_sovereignty__graded_sovereignty, westphalia_sovereignty__absolute_non_intervention).
narrative_ontology:affects_constraint(westphalia_sovereignty__graded_sovereignty, westphalia_sovereignty__conditional_responsibility).
narrative_ontology:affects_constraint(westphalia_sovereignty__graded_sovereignty, humanitarian_intervention_doctrine).
narrative_ontology:affects_constraint(westphalia_sovereignty__graded_sovereignty, responsibility_to_protect).
narrative_ontology:affects_constraint(westphalia_sovereignty__graded_sovereignty, state_building_conditionality).

% DUAL FORMULATION NOTE:
% This constraint is one reading of the westphalia_sovereignty kernel family. The family decomposes the natural-language concept 'sovereignty' into three structurally distinct constraints with different beneficiary structures and intervention thresholds. Graded_sovereignty differs from absolute_non_intervention in treating sovereignty as scalar rather than categorical, enabling calibrated intervention; it differs from conditional_responsibility in making capacity deficits rather than atrocity the intervention trigger, which expands the intervention-legitimate domain and shifts authority to capacity evaluators rather than atrocity documentation bodies.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
