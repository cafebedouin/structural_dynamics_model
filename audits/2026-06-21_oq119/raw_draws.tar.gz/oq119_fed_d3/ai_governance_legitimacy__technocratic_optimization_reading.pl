% ============================================================================
% CONSTRAINT STORY: ai_governance_legitimacy__technocratic_optimization_reading
% ============================================================================
% Version: 1.0 (Deferential Realism Core + Directionality + Boltzmann + Network)
% Logic: 6.0 (Indexed Tuple P,T,E,S + Sigmoid f(d) + Coupling + Purity + Network)
% Generated: 2026-06-12
% Status: [ACTIVE]
% ============================================================================

:- module(constraint_ai_governance_legitimacy__technocratic_optimization_reading, []).

:- use_module(constraint_indexing).
:- use_module(domain_priors).
:- use_module(narrative_ontology).

% --- Constraint Identity Rule (DP-001: ε-Invariance) ---
% Each constraint story must have a single, stable base extractiveness (ε).
% If changing the observable used to evaluate this constraint would change ε,
% you are looking at two distinct constraints. Write separate .pl files for
% each, link them with affects_constraint/2, and document the relationship
% in both files' narrative context sections.
%
% The context tuple is CLOSED at arity 4: (P, T, E, S).
% Do not add measurement_basis, beneficiary/victim, or any other arguments.
% Linter Rule 23 enforces context/4.
%
% See: epsilon_invariance_principle.md

% --- Namespace Hooks (Required for loading) ---
:- multifile
    domain_priors:base_extractiveness/2,
    domain_priors:suppression_score/2,
    domain_priors:theater_ratio/2,
    domain_priors:requires_active_enforcement/1,
    narrative_ontology:has_sunset_clause/1,
    narrative_ontology:interval/3,
    narrative_ontology:measurement/5,
    narrative_ontology:constraint_metric/3,
    narrative_ontology:constraint_beneficiary/2,
    narrative_ontology:constraint_victim/2,
    narrative_ontology:constraint_claim/2,
    narrative_ontology:constraint_vindicates/2,
    narrative_ontology:affects_constraint/2,
    narrative_ontology:coordination_type/2,
    narrative_ontology:boltzmann_floor_override/2,
    constraint_indexing:constraint_classification/3,
    narrative_ontology:constraint_stakeholder/7,
    narrative_ontology:disappearance_verdict/2,
    narrative_ontology:founding_problem_status/2,
    domain_priors:emerges_naturally/1,
    narrative_ontology:omega_variable/3,
    narrative_ontology:cs_story_uid/2,
    narrative_ontology:cs_kernel_codification/2,
    narrative_ontology:cs_authority_grounding/2,
    narrative_ontology:cs_interpretation_layer_present/1,
    narrative_ontology:cs_kernel_id/2,
    narrative_ontology:cs_reading_relation/3,
    narrative_ontology:cs_axiom/3,
    narrative_ontology:cs_axiom_status/2,
    narrative_ontology:cs_axiom_grounding/3,
    narrative_ontology:cs_reference_frame/2,
    narrative_ontology:cs_drift_state/3,
    narrative_ontology:cs_created_at/2,
    narrative_ontology:human_readable/2,
    narrative_ontology:topic_domain/2.

/* ==========================================================================
   1. NARRATIVE CONTEXT
   ========================================================================== */

/**
 * CONSTRAINT IDENTIFICATION
 *   constraint_id: ai_governance_legitimacy__technocratic_optimization_reading
 *   human_readable: Technocratic Optimization Reading of AI Governance Legitimacy
 *   domain: theological_ethics/technology_governance/political_theology
 *
 * SUMMARY:
 *   This constraint instantiates one reading of the contested kernel
 *   'ai_governance_legitimacy': the technocratic optimization reading. Under
 *   this framework, AI governance derives its legitimacy from maximizing
 *   aggregate welfare, efficiency, and innovation through technical
 *   expertise. Ethical principles from religious traditions (Catholic Social
 *   Doctrine) or democratic theory appear as secondary constraints on
 *   optimization rather than primary objectives. Authority rests with those
 *   who demonstrate technical competence and deliver measurable performance
 *   gains. The constraint is CLAIMED as mountain (presented as
 *   natural/inevitable outcome of technical complexity and economic
 *   rationality) while the authored metrics describe moderate extraction,
 *   active enforcement, and identifiable victims—the engine measures that
 *   divergence. The siblings are magisterial_subsidiarity_reading (legitimacy
 *   from Catholic Social Doctrine), democratic_pluralist_reading (legitimacy
 *   from deliberation and consent), and market_libertarian_reading
 *   (legitimacy from voluntary exchange).
 *
 * KEY AGENTS:
 *   - technology_firms: Institutional agenda-setters (institutional/arbitrage) — set optimization metrics, control infrastructure
 *   - institutional_investors: Powerful beneficiaries (powerful/mobile) — capture returns from efficiency gains
 *   - high_skill_technical_workers: Powerful beneficiaries (powerful/mobile) — premium compensation for scarce expertise
 *   - early_adopters: Moderate beneficiaries (moderate/mobile) — productivity gains from early access
 *   - displaced_manufacturing_workers: Powerless payers (powerless/trapped) — lose employment to automation without support
 *   - digital_infrastructure_poor_communities: Powerless payers (powerless/trapped) — excluded from participation by infrastructure gaps
 *   - algorithmic_profiling_targets: Powerless payers (powerless/identity_locked) — sorted into higher-risk categories by opaque systems
 *   - magisterial_authority: Institutional excluded (institutional/analytical) — would elevate dignity from constraint to objective
 *   - democratic_publics: Organized excluded (organized/constrained) — lack effective governance mechanisms despite being affected
 *   - technology_governance_researchers: Analytical observers (analytical/analytical) — document power distributions and legitimacy contests
 */

/* ==========================================================================
   2. BASE PROPERTIES (DOMAIN PRIORS)
   ========================================================================== */

% --- Numerical metrics ---
domain_priors:base_extractiveness(ai_governance_legitimacy__technocratic_optimization_reading, 0.36).
domain_priors:suppression_score(ai_governance_legitimacy__technocratic_optimization_reading, 0.48).
domain_priors:theater_ratio(ai_governance_legitimacy__technocratic_optimization_reading, 0.22).

% --- Constraint metric facts (engine primary keys, must mirror domain_priors) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, extractiveness, 0.36).
narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 0.48).
narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 0.22).

% --- NL Profile Metrics (required for mountain constraints) ---
narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, accessibility_collapse, 0.42).
narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, resistance, 0.58).

% --- Constraint claim ---
narrative_ontology:constraint_claim(ai_governance_legitimacy__technocratic_optimization_reading, mountain).
narrative_ontology:human_readable(ai_governance_legitimacy__technocratic_optimization_reading, "Technocratic Optimization Reading of AI Governance Legitimacy").
narrative_ontology:topic_domain(ai_governance_legitimacy__technocratic_optimization_reading, "theological_ethics/technology_governance/political_theology").

domain_priors:requires_active_enforcement(ai_governance_legitimacy__technocratic_optimization_reading).
domain_priors:emerges_naturally(ai_governance_legitimacy__technocratic_optimization_reading).

% --- Commitment system structure ---
narrative_ontology:cs_story_uid(ai_governance_legitimacy__technocratic_optimization_reading, '1f5a3a58-342c-4dcd-ba63-50297e004ca8').
narrative_ontology:cs_kernel_codification('1f5a3a58-342c-4dcd-ba63-50297e004ca8', distributed).
narrative_ontology:cs_authority_grounding('1f5a3a58-342c-4dcd-ba63-50297e004ca8', expertise).
narrative_ontology:cs_interpretation_layer_present('1f5a3a58-342c-4dcd-ba63-50297e004ca8').
narrative_ontology:cs_reading_relation('1f5a3a58-342c-4dcd-ba63-50297e004ca8', ai_governance_legitimacy__magisterial_subsidiarity_reading, coexists_with).
narrative_ontology:cs_reading_relation('1f5a3a58-342c-4dcd-ba63-50297e004ca8', ai_governance_legitimacy__democratic_pluralist_reading, coexists_with).
narrative_ontology:cs_reading_relation('1f5a3a58-342c-4dcd-ba63-50297e004ca8', ai_governance_legitimacy__market_libertarian_reading, influences).
narrative_ontology:cs_axiom('1f5a3a58-342c-4dcd-ba63-50297e004ca8', foundational, aggregate_welfare_optimization_primacy).
narrative_ontology:cs_axiom_status(aggregate_welfare_optimization_primacy, holdable).
narrative_ontology:cs_axiom_grounding('1f5a3a58-342c-4dcd-ba63-50297e004ca8', aggregate_welfare_optimization_primacy, instrumental).
narrative_ontology:cs_axiom('1f5a3a58-342c-4dcd-ba63-50297e004ca8', foundational, technical_expertise_governance_authority).
narrative_ontology:cs_axiom_status(technical_expertise_governance_authority, holdable).
narrative_ontology:cs_axiom_grounding('1f5a3a58-342c-4dcd-ba63-50297e004ca8', technical_expertise_governance_authority, empirically_contingent).
narrative_ontology:cs_axiom('1f5a3a58-342c-4dcd-ba63-50297e004ca8', secondary, ethical_constraints_as_parameters).
narrative_ontology:cs_axiom_status(ethical_constraints_as_parameters, holdable).
narrative_ontology:cs_axiom_grounding('1f5a3a58-342c-4dcd-ba63-50297e004ca8', ethical_constraints_as_parameters, instrumental).
narrative_ontology:cs_reference_frame('1f5a3a58-342c-4dcd-ba63-50297e004ca8', technical_meritocratic_efficiency_primacy).
narrative_ontology:cs_drift_state('1f5a3a58-342c-4dcd-ba63-50297e004ca8', post_encyclical_ai_governance_contestation, gap(authority_erosion, substantial, false)).
narrative_ontology:cs_created_at('1f5a3a58-342c-4dcd-ba63-50297e004ca8', '').
narrative_ontology:cs_kernel_id(ai_governance_legitimacy__technocratic_optimization_reading, ai_governance_legitimacy).

% --- Structural relationships ---
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__technocratic_optimization_reading, technology_firms).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__technocratic_optimization_reading, institutional_investors).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__technocratic_optimization_reading, high_skill_technical_workers).
narrative_ontology:constraint_beneficiary(ai_governance_legitimacy__technocratic_optimization_reading, early_adopters).
narrative_ontology:constraint_victim(ai_governance_legitimacy__technocratic_optimization_reading, displaced_manufacturing_workers).
narrative_ontology:constraint_victim(ai_governance_legitimacy__technocratic_optimization_reading, digital_infrastructure_poor_communities).
narrative_ontology:constraint_victim(ai_governance_legitimacy__technocratic_optimization_reading, algorithmic_profiling_targets).
narrative_ontology:constraint_vindicates(ai_governance_legitimacy__technocratic_optimization_reading, utilitarian_aggregate_welfare_maximization).
narrative_ontology:constraint_vindicates(ai_governance_legitimacy__technocratic_optimization_reading, technocratic_expertise_authority).
narrative_ontology:constraint_vindicates(ai_governance_legitimacy__technocratic_optimization_reading, innovation_imperative_primacy).

/* ==========================================================================
   2b. STAKEHOLDER LAYER (OQ-83; roles from the DECLARED dial-set —
   see schemas/constraint_story_schema.json $defs/StakeholderRole and the
   attached residue ledger. Names are per-story and domain-specific; never
   standardized across readings (OQ-84).
   ========================================================================== */

% Design, deploy, and govern AI systems according to efficiency metrics, competitive advantage, and shareholder value. Frame governance debates in terms of innovation velocity and technical feasibility. Control the infrastructure and data that alternative governance models would depend on. Ethical principles appear as constraints on optimization functions, not as primary objectives.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, technology_firms, agenda_setter,
    institutional, generational, arbitrage, global).

% Capture returns from AI-driven productivity gains and market concentration. Evaluate governance proposals through portfolio risk and growth projections. Support regulatory frameworks that stabilize investment conditions without limiting upside. Exit to other asset classes if governance constraints threaten returns.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, institutional_investors, beneficiary,
    powerful, biographical, mobile, global).

% Command premium compensation for designing and maintaining AI systems. Possess scarce expertise that makes them structural winners in the optimization economy. Can move between firms and jurisdictions. Experience minimal displacement risk and substantial wealth accumulation from equity compensation tied to efficiency gains.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, high_skill_technical_workers, beneficiary,
    powerful, biographical, mobile, global).

% Access productivity tools, personalized services, and innovation benefits ahead of broader diffusion. Possess resources and literacy to navigate AI systems effectively. Gain competitive advantages in labor markets and consumption through early access. Bear minimal costs of algorithmic errors due to higher baseline resources.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, early_adopters, beneficiary,
    moderate, biographical, mobile, regional).

% Lose employment to automation without equivalent retraining pathways or social support. Concentrated in regions where AI-driven efficiency gains eliminate labor demand faster than new opportunities emerge. Lack mobility to follow employment shifts. Bear the welfare losses that optimization metrics aggregate away as transition costs.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, displaced_manufacturing_workers, payer,
    powerless, biographical, trapped, regional).

% Excluded from participation in AI-mediated services and opportunities due to infrastructure gaps. Experience governance decisions made without their input by distant technical elites. Cannot exit to better-served jurisdictions. Carry opportunity costs of underinvestment while being subject to algorithmic systems designed for wealthier populations.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, digital_infrastructure_poor_communities, payer,
    powerless, generational, trapped, regional).

% Sorted by opaque algorithms into higher-risk categories for credit, employment, insurance, and law enforcement based on demographic proxies. Cannot escape the profiling because identity markers travel with them. Lack resources to contest classifications or access alternative systems. Bear the costs of false positives and discriminatory correlations optimized for aggregate accuracy.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, algorithmic_profiling_targets, payer,
    powerless, biographical, identity_locked, national).

% Articulates human dignity and common good principles through social encyclicals and doctrine. Under this reading, functions as aspirational input to optimization constraints rather than authoritative governance framework. Excluded from technical decision-making venues where efficiency metrics are set. Would elevate dignity from constraint to objective if governance authority were restructured.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, magisterial_authority, excluded,
    institutional, civilizational, analytical, global).

% Lack effective mechanisms to shape AI governance despite being subject to its effects. Technical complexity and regulatory capture route governance decisions to expert venues where optimization metrics dominate. Electoral accountability attenuated by information asymmetries. Would contest technocratic authority through political processes if institutional channels were accessible.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, democratic_publics, excluded,
    organized, generational, constrained, national).

% Study the political economy of AI governance, map power distributions, and analyze legitimacy claims across frameworks. Document whose values are embedded in optimization metrics and who bears transition costs. Provide empirical evidence on distributional effects that challenge aggregate welfare claims. Operate across institutional contexts without stake in any reading's dominance.
narrative_ontology:constraint_stakeholder(ai_governance_legitimacy__technocratic_optimization_reading, technology_governance_researchers, observer,
    analytical, generational, analytical, global).

% --- Six-questions battery (story-level; texts kept as comments — the
% engine consumes only the two atoms below; the founding-problem narrative
% is NEVER consumed as a claim, mismatch-consumer only, OQ-83 R5) ---
% COORDINATION_FUNCTION: Establishes shared efficiency and innovation metrics as governance criteria, reducing transaction costs in evaluating AI system performance and allocating investment. Coordinates expectations around technical expertise as authoritative for governance decisions.
% TRANSFER_FUNCTION: Moves productivity gains and wealth accumulation from labor to capital and high-skill technical workers. Transfers governance authority from democratic institutions to technical elites and corporate actors. Externalizes transition costs and algorithmic harms to displaced workers, infrastructure-poor communities, and profiling targets.
% ABSENT_VOICES: Magisterial authority articulating human dignity principles, democratic publics seeking participatory governance, displaced workers bearing transition costs, communities excluded by infrastructure gaps. They are absent from the technical venues and corporate boardrooms where optimization metrics are set and encoded into systems.
% DISAPPEARANCE_RATIONALE: If this legitimacy framework vanished, AI governance would require democratic deliberation or alternative ethical foundations. Technology firms would face different accountability structures. Investment patterns would shift away from pure optimization toward distributional considerations. The displaced and excluded would gain standing in governance venues currently dominated by efficiency metrics. Power would redistribute from technical elites to broader stakeholder coalitions.
% FOUNDING_PROBLEM: Early AI development faced fragmented governance with no clear authority structure. Multiple ethical frameworks competed without resolution mechanism. Investment required predictable regulatory environment. Technical complexity made democratic oversight appear infeasible.
% FOUNDING_PROBLEM_CORROBORATION: Technology firms and their affiliated think tanks attest the problem remains live, citing rapid innovation pace and need for technical agility. Democratic theorists, labor advocates, and religious ethicists from outside the beneficiary set attest the founding problem was never the real problem—the arrangement solved investor uncertainty and elite authority, not governance legitimacy. Legislative hearings and academic governance research document the contested status.
narrative_ontology:disappearance_verdict(ai_governance_legitimacy__technocratic_optimization_reading, world_rearranges).
narrative_ontology:founding_problem_status(ai_governance_legitimacy__technocratic_optimization_reading, contested).

/* ==========================================================================
   3. PROVENANCE (cohort metadata — schema-required since Phase C)
   ========================================================================== */

narrative_ontology:story_provenance(ai_governance_legitimacy__technocratic_optimization_reading, '8080348c4e16a265fafc924dcde83360dfd170fc',
    'becd0f87568a1ec0be97d1229ae702098dbd6568', '2026-06-21',
    'no_scope_rebuild', 'agent/example_platform_commission.json',
    'claude-sonnet-4-5-20250929', 'max_tokens=16384,temperature=api_default').
narrative_ontology:story_seed(ai_governance_legitimacy__technocratic_optimization_reading, 'none', 1).

/* ==========================================================================
   4. VALIDATION TESTS
   ========================================================================== */

:- begin_tests(ai_governance_legitimacy__technocratic_optimization_reading_tests).

test(mountain_threshold_validation) :-
    config:param(extractiveness_metric_name, ExtMetricName),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, ExtMetricName, E),
    domain_priors:suppression_score(ai_governance_legitimacy__technocratic_optimization_reading, S),
    E =< 0.25,
    S =< 0.05.

test(nl_profile_validation) :-
    domain_priors:emerges_naturally(ai_governance_legitimacy__technocratic_optimization_reading),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, accessibility_collapse, AC),
    narrative_ontology:constraint_metric(ai_governance_legitimacy__technocratic_optimization_reading, resistance, R),
    AC >= 0.85,
    R =< 0.15.

:- end_tests(ai_governance_legitimacy__technocratic_optimization_reading_tests).

/* ==========================================================================
   5. GENERATIVE COMMENTARY
   ========================================================================== */

/**
 * LOGIC RATIONALE:
 *   Extraction is moderate (0.36) because the framework channels productivity gains to capital and high-skill labor while externalizing transition costs to displaced workers and infrastructure-poor communities. It is not higher because genuine coordination around efficiency metrics exists and some welfare gains are real. Suppression (0.48) reflects the active exclusion of alternative governance frameworks from decision-making venues—democratic deliberation and magisterial principles must be kept secondary for optimization metrics to dominate. Theater ratio (0.22) captures growing ethics-washing: corporate AI ethics boards and principles documents that perform concern while preserving optimization primacy. Accessibility collapse (0.42) is moderate because alternative frameworks (democratic, religious) remain intellectually available but structurally marginalized. Resistance (0.58) is substantial—labor movements, religious communities, and democratic theorists actively contest technocratic authority. The measurement series shows gradual extraction accumulation as optimization metrics entrench and alternatives are progressively excluded from governance venues.
 *
 * PERSPECTIVAL GAP:
 *   From the technology firm seat, this framework is natural coordination around technical reality—optimization metrics are objective, expertise is authoritative, and governance should follow performance. From the displaced worker or profiling target seat, the same structure operates as extractive: gains accrue to elites while costs are externalized to those without voice or exit. From the magisterial seat, the framework subordinates human dignity to efficiency in a way that violates civilizational ethical commitments. The engine computes these divergent type classifications from the structural data; the authored mountain claim reflects the beneficiary seat's naturalization of its own position.
 *
 * DIRECTIONALITY LOGIC:
 *   Technology firms operate as both beneficiaries and agenda-setters—a dual position where they extract value AND control the rules. This pushes their effective d lower than a pure beneficiary (they capture optimization gains) but the agenda-setting role gives them arbitrage-grade exit (they can relocate or restructure if challenged). High-skill workers and investors are pure beneficiaries with mobile exit. Displaced workers are trapped targets bearing concentrated transition costs. Profiling targets are identity-locked—the demographic markers that trigger algorithmic sorting travel with them. Infrastructure-poor communities are trapped by geography. Magisterial and democratic seats are excluded from the optimization venue but could restructure governance if their frameworks gained authority—they sit at constrained/analytical rather than trapped because institutional position gives them latent power. The directionality computation should reflect that exclusion from current governance differs from being a target of extraction.
 *
 * MANDATROPHY ANALYSIS:
 *   This constraint presents a mandatrophy risk: it was built to solve governance uncertainty during rapid AI development (founding problem) but now functions to concentrate authority and externalize costs. The founding_problem_status is contested—beneficiaries claim ongoing need for technical agility while victims and excluded voices attest the arrangement solves investor authority, not legitimate governance. The disappearance verdict (world_rearranges) confirms dependencies exist. If extraction continues accumulating while theater ratio rises, the lifecycle trajectory points toward captured governance maintaining optimization primacy after its coordination function has been served.
 */

/* ==========================================================================
   6. OMEGA VARIABLES (Ω) - IRREDUCIBLE UNCERTAINTIES
   ========================================================================== */

omega_variable(
    kernel_reading_ambiguity,
    'Is technocratic optimization the natural governance framework for complex technical systems, or is it one reading among legitimate alternatives that concentrates authority with technical elites?',
    'Empirical comparison of governance outcomes across jurisdictions adopting different frameworks. Historical analysis of how technical complexity was used to justify exclusion of democratic and religious input. Examination of whether optimization metrics encode particular value commitments rather than neutral efficiency.',
    'If technocratic optimization is one contested reading rather than natural law, the constraint''s mountain claim is false and it should reclassify based on its extractive operation. The beneficiary/victim structure would be exposed as political rather than technical necessity.',
    confidence_without_resolution(high)
).

narrative_ontology:omega_variable(kernel_reading_ambiguity, conceptual, 'Whether this governance framework is natural law or constructed constraint that benefits identifiable elites.').

omega_variable(
    aggregate_welfare_vs_distribution,
    'Do aggregate welfare gains justify transition costs concentrated on powerless victims, or does legitimate governance require distributive justice alongside efficiency?',
    'Philosophical resolution of utilitarian vs. deontological ethics. Empirical measurement of whether welfare gains reach displaced populations or concentrate with beneficiaries. Democratic deliberation on acceptable trade-offs.',
    'If distribution matters for legitimacy, extraction measurement must weight victim costs differently than current aggregate metrics suggest. The coordination function would be real but insufficient for legitimate authority without addressing distributional harms.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(aggregate_welfare_vs_distribution, preference, 'Whether legitimacy requires distributive justice or only aggregate welfare maximization.').

omega_variable(
    technical_complexity_vs_democratic_capacity,
    'Is AI governance inherently too complex for democratic oversight, or does technical complexity serve as justification for elite authority?',
    'Comparative case studies of participatory technology governance. Research on effective democratic mechanisms for complex technical decisions. Analysis of how complexity claims function rhetorically to exclude non-expert input.',
    'If democratic capacity exists despite complexity, the exclusion of democratic publics and magisterial voices is a political choice rather than technical necessity. The suppression metric would represent illegitimate authority concentration rather than coordination requirements.',
    confidence_without_resolution(medium)
).

narrative_ontology:omega_variable(technical_complexity_vs_democratic_capacity, empirical, 'Whether technical complexity necessitates technocratic authority or enables its justification.').

omega_variable(
    ethics_as_constraint_vs_objective,
    'Is human dignity appropriately modeled as a constraint on optimization, or does treating it as secondary parameter rather than primary objective constitute a category error?',
    'Theological and philosophical analysis of dignity''s status. Examination of whether optimization frameworks can adequately capture non-fungible values. Historical assessment of when dignity-as-constraint led to atrocities versus dignity-as-objective prevented them.',
    'If dignity must be objective rather than constraint, the entire optimization framework is illegitimate regardless of efficiency gains. The magisterial reading would have authoritative priority over technocratic optimization.',
    confidence_without_resolution(low)
).

narrative_ontology:omega_variable(ethics_as_constraint_vs_objective, conceptual, 'Whether dignity can be subordinated to efficiency or must be the governance objective itself.').


/* ==========================================================================
   7. INTEGRATION HOOKS
   ========================================================================== */

narrative_ontology:interval(ai_governance_legitimacy__technocratic_optimization_reading, 0, 25).

/* ==========================================================================
   8. TEMPORAL MEASUREMENTS (LIFECYCLE DRIFT DATA)
   ========================================================================== */

% Theater ratio over time
narrative_ontology:measurement(ai_g_tr_t0, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 0, 0.12).
narrative_ontology:measurement(ai_g_tr_t5, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 5, 0.15).
narrative_ontology:measurement(ai_g_tr_t10, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 10, 0.18).
narrative_ontology:measurement(ai_g_tr_t15, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 15, 0.2).
narrative_ontology:measurement(ai_g_tr_t20, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 20, 0.21).
narrative_ontology:measurement(ai_g_tr_t25, ai_governance_legitimacy__technocratic_optimization_reading, theater_ratio, 25, 0.22).

% Extraction over time
narrative_ontology:measurement(ai_g_be_t0, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 0, 0.28).
narrative_ontology:measurement(ai_g_be_t5, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 5, 0.3).
narrative_ontology:measurement(ai_g_be_t10, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 10, 0.33).
narrative_ontology:measurement(ai_g_be_t15, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 15, 0.35).
narrative_ontology:measurement(ai_g_be_t20, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 20, 0.36).
narrative_ontology:measurement(ai_g_be_t25, ai_governance_legitimacy__technocratic_optimization_reading, base_extractiveness, 25, 0.36).

% Suppression requirement over time
narrative_ontology:measurement(ai_g_su_t0, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 0, 0.38).
narrative_ontology:measurement(ai_g_su_t5, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 5, 0.41).
narrative_ontology:measurement(ai_g_su_t10, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 10, 0.44).
narrative_ontology:measurement(ai_g_su_t15, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 15, 0.46).
narrative_ontology:measurement(ai_g_su_t20, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 20, 0.47).
narrative_ontology:measurement(ai_g_su_t25, ai_governance_legitimacy__technocratic_optimization_reading, suppression_requirement, 25, 0.48).


/* ==========================================================================
   9. BOLTZMANN & NETWORK DATA
   ========================================================================== */

narrative_ontology:coordination_type(ai_governance_legitimacy__technocratic_optimization_reading, enforcement_mechanism).
narrative_ontology:boltzmann_floor_override(ai_governance_legitimacy__technocratic_optimization_reading, 0.18).
narrative_ontology:affects_constraint(ai_governance_legitimacy__technocratic_optimization_reading, ai_governance_legitimacy__magisterial_subsidiarity_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__technocratic_optimization_reading, ai_governance_legitimacy__democratic_pluralist_reading).
narrative_ontology:affects_constraint(ai_governance_legitimacy__technocratic_optimization_reading, ai_governance_legitimacy__market_libertarian_reading).

% DUAL FORMULATION NOTE:
% This constraint is one of four readings of the ai_governance_legitimacy kernel. Each reading instantiates a different governance framework with distinct beneficiary/victim structures and legitimacy criteria. The technocratic_optimization reading treats efficiency as primary and subordinates other values; magisterial_subsidiarity elevates dignity to objective status; democratic_pluralist distributes authority through deliberation; market_libertarian rejects collective mandates. These are not the same constraint measured differently—they are structurally distinct arrangements with different ε values. Network edges indicate influence relationships: optimization metrics create downstream pressure on democratic and religious alternatives by controlling infrastructure and framing debates.

/* ==========================================================================
   10. DIRECTIONALITY OVERRIDES (v6.0, OPTIONAL)
   ========================================================================== */

/* ==========================================================================
   END OF CONSTRAINT STORY
   ========================================================================== */
